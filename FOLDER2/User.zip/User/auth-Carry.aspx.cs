﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using DataAccessLayer;
using System.IO;
using System.Drawing;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
using System.Web.Script.Serialization;
using iTextSharp.text.pdf.codec;
using System.Configuration;
using System.Data.SqlClient;

public partial class customer_auth_Carry : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                Paybetween();
                Payoutsummary();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    protected void Paybetween()
    {
        try
        {
            drppayoutlist.DataTextField = "PayoutBetween";
            drppayoutlist.DataValueField = "PayoutBetween";
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select DISTINCT PayoutBetween,max(Date) from MemberPayment group by PayoutBetween order by max(Date)");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                drppayoutlist.DataSource = dt;
                drppayoutlist.DataBind();
                drppayoutlist.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select Payout Date", "0"));
            }
            else
            {
                drppayoutlist.DataSource = null;
                drppayoutlist.DataBind();
                drppayoutlist.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select Payout Date", "0"));
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    protected void Payoutsummary()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            if (drppayoutlist.SelectedIndex == 0)
            {
                sb.AppendFormat("select Top 1 mp.UserID,mm.Name,mp.LeftCarry as [Left Carry],mp.RightCarry as [Right Carry],CONVERT(nvarchar,Date,105) as Date,mp.PayoutBetween from MemberPayment mp left join MLM_Registration mm on mm.UserID=mp.UserID where mp.UserID='{0}' and mp.Descriptions='Matching Income' order by mp.PaymentID desc", Session["UserID"].ToString());
            }
            else
            {
                sb.AppendFormat("select Top 1 mp.UserID,mm.Name,mp.LeftCarry as [Left Carry],mp.RightCarry as [Right Carry],CONVERT(nvarchar,Date,105) as Date,mp.PayoutBetween from MemberPayment mp left join MLM_Registration mm on mm.UserID=mp.UserID where mp.UserID='{0}' and mp.Descriptions='Matching Income' and mp.PayoutBetween='{1}' order by mp.PaymentID desc", Session["UserID"].ToString(), drppayoutlist.SelectedValue);
            }
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                btnexportexcel.Visible = true;
                btnpdf.Visible = true;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnexportexcel.Visible = false;
                btnpdf.Visible = false;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Payoutsummary();
    }
    protected void btnexportpdf_Click(object sender, EventArgs e)
    {
        try
        {
            //PdfPTable pdftable = new PdfPTable(GridView1.HeaderRow.Cells.Count);
            //foreach (GridViewRow item in GridView1.Rows)
            //{
            //    foreach (TableCell tablecell in item.Cells)
            //    {
            //        PdfPCell pdfcell = new PdfPCell(new Phrase(tablecell.Text));
            //        pdftable.AddCell(pdfcell);
            //    }
            //}
            //Document pdfdocument = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
            //PdfWriter.GetInstance(pdfdocument, Response.OutputStream);
            //pdfdocument.Open();
            //pdfdocument.Add(pdftable);
            //pdfdocument.Close();

            //Response.ContentType = "application/pdf";
            //Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.pdf");
            //Response.Write(pdfdocument);
            //Response.Flush();
            //Response.End();


            Response.ContentType = "application/pdf";

            Response.AddHeader("content-disposition", "attachment;filename=CarryForward.pdf");

            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            StringWriter sw = new StringWriter();

            HtmlTextWriter hw = new HtmlTextWriter(sw);

            GridView1.AllowPaging = false;
            this.Payoutsummary();
            //GridView1.DataBind();

            GridView1.RenderControl(hw);

            StringReader sr = new StringReader(sw.ToString());

            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 30f, 10f);

            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);

            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);

            pdfDoc.Open();

            htmlparser.Parse(sr);

            pdfDoc.Close();

            Response.Write(pdfDoc);

            Response.End();
        }
        catch (Exception)
        {

            throw;
        }
    }

    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=Carry Forward.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridView1.AllowPaging = false;
                this.Payoutsummary();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GridView1.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridView1.HeaderRow.Cells)
                {
                    cell.BackColor = GridView1.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridView1.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridView1.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridView1.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridView1.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

}




