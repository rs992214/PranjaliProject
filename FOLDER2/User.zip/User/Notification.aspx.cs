﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_Notification : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                GetType();
                NotificationRead();
                GetName();
                GetAmount();
            }
        }
    }

    void GetType()
    {
        DataTable dt = dal.Gettable("select JoinType from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            string jointype = dt.Rows[0]["JoinType"].ToString();

            if(jointype == "Free")
            {
                div1.Visible = false;
                div2.Visible = true;
            }
            else
            {
                div1.Visible = true;
                div2.Visible = false;
            }
        }
    }


    public void NotificationRead()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Update WithdrawalRequest set ReadNotification='1',NotificationDate=GETDATE() where UserID='{0}' and ReadNotification='0' and Status='APPROVED'", Session["UserID"].ToString());
        int rowaffected = dal.Executequery(sb.ToString(), ref message);
        if (rowaffected > 0)
        {

        }
    }

    public void GetAmount()
    {
        DataTable dt = dal.Gettable("select Top 1 amount ,PaymentMode,convert(nvarchar,NotificationDate,105) as Date  from WithdrawalRequest where  ReadNotification='1' and UserID='" + Session["UserID"].ToString() + "'and Status='APPROVED' order by id desc", ref message);
        if (dt.Rows.Count > 0)
        {
            lblamt.Text = dt.Rows[0]["amount"].ToString();
            lblmode.Text = dt.Rows[0]["PaymentMode"].ToString();
            lbldate.Text = dt.Rows[0]["Date"].ToString();
        }
    }

    public void GetName()
    {
        DataTable dt = dal.Gettable("select Name from MLM_Registration Where UserID='" + Session["UserID"].ToString() +"'", ref message);
        if (dt.Rows.Count > 0)
        {
            lblname.Text= dt.Rows[0]["Name"].ToString();
        }
    }
}