﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Collections;

public partial class customer_auth_GrowthPool : System.Web.UI.Page
{
    string message = string.Empty;
    ArrayList UserIDRightList = new ArrayList();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShoppingAutoPool();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    //protected void Page_LoadComplete(object sender, EventArgs e)
    //{
    //    ShowMembersofteam();
    //}
   
    protected void GV_UserList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_UserList_A.PageIndex = e.NewPageIndex;
    }
    protected void GV_UserList_B_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_UserList_B.PageIndex = e.NewPageIndex;
    }


    protected void ShoppingAutoPool()
    {
        List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Select UserID from AutoPool_GrowthFund order by DID ASC");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            string userid = string.Empty;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                userid = dt.Rows[i]["UserID"].ToString();
                DataTable dtUser1 = dal.Gettable("select UserID,Name,JoinType,Mobile,Email,Package,CONVERT(nvarchar,JoinDate,105)As JoinDate from AutoPool_GrowthFund where UserID='" + userid + "'", ref message);
                if (dtUser1.Rows.Count > 0)
                {
                    detail.Add(new MLMUserDetailProperty
                    {
                        UserID = dtUser1.Rows[0]["UserID"].ToString(),
                        Name = dtUser1.Rows[0]["Name"].ToString(),
                        Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                        Email = dtUser1.Rows[0]["Email"].ToString(),
                        Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                        JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                        Package = dtUser1.Rows[0]["Package"].ToString(),
                    });
                }
            }
            GV_UserList_A.DataSource = detail.ToList();
            GV_UserList_A.DataBind();
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here 
}