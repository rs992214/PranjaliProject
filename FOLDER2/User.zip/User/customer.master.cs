﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class customer_customer : System.Web.UI.MasterPage
{
    string message = string.Empty;
    DAL dal = new DAL();
    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    string CssName = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        // Showdatalogo();
        GetCssColour();

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {

                lblcompanyname.Text = Session["UserID"].ToString();
                Showdatalogo();
                showname();
                Showuserlogo();
                Notification();
                PlutoAddress();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    private void PlutoAddress()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        DataTable dt = dal.Gettable("Select PlutoAddress from MLM_Registration Where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["PlutoAddress"]!=DBNull.Value)
            {
                lblPlutoAddress.Text = dt.Rows[0]["PlutoAddress"].ToString();
                id_plutoaddress.Visible = true;
            }
            else
            {
                id_plutoaddress.Visible = false;
            }
        }
        else
        {

        }
    }

    public object GetCssColour()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from color_master where Status='Active'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            CssName = dt.Rows[0]["colorname"].ToString();
        }
        return CssName;
    }
    public void Showuserlogo()
    {
        try
        {

            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select PhotoPath from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {

                string Logo = dt.Rows[0]["PhotoPath"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    //byte[] bytes = (byte[])dt.Rows[0]["PhotoPath"];
                    //string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    //// imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    //Image1.ImageUrl = "data:image/png;base64," + base64String;
                    Image1.ImageUrl = Logo.ToString();

                }
            }
            else
            {
            }
        }
        catch (Exception ex)
        {


        }
    }
    public void showname()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            //sb.AppendFormat("select Name,status,CAST(JoinDate as date) as JoinDate,CAST(PackageDate as date) as PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            sb.AppendFormat("select Name,status,JoinDate,PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblUsername.Text = dt.Rows[0]["Name"].ToString();
                //lblUserName.Text = dt.Rows[0]["Name"].ToString();
                // lbljoindate.Text = Convert.ToDateTime(dt.Rows[0]["JoinDate"]).ToString("dd-MM-yyyy");
                //    lblactivationdate.Text = Convert.ToDateTime(dt.Rows[0]["PackageDate"]).ToString("dd-MM-yyyy");
                string status = dt.Rows[0]["status"].ToString();
                if (status == "InActive")
                {
                    Response.RedirectPermanent("~/pages/Status.html");
                }
            }
            else
            {
                lblUsername.Text = "Company Associate";
            }
        }
        catch (Exception ex)
        {
            /// ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {

                //  lblcompanyname.Text = dt.Rows[0]["CompanyName"].ToString();
                lblcompanyname1.Text = dt.Rows[0]["CompanyName"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    // imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    imgLogo1.ImageUrl = "data:image/png;base64," + base64String;
                }
            }
            else
            {
            }
        }
        catch (Exception ex)
        {


        }
    }

    public void Notification()
    {
        DataTable dt = dal.Gettable("select Top 1 count(*) as count from WithdrawalRequest where  ReadNotification='0' and UserID='" + Session["UserID"].ToString() + "'  group by id order by id desc", ref message);
        if (dt.Rows.Count > 0)
        {
            lblnotification.Text = dt.Rows[0]["count"].ToString();

        }
        else
        {
            lblnotification.Text = "0";
        }
    }
}
