﻿using DataAccessLayer;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_AgentVerify : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();

    public string key = "";
    public string mode = "";
    public string service = "";
    public string Name = "";
    public string Address = "";
    public string Email = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                if (Request.QueryString["userid"] != "")
                {
                    ShowPopupMessage("Success :Agent Account created but not verified Please Enter OTP.", PopupMessageType.Success);
                    //btnSave.Enabled = false;
                }
                else
                {
                    Response.Redirect("Logout.aspx");
                }

            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }

    protected void txtotp_TextChanged(object sender, EventArgs e)
    {
        if (txtotp.Text != "")
        {
            btnSave.Enabled = true;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            JoloGetAPIKEY();
            DataTable dtdata = dal.Gettable("select mm.UserID,mm.Name,mm.Mobile,mm.Email,ml.Address from MLM_Registration mm inner join MLM_UserDetail ml on mm.UserID=ml.UserID where mm.UserID='" + Request.QueryString["userid"].ToString() + "' and mm.JoinType='Paid'", ref message);
            if (dtdata.Rows.Count > 0)
            {
                Name = dtdata.Rows[0]["Name"].ToString();
                service = dtdata.Rows[0]["Mobile"].ToString();
                Email = dtdata.Rows[0]["Email"].ToString();
                Address = dtdata.Rows[0]["address"].ToString();

                string sURL = "http://jolosoft.com/dmr/cdmr_signup_verify.php?mode=" + mode + "&key=" + key + "&service=" + service + "&otp=" + txtotp.Text + "";
                //Response.Write(url);
                //Response.End();
                // Response.Redirect("https://jolosoft.com/dmr/cdmr_signup_verify.php?mode=" + mode + "&key=" + key + "&service=7972947432&otp=12345");
                WebRequest wrGETURL;
                string jsonValue = "";
                wrGETURL = WebRequest.Create(sURL);
                try
                {
                    StreamReader objReader;
                    Stream objStream;
                    objStream = wrGETURL.GetResponse().GetResponseStream();
                    objReader = new StreamReader(objStream);
                    jsonValue = objReader.ReadToEnd();
                    var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                    string status = myDetails.status;
                    service = myDetails.service;
                    if (status == "FAILED")
                    {
                        ShowPopupMessage("Error :Account Not be Verified .", PopupMessageType.Success);
                    }
                    else
                    {
                        //Response.Write(status +"/"+service);
                        //Response.End();
                        //Response.Redirect("auth-AgentVerify.aspx");
                        //txtotp.Text = "";
                        //btnSave.Enabled = false;
                        //ShowPopupMessage("Success :Account Verified .", PopupMessageType.Success);
                        SaveAgentDetails(service);
                    }
                    objReader.Close();
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }


        }
        catch (Exception ex)
        {

        }
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-AddAgent.aspx");
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }
    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void JoloGetAPIKEY()
    {
        DataTable dt = dal.Gettable("select APIKey,Mode from JoloGetway where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            key = dt.Rows[0]["APIKey"].ToString();
            mode = dt.Rows[0]["Mode"].ToString();
        }
        else
        {
            btnSave.Enabled = false;
            ShowPopupMessage("Error : Payment Getway Could Not Be Working .", PopupMessageType.Success);
        }
    }

    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
        public string error
        {
            get;
            set;
        }

        public string service
        {
            get;
            set;
        }
    }

    protected void SaveAgentDetails(string Mobile)
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("InserAgentBeneficiary_Sp", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", Request.QueryString["userid"].ToString());
        cmd.Parameters.AddWithValue("@Mobile", Mobile);
        cmd.Parameters.AddWithValue("@Mode", "InserAgent");
        int flag = cmd.ExecuteNonQuery();
        con.Close();
        if (flag > 0)
        {
            txtotp.Text = "";
            btnSave.Enabled = false;
            ShowPopupMessage("Success :Account Verified .", PopupMessageType.Success);
        }
        else
        {
            txtotp.Text = "";
            btnSave.Enabled = false;
            ShowPopupMessage("Message:Account Already Verified .", PopupMessageType.Success);
        }
    }
}