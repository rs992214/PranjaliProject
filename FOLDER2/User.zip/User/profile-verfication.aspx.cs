﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;

public partial class customer_verfication : System.Web.UI.Page
{
    DAL dal;
    string message;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            if (!IsPostBack)
            {
                ShowCountry();
                //  ShowStateName();
                //drpcity.Items.Insert(0, new ListItem("Select District", "0"));
                ShowProfile();
                ShowProfileImage();
                statuskyc();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }

    }

    private void Bind_Country_State_City()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("select State,City,CityName,Country,CountryName,Nationality,Address,Telegram,AddressLine2,CityName,StateName,Country,Zipcode from MLM_UserDetail where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            string CountryID = dt.Rows[0]["Country"].ToString();
            if (!string.IsNullOrEmpty(CountryID))
            {
                ddlCountry.ClearSelection();
                //  drpstate.Items.FindByValue(dt.Rows[0]["State"].ToString()).Selected = true;
                ddlCountry.Items.FindByValue(dt.Rows[0]["Country"].ToString()).Selected = true;
                //  drpstate.Enabled = false;
                //ddlCountry.Enabled = false;
                ShowStateName();
                // ShowCityName();
                //  drpcity.ClearSelection();
                string cityid = dt.Rows[0]["CityName"].ToString();
                if (!string.IsNullOrEmpty(cityid))
                {
                    txtCity.Text = dt.Rows[0]["CityName"].ToString();
                  //  txtCity.Enabled = false;
                    //  drpcity.Items.FindByValue(dt.Rows[0]["CityName"].ToString()).Selected = true;
                    //  drpcity.Enabled = false;
                }
            }

            string Stateid = dt.Rows[0]["State"].ToString();
            if (!string.IsNullOrEmpty(Stateid))
            {
                drpstate.ClearSelection();
                drpstate.Items.FindByValue(dt.Rows[0]["State"].ToString()).Selected = true;
              //  drpstate.Enabled = false;
                //  ShowCityName();
                //  drpcity.ClearSelection();
                string cityid = dt.Rows[0]["CityName"].ToString();
                if (!string.IsNullOrEmpty(cityid))
                {
                    txtCity.Text = dt.Rows[0]["CityName"].ToString();
                  //  txtCity.Enabled = false;
                    //    drpcity.Items.FindByValue(dt.Rows[0]["CityName"].ToString()).Selected = true;
                    //    drpcity.Enabled = false;
                }
            }

        }
    }


    public void ShowCountry()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("select * from [dbo].[CountryMaster]", ref message);
        if (dt.Rows.Count > 0)
        {
            ddlCountry.DataSource = dt;
            ddlCountry.DataTextField = "Name";
            ddlCountry.DataValueField = "ID";
            ddlCountry.DataBind();
            ddlCountry.Items.Insert(0, new ListItem("--Select Country--", "0"));
        }
        else
        {

        }
    }

    public void statuskyc()
    {
        try
        {
            string userID = Session["UserID"].ToString();
            DAL dal = new DAL();
            DataTable dt1 = dal.Gettable("Select KYC from MLM_UserDetail where UserID='" + userID.ToString() + "'", ref message);
            if (dt1.Rows.Count > 0)
            {
                string status = dt1.Rows[0]["KYC"].ToString();
                if (status == "Yes")
                {
                    lblKyc.Text = "KYC Approved";
                    lblKyc.CssClass = "btn btn-success";
                }
                else
                {
                    lblstatus.Text = "KYC pending";
                    lblKyc.CssClass = "btn btn-danger";
                }
            }
        }
        catch (Exception ex)
        {

        }
    }


    private void Load_First_Last_Name()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("Select Name,LastName from [MLM_Registration] where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["Name"] != DBNull.Value && dt.Rows[0]["LastName"] != DBNull.Value)
            {
                txtFname.Text = dt.Rows[0]["Name"].ToString();
                txtLname.Text = dt.Rows[0]["LastName"].ToString();
            }
        }
    }

    private void ShowProfileImage()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("select PhotoPath from [MLM_UserDetail] where UserID='" + Session["UserID"].ToString() + "'  ", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["PhotoPath"] != DBNull.Value)
            {
                Image1.ImageUrl = dt.Rows[0]["PhotoPath"].ToString();
            }
            else
            {
                Image1.ImageUrl = "~/customer/assets/images/user.jpg";
            }
        }

    }

    public void ShowSponsorName()
    {
        //22/10/2019 ShowSponsorName  Check All  SponsorID

        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select Name From MLM_Registration where UserID='{0}'", lblsponsoraccount.Text);
            StringBuilder sba = new StringBuilder();
            sba.AppendFormat("select Name from MLM_Registration where UserID='{0}'", lblplaceaccountno.Text);
            object Sposorname = dal.Getscalar(sb.ToString(), ref message);
            object PlaceName = dal.Getscalar(sba.ToString(), ref message);
            if (Sposorname is DBNull)
            {
                lblsponsorname.Text = "Company";
            }
            else
            {
                if (Sposorname != null)
                {
                    lblsponsorname.Text = Sposorname.ToString();
                }
                else
                {
                    lblsponsorname.Text = "Company";
                }
            }
            if (PlaceName is DBNull)
            {
                lblplaceaccountname.Text = "Company";
            }
            else
            {
                if (PlaceName != null)
                {
                    lblplaceaccountname.Text = PlaceName.ToString();
                }
                else
                {
                    lblplaceaccountname.Text = "Company";
                }
            }
        }
        catch (Exception ex)
        {
            //ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void BTCAddress()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("Select BTC_Address from MLM_UserDetail  where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtBTC_Address.Text = dt.Rows[0]["BTC_Address"].ToString();
            if (!string.IsNullOrEmpty(txtBTC_Address.Text))
            {
                txtBTC_Address.Text = dt.Rows[0]["BTC_Address"].ToString();
            }
        }
    }
    private void TronAddress()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("Select TRON_Address from MLM_UserDetail  where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txttron.Text = dt.Rows[0]["TRON_Address"].ToString();
            if (!string.IsNullOrEmpty(txttron.Text))
            {
                txttron.Text = dt.Rows[0]["TRON_Address"].ToString();
            }
        }
    }

    private void EthereumAddress()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("Select Ethereum_Address from MLM_UserDetail  where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtethereum.Text = dt.Rows[0]["Ethereum_Address"].ToString();
            if (!string.IsNullOrEmpty(txtethereum.Text))
            {
                txtethereum.Text = dt.Rows[0]["Ethereum_Address"].ToString();
            }
        }
    }
    private void ShowProfile()
    {
        MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = Session["UserID"].ToString() };
        MLMUserDetailLogic MDL = new MLMUserDetailLogic();
        DataTable dt = MDL.UserDetail(MDP, ref message);
        if (dt.Rows.Count > 0)
        {
            lblsponsoraccount.Text = dt.Rows[0]["SponsorID"].ToString();
            lblplaceaccountno.Text = dt.Rows[0]["PlaceunderID"].ToString();
            lblaccountno.Text = dt.Rows[0]["UserID"].ToString();
            lblstatus.Text = dt.Rows[0]["Status"].ToString();

            ShowSponsorName();
            Load_First_Last_Name();
            BTCAddress();
            TronAddress();
            EthereumAddress();
            statuskyc();

            string Gender = dt.Rows[0]["Gender"].ToString();
            if (!string.IsNullOrEmpty(Gender))
            {
                drpgender.ClearSelection();
                drpgender.Items.FindByText(dt.Rows[0]["Gender"].ToString()).Selected = true;
                // drpgender.Enabled = false;
            }
            string date = dt.Rows[0]["DOB"].ToString();
            if (!string.IsNullOrEmpty(date))
            {
                DateTime d1 = Convert.ToDateTime(date);
                txtDOB.Text = Convert.ToDateTime(date).ToString("yyyy-MM-dd");
            }



            txtmobile.Text = dt.Rows[0]["Mobile"].ToString();
            if (!string.IsNullOrEmpty(txtmobile.Text))
            {
                //txtmobile.ReadOnly = true;
            }
            txtGmob.Text = dt.Rows[0]["AlternateMobile"].ToString();
            if (!string.IsNullOrEmpty(txtGmob.Text))
            {
                //txtalternate.ReadOnly = true;
            }
            txtofficeno.Text = dt.Rows[0]["Office"].ToString();
            if (!string.IsNullOrEmpty(txtofficeno.Text))
            {
                // txtofficeno.ReadOnly = true;
            }
            txtEmail.Text = dt.Rows[0]["Email"].ToString();
            if (!string.IsNullOrEmpty(txtEmail.Text))
            {
                // txtemail.ReadOnly = true;
            }
            #region Unused Code
            //string Stateid = dt.Rows[0]["State"].ToString();
            //if (!string.IsNullOrEmpty(Stateid))
            //{
            //    drpstate.ClearSelection();
            //    drpstate.Items.FindByValue(dt.Rows[0]["State"].ToString()).Selected = true;
            //    //drpstate.Enabled = false;
            //    ShowCityName();
            //    drpcity.ClearSelection();
            //    string cityid = dt.Rows[0]["City"].ToString();
            //    if (!string.IsNullOrEmpty(cityid))
            //    {
            //        drpcity.Items.FindByValue(dt.Rows[0]["City"].ToString()).Selected = true;
            //        // drpcity.Enabled = false;
            //    };
            //}
            //txtpostalcode.Text = dt.Rows[0]["PostalCode"].ToString();
            #endregion
            Bind_Country_State_City();
            if (!string.IsNullOrEmpty(txtpostalcode.Text))
            {
                // txtpostalcode.ReadOnly = true;
            }
            txtaddress.Text = dt.Rows[0]["Address"].ToString();
            if (!string.IsNullOrEmpty(txtaddress.Text) && !string.IsNullOrEmpty(txtFname.Text))
            {
                //txtaddress.ReadOnly = true;
                // btnU.Enabled = false;
            }
        }
        else
        {

        }
    }
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserID"] != null)
            {
                if (fupphoto.HasFile)
                {
                    string UserID = Session["UserID"].ToString();
                    string fileName = Path.GetFileName(fupphoto.PostedFile.FileName);
                    string extension = Path.GetExtension(fupphoto.PostedFile.FileName);

                    if (extension == ".jpg")
                    {
                        // fileName = string.Empty;
                        // fileName = UserID + ".jpg";
                    }
                    else if (extension == ".jpeg")
                    {
                        // fileName = string.Empty;
                        // fileName = UserID + ".jpeg";
                    }
                    else if (extension == ".png")
                    {
                        //fileName = string.Empty;
                        //fileName = UserID + ".png";
                    }
                    string filePath = Server.MapPath("../customer/customerphoto/" + fileName);
                    fupphoto.PostedFile.SaveAs(Server.MapPath("../customer/customerphoto/" + fileName));
                    Image1.ImageUrl = "../customer/customerphoto/" + fileName;

                    DAL dal = new DAL();
                    StringBuilder sb = new StringBuilder();
                    sb.AppendFormat("update MLM_UserDetail set PhotoPath='{0}' where UserID='{1}'", "../customer/customerphoto/" + fileName, Session["UserID"].ToString());
                    int rowaffected = dal.Executequery(sb.ToString(), ref message);
                    if (rowaffected > 0)
                    {
                        ShowPopupMessage("Profile Photo has been Updated.", PopupMessageType.Success);
                        ShowProfile();
                        ShowProfileImage();
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Warning);
                    }


                }
                else
                {
                    ShowPopupMessage("Please Select Profile Photo.", PopupMessageType.Message);
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowStateName()
    {
        try
        {
            DAL dal = new DAL();
            drpstate.DataTextField = "StateName";
            drpstate.DataValueField = "StateID";
            DataTable dt = dal.Gettable("Select StateID,StateName from [State] where CountryID="+ddlCountry.SelectedValue, ref message);
            //State St = new State();
            //DataTable dt = St.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                drpstate.DataSource = dt;
                drpstate.DataBind();
                drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));

            }
            else
            {
                drpstate.DataSource = null;
                drpstate.DataBind();
                drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));
            }
        }
        catch (Exception ex)
        {

            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    public void ShowCityName()
    {

        drpcity.DataTextField = "CityName";
        drpcity.DataValueField = "CityID";
        CityProperty Cp = new CityProperty();
        Cp.StateID = Convert.ToInt32(drpstate.SelectedValue);
        try
        {
            City cty = new City();
            DataTable dt = cty.GetData(Cp, ref message);
            if (dt.Rows.Count > 0)
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
            }
            else
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void drpstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowCityName();
    }

    protected void txtUpdateprofile_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                CultureInfo MyCultureInfo = new CultureInfo("en-IN");
                DateTime date = DateTime.Parse(txtDOB.Text, MyCultureInfo);
                DAL dal = new DAL();

                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("update MLM_UserDetail set Gender='{0}',DOB='{1}',AlternateMobile='{2}',Office='{3}',State='{4}',City='{5}',PostalCode='{6}',Address='{7}',StateName='{8}',CityName='{9}',BTC_Address='{10}',TRON_Address='{11}',Ethereum_Address='{12}',Country='{13}',CountryName='{14}' where UserID='{15}'", drpgender.SelectedItem.Text, Convert.ToDateTime(date).ToString("yyyy-MM-dd"), txtGmob.Text, txtofficeno.Text, Convert.ToInt32(drpstate.SelectedValue), drpcity.SelectedValue, txtpostalcode.Text, txtaddress.Text, drpstate.SelectedItem.Text, txtCity.Text, txtBTC_Address.Text,txttron.Text,txtethereum.Text,ddlCountry.SelectedValue,ddlCountry.SelectedItem.Text, Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                StringBuilder sba = new StringBuilder();
                sba.AppendFormat("update MLM_Registration set Email='{0}',Name='{1}',Mobile='{2}',LastName='{3}',DOB='{4}' where UserID='{5}'", txtEmail.Text, txtFname.Text, txtmobile.Text, txtLname.Text, Convert.ToDateTime(txtDOB.Text).ToString("yyyy-MM-dd"), Session["UserID"].ToString());
                int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0 && rowaffected1 > 0)
                {
                    ShowPopupMessage("Personal Detail Updated Successfully", PopupMessageType.Success);
                    ShowProfile();
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
            finally
            {
                ShowProfile();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowStateName();
    }
}