﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.IO;
using System.Drawing;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;

public partial class customer_auth_providehelp_history : System.Web.UI.Page
{
    string cn = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    string message = string.Empty;
    DAL objDAL = new DAL();
    int index = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                GetData();
                //   detailsBank();

            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }
    private void GetData()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DataTable dt = new DataTable();
            //  dt = objDAL.Gettable("select * from DonationNew where UserID='" + UserID + "' ", ref message);

            // where  assignstatus='assigned'
            //   dt = objDAL.Gettable("select * from Donation where PH_ID='"+ UserID + "' AND status='Pending'", ref message);

            dt = objDAL.Gettable("select ph.ID,ph.GH_ID,(select mobile from MLM_Registration where  UserID = ph.GH_ID) As Mobile, ph.PH_ID,ph.Photo,ph.UpdationDate,PayAmount,ph.CreationDate,ph.Status from Donation ph inner join MLM_Registration mr on ph.PH_ID = mr.UserID where mr.UserID = '" + UserID + "' and ph.Status = 'Confirm'", ref message);





            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        GetData();
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            GetData();
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=DonationLink.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GV_LedgerList.AllowPaging = false;
                GetData();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GV_LedgerList.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GV_LedgerList.HeaderRow.Cells)
                {
                    cell.BackColor = GV_LedgerList.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GV_LedgerList.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GV_LedgerList.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GV_LedgerList.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GV_LedgerList.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void btnUpdate_Command(object sender, CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        GridViewRow row = (GridViewRow)GV_LedgerList.Rows[id];
        FileUpload file = (FileUpload)row.FindControl("fileUpload");

        int id2 = Convert.ToInt32(GV_LedgerList.DataKeys[id].Values[0]);

        if (file.HasFile)
        {
            try
            {
                file.SaveAs(System.IO.Path.Combine(Server.MapPath("~/upload/"), file.FileName));
                con = new SqlConnection(cn);
                cmd = new SqlCommand("Update Donation set status = 'Confirm', Updationdate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', Photo = '~/upload/" + file.FileName + "' where ID=" + id2, con);
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (i > 0)
                {
                    Response.Write("<script>alert('Receipt Uploaded Successfully.');window.location='provide_help.aspx';</script>");
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.Message);
                //Note: Exception.Message returns a detailed message that describes the current exception. 
                //For security reasons, we do not recommend that you return Exception.Message to end users in 
                //production environments. It would be better to put a generic error message. 
            }
        }
        else
        {
            Response.Write("Please select a file to upload.");
        }
    }

    protected void GV_LedgerList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        index = Convert.ToInt32(e.CommandArgument);

    }

    public void detailsBank()
    {
        DAL dal = new DAL();
        string msg = string.Empty;
        string spid = "";
        DataTable dt = dal.Gettable("select SponsorID from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            spid = dt.Rows[0]["SponsorID"].ToString();
            DataTable dt1 = dal.Gettable("select mr.Name,mr.Mobile,mm.BankName,mm.Branch,mm.AccountNo,mm.AccountType,mm.IFSCCode,mm.PANNO,mm.Paytm from MLM_UserDetail mm inner join MLM_Registration mr on mr.UserID=mm.UserID where mm.UserID='top'", ref message);
            if (dt1.Rows.Count > 0)
            {
                //lblSname.Text = dt1.Rows[0]["Name"].ToString();
                //lblbankname.Text = dt1.Rows[0]["BankName"].ToString();
                //lblbranch.Text = dt1.Rows[0]["Branch"].ToString();
                //lblAccount.Text = dt1.Rows[0]["AccountNo"].ToString();
                //lbltype.Text = dt1.Rows[0]["AccountType"].ToString();
                //lblIFSC.Text = dt1.Rows[0]["IFSCCode"].ToString();
                //lblPAN.Text = dt1.Rows[0]["PANNO"].ToString();
                //lblPayTm.Text = dt1.Rows[0]["Paytm"].ToString();

            }

        }
    }

    protected void GV_LedgerList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblStatus = e.Row.FindControl("lblStatus") as Label;
            LinkButton btnApproved = e.Row.FindControl("btnUpdate") as LinkButton;
            if (lblStatus.Text == "Confirm")
            {
                btnApproved.Enabled = false;
                btnApproved.CssClass = "btn btn btn-warning disabled";
            }
            else
            {
                btnApproved.Enabled = true;
                btnApproved.CssClass = "btn btn btn-warning";
            }
        }
    }
}