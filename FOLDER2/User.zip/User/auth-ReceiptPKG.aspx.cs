﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_ReceiptPKG : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["invoiceNo"]))
                {
                    ViewState["InvoiceNo"] = Request.QueryString["invoiceNo"].ToString();
                    ShowInvoiceDetail();
                    ShowCompanyName();
                }
                else
                {
                    Response.Redirect("auth-myinvoice.aspx");
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void ShowInvoiceDetail()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select OrderBy,TransferBy,Subtotal,CGSTamt,SGSTamt,IGSTamt,ShippingCharge,TotalAmount,AmountInWord,PaymentMode,ShipingAddress,Dispatchmode,convert(nvarchar(10),Date,103) as Date from BBOOredertbl where InvoiceNo='{0}'", ViewState["InvoiceNo"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblinvoice.Text = ViewState["InvoiceNo"].ToString();
                lblorderdate.Text = dt.Rows[0]["Date"].ToString();
                lbltotalamount.Text = dt.Rows[0]["Subtotal"].ToString();
                lblcgstamount.Text = dt.Rows[0]["CGSTamt"].ToString();
                lblsgstamount.Text = dt.Rows[0]["SGSTamt"].ToString();
                lbligstamount.Text = dt.Rows[0]["IGSTamt"].ToString();
                lblshippingcharge.Text = dt.Rows[0]["ShippingCharge"].ToString();
                lblnetamount.Text = dt.Rows[0]["TotalAmount"].ToString();
                lblpaymentmode.Text = dt.Rows[0]["PaymentMode"].ToString();
                lblShippingaddress.Text = dt.Rows[0]["ShipingAddress"].ToString();
                lbldispatchmode.Text = dt.Rows[0]["Dispatchmode"].ToString();
                lblamountinword.Text = dt.Rows[0]["AmountInWord"].ToString();
                string TransferBy = dt.Rows[0]["TransferBy"].ToString();
                string orderby = dt.Rows[0]["OrderBy"].ToString();
                Showtransferbydetail(TransferBy);
                Showorderdetail(orderby);
                StringBuilder sba = new StringBuilder();
                sba.AppendFormat("select P.ProductName, cast(round(BD.TotalAmount / BD.QTY, 2) as numeric(36, 2)) as [Price Per Item],BD.QTY,BD.TotalAmount,BD.CGSTper,BD.CGSTAmt,BD.SGSTPer,BD.SGSTAmt,BD.IGSTPer,BD.IGSTAmt from BBOOreder_Detail as BD   inner join Product as P on BD.ProductCode = P.ProductCode where BD.InvoiceNo = '{0}'", ViewState["InvoiceNo"].ToString());
                DataTable dt1 = dal.Gettable(sba.ToString(), ref message);
                if (dt1.Rows.Count > 0)
                {
                    GridView1.DataSource = dt1;
                    GridView1.DataBind();
                }
                else
                {
                    GridView1.DataSource = null;
                    GridView1.DataBind();

                }
            }
        }
        catch (Exception)
        {

            throw;
        }


    }
    public void Showtransferbydetail(string TransferBy)
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            if (TransferBy == "Company")
            {
                sb.AppendFormat("select CI.CompanyName,CI.Address,CT.CityName,ST.StateName,CI.PhoneNo,CI.GstNo,CI.Email from CompanyInfo as CI inner join State as ST on CI.StateID = ST.StateID inner join City as CT on CI.CityID = CT.CityID");
            }
            else
            {
                sb.AppendFormat("select Sd.UserID,Sd.BussinessName as CompanyName,SD.Address,S.StateName,C.CityName,SD.Mobile as PhoneNo,SD.Email,SD.GSTNO from StockistDetail as SD inner join State as S on SD.State = S.StateID inner join City as C on SD.District = c.CityID where SD.UserID ='{0}'", TransferBy);
            }
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                if (TransferBy == "Company")
                {
                    lblcomapnyname.Text = dt.Rows[0]["CompanyName"].ToString();
                }
                else
                {
                    lblcomapnyname.Text = dt.Rows[0]["CompanyName"].ToString() + " (" + dt.Rows[0]["UserID"].ToString() + ")";
                }

                lblcompanyaddress.Text = dt.Rows[0]["Address"].ToString() + "\n" + dt.Rows[0]["CityName"].ToString() + "," + dt.Rows[0]["StateName"].ToString();
                lblphone.Text = "Phone No: " + dt.Rows[0]["PhoneNo"].ToString();
                lblemail.Text = "Email ID: " + dt.Rows[0]["Email"].ToString();
                lblgstno.Text = "GSTIN: " + dt.Rows[0]["GstNo"].ToString();
            }
            else
            {
                lblcomapnyname.Text = null; ;
                lblcompanyaddress.Text = null;
                lblphone.Text = "Phone No: ";
                lblemail.Text = "Email ID: ";
                lblgstno.Text = "GSTIN: ";
            }

        }
        catch (Exception)
        {

            throw;
        }

    }
    public void Showorderdetail(string orderby)
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select MR.UserID,MR.Name,MR.Mobile,MR.Email,ST.StateName,CT.CityName,Mu.Address,Mu.PostalCode,Mu.GSTProofvalue from MLM_Registration as MR Left join MLM_UserDetail as MU on MR.UserID = MU.UserID left Join State as ST on MU.State = ST.StateID left join city as CT on Mu.District = CT.CityID where MR.UserID ='{0}'", orderby);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblbboname.Text = dt.Rows[0]["Name"].ToString() + " (" + dt.Rows[0]["UserID"].ToString() + ")";
                lblbboaddress.Text = dt.Rows[0]["Address"].ToString() + "\n" + dt.Rows[0]["CityName"].ToString() + "," + dt.Rows[0]["StateName"].ToString() + "-" + dt.Rows[0]["PostalCode"].ToString();
                lblbbophone.Text = dt.Rows[0]["Mobile"].ToString();
                lblbboemail.Text = dt.Rows[0]["Email"].ToString();
                lblbbogst.Text = "GSTIN: " + dt.Rows[0]["GSTProofvalue"].ToString();
            }
            else
            {
                lblbboname.Text = null;
                lblbboaddress.Text = null;
                lblbbophone.Text = null;
                lblbboemail.Text = null;
                lblbbogst.Text = "GSTIN: ";
            }

        }
        catch (Exception)
        {

            throw;
        }
    }

    protected void ShowCompanyName()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select CI.CompanyName,CI.Address,CT.CityName,ST.StateName,CI.PhoneNo,CI.GstNo,CI.Email from CompanyInfo as CI inner join State as ST on CI.StateID = ST.StateID inner join City as CT on CI.CityID = CT.CityID");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                Label1.Text = dt.Rows[0]["CompanyName"].ToString();
                Label2.Text = dt.Rows[0]["Address"].ToString() + "\n" + dt.Rows[0]["CityName"].ToString() + "," + dt.Rows[0]["StateName"].ToString();
                Label3.Text = "Phone No :  " + dt.Rows[0]["PhoneNo"].ToString();
                Label4.Text = "Email ID :  " + dt.Rows[0]["Email"].ToString();
                Label5.Text = "GSTIN    :  " + dt.Rows[0]["GstNo"].ToString();
            }
            else
            {
                Label1.Text = null; ;
                Label2.Text = null;
                Label3.Text = "Phone No: ";
                Label4.Text = "Email ID: ";
                Label5.Text = "GSTIN: ";
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
}