﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
public partial class customer_Deposit_BBT : System.Web.UI.Page
{
    string constrc = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            getdata();
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    private void getdata()
    {
        try
        {       
            SqlConnection conn = new SqlConnection(constrc);
            SqlCommand cmd = new SqlCommand("select * from QR_Master", conn);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DataList1.DataSource = dt;
            DataList1.DataBind();
            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('ex.Message')</script>");
        }
    }

}