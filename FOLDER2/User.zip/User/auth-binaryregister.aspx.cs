﻿using DataAccessLayer;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_login : System.Web.UI.Page
{
    string message = string.Empty;
    string message1 = string.Empty;
    DAL dal = new DAL();
    DAL dal1 = new DAL();
    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        string Refferalid = Request.QueryString["Refferalid"];
        string Position = Request.QueryString["Position"];
        ViewState["Placeunder"] = Request.QueryString["Placeunder"];//referlink joining code karan
        if (!IsPostBack)
        {
            //btnsignup.Enabled = false;
            if (Refferalid != null)
            {
                txtsponsorid.Text = Refferalid;
                ddlposition.SelectedValue= Position;
                if (Position != "")
                {
                    ddlposition.Enabled = false;
                    txtsponsorid.ReadOnly = true;
                }
                GetUserID();
              //  GetPlutoAddress();
                GetNameSporid();
                Showdatalogo();
                ViewState["PlutoAddress"] = GetUniqueKeyOriginal_BIASED(34);
                //btnsignup.Enabled = false;
                BindCountry();
            }
            else
            {
                //txtSponsorid.Text = "LKD543137";
                //txtEmailid.Text = "memberlkd@gmail.com";
                //lblsponsorname.Visible = true;
                //lblsponsorname.Text = "Probuz";
                GetUserID();
               // GetPlutoAddress();
                //BindState();
                ViewState["PlutoAddress"] = GetUniqueKeyOriginal_BIASED(34);
                Showdatalogo();
                BindCountry();
                //btnsignup.Enabled = false;
            }
        }
    }
    private void BindCountry()
    {
        DataTable dt = dal.Gettable("select * from [dbo].[CountryMaster]", ref message);
        if (dt.Rows.Count > 0)
        {
            ddlcountry.DataSource = dt;
            ddlcountry.DataTextField = "Name";
            ddlcountry.DataValueField = "ID";
            ddlcountry.DataBind();
            ddlcountry.Items.Insert(0, new ListItem("Select Country Name", "0"));
        }
        else
        {

        }
    }


    public static string GetUniqueKeyOriginal_BIASED(int size)
    {
        char[] chars = "@#$%&abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789".ToCharArray();
        byte[] data = new byte[size];
        using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
        {
            crypto.GetBytes(data);
        }
        StringBuilder result = new StringBuilder(size);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }


    public void pannumberUpdate()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("MLM_Registration_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", lblUserId.Text);
        //cmd.Parameters.AddWithValue("@PANNO", txtpancardno.Text);
        cmd.Parameters.AddWithValue("@Mode", "Updatepannumber");
        int flag = cmd.ExecuteNonQuery();
    }
    public void GetNameSporid()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        //   sb.AppendFormat("select Name From MLM_Registration where UserID='{0}'", txtsponsorid.Text);
        try
        {
            //DataTable dt = dal.Gettable("select Name From MLM_Registration where UserID='"+txtsponsorid.Text+"'", ref message);
            DataTable dt1 = dal.Gettable("Select * From MLM_Registration where UserID='" + txtsponsorid.Text + "'", ref message);
            if (dt1.Rows.Count > 0)
            {
                btnSubmit.Enabled = true;
                lblsponsorname.ForeColor = System.Drawing.Color.White;
                lblsponsorname.Text = dt1.Rows[0]["Name"].ToString();
            }
            else
            {
                btnSubmit.Enabled = false;
                lblsponsorname.ForeColor = System.Drawing.Color.Red;
                lblsponsorname.Text = "Invalid Sponsor ID / Account Is Inactive";
            }
        }


        catch (Exception ex)
        {
            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }

    private void GetUserID()
    {
        try
        {
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            con.Open();
            int flag = 1;
            while (flag == 1)
            {
                string COMPNY = "PL";
                string UserID = GetUniqueKey(6);
                SqlCommand cmd = new SqlCommand("MLM_Registration_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserID", UserID);
                cmd.Parameters.AddWithValue("@Mode", "CHECK_USERID");
                flag = (int)cmd.ExecuteScalar();
                lblUserId.Text = COMPNY + UserID;
            }
            con.Close();

        }catch(Exception ex)
        {

        }

    }
    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }
    public string GetUniqueKeyforBTC(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }
    private void GetPlutoAddress()
    {
                string COMPNY = "PLAD";
                string plutoaddress = GetUniqueKeyforBTC(22);
                //SqlCommand cmd = new SqlCommand("MLM_Registration_ALL", con);
                //cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@UserID", UserID);
                //cmd.Parameters.AddWithValue("@Mode", "CHECK_USERID");
                //flag = (int)cmd.ExecuteScalar();
                //lblUserId.Text = COMPNY + UserID;
                ViewState["plutoaddress"] = COMPNY+ plutoaddress;
                string plad = ViewState["plutoaddress"].ToString();

    }
    protected void txtsponsorid_TextChanged(object sender, EventArgs e)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        try
        {
            DataTable dt1 = dal.Gettable("Select * From MLM_Registration where UserID='" + txtsponsorid.Text + "'", ref message);
            if (dt1.Rows.Count > 0)
            {
                btnSubmit.Enabled = true;
                lblsponsorname.ForeColor = System.Drawing.Color.White;
                lblsponsorname.Text = dt1.Rows[0]["Name"].ToString();
            }
            else
            {
                btnSubmit.Enabled = false;
                lblsponsorname.ForeColor = System.Drawing.Color.Red;
                lblsponsorname.Text = "Invalid Sponsor ID / Account Is Inactive";
            }
        }
        catch (Exception ex)
        {
            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        checkvalidity();
    }

    public void checkvalidity()
    {
        if (lblsponsorname.Text == "Invalid Sponsor ID / Account Is Inactive" || string.IsNullOrEmpty(lblsponsorname.Text))
        {
            btnSubmit.Enabled = false;
        }
        else
        {
            btnSubmit.Enabled = true;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //referlink joining code karan
        if (ViewState["Placeunder"] != null)
        {
            SaveRecord(ViewState["Placeunder"].ToString());

        }//referlink joining code karan
        else
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select {0} From MLM_Registration where UserID='{1}'", ddlposition.SelectedValue, txtsponsorid.Text);
            //sb.AppendFormat("select {0} From MLM_Registration where UserID='{1}'", "LLeg", txtSponsorid.Text);
            try
            {
                object Position = dal.Getscalar(sb.ToString(), ref message);
                if (Position is DBNull)
                {
                    SaveRecord(txtsponsorid.Text);
                }
                else
                {
                    if (Position != null)
                    {
                        ExploringNetwork(ddlposition.SelectedValue, Position.ToString());

                        // ExploringNetwork("LLeg", Position.ToString());
                    }
                    else
                    {
                        SaveRecord(txtsponsorid.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }
    }

    private void Save_Counting()
    {
        DAL objDAL = new DAL();
        // string type =
        string type = "LLeg";

        int Current = 0;
        int Previous = 0;
        int Total = 0;
        if (type == "LLeg")
        {
            type = "LEFT";
            DataTable dtCount = objDAL.Gettable("Select UserID,CurrentCount,PreviousCount,Total From LeftCounting Where UserID='" + txtsponsorid.Text + "'", ref message);
            if (dtCount.Rows.Count > 0)
            {
                Current = Convert.ToInt32(dtCount.Rows[0]["CurrentCount"]);
                Previous = Convert.ToInt32(dtCount.Rows[0]["PreviousCount"]);
                Current = Current + 1;
                Total = Previous + Current;
            }
            else
            {
                Current = 1;
                Total = Previous + Current;
            }
        }
        else if (type == "RLeg")
        {
            type = "RIGHT";
            DataTable dtCount = objDAL.Gettable("Select UserID,CurrentCount,PreviousCount,Total From RightCounting Where UserID='" + txtsponsorid.Text + "'", ref message);
            if (dtCount.Rows.Count > 0)
            {
                Current = Convert.ToInt32(dtCount.Rows[0]["CurrentCount"]);
                Previous = Convert.ToInt32(dtCount.Rows[0]["PreviousCount"]);
                Current = Current + 1;
                Total = Previous + Current;
            }
            else
            {
                Current = 1;
                Total = Previous + Current;
            }
        }

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("LEFT_RIGHT_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtsponsorid.Text);
        cmd.Parameters.AddWithValue("@CurrentCount", Current);
        cmd.Parameters.AddWithValue("@PreviousCount", Previous);
        cmd.Parameters.AddWithValue("@Total", Total);
        cmd.Parameters.AddWithValue("@Type", type);
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }

    public void SaveRecord(string PlaceunderID)
    {
        //saurabh k
        try
        {
            string date;
            //string joinstring = "/";
            //string[] date = txtdob.Text.Split('/');
            //string finaldate = date[2] + joinstring + date[1] + joinstring + date[0];

            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            sba.AppendLine("insert into MLM_Registration(SponsorID,PlaceunderID,UserID,Password,Name,Mobile,Email,JoinType,PlutoAddress)");
            sba.AppendFormat("values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')", txtsponsorid.Text, PlaceunderID, lblUserId.Text, txtpwd.Text, txtname.Text, txtphnno.Text, txtemail.Text, "Free", ViewState["PlutoAddress"].ToString());
            int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
            if (rowaffected1 > 0)
            {
                StringBuilder sbb = new StringBuilder();
                sbb.AppendLine("insert into MLM_UserDetail(UserID,Gender,Country,CountryName)");
                sbb.AppendFormat("values('{0}','{1}','{2}','{3}')", lblUserId.Text,"Male",ddlcountry.SelectedValue,ddlcountry.SelectedItem.Text);
                int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);
                if (rowaffected1 > 0 && rowaffected2 > 0)
                {
                    //SendMsg();
                   SendMail(txtemail.Text, lblUserId.Text, txtpwd.Text);
                    StringBuilder sb = new StringBuilder();
                    //sb.AppendFormat("Update MLM_Registration set {0}='{1}' where UserID='{2}'", "LLeg", txtaadharno.Text, PlaceunderID);
                    sb.AppendFormat("Update MLM_Registration set {0}='{1}' where UserID='{2}'", ddlposition.SelectedValue, lblUserId.Text, PlaceunderID);
                    int rowaffected = dal.Executequery(sb.ToString(), ref message);
                    if (rowaffected > 0)
                    {
                        Updatejoining1(lblUserId.Text, PlaceunderID);
                      //  SendMsg();
                        SendMail(txtemail.Text, lblUserId.Text, txtpwd.Text);

                      
                    }
                    else
                    {
                        var errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                        var script = string.Format("alert({0});", errormessage);
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
                    }
                }
            }
            else
            {
                var errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }


        catch (Exception ex)
        {
            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Registration Completed Successfully.')", true);
            Response.Redirect("auth-logindetails.aspx?userid='" + lblUserId.Text + "'&password='" + txtpwd.Text + "'&name='" + txtname.Text + "'");
            Clear();
            GetUserID();
        }
    }

    //public void updateepinstatus()
    //{
    //    StringBuilder sb = new StringBuilder();
    //    sb.AppendFormat("Update PinGenerateNew set Status='Used',UserID='"+txtaadharno.Text+"',ActivationDate=getdate(),UpdationDate=getdate() where PinNo='" + txtPin.Text + "'");
    //    int rowaffected = dal.Executequery(sb.ToString(), ref message);
    //}

    public void InsertDonationtoadmin()
    {
        string mob = "";
        DataTable dtmob = dal.Gettable("Select Mobile from MLM_Registration Where UserID='C1001' ", ref message);
        if (dtmob.Rows.Count > 0)
        {
            mob = dtmob.Rows[0]["Mobile"].ToString();
            StringBuilder sbb1 = new StringBuilder();


            sbb1.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo,Pinamount)");


            sbb1.AppendFormat("values('{0}','{1}','{2}','{3}','{4}')", lblUserId.Text, "C1001", "2500", mob, "250");




            int rowaffected2 = dal.Executequery(sbb1.ToString(), ref message);

        }

    }
    public void InsertDonationtosponsor()
    {
        string mob = "";
        DataTable dtmob = dal.Gettable("Select Mobile from MLM_Registration Where UserID='" + txtsponsorid.Text + "' ", ref message);
        if (dtmob.Rows.Count > 0)
        {
            mob = dtmob.Rows[0]["Mobile"].ToString();
            StringBuilder sbb1 = new StringBuilder();
            //StringBuilder sbb2 = new StringBuilder();
            //StringBuilder sbb3 = new StringBuilder();
            //StringBuilder sbb4 = new StringBuilder();

            sbb1.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo)");
            //sbb2.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo)");
            //sbb3.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo)");
            //sbb4.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo)");

            sbb1.AppendFormat("values('{0}','{1}','{2}','{3}')", lblUserId.Text, "TOP", "250", mob);
            //sbb2.AppendFormat("values('{0}','{1}','{2}','{3}')", txtaadharno.Text, "TOP", "500", mob);
            //sbb3.AppendFormat("values('{0}','{1}','{2}','{3}')", txtaadharno.Text, "TOP", "1000", mob);
            //sbb4.AppendFormat("values('{0}','{1}','{2}','{3}')", txtaadharno.Text, "TOP", "2500", mob);



            int rowaffected2 = dal.Executequery(sbb1.ToString(), ref message);
            //int rowaffected3 = dal.Executequery(sbb2.ToString(), ref message);
            //int rowaffected4 = dal.Executequery(sbb3.ToString(), ref message);
            //int rowaffected5 = dal.Executequery(sbb4.ToString(), ref message);
        }

    }

    //update joining binary
    public void Updatejoining1(string userid, string placeunder)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        string Username = userid;
        string placeunderid = placeunder;
        int CurrentCount = 0;
        int Previous = 0;
        int Total = 0;

        do
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select PlaceunderID,LLeg,RLeg,ISNULL(LJoining,0)as LJoining,ISNULL(PreviousLJoin,0)as PreviousLJoin,ISNULL(TotalLJoin,0)as TotalLJoin,ISNULL(Rjoining,0) as Rjoining,ISNULL(PreviousRJoin,0) as PreviousRJoin,ISNULL(TotalRJoin,0) as TotalRJoin from MLM_Registration where UserID='{0}'", placeunderid);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["LLeg"].ToString() == Username)
                {
                    CurrentCount = Convert.ToInt32(dt.Rows[0]["LJoining"]);
                    Previous = Convert.ToInt32(dt.Rows[0]["PreviousLJoin"]);
                    CurrentCount = CurrentCount + 1;
                    Total = Previous + CurrentCount;
                    //joiningcount++;
                    StringBuilder sba = new StringBuilder();
                    sba.AppendFormat("update MLM_Registration set LJoining='{0}',TotalLJoin='{1}' where Userid='{2}'", CurrentCount, Total, placeunderid);
                    int rowaffected = dal.Executequery(sba.ToString(), ref message);
                    Username = placeunderid;
                    ViewState["PlaceunderID"] = dt.Rows[0]["PlaceunderID"];
                    if (ViewState["PlaceunderID"] != null)
                    {
                        placeunderid = ViewState["PlaceunderID"].ToString();
                    }
                    else
                    {
                        placeunderid = null;
                    }

                }
                else if (dt.Rows[0]["RLeg"].ToString() == Username)
                {
                    CurrentCount = Convert.ToInt32(dt.Rows[0]["RJoining"]);
                    Previous = Convert.ToInt32(dt.Rows[0]["PreviousRJoin"]);
                    CurrentCount = CurrentCount + 1;
                    Total = Previous + CurrentCount;
                    //joiningcount++;
                    StringBuilder sba = new StringBuilder();
                    sba.AppendFormat("update MLM_Registration set Rjoining='{0}',TotalRJoin='{1}' where Userid='{2}'", CurrentCount, Total, placeunderid);
                    int rowaffected = dal.Executequery(sba.ToString(), ref message);
                    Username = placeunderid;
                    ViewState["PlaceunderID"] = dt.Rows[0]["PlaceunderID"];
                    if (ViewState["PlaceunderID"] != null)
                    {
                        placeunderid = ViewState["PlaceunderID"].ToString();
                    }
                    else
                    {
                        placeunderid = null;
                    }
                }
                else
                {
                    placeunderid = null;
                }

            }
            else
            {
                placeunderid = null;
            }

        } while (!string.IsNullOrEmpty(placeunderid));
    }
    public void ExploringNetwork(string Leg, string UserName)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        bool Condition = true;
        string UserID = UserName;
        string Poisition = Leg;
        do
        {

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select {0} from MLM_Registration where UserID='{1}'", Poisition, UserID);
            object Result = dal.Getscalar(sb.ToString(), ref message);
            if (Result is DBNull)
            {
                SaveRecord(UserID);

                Condition = false;
            }
            else
            {
                if (Result != null)
                {
                    UserID = Result.ToString();
                }
                else
                {
                    SaveRecord(UserID);

                    Condition = false;
                }
            }
        } while (Condition);
    }

    //NEW SMS API
    public string sendSMS()
    {
        String result;
        string apiKey = "pDgVmhh5U7w-8rkRuNEEIv5SmnpCaFvRMcn0JdWLe6";
        // string numbers = "918055002299"; // in a comma seperated list
        string numbers = txtphnno.Text;
        string smstext = "Congratulations, Dear Donor Your Account Has Been Created Successfully. Your User ID: '" + lblUserId.Text + "' and password:'" + txtpwd.Text + "'. Thank You.";


        string message = smstext.ToString();



        string sender = "TXTLCL";

        String url = "https://api.textlocal.in/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + sender;
        //refer to parameters to complete correct url string

        StreamWriter myWriter = null;
        HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

        objRequest.Method = "POST";
        objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
        objRequest.ContentType = "application/x-www-form-urlencoded";
        try
        {
            myWriter = new StreamWriter(objRequest.GetRequestStream());
            myWriter.Write(url);
        }
        catch (Exception e)
        {
            return e.Message;
        }
        finally
        {
            myWriter.Close();
        }

        HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
        using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
        {
            result = sr.ReadToEnd();
            // Close and clean up the StreamReader
            sr.Close();
        }
        return result;
    }
    string smsstatus = string.Empty;
    string emailstatus = string.Empty;
    public string sendSMS_new()
    {

        DAL dal = new DAL();
        string website1 = "";
        string txtApiurl = "";
        string txtApikeys = "";
        string txtSender = "";
        string companyname = "";
        string message = string.Empty;

        DataTable dt = dal.Gettable("select api_key,url,sender,Status from Smsmaster Where Status='" + smsstatus + "'", ref message);
        DataTable dt1 = dal.Gettable("Select CompanyName,Website from Companyinfo", ref message);

        if (dt.Rows.Count > 0)
        {
            txtApiurl = dt.Rows[0]["url"].ToString();
            txtApikeys = dt.Rows[0]["api_key"].ToString();
            txtSender = dt.Rows[0]["sender"].ToString();
            string status = dt.Rows[0]["Status"].ToString();
            website1 = dt1.Rows[0]["Website"].ToString();
            companyname = dt1.Rows[0]["CompanyName"].ToString();
        }

        //end
        String result;

        string apiKey = txtApikeys.ToString(); ;

        string numbers = txtphnno.Text; // in a comma seperated list


        string sms = "Congratulations, Dear '" + txtname.Text + "' Welcome To " + companyname + " Your Account Created Successfully.Your Customer ID: '" + lblUserId.Text + "'Password:'" + txtpwd.Text + "'.For More Info Visit '" + website1 + "'";



        String url = "" + txtApiurl + "" + apiKey + "&numbers=" + numbers + "&message=" + sms + "&sender=" + txtSender;
        //refer to parameters to complete correct url string

        StreamWriter myWriter = null;
        HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

        objRequest.Method = "POST";
        objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
        objRequest.ContentType = "application/x-www-form-urlencoded";
        try
        {
            myWriter = new StreamWriter(objRequest.GetRequestStream());
            myWriter.Write(url);
        }
        catch (Exception e)
        {
            return e.Message;
        }
        finally
        {
            myWriter.Close();
        }

        HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
        using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
        {
            result = sr.ReadToEnd();

            sr.Close();
        }
        return result;
    }

    public void SendMsg()
    {
        DAL dal = new DAL();

        string url = "";
        string username = "";
        string key = "";
        string request = "";
        string sender = "";
        string route = "";
        int sms = 0;
        string status = "";
        string message = string.Empty;
        DataTable dt2 = dal.Gettable("Select RegistrationSMS,RegistrationEmail from SMS_Email_Notification", ref message);
        smsstatus = dt2.Rows[0]["RegistrationSMS"].ToString();
        emailstatus = dt2.Rows[0]["RegistrationEmail"].ToString();
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='" + smsstatus + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            url = dt.Rows[0]["APIurl"].ToString();
            username = dt.Rows[0]["Username"].ToString();
            key = dt.Rows[0]["APIkey"].ToString();
            request = dt.Rows[0]["APIrequest"].ToString();
            sender = dt.Rows[0]["Sender"].ToString();
            route = dt.Rows[0]["Route"].ToString();
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());

            if (sms != 0)
            {

                string text = "Congratulations, Dear User Your Account Has Been Created Successfully. Your User ID: " + lblUserId.Text + " and password:" + txtname.Text + ". Thank You. ";
                try
                {
                    string jsonValue = "";
                    string sURL;
                    StreamReader objReader;
                    // sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + username + "&password=" + password + "&sender=" + senderId + "&to=" + txtmobileNo.Text + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + routeId + "";
                    // sURL = "http://sms.probuztech.com/sms-panel/api/http/index.php?username=WYSE&apikey=FC144-3DD84&apirequest=Text&sender=PROBUZ&mobile=8055002299&message=TEST&route=TRANS&format=JSON";
                    sURL = "" + url + "?username=" + username + "&apikey=" + key + "&apirequest=" + request + "&sender=" + sender + "&mobile=" + txtphnno.Text + "&message=" + text + "&route=" + route + "&format=JSON";
                    WebRequest wrGETURL;
                    wrGETURL = WebRequest.Create(sURL);
                    try
                    {
                        Stream objStream;
                        objStream = wrGETURL.GetResponse().GetResponseStream();
                        objReader = new StreamReader(objStream);
                        jsonValue = objReader.ReadToEnd();
                        var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                        string status1 = myDetails.status;
                        if (status1 == "error")
                        {
                            SMSHistory(lblUserId.Text, txtname.Text, txtphnno.Text, text, "Not Send");
                        }
                        else
                        {
                            SMSdebit();
                            SMSHistory(lblUserId.Text, txtname.Text, txtphnno.Text, text, "Send");
                        }

                        objReader.Close();
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
    }
    public void Clear()
    {
        txtsponsorid.Text = "";
        lblsponsorname.Text = "";
        txtname.Text = "";
        txtphnno.Text = "";
        txtemail.Text = "";
        txtpwd.Text = "";
        txtconfirmpwd.Text = "";
        if (ViewState["PlaceunderID"] != null)
        {
            ViewState["PlaceunderID"] = null;
        }
    }

    protected void SendEmail()
    {
        //string email = "";
        //string password = "";
        //DAL dal = new DAL();
        //string message = string.Empty;
        //StringBuilder sb = new StringBuilder();
        //sb.AppendFormat("select Emailid,EmailPassword from Adminlogin");
        //DataTable dt = dal.Gettable(sb.ToString(), ref message);
        //if (dt.Rows.Count > 0)
        //{
        //    email = dt.Rows[0]["Emailid"].ToString();
        //    password = dt.Rows[0]["EmailPassword"].ToString();
        //}

        string date = DateTime.Now.ToString("dd/MM/yyyy");
        string MSG = "<table><tr><th><b>Dear Member,</b></th></tr><tr><td>Congratulations!!! Your Registration has been done Successfully . Your Login Credentials are given Below:</td></tr><tr><td><b>UserID: '" + lblUserId.Text + "'</b></td></tr><tr><td><b>Password:'" + ViewState["Pass"] + "' </b></td></tr><tr><td><b>Regards<b></td></tr><tr><td>demosite</td></tr><tr><td>http://demosite.com</td></tr><tr><td>Date:'" + date + "'</td></tr></table>";
        const string SERVER = "mail.probuztech.co.in";
        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        mail.To.Add(txtemail.Text);
        mail.From = new MailAddress("no_reply@probuztech.co.in", "", System.Text.Encoding.UTF8);
        mail.Subject = "Registration Confirmation";
        mail.SubjectEncoding = System.Text.Encoding.UTF8;
        mail.Body = MSG;
        mail.BodyEncoding = System.Text.Encoding.UTF8;
        mail.IsBodyHtml = true;
        mail.Priority = MailPriority.High;
        SmtpClient client = new SmtpClient("mail.probuztech.co.in", 587);
        client.Credentials = new System.Net.NetworkCredential("no_reply@probuztech.co.in", "No@123");
        client.UseDefaultCredentials = false;
        try
        {
            client.Send(mail);
            //ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Email sent successfully.');", true); //comment Date :-06-02-2019
        }
        catch (Exception ex)
        {
            Exception ex2 = ex;
            string errorMessage = string.Empty;
            while (ex2 != null)
            {
                errorMessage += ex2.ToString();
                ex2 = ex2.InnerException;
            }
        }
    }


    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {

                DateTime dte = DateTime.Now;
                // DateTime dte = Convert.ToDateTime(Date);
                string lastmonth = dte.Month + "";
                string lastday = dte.Day + "";
                string year = dte.Year + "";

                //lblyear.Text = year;
                Session["Company"] = dt.Rows[0]["CompanyName"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    imgLogo.ImageUrl = "data:image/png;base64," + base64String;
                    ViewState["Logo"]= "data:image/png;base64," + base64String;
                }
            }
            else
            {
            }
        }
        catch (Exception ex)
        {
            // lblmsg.Visible = true;
            //lblmsg.Text = ex.Message;
            // lblmsg.ForeColor = System.Drawing.Color.Red;
            // lblmsg.BackColor = System.Drawing.Color.White;
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
        }
    }
    public void SendMail(string mailID, string Username1, string userPassword)
    {

        string email = "";
        string password = "";
        string smtp = "";
        int port = 0;
        Boolean ssl = false;
        string logolink = "";
        string loginlink = "";


        DAL dal = new DAL();
        string message1 = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select EmailID,Password,SMTP,PortNo,EnableSSl,Logolink,Loginlink from EmailConfig where Status='" + emailstatus + "'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message1);
        if (dt.Rows.Count > 0)
        {
            email = dt.Rows[0]["EmailID"].ToString();
            password = dt.Rows[0]["Password"].ToString();
            smtp = dt.Rows[0]["SMTP"].ToString();
            port = Convert.ToInt32(dt.Rows[0]["PortNo"].ToString());
            ssl = Convert.ToBoolean(dt.Rows[0]["EnableSSl"].ToString());
            logolink = dt.Rows[0]["Logolink"].ToString();
            loginlink = dt.Rows[0]["Loginlink"].ToString();

            //gather email from form textbox
            string remail = mailID;

            //MailAddress from = new MailAddress("info@paxpluewealth.com");
            MailAddress from = new MailAddress(email);

            MailAddress to = new MailAddress(remail);
            MailMessage message = new MailMessage(from, to);

            message.Subject = Session["Company"].ToString() + " Registration Success";

            //string note = "<div>Hello! <b>'" + txtname.Text + "'</b> </div>";
            //note += "<div><br><p>Your Registerd Username IS : <b>'" + Username1 + "'</b> AND Password IS : <b>'" + userPassword + "'</b>. Keep it secured.<br>Thank You.</p></div>";
            //note += "<div><br>Regards<br><a href='http://www.paxpluewealth.com/Member/login.aspx'>http://www.paxpluewealth.com</a></div>";

            //string note = MailBody(Username1, userPassword, TransactionPassword);

            string note = "<!DOCTYPE html>";
            note += "<html><body>";
            //note += "<h1><img src='" + logolink + "' height=100px width=100px></h1>";
            note += "<h1><img src='" +logolink+ "' height=100px width=100px></h1>";
            note += "<p>Hello <b>'" + txtname.Text + "'</b>,</p>";
            note += "<p>Welcome to <b>" + Session["Company"].ToString() + "</b>, You have Registered successfully with us. We provide you your login Credentials. Please Keep it secure.</p>";
            note += "<p>Following are the log-in Credential.</p>";
            note += "<p><blink><a href='" + loginlink + "' target='_blank'>Click Here</a></blink></p>";
            note += "<p>Username : <b>'" + Username1 + "'</b></p>";
            note += "<p>Password : <b>'" + userPassword + "'</b></p>";
            note += "<br><br><br>";
            note += "<p>Regards</p>";
            note += "<p><a href='" + loginlink + "' target='_blank'>" + Session["Company"].ToString() + "</a><p>";
            note += "</body></html>";

            message.Body = note;
            message.BodyEncoding = System.Text.Encoding.UTF8;
            message.IsBodyHtml = true;

            //SmtpClient client = new SmtpClient("smtp.paxpluewealth.com", 587);
            SmtpClient client = new SmtpClient(smtp, port);
            client.UseDefaultCredentials = false;
            client.EnableSsl = ssl;
            //client.Credentials = new NetworkCredential("info@paxpluewealth.com", "aXGU(nT0");
            client.Credentials = new NetworkCredential(email, password);

            try
            {
                client.Send(message);
            }
            catch (Exception ex)
            {
                //error message?
            }
            finally
            {

            }

        }

    }

    protected void SMSdebit()
    {
        int sms = 0;
        int smsAvailable = 0;
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());
            smsAvailable = sms - 2;

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update SmsmasterNew set CreditSMS='{0}'", smsAvailable);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {

                }
                else
                {
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {

            }

        }


    }
    protected void SMSHistory(string userid, string name, string mobile, string msg, string sts)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sba = new StringBuilder();
        sba.AppendLine("insert into SMSHistory(UserID,Name,Mobileno,Message,Status)");
        sba.AppendFormat("values('{0}','{1}','{2}','{3}','{4}')", userid, name, mobile, msg, sts);
        int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
        if (rowaffected1 > 0)
        {

        }

    }
    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
    }
}