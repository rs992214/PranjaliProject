﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class customer_auth_recoverpw : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    static string Status = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        Showdatalogo();
        showsmssender();
    }
    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {

                lblCompanyname.Text = dt.Rows[0]["CompanyName"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    // imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    imgLogo1.ImageUrl = "data:image/png;base64," + base64String;
                }
            }
            else
            {
            }
        }
        catch (Exception ex)
        {


        }
    }
  
    public void showsmssender()
    {
        DAL dal = new DAL();

        try
        {
            DataTable dt = dal.Gettable("select * from Smsmaster", ref message);
            if (dt.Rows.Count > 0)
            {
                userid = dt.Rows[0]["Userid"].ToString();
                password = dt.Rows[0]["Password"].ToString();
                senderid = dt.Rows[0]["Senderid"].ToString();
                route = dt.Rows[0]["Routeid"].ToString();
                Status = dt.Rows[0]["Status"].ToString();
                if (Status == "Inactive")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('SMS is In inactive Mode.Please Contact to admin For Password.')", true);
                    btnRecover.Enabled = false;
                }
                else
                {
                    btnRecover.Enabled = true;
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Currently SMS Facility is not active.Contact to admin for Password.')", true);
                btnRecover.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }

    protected void btnRecover_Click(object sender, EventArgs e)
    {
        if(txtmobile.Text!=null)
        { 
          try
          {
              DAL dal = new DAL();
              string message = string.Empty;
              StringBuilder sb = new StringBuilder();
              sb.AppendFormat("select UserID,Password,Name,Email from MLM_Registration where UserID='{0}'", txtmobile.Text);
              DataTable dt = dal.Gettable(sb.ToString(), ref message);
              if (dt.Rows.Count > 0)
              {
                  string NAME = dt.Rows[0]["Name"].ToString();
                  string mailID= dt.Rows[0]["Email"].ToString();
                  string Username1= dt.Rows[0]["UserID"].ToString();
                  string userPassword= dt.Rows[0]["Password"].ToString();
                  SendMail(mailID, Username1, userPassword, NAME);
                  string text = "Hello,'" + dt.Rows[0]["Name"].ToString() + "'You Requested For Login Credential.Your Credential Information Are Given Below: AccountNo:'" + dt.Rows[0]["UserID"].ToString() + "', Password:'" + dt.Rows[0]["Password"].ToString() + "'Thank You.";
                  string sURL;
                  StreamReader objReader;

                  sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userid + "&password=" + password + "&sender=" + senderid + "&to=" + txtmobile.Text + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + route + "";

                  //sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=probuz&password=probuz#123&sender=" + senderusername + "" + "&to=" + mobile + "&message=" + txtmessage.Text + " &reqid=1&format={json|text}&route_id=7";
                  WebRequest wrGETURL;
                  wrGETURL = WebRequest.Create(sURL);
                  try
                  {
                      Stream objStream;
                      objStream = wrGETURL.GetResponse().GetResponseStream();
                      objReader = new StreamReader(objStream);
                      objReader.Close();
                      
                      ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Credential Information Send on Your Mobile No. Successfully.')", true);
                  }
                  catch (Exception ex)
                  {
                      ex.ToString();
                  }
              }
              else
              {
                      ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Sorry,Your UserID Is Not Present In Our DataBase.')", true);
                      return;
              }
          }
          catch (Exception ex)
          {
                      string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
                      var script = string.Format("alert({0});", errormessage);
                      ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
          }
          finally
          {
                txtmobile.Text = null;
          }

        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter UserID')", true);
        }
    }
    public void SendMail(string mailID, string Username1, string userPassword,string NAME)
    {
        //gather email from form textbox
        string remail = mailID;

        MailAddress from = new MailAddress("info@paxpluewealth.com");
        MailAddress to = new MailAddress(remail);
        MailMessage message = new MailMessage(from, to);

        message.Subject = "THEALPHATRADE Account Information";

        //string note = "<div>Hello! <b>'" + txtname.Text + "'</b> </div>";
        //note += "<div><br><p>Your Registerd Username IS : <b>'" + Username1 + "'</b> AND Password IS : <b>'" + userPassword + "'</b>. Keep it secured.<br>Thank You.</p></div>";
        //note += "<div><br>Regards<br><a href='http://www.paxpluewealth.com/Member/login.aspx'>http://www.paxpluewealth.com</a></div>";

        //string note = MailBody(Username1, userPassword, TransactionPassword);

        string note = "<!DOCTYPE html>";
        note += "<html><body>";
        //note += "<h1><img src='http://www.paxpluewealth.com/pages/assets/images/pax.png' height=100px width=100px></h1>";
        note += "<h1><img src='http://thealphatrade.in/pages/assets/img/NEWLOGO.png' height=100px width=100px></h1>";
        note += "<p>Hello <b>'" + NAME + "'</b>,</p>";
        note += "<p>Welcome to <b>The Alpha Trade</b>, Your Request is accepted. We provide your login credentials. Please Keep it secure.</p>";
        note += "<p>Following are the log-in Credential.</p>";
        note += "<p>Username : <b>'" + Username1 + "'</b></p>";
        note += "<p>Password : <b>'" + userPassword + "'</b></p>";
        //note += "<p>Transaction Password : <b>'" + TransactionPassword + "'</b></p>";
        note += "<br><br><br>";
        note += "<p>Regards</p>";
        note += "<p><a href='http://thealphatrade.in/customer/auth-login' target='_blank'>THEALPHATRADE</a><p>";
        note += "</body></html>";

        message.Body = note;
        message.BodyEncoding = System.Text.Encoding.UTF8;
        message.IsBodyHtml = true;

        //SmtpClient client = new SmtpClient("mail.probuztech.co.in", 587);
        SmtpClient client = new SmtpClient("smtp.paxpluewealth.com", 587);
        client.UseDefaultCredentials = false;
        client.EnableSsl = false;
        client.Credentials = new NetworkCredential("info@paxpluewealth.com", "aXGU(nT0");

        try
        {
            client.Send(message);
        }
        catch (Exception ex)
        {
            //error message?
        }
        finally
        {

        }
    }
}