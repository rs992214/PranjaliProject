﻿using DataAccessLayer;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_MobileRecharge : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DAL dal = new DAL();
    string message = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        GetRechargeMaster();
        if (!IsPostBack)
        {
            GetWalletBalance();
        }
    }

    public void GetRechargeMaster()
    {
        try
        {
            DataTable dt = dal.Gettable("SELECT * FROM RechargeMaster WHERE Status = 'Active'", ref message);
            if (dt.Rows.Count > 0)
            {
                hdUserID.Value = dt.Rows[0]["UserID"].ToString();
                hdKey.Value = dt.Rows[0]["APIKey"].ToString();
            }
            else
            {
                hdUserID.Value = "";
                hdKey.Value = "";
                EnableFalse_Control();
                ShowPopupMessage("Temporary Out Of Service.", PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    private void EnableFalse_Control()
    {
        txtAmount.Enabled = false;
        txtDescription.Enabled = false;
        btnSave.Enabled = false;
    }
    private void EnableTrue_Control()
    {
        txtAmount.Enabled = true;
        txtDescription.Enabled = true;
        btnSave.Enabled = true;
    }
    private void CheckWithdrawal_Request()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID,Status From WithdrawalRequest Where UserID='" + UserID + "' and Status='REQUEST' ", ref message);
        if (dt.Rows.Count > 0)
        {
            EnableFalse_Control();
            ShowPopupMessage("You have already requested to admin.", PopupMessageType.Message);
        }
        else
        {
            EnableTrue_Control();
        }
    }
    private void GetWalletBalance()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Recharge_Wallet Where UserID='" + UserID + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                lblWalletBalance.Text = dt.Rows[0]["WalletAmount"].ToString();
                decimal WalletBalance = Convert.ToDecimal(lblWalletBalance.Text);
                if (WalletBalance <= 0)
                {
                    EnableFalse_Control();
                    ShowPopupMessage("You have insufficient Wallet Amount For Withdrawal Request.", PopupMessageType.Message);
                }
                else
                {
                    EnableTrue_Control();
                    CheckWithdrawal_Request();
                }
            }
            else
            {
                lblWalletBalance.Text = "0";
                EnableFalse_Control();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void txtAmount_TextChanged(object sender, EventArgs e)
    {
        try
        {
            double amount = Convert.ToDouble(txtAmount.Text);
            double balance = Convert.ToDouble(lblWalletBalance.Text);
            if (balance >= amount)
            {
                btnProceed.Enabled = true;
            }
            else
            {
                btnProceed.Enabled = false;
                ShowPopupMessage("Please Enter Valid Amount.", PopupMessageType.Warning);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.ToString(), PopupMessageType.Error);

        }
    }

    protected void txtMobileNo_TextChanged(object sender, EventArgs e)
    {
        Recharge();
        PlanFinder();
    }

    string circlecode = string.Empty;
    string operatorname = string.Empty;
    void GetRechargeCode()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select * from rechargeoperatorcode Where operatorname='" + hdOperator.Value + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            operatorname = dt.Rows[0]["operatorcode"].ToString();
        }
    }

    void GetCode()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select * from rechargecirclecode Where circlename='" + drpOperatorName.SelectedItem.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            circlecode = dt.Rows[0]["circlecode"].ToString();
        }
    }
    public void PlanFinder()
    {
        GetRechargeMaster();
        GetRechargeCode();
        GetCode();
        string userid = hdUserID.Value;
        string key = hdKey.Value;

        string sURL;
        StreamReader objReader;

        sURL = "https://joloapi.com/api/v1/operatorplanfinder.php?userid='"+userid+"'&key='"+key+"'&operator_code='"+operatorname+"'&circle_code='"+circlecode+"'";
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        WebRequest wrGETURL;
        string jsonValue = "";
        wrGETURL = WebRequest.Create(sURL);
        try
        {
            Stream objStream;
            objStream = wrGETURL.GetResponse().GetResponseStream();
            objReader = new StreamReader(objStream);
            jsonValue = objReader.ReadToEnd();
            var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
            string status = myDetails.status;

            if (status == "FAILED")
            {
                lblMsg.Visible = true;
                lblMsg.Text = myDetails.error;
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                //gvlist.DataSource = myDetails;
                //gvlist.DataBind();

                string json = (new WebClient()).DownloadString("https://raw.githubusercontent.com/aspsnippets/test/master/Customers.json");
                gvlist.DataSource = JsonConvert.DeserializeObject<DataTable>(json);
                gvlist.DataBind();

            }
            objReader.Close();
        }
        catch (Exception ex)
        {
            ex.ToString();
        }
    }

    public void Recharge()
    {
        try
        {
            string userid = hdUserID.Value;
            string key = hdKey.Value;

            string sURL;
            StreamReader objReader;

            sURL = "https://joloapi.com/api/v1/operatorfinder.php?userid=" + userid + "&key=" + key + "&mob=" + txtMobileNo.Text;
            //sURL = "https://joloapi.com/api/demo/operatorfinder.php?userid=" + userid + "&key=" + key + "&mob=" + txtMobileNo.Text;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            WebRequest wrGETURL;
            string jsonValue = "";
            wrGETURL = WebRequest.Create(sURL);
            try
            {
                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                jsonValue = objReader.ReadToEnd();
                var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                string status = myDetails.status;

                if (status == "FAILED")
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = myDetails.error;
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    drpOperatorName.SelectedValue = myDetails.operator_code;
                    hdOperator.Value = drpOperatorName.SelectedValue.ToString();
                    txtOperatorName.Text = myDetails.operator_name;
                    txtCircle.Text = myDetails.circle_name;
                }
                objReader.Close();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserID"] != null)
            {
                double WalletBalance = Convert.ToDouble(lblWalletBalance.Text);
                double RequestAmount = Convert.ToDouble(txtAmount.Text);
                double Balance = 0;

                if (RequestAmount < WalletBalance)
                {
                    Balance = WalletBalance - RequestAmount;
                    if (RequestAmount > 0)
                    {
                        txtDescription.Text = "Recharge Success";
                        string UserID = Session["UserID"].ToString();
                        double CR = 0;
                        double DR = Convert.ToDouble(txtAmount.Text);
                        double Admin = 0;
                        double TDS = 0;
                        double NetAmount = 0;

                        con = new SqlConnection(connstring);
                        con.Open();
                        cmd = new SqlCommand("SP_Recharge_Wallet", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        //withdrawal request tbl
                        cmd.Parameters.AddWithValue("@UserID", UserID);
                        cmd.Parameters.AddWithValue("@DR", DR);
                        cmd.Parameters.AddWithValue("@Descriptions", txtDescription.Text);

                        cmd.Parameters.AddWithValue("@Mode", "RECHARGE");
                        int flag = cmd.ExecuteNonQuery();
                        if (flag > 0)
                        {
                            GetWalletBalance();
                            ShowPopupMessage("Recharge Done Successfully!...", PopupMessageType.Success);
                        }
                        else
                        {
                            ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                        }
                    }
                    else
                    {
                        ShowPopupMessage("User must have minimum 10 Wallet Amount.", PopupMessageType.Message);
                    }
                }
                else
                {
                    ShowPopupMessage("Invalid Amount.", PopupMessageType.Message);
                }


            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
            
        }
    }

    protected void btnProceed_Click(object sender, EventArgs e)
    {
        try
        {
            double amount = Convert.ToDouble(txtAmount.Text);
            double balance = Convert.ToDouble(lblWalletBalance.Text);
            if (balance >= amount)
            {
                Proceed(sender);
                ShowPopupMessage("Success.", PopupMessageType.Warning);
            }
            else
            {
                ShowPopupMessage("Please Enter Valid Amount.", PopupMessageType.Warning);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.ToString(), PopupMessageType.Error);
        }
    }

    public void Proceed(object sender)
    {
        try
        {
            hdOperator.Value = drpOperatorName.SelectedValue.ToString();
            string userid = hdUserID.Value;
            string key = hdKey.Value;
            string Operator = hdOperator.Value;
            string service = txtMobileNo.Text;
            string amount = txtAmount.Text;
            string OrderID = GetUniqueKey(25);

            string sURL;
            StreamReader objReader;

            /// LIVE URL
            sURL = "https://joloapi.com/api/v1/recharge.php?userid=" + userid + "&key=" + key + "&operator=" + Operator + "&service=" + service + "&amount=" + amount + "&orderid=" + OrderID;

            //sURL = "https://joloapi.com/exampleresponse/transaction.txt";

            /// DEMO URL
            //sURL = "https://joloapi.com/api/demo/recharge.php?userid=gopal007&key=338005501233751&operator=JO&service=9356272564&amount=10&orderid=12345";
            WebRequest wrGETURL;
            string jsonValue = "";
            wrGETURL = WebRequest.Create(sURL);
            try
            {
                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                jsonValue = objReader.ReadToEnd();
                var myDetails = JsonConvert.DeserializeObject<MobileRecharge>(jsonValue);
                string status = myDetails.status;

                if (status == "FAILED")
                {
                    lblMsg.Visible = true;
                    lblMsg.Text = myDetails.error;
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    DAL mob = new DAL();
                    string message = string.Empty;
                    string txid1 = myDetails.txid;
                    string Operator1 = myDetails.Operator;
                    string service1 = myDetails.service;
                    string amount1 = myDetails.amount;
                    string orderid1 = myDetails.orderid;
                    string operatorid1 = myDetails.operatorid;
                    string balance1 = myDetails.balance;
                    string margin1 = myDetails.margin;
                    string UserID = Session["UserID"].ToString();

                    if (Convert.ToDouble(balance1) <= 0)
                    {
                        balance1 = "0";
                    }

                    int index = mob.Executequery("INSERT INTO Recharge_Wallet(UserID, TransactionType, CR, DR, Descriptions, CreationDate, transactiondate)VALUES('" + UserID + "', 'DR', 0, " + amount1 + ", 'Mobile Recharge', GETDATE(), GETDATE())", ref message);
                    if (index > 0)
                    {
                        StringBuilder str = new StringBuilder();
                        str.AppendFormat("INSERT INTO Margin_History(UserID, TxnID, Operator, Service, Amount, OrderID, OperatorID, Balance, Margin, CreationDate, Descriptions) ");
                        str.AppendFormat("VALUES('" + UserID + "', '" + txid1 + "', '" + Operator1 + "', '" + service1 + "', " + amount1 + ", '" + OrderID + "', '" + operatorid1 + "', " + balance1 + ", " + margin1 + ", GETDATE(), 'Mobile Recharge')");

                        int index2 = mob.Executequery(str.ToString(), ref message);
                        if (index2 > 0)
                        {
                            //btnSave_Click(sender, new EventArgs());
                            lblMsg.Visible = true;
                            lblMsg.Text = "Recharge Done Successfully.";
                            lblMsg.ForeColor = System.Drawing.Color.Green;

                            txtMobileNo.Text = "";
                            txtOperatorName.Text = "";
                            txtCircle.Text = "";
                            txtAmount.Text = "";
                            hdOperator.Value = "";
                        }
                    }
                }
                objReader.Close();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    public class MobileRecharge
    {
        public string status
        {
            get;
            set;
        }
        public string error
        {
            get;
            set;
        }
        public string txid
        {
            get;
            set;
        }
        public string Operator
        {
            get;
            set;
        }
        public string service
        {
            get;
            set;
        }
        public string amount
        {
            get;
            set;
        }
        public string orderid
        {
            get;
            set;
        }
        public string operatorid
        {
            get;
            set;
        }
        public string balance
        {
            get;
            set;
        }
        public string margin
        {
            get;
            set;
        }
    }

    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }



    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("../customer/auth-withdrawallist.aspx");
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
        public string error
        {
            get;
            set;
        }
        public string operator_code
        {
            get;
            set;
        }
        public string operator_name
        {
            get;
            set;
        }
        public string circle_code
        {
            get;
            set;
        }
        public string circle_name
        {
            get;
            set;
        }
        public string current_type
        {
            get;
            set;
        }
        public string hits_left
        {
            get;
            set;
        }
    }

    protected void btnselect_Command(object sender, CommandEventArgs e)
    {

    }
}