﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_myinvoice : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShowInvoices();
            }
            else
            {
                Response.Redirect("Logout.aspx");

            }
        }
    }

    public void ShowInvoices()
    {
        DAL dal = new DAL();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select OrderID as [Order No],InvoiceNo As [Invoice No],convert(nvarchar(10),Date,103) as [Invoice Date],TotalAmount As [Invoice Amount],TotalSV,PaymentStatus as [Order Status] from BBOOredertbl where OrderBy ='{0}' and Date between '2019-08-11' and '" + DateTime.Now.ToString("yyyy-MM-dd") + "' order by BBO_ID desc", Session["UserID"].ToString());
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowInvoices();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string invoiceno = GridView1.SelectedRow.Cells[2].Text;
        Response.Redirect("auth-ReceiptPKG.aspx?invoiceNo=" + invoiceno, false);
    }
}