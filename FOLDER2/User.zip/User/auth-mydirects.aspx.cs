﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using DataAccessLayer;
using System.Collections;
using System.Configuration;


public partial class customer_auth_mydirects : System.Web.UI.Page
{
    string message = string.Empty;
    ArrayList UserIDRightList = new ArrayList();
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShowMembersofteam();
                ShowleftrightBV(Session["UserID"].ToString());
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    //protected void Page_LoadComplete(object sender, EventArgs e)
    //{
    //    ShowMembersofteam();
    //}

    public void ShowleftrightBV(string UserID)
    {
        string USERIDBV = UserID;
        SqlConnection con = new SqlConnection(connstring);
        SqlCommand mcmd1 = new SqlCommand("auth_total_Direct", con);
        mcmd1.CommandType = CommandType.StoredProcedure;
        mcmd1.Parameters.AddWithValue("@SessionID", USERIDBV);
        SqlDataAdapter sda = new SqlDataAdapter(mcmd1);
        DataTable dtd = new DataTable();
        sda.Fill(dtd);
        if (dtd.Rows.Count > 0)
        {
            lblTeamacounts.Text = dtd.Rows[0]["LEFTDIRECT"].ToString();
            lblTeambcounts.Text = dtd.Rows[0]["RIGHTDIRECT"].ToString();



        }
    }

    public void ShowMembersofteamA(string Leftuserid)
    {
        try
        {
            List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
            string L = null;
            string R = null;
            string UserID = Leftuserid;
            DataTable dtUser1 = new DataTable();
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    dtUser1 = dal.Gettable("select SponsorID,UserID,Name,JoinType,Mobile,Email,CONVERT(nvarchar,JoinDate,105)As JoinDate from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtUser1.Rows.Count > 0)
                    {
                        string sponsorid = dtUser1.Rows[0]["SponsorID"].ToString();
                        if (Session["UserID"].ToString().ToUpper() == sponsorid.ToUpper())
                        {
                            detail.Add(new MLMUserDetailProperty
                            {
                                UserID = dtUser1.Rows[0]["UserID"].ToString(),
                                Name = dtUser1.Rows[0]["Name"].ToString(),
                                Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                                Email = dtUser1.Rows[0]["Email"].ToString(),
                                Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                                JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            });
                        }
                        else
                        {
                            //
                        }
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
            GV_UserList_A.DataSource = detail.ToList();
            GV_UserList_A.DataBind();
            //lblTeamacounts.Text = GV_UserList_A.Rows.Count.ToString();
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteamB(string Rightuserid)
    {
        try
        {
            List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
            string L = null;
            string R = null;
            DataTable dtUser1 = new DataTable();
            string UserID = Rightuserid;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    dtUser1 = dal.Gettable("select SponsorID,UserID,Name,JoinType,Mobile,Email,CONVERT(nvarchar,JoinDate,105)As JoinDate from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtUser1.Rows.Count > 0)
                    {
                        string sponsorid = dtUser1.Rows[0]["SponsorID"].ToString();
                        if (Session["UserID"].ToString().ToUpper() == sponsorid.ToUpper())
                        {
                            detail.Add(new MLMUserDetailProperty
                            {
                                UserID = dtUser1.Rows[0]["UserID"].ToString(),
                                Name = dtUser1.Rows[0]["Name"].ToString(),
                                Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                                Email = dtUser1.Rows[0]["Email"].ToString(),
                                Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                                JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            });
                        }
                        else
                        {
                            //
                        }
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }

            } while (UserID != null);
            GV_UserList_B.DataSource = detail.ToList();
            GV_UserList_B.DataBind();
            //lblTeambcounts.Text = GV_UserList_B.Rows.Count.ToString();

        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteam()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            string LeftUser = null;
            string RightUser = null;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();

                if (LeftUser != null)
                {
                    ShowMembersofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowMembersofteamB(RightUser);
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void GV_UserList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_UserList_A.PageIndex = e.NewPageIndex;
        ShowMembersofteam();
    }
    protected void GV_UserList_B_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_UserList_B.PageIndex = e.NewPageIndex;
        ShowMembersofteam();
    }
    protected void lnkview_A_Command(object sender, CommandEventArgs e)
    {
        try
        {
            string UserID = e.CommandArgument.ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select UserID,Name,Mobile,Email,Status,JoinDate from MLM_Registration where UserID='{0}'", UserID);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblnamejoindate.Text = dt.Rows[0]["Name"].ToString() + "/" + dt.Rows[0]["JoinDate"].ToString();
                lblaccountno.Text = dt.Rows[0]["UserID"].ToString();
                lblmobile.Text = dt.Rows[0]["Mobile"].ToString();
                lblemail.Text = dt.Rows[0]["Email"].ToString();
                lbljoiningdate.Text = dt.Rows[0]["JoinDate"].ToString();
                lblstatus.Text = dt.Rows[0]["Status"].ToString();
            }
        }
        catch (Exception)
        {

            throw;
        }
        ModalPopupExtender1.Show();
    }
    protected void lnkview_B_Command(object sender, CommandEventArgs e)
    {
        try
        {
            string UserID = e.CommandArgument.ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select UserID,Name,Mobile,Email,Status,JoinDate from MLM_Registration where UserID='{0}'", UserID);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblnamejoindate.Text = dt.Rows[0]["Name"].ToString() + "/" + dt.Rows[0]["JoinDate"].ToString();
                lblaccountno.Text = dt.Rows[0]["UserID"].ToString();
                lblmobile.Text = dt.Rows[0]["Mobile"].ToString();
                lblemail.Text = dt.Rows[0]["Email"].ToString();
                lbljoiningdate.Text = dt.Rows[0]["JoinDate"].ToString();
                lblstatus.Text = dt.Rows[0]["Status"].ToString();
            }
        }
        catch (Exception)
        {

            throw;
        }
        ModalPopupExtender1.Show();
    }
}