﻿using DataAccessLayer;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_BeneficiaryDetails : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();

    public string key = "";
    public string mode = "";
    public string service = "";
    public string Name = "";
    public string Address = "";
    public string Email = "";
    public string AccountNo = "";
    public string IFSCcode = "";

    public string BeneficiaryID = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                JoloGetAPIKEY();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    protected void JoloGetAPIKEY()
    {
        DataTable dt = dal.Gettable("select APIKey,Mode from JoloGetway where Status='Active'", ref message);
        DataTable dtBeneficiaryID = dal.Gettable("select UserID,AgentMobile,BenificiaryID,CONVERT(nvarchar,AgentVerifyDate,105) as VerifyDate from AgentDetailsJoloGetway where UserID='" + Session["UserID"].ToString() + "'", ref message);

        if (dt.Rows.Count > 0 && dtBeneficiaryID.Rows.Count > 0)
        {
            key = dt.Rows[0]["APIKey"].ToString();
            mode = dt.Rows[0]["Mode"].ToString();
            BeneficiaryID = dtBeneficiaryID.Rows[0]["BenificiaryID"].ToString();
            service = dtBeneficiaryID.Rows[0]["AgentMobile"].ToString();
            getdetails();
        }
        else
        {
            ShowPopupMessage("Error : Payment Getway Could Not Be Working .", PopupMessageType.Success);
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }
    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here
    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
        public string error
        {
            get;
            set;
        }
        public string service
        {
            get;
            set;
        }
        public string beneficiaryid
        {
            get;
            set;
        }
        public string beneficiary_account_no
        {
            get;
            set;
        }
        public string beneficiary_name
        {
            get;
            set;
        }
        public string beneficiary_ifsc
        {
            get;
            set;
        }
        public string beneficiary_bank
        {
            get;
            set;
        }
        public string beneficiary_branch
        {
            get;
            set;
        }
    }


    protected void getdetails()
    {
        if (BeneficiaryID != "")
        {
            string sURL = "http://jolosoft.com/dmr/cdmr_beneficiary_detail.php?mode=" + mode + "&key=" + key + "&beneficiaryid=" + BeneficiaryID + "";
            WebRequest wrGETURL;
            string jsonValue = "";
            wrGETURL = WebRequest.Create(sURL);
            try
            {
                StreamReader objReader;
                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                jsonValue = objReader.ReadToEnd();
                var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                string status = myDetails.status;
                string er = myDetails.error;
                string beneficiaryid = myDetails.beneficiaryid;
                string beneficiary_account_no = myDetails.beneficiary_account_no;
                string beneficiary_ifsc = myDetails.beneficiary_ifsc;
                string beneficiary_name = myDetails.beneficiary_name;
                string beneficiary_bank = myDetails.beneficiary_bank;
                string beneficiary_branch = myDetails.beneficiary_branch;

                if (status == "FAILED")
                {
                    ShowPopupMessage("Error :(" + er + ") .", PopupMessageType.Success);
                }
                else
                {
                    lbluserid.Text = Session["UserID"].ToString();
                    lblbeneficiaryId.Text = beneficiaryid;
                    lblname.Text = beneficiary_name;
                    lblmonile.Text = service;
                    lblaccount.Text = beneficiary_account_no;
                    lblifsc.Text = beneficiary_ifsc;
                    lblbrach.Text = beneficiary_bank;
                    lblbranchName.Text = beneficiary_branch;
                    //ShowPopupMessage("Success :Beneficiary Details.", PopupMessageType.Success);
                }
                objReader.Close();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        else
        {
            ShowPopupMessage("Error :Please Add Beneficiary .", PopupMessageType.Success);
        }
    }
}