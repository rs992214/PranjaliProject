﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.IO;
using System.Net;
//using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;

public partial class customer_dashboardnew : System.Web.UI.Page
{
    DAL dal;
    string message = string.Empty;
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (Session["UserID"]!=null)
            {
                MasterPlutoCoin();
                Wallet();
                matchingincome();
                ROI_Bonus();
                SponsorIncome();
                UpgradeWallet();
                Withdrawalamount();
                directincome();
                latesttransactions();
                graph();
                Todys_Income();
                Weekly_Income();
                PlutoAddress();
                PlutoCoin();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
        else
        {
            PlutoAddress();
            PlutoCoin();
        }
    }

    private void PlutoAddress()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        DataTable dt = dal.Gettable("Select PlutoAddress from MLM_Registration Where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["PlutoAddress"] != DBNull.Value)
            {
                lblPlutoAddress.Text = dt.Rows[0]["PlutoAddress"].ToString();
                //id_plutoaddress.Visible = true;
            }
            else
            {
                //  id_plutoaddress.Visible = false;
                lblPlutoAddress.Text = string.Empty;
            }
        }
        else
        {

        }
    }


    private void Weekly_Income()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0)) As WeeklyIncome From Ledger_Wallet Where UserID='"+UserID+"' and CreationDate BETWEEN (select cast(dateadd(day,-(datepart(dw,getdate())),getdate()) as date)) AND (select cast(dateadd(day,-(datepart(dw,getdate())-1),getdate()) -7 as date)) and  Descriptions in ('ROI INCOME','SPONSER INCOME','MATCHING INCOME','2:1 OR 1:2')", ref message);
        if (dt.Rows.Count > 0)
        {
            lblWeekly_Income.Text = dt.Rows[0]["WeeklyIncome"].ToString();
        }
        else
        {
            lblWeekly_Income.Text = "0.0";
        }
    }
    private void Todys_Income()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0)) As TodaysIncome From Ledger_Wallet Where UserID='" + UserID+ "' and CreationDate=CAST( GETDATE() as date) and  Descriptions in ('ROI INCOME','SPONSER INCOME','MATCHING INCOME','2:1 OR 1:2')", ref message);
        if (dt.Rows.Count > 0)
        {
            lblTodayIncome.Text = dt.Rows[0]["TodaysIncome"].ToString();
        }
        else
        {
            lblTodayIncome.Text = "0.0";
        }
    }
    private void MasterPlutoCoin()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select Dollar from Pluto_Master",ref message);
        if (dt.Rows.Count > 0)
        {
            lblUSD.Text = dt.Rows[0]["Dollar"].ToString();
        }
        else
        {
            lblUSD.Text = "0.0";
        }
    }

    private void PlutoCoin()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0)) As Plutocoin  from Ledger_Wallet where Descriptions in ('UPGRADE PLUTO','Withdrawal Request Pluto') and UserID='" + Session["UserID"]+"'", ref message);
        if (dt.Rows.Count > 0)
        {
            lblPlutoCoin.Text = dt.Rows[0]["Plutocoin"].ToString();
        }
        else
        {
            lblPlutoCoin.Text = "0.0";
        }
    }


    public void graph()
    {
        //string updateProgress = "25";
        //string updateProgress1 = "25";
        //string updateProgress2 = "25";
        //string updateProgress3 = "25";

        string updateProgress = lblMatchingIncome.Text;
        string updateProgress1 = lblS.Text;
        string updateProgress2 = lblRoibonus.Text;
        string updateProgress4 = string.Empty;
        string updateProgress3 =string.Empty ;
        //string updateProgress3 = lblRoibonus.Text;
        ClientScript.RegisterStartupScript(this.GetType(), "updateProgress", "functionName(" + updateProgress + "," + updateProgress1 + "," + updateProgress2 + "," + updateProgress3 + ");ColumnfunctionName1(" + updateProgress + "," + updateProgress1 + "," + updateProgress2 + "," + updateProgress3 + ");", true);
    }


    public void UpgradeWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('UPGRADE WALLET','Current Package Amount!','Transfer Money Debit','Transfer Money Credit')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblupgradewallet.Text = dt.Rows[0]["WalletAmount"].ToString();
                //    lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblupgradewallet.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void directincome()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions='DIRECT INCOME' ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblDirectIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblDirectIncome.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void ROI_Bonus()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions in ('Withdrawal Request ROI','ROI INCOME')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblRoibonus.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblRoibonus.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void Withdrawalamount()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions in ('ROI INCOME','SPONSER INCOME','MATCHING INCOME','2:1 OR 1:2') ", ref message);
            if (dt.Rows.Count > 0)
            {
                // lblDirectIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
                lblMywallet.Text = dt.Rows[0]["WalletAmount"].ToString();
                decimal walletdollar=  Convert.ToDecimal(lblMywallet.Text) * Convert.ToDecimal(lblUSD.Text);
                lblWalletDollar.Text = String.Format("{0:0.00}", walletdollar);
            }
            else
            {
                // lblDirectIncome.Text = "0.00";
                lblMywallet.Text = "0.00";
                lblWalletDollar.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }


    public void SponsorIncome()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions ='SPONSER INCOME'", ref message);
            if (dt.Rows.Count > 0)
            {
               // lblDirectIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
                lblS.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
               // lblDirectIncome.Text = "0.00";
                lblS.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void matchingincome()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions IN ('Matching INCOME','2:1 OR 1:2')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblMatchingIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblMatchingIncome.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    private void latesttransactions()
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();

           // dt = objDAL.Gettable("Select top 10 ID,UserID,TransactionType,CR,DR,Descriptions,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions Not In ('Current Package Amount!','Pin Purchased.') order by CreationDate desc", ref message);
            dt = objDAL.Gettable("Select top 10 * From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions Not In ('Current Package Amount!','Pin Purchased.') order by CreationDate desc", ref message);

            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        latesttransactions();
    }

    string symbol = null;
    protected void GV_LedgerList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            // add the UnitPrice and QuantityTotal to the running total variables

            // CR = Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "CR"));
            ((Label)e.Row.FindControl("lblcr")).Text = symbol;

            //  DR = Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "DR"));
            ((Label)e.Row.FindControl("lbldr")).Text = symbol;

        }
    }



    public void Wallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('MATCHING INCOME','2:1 OR 1:2','Withdrawal Request','SPONSER INCOME')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblwamount.Text = dt.Rows[0]["WalletAmount"].ToString();
                decimal withdrawal_dollar =   Convert.ToDecimal(lblUSD.Text) * Convert.ToDecimal(lblwamount.Text);
                //lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
               lblwithdrawal_dollar.Text = String.Format("{0:0.00}", withdrawal_dollar);
            }
            else
            {
                lblwamount.Text = "0";
                lblwithdrawal_dollar.Text = "0.0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    //private void Demo()
    //{
    //    decimal temp_dollar = Convert.ToDecimal(txtCalculate_In_dollar.Text);
    //    //    decimal value = temp_dollar * Convert.ToDecimal(lblUSD.Text);
    //    string dollar = String.Format("{0:0.00}", temp_dollar * Convert.ToDecimal(lblUSD.Text));
    //    lblConverUsd.Text = dollar;
    //    id_dollar.Visible = true;

    //    ClientScript.RegisterStartupScript(this.GetType(), "updateProgress", "check(" + lblConverUsd.Text +  ","+id_dollar.Visible+");", true);

    //}

    protected void btnConvert_In_Dollar_Click(object sender, EventArgs e)
    {
        if (txtCalculate_In_dollar.Text != string.Empty)
        {
            decimal temp_dollar = Convert.ToDecimal(txtCalculate_In_dollar.Text);
            //    decimal value = temp_dollar * Convert.ToDecimal(lblUSD.Text);
            string dollar = String.Format("{0:0.00}", temp_dollar * Convert.ToDecimal(lblUSD.Text));
            lblConverUsd.Text = dollar;
            id_dollar.Visible = true;
              MasterPlutoCoin();
                Wallet();
                matchingincome();
                ROI_Bonus();
                SponsorIncome();
                UpgradeWallet();
                Withdrawalamount();
                directincome();
                latesttransactions();
                graph();
                Todys_Income();
                Weekly_Income();
        }
        else
        {
            lblConverUsd.Text = "0.0";
        }
    }
}