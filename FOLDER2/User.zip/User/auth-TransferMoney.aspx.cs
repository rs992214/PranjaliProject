﻿using DataAccessLayer;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_TransferMoney : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();

    public string key = "";
    public string mode = "";
    public string service = "";
    public string Name = "";
    public string Address = "";
    public string Email = "";
    public string AccountNo = "";
    public string IFSCcode = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            if (!IsPostBack)
            {
                pkgrid.Visible = true;
                GetWallet();
                TransactionID();
                JoloGetAPIKEY();
                btnSave.Enabled = false;
                txtuserid.Text = Session["UserID"].ToString();

            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    protected void txtuserid_TextChanged(object sender, EventArgs e)
    {

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        btnSave.Enabled = false;
        try
        {
            DataTable dtDirect = dal.Gettable("SELECT UserID FROM MLM_Registration WHERE SponsorID = '" + Session["UserID"].ToString() + "' AND JoinType = 'Paid' ", ref message);

            if (dtDirect.Rows.Count >= 1)

            {
                JoloGetAPIKEY();

                if (txtbenificiaryID.Text != "" && txtmobile.Text != "" && txttransctn.Text != "" && txtremark.Text != "")
                {
                    Name = txtBeneficiaryName.Text;
                    service = txtmobile.Text;
                    IFSCcode = txtIFSC.Text;
                    AccountNo = txtaccount.Text;

                    string sURL = "http://jolosoft.com/dmr/cdmr_transfer.php?mode=" + mode + "&key=" + key + "&service=" + txtmobile.Text + "&beneficiaryid=" + txtbenificiaryID.Text + "&orderid=" + txttransctn.Text + "&amount=" + txtNetAmount.Text + "&remarks=" + txtremark.Text + "";
                    //Response.Write(sURL);
                    //Response.End();
                    WebRequest wrGETURL;
                    string jsonValue = "";
                    wrGETURL = WebRequest.Create(sURL);
                    try
                    {
                        StreamReader objReader;
                        Stream objStream;
                        objStream = wrGETURL.GetResponse().GetResponseStream();
                        objReader = new StreamReader(objStream);
                        jsonValue = objReader.ReadToEnd();
                        var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                        string status = myDetails.status;
                        string er = myDetails.error;
                        if (status == "FAILED")
                        {
                            ShowPopupMessage("Error :Transfer Failed(" + er + ") .", PopupMessageType.Success);
                        }
                        else
                        {
                            //btnSave.Enabled = false;
                            //ShowPopupMessage("Success :Transfer completed successfully.", PopupMessageType.Success);
                            double DR = Convert.ToDouble(txtINRAmount.Text);
                            double Admin = 0;
                            double TDS = 0;
                            double NetAmount = 0;
                            DataTable dtCharges = dal.Gettable("select ISNULL(AdminCharge, 0) AS AdminCharge, ISNULL(TDS, 0) AS TDS from PlanSetting", ref message);
                            if (dtCharges.Rows.Count > 0)
                            {
                                Admin = Convert.ToDouble(dtCharges.Rows[0]["AdminCharge"].ToString());
                                TDS = Convert.ToDouble(dtCharges.Rows[0]["TDS"].ToString());

                                TDS = ((DR * TDS) / 100);
                                Admin = ((DR * Admin) / 100);
                                NetAmount = (DR - (TDS + Admin));
                            }
                            else
                            {
                                Admin = 0;
                                TDS = 0;
                                NetAmount = DR;
                            }
                            TransferLedger(DR, Admin, TDS, NetAmount);
                        }
                        objReader.Close();
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                    }
                }
                else
                {
                    btnSave.Enabled = false;
                    ShowPopupMessage("Error :User Detail Not Get Plz Update Your Profile .", PopupMessageType.Success);
                }
            }
            else
            {
                ShowPopupMessage("User Must Have Minimum 2 Sponsor ID For IMPS Withdrawal.", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.ToString(), PopupMessageType.Error);
        }
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {

    }

    protected void JoloGetAPIKEY()
    {
        DataTable dt = dal.Gettable("select APIKey,Mode from JoloGetway where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            key = dt.Rows[0]["APIKey"].ToString();
            mode = dt.Rows[0]["Mode"].ToString();

            //DataTable dtmobile = dal.Gettable("select Mobile,Name from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", ref message);
            DataTable dtmobile = dal.Gettable("select Mobile,Name from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", ref message);
            if (dtmobile.Rows.Count > 0)
            {
                string mob = dtmobile.Rows[0]["Mobile"].ToString();
                string Name = dtmobile.Rows[0]["Name"].ToString();

                txtmobile.Text = mob;
                txtBeneficiaryName.Text = Name;

                string sURL = "http://jolosoft.com/dmr/cdmr_detail.php?mode=" + mode + "&key=" + key + "&service=" + mob + "";
                WebRequest wrGETURL;
                string jsonValue = "";
                wrGETURL = WebRequest.Create(sURL);
                try
                {
                    StreamReader objReader;
                    Stream objStream;
                    objStream = wrGETURL.GetResponse().GetResponseStream();
                    objReader = new StreamReader(objStream);
                    jsonValue = objReader.ReadToEnd();
                    var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                    string status = myDetails.status;
                    string er = myDetails.error;
                    string beneficiaryid = myDetails.beneficiaryid;
                    if (status == "FAILED")
                    {

                        ShowPopupMessage("Error : (" + er + ") .", PopupMessageType.Success);
                    }
                    else
                    {
                        DataTable dtid = dal.Gettable("select BenificiaryID from AgentDetailsJoloGetway where AgentMobile='" + mob + "'", ref message);
                        if (dtid.Rows.Count > 0)
                        {
                            string beneid = dtid.Rows[0]["BenificiaryID"].ToString();
                            txtbenificiaryID.Text = beneid;
                            //Response.Write("BeneficiaryID=:" + beneid);
                            //Response.End();
                        }
                    }
                    objReader.Close();
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }

            }

        }
        else
        {
            btnSave.Enabled = false;
            ShowPopupMessage("Error : Payment Getway Could Not Be Working .", PopupMessageType.Success);
        }
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }
    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here
    protected void GetAgentBenificiarydetails()
    {

        //string sUrl = "https://jolosoft.com/dmr/cdmr_detail.php?mode=" + mode + "&key=" + key + "&service=" + mo + "";
    }
    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
        public string error
        {
            get;
            set;
        }
        public string service
        {
            get;
            set;
        }
        public string beneficiaryid
        {
            get;
            set;
        }
    }
    private void TransactionID()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        int flag = 1;
        while (flag == 1)
        {
            string COMPNY = "txn";
            string UserID = GetUniqueKey(10);
            SqlCommand cmd = new SqlCommand("MLM_Registration_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", UserID);
            cmd.Parameters.AddWithValue("@Mode", "CHECK_USERID");
            flag = (int)cmd.ExecuteScalar();
            txttransctn.Text = COMPNY + UserID;
        }
        con.Close();

    }
    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }

    protected void GetWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions in ('ROI INCOME','LEVEL INCOME','Withdrawal Amount', 'Transfer Money')", ref message);
            if (dt.Rows.Count > 0)
            {
                double Amount = Convert.ToDouble(dt.Rows[0]["WalletAmount"].ToString());
                double Deduction = ((Amount * 15) / 100);
                double NetAmount = Amount;
                lblwallet.Text = NetAmount.ToString();
            }
            else
            {
                lblwallet.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void TransferLedger(double Amount, double Admin, double TDS, double NetAmount)
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("TransferMoney_Ledger", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
        cmd.Parameters.AddWithValue("@Amount", Amount);
        cmd.Parameters.AddWithValue("@Admin", Admin);
        cmd.Parameters.AddWithValue("@TDS", TDS);
        cmd.Parameters.AddWithValue("@NetAmount", NetAmount);
        cmd.Parameters.AddWithValue("@Mode", "TransferMoney");
        int flag = cmd.ExecuteNonQuery();
        con.Close();
        if (flag > 0)
        {
            btnSave.Enabled = false;
            ShowPopupMessage("Success :Transfer completed successfully.", PopupMessageType.Success);
        }
        else
        {
            btnSave.Enabled = true;
            ShowPopupMessage("ERROR :Transfer Money Failed.", PopupMessageType.Success);
        }
    }

    protected void txtINRAmount_TextChanged(object sender, EventArgs e)
    {
        try
        {
            double limit = 0;
            DataTable dtLimit = dal.Gettable("SELECT MinimumAmount FROM WithdrawalRequestMaster", ref message);
            if (dtLimit.Rows.Count > 0)
            {
                limit = 500;
                /*Convert.ToDouble(dtLimit.Rows[0]["MinimumAmount"].ToString());*/
            }
            else
            {
                limit = 0;
            }

            if (Convert.ToDouble(txtINRAmount.Text) >= limit && Convert.ToDouble(txtINRAmount.Text) <= 5000)
            {
                if (Convert.ToDouble(txtINRAmount.Text) <= Convert.ToDouble(lblwallet.Text))
                {
                    double DollerRate = 0;
                    double WithdrawalAmount = 0;

                    double DR = Convert.ToDouble(txtINRAmount.Text);
                    double Admin = 0;
                    double TDS = 0;
                    double NetAmount = 0;
                    DataTable dtCharges = dal.Gettable("select ISNULL(AdminCharge, 0) AS AdminCharge, ISNULL(TDS, 0) AS TDS from PlanSetting", ref message);
                    if (dtCharges.Rows.Count > 0)
                    {
                        Admin = Convert.ToDouble(dtCharges.Rows[0]["AdminCharge"].ToString());
                        TDS = Convert.ToDouble(dtCharges.Rows[0]["TDS"].ToString());

                        TDS = ((DR * TDS) / 100);
                        Admin = ((DR * Admin) / 100);
                        NetAmount = (DR - (TDS + Admin));
                    }
                    else
                    {
                        Admin = 0;
                        TDS = 0;
                        NetAmount = DR;
                    }
                    //ShowPopupMessage("DONE", PopupMessageType.Success);
                    WithdrawalAmount = NetAmount;
                    //txtINRAmount.Text = (NetAmount * DollerRate).ToString();
                    txtNetAmount.Text = (Math.Round((NetAmount) - 15)).ToString();
                    double a;
                    a = Convert.ToDouble(txtINRAmount.Text) % 100;

                    if (Convert.ToDouble(txtINRAmount.Text) >= 500 && a == 0)
                    {
                        btnSave.Enabled = true;
                    }
                    else
                    {
                        lblmsg.Text = "Error: It should be multiple of 100 rs...";
                        lblmsg.ForeColor = Color.Red;
                        btnSave.Enabled = false;
                    }
                }
                else
                {
                    txtINRAmount.Text = string.Empty;
                    txtNetAmount.Text = string.Empty;
                    ShowPopupMessage("Error: Insufficient Amount In Wallet ", PopupMessageType.Error);
                    lblmsg.Text = "Error: Incorrect Amount...";
                    lblmsg.ForeColor = Color.Red;
                    btnSave.Enabled = false;
                }
            }
            else
            {
                txtNetAmount.Text = string.Empty;
                txtINRAmount.Text = string.Empty;
                ShowPopupMessage("Error: Minimun Withdrawal Amount Should Be " + limit + "and maxi limit 5000", PopupMessageType.Error);
                lblmsg.Text = "Error: Minimun Withdrawal Amount Should Be " + limit + " and maxi limit 5000";
                lblmsg.ForeColor = Color.Red;
                btnSave.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.ToString(), PopupMessageType.Error);
        }
    }
}