﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class customer_idverfication : System.Web.UI.Page
{
    DAL dal;
    string message;
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(connstring);
        cmd = new SqlCommand();
        cmd.Connection = con;
        if (Session["UserID"]!=null)
        {
            if (!IsPostBack)
            {
                  ShowCountry();
                  // ShowStateName();
              //  drpcity.Items.Insert(0, new ListItem("Select City", "0"));
                LoadData();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    private void BTCAddress()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("Select BTC_Address,TRON_Address,Ethereum_Address from MLM_UserDetail  where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtBTC_Address.Text = dt.Rows[0]["BTC_Address"].ToString();
            txtTron.Text = dt.Rows[0]["TRON_Address"].ToString();
            txtEthereum.Text = dt.Rows[0]["Ethereum_Address"].ToString();
            if (!string.IsNullOrEmpty(txtBTC_Address.Text)|| !string.IsNullOrEmpty(txtTron.Text)|| !string.IsNullOrEmpty(txtEthereum.Text))
            {
                txtBTC_Address.Text = dt.Rows[0]["BTC_Address"].ToString();
                txtTron.Text = dt.Rows[0]["TRON_Address"].ToString();
                txtEthereum.Text = dt.Rows[0]["Ethereum_Address"].ToString();
            }
        }
    }
    public void ShowStateName()
    {
        try
        {
            drpstate.DataTextField = "StateName";
            drpstate.DataValueField = "StateID";
            // State St = new State();
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("Select StateID,StateName from [State] where CountryID="+ddlCountry.SelectedValue, ref message);
          //  DataTable dt = St.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                drpstate.DataSource = dt;
                drpstate.DataBind();
                drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));

            }
            else
            {
                drpstate.DataSource = null;
                drpstate.DataBind();
                drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));
            }
            
        }
        catch (Exception ex)
        {

         //   ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    public void ShowCityName()
    {

        drpcity.DataTextField = "CityName";
        drpcity.DataValueField = "CityID";
        CityProperty Cp = new CityProperty();
        Cp.StateID = Convert.ToInt32(drpstate.SelectedValue);
        try
        {
            City cty = new City();
            DataTable dt = cty.GetData(Cp, ref message);
            if (dt.Rows.Count > 0)
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
            }
            else
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
            }
        }
        catch (Exception ex)
        {
           // ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    private void LoadData()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("select State,City,CityName,Country,CountryName,Nationality,Address,Telegram,AddressLine2,CityName,StateName,Country,Zipcode from MLM_UserDetail where UserID='" + Session["UserID"].ToString() + "'",ref message);
        if (dt.Rows.Count>0)
        {
            if (dt.Rows[0]["Address"] != DBNull.Value && dt.Rows[0]["Telegram"] != DBNull.Value && dt.Rows[0]["AddressLine2"] != DBNull.Value && dt.Rows[0]["CityName"] != DBNull.Value && dt.Rows[0]["StateName"] != DBNull.Value && dt.Rows[0]["Country"] != DBNull.Value && dt.Rows[0]["Zipcode"] != DBNull.Value)
            {
                dal = new DAL();
                DataTable dt1 = dal.Gettable("select Lastname,DOB,Name,Email,Mobile from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", ref message);
                if (dt.Rows.Count > 0)
                {
                    btnSubmit.Visible = false;
                    btnUpdate.Visible = true;
                    BTCAddress();
                    txtFname.Text = dt1.Rows[0]["Name"].ToString();
                    txtLname.Text = dt1.Rows[0]["Lastname"].ToString();
                    txtEmail.Text = dt1.Rows[0]["Email"].ToString();
                    txtPhone.Text = dt1.Rows[0]["Mobile"].ToString();
                    txtDOB.Text = Convert.ToDateTime(dt1.Rows[0]["DOB"].ToString()).ToString("yyyy-MM-dd");

                    txtAddress1.Text = dt.Rows[0]["Address"].ToString();
                    txtTelegram.Text = dt.Rows[0]["Telegram"].ToString();
                    txtAddress2.Text = dt.Rows[0]["AddressLine2"].ToString();
                    //   txtCity.Text = dt.Rows[0]["CityName"].ToString();
                    // txtState.Text = dt.Rows[0]["StateName"].ToString();
                    txtNationality.Text = dt.Rows[0]["Nationality"].ToString();
                    RequiredFieldValidator11.InitialValue = "1";
                    txtZipcode.Text = dt.Rows[0]["Zipcode"].ToString();
                    // ddlCountry.FindControl(dt.Rows[0]["Country"].ToString());

                    string CountryID = dt.Rows[0]["Country"].ToString();
                    if (!string.IsNullOrEmpty(CountryID))
                    {
                        ddlCountry.ClearSelection();
                      //  drpstate.Items.FindByValue(dt.Rows[0]["State"].ToString()).Selected = true;
                        ddlCountry.Items.FindByValue(dt.Rows[0]["Country"].ToString()).Selected = true;
                      //  drpstate.Enabled = false;
                         ddlCountry.Enabled = false;
                        ShowStateName();
                       // ShowCityName();
                      //  drpcity.ClearSelection();
                        string cityid = dt.Rows[0]["CityName"].ToString();
                        if (!string.IsNullOrEmpty(cityid))
                        {
                            txtCity.Text = dt.Rows[0]["CityName"].ToString();
                            txtCity.Enabled = false;
                          //  drpcity.Items.FindByValue(dt.Rows[0]["CityName"].ToString()).Selected = true;
                          //  drpcity.Enabled = false;
                        }
                    }

                    string Stateid = dt.Rows[0]["State"].ToString();
                    if (!string.IsNullOrEmpty(Stateid))
                    {
                        drpstate.ClearSelection();
                        drpstate.Items.FindByValue(dt.Rows[0]["State"].ToString()).Selected = true;
                        drpstate.Enabled = false;
                      //  ShowCityName();
                      //  drpcity.ClearSelection();
                        string cityid = dt.Rows[0]["CityName"].ToString();
                        if (!string.IsNullOrEmpty(cityid))
                        {
                            txtCity.Text = dt.Rows[0]["CityName"].ToString();
                            txtCity.Enabled = false;
                            //    drpcity.Items.FindByValue(dt.Rows[0]["CityName"].ToString()).Selected = true;
                            //    drpcity.Enabled = false;
                        }
                    }
                }
            }
            else
            {
                btnSubmit.Visible = true;
            }
        }
    }
    public void ShowCountry()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("select * from [dbo].[CountryMaster]", ref message);
        if (dt.Rows.Count > 0)
        {
            ddlCountry.DataSource = dt;
            ddlCountry.DataTextField = "Name";
            ddlCountry.DataValueField = "ID";
            ddlCountry.DataBind();
            ddlCountry.Items.Insert(0, new ListItem("--Select Country--", "0"));
        }
        else
        {

        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            cmd.CommandText ="sp_Update_UserProfile";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID",Session["UserID"].ToString());
            cmd.Parameters.AddWithValue("@Fname",txtFname.Text);
            cmd.Parameters.AddWithValue("@Lname",txtLname.Text);
            cmd.Parameters.AddWithValue("@Email",txtEmail.Text);
            cmd.Parameters.AddWithValue("@Mobile",txtPhone.Text);
            cmd.Parameters.AddWithValue("@DOB",txtDOB.Text);
            cmd.Parameters.AddWithValue("@Telegram",txtTelegram.Text);
            cmd.Parameters.AddWithValue("@Address",txtAddress1.Text);
            cmd.Parameters.AddWithValue("@AddressLine2",txtAddress2.Text);
            cmd.Parameters.AddWithValue("@CityName", txtCity.Text);
            cmd.Parameters.AddWithValue("@StateName",drpstate.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@State",drpstate.SelectedValue);
            cmd.Parameters.AddWithValue("@City",drpcity.SelectedValue);
            cmd.Parameters.AddWithValue("@Country", ddlCountry.SelectedValue);
            cmd.Parameters.AddWithValue("@CountryName",ddlCountry.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Nationality", txtNationality.Text);
            cmd.Parameters.AddWithValue("@Zipcode",txtZipcode.Text);
            cmd.Parameters.AddWithValue("@BTC_Address", txtBTC_Address.Text);
            cmd.Parameters.AddWithValue("@TRON", txtTron.Text);
            cmd.Parameters.AddWithValue("@Ethereum ", txtEthereum.Text);
            cmd.Parameters.AddWithValue("@mode","Update");
            con.Open();
            if (cmd.ExecuteNonQuery()>0)
            {
                btnSubmit.Visible = false;
                btnUpdate.Visible = true;
                LoadData();
                ScriptManager.RegisterStartupScript(this, GetType(), "", "alert('Information Updated Successfully!')", true);
            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            
        }
        finally
        {
            con.Close();
        }
    }

    protected void drpstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowCityName();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        Response.Redirect("profile-verfication.aspx");
    }
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowStateName();
    }
}