

Please Check database which is connected to our demo binary project...


     Table --- MLM_UserDetails

     Column Name Country---- Change datatype ---- int to nvarchar(250)