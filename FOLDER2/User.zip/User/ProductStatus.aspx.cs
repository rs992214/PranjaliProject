﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_ProductStatus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ProductStatus();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }

    }

    public void ProductStatus()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Package, Status from MLM_Registration where UserID='" + Session["UserID"] + "'", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                lblProductName.Visible = true;
                lblProductName.Text = dt.Rows[0]["Package"].ToString();
                lblStatus.Visible = true;
                lblStatus.Text= dt.Rows[0]["Status"].ToString();
            }
        }
        catch (Exception ex)
        {
        }

        finally
        {
            con.Close();
        }
    }
}