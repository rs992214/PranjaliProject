﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Net;

public partial class customer_auth_withdrawallist : System.Web.UI.Page
{
    string Password = "";
    string UserID = "";
    string LoginIP = GetLocalIPAddress();
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                int amount = Convert.ToInt32(Request.QueryString["amount"]);
                if (amount > 0)
                {
                    ShowPopupMessage("Your Request has been send to Admin.", PopupMessageType.Success);
                }
                // GetData();
                LoadData();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    private void GetData()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            MLMUserDetailProperty MDP = new MLMUserDetailProperty();
            if (txtFrom.Text != string.Empty)
            {
                MDP.FromDate = txtFrom.Text;
            }
            if (txtTo.Text != string.Empty)
            {
                MDP.ToDate = txtTo.Text;
            }

            con = new SqlConnection(connstring);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@UserID", UserID);
            da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
            da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
            da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA_1");
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GV_WithdrawalList.DataSource = dt;
                GV_WithdrawalList.DataBind();
                btnExport.Visible = true;
            }
            else
            {
                GV_WithdrawalList.DataSource = dt;
                GV_WithdrawalList.DataBind();
                btnExport.Visible = false;
                btnPdf.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void GV_WithdrawalList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_WithdrawalList.PageIndex = e.NewPageIndex;
        //GetData();
        LoadData();
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-WithdrawalList.aspx");
    }

    private void LoadData()
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtTo.Text)))
            {
                dt = objDAL.Gettable("select mp.PaymentID,mp.UserID,mp.PayoutAmount,mp.TDS,mp.AdminCharge,mp.NetAmount,mp.Currency,mp.BTC,mp.PLUTO,mp.Date,mp.Status,MMR.BTC_Address from MemberPayment mp inner join MLM_UserDetail MMR ON MMR.UserID=mp.UserID  where (mp.Status='REQUEST' or mp.Status='APPROVED') and cast(mp.Date as date) BETWEEN '" + Convert.ToDateTime(txtFrom.Text).ToString("yyyy-MM-dd") + "'  AND '" + Convert.ToDateTime(txtTo.Text).ToString("yyyy-MM-dd") + "' and mp.UserID='" + UserID + "' order by Date desc  ", ref message);
                // dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "' and CreationDate BETWEEN '" + txtFrom.Text + "' and '" + txtTo.Text + "'  order by CreationDate desc", ref message);
            }
            else
            {
                dt = objDAL.Gettable("select mp.PaymentID,mp.UserID,mp.PayoutAmount,mp.TDS,mp.AdminCharge,mp.NetAmount,mp.Currency,mp.BTC,mp.PLUTO,mp.Date,mp.Status,MMR.BTC_Address from MemberPayment mp inner join MLM_UserDetail MMR ON MMR.UserID=mp.UserID  where (mp.Status='REQUEST' or mp.Status='APPROVED') and  mp.UserID='" + UserID + "' order by Date desc ", ref message);
                //dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "'  order by CreationDate desc", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_WithdrawalList.DataSource = dt;
                GV_WithdrawalList.DataBind();
            }
            else
            {
                GV_WithdrawalList.DataSource = dt;
                GV_WithdrawalList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }


    private void LoadData_Excel_Pdf()
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtTo.Text)))
            {
                dt = objDAL.Gettable("select mp.PaymentID,mp.UserID,mp.PayoutAmount,mp.TDS,mp.AdminCharge,mp.NetAmount,mp.Currency,mp.BTC,mp.PLUTO,mp.Date,mp.Status,MMR.BTC_Address from MemberPayment mp inner join MLM_UserDetail MMR ON MMR.UserID=mp.UserID  where (mp.Status='REQUEST' or mp.Status='APPROVED') and cast(mp.Date as date) BETWEEN '" + Convert.ToDateTime(txtFrom.Text).ToString("yyyy-MM-dd") + "'  AND '" + Convert.ToDateTime(txtTo.Text).ToString("yyyy-MM-dd") + "' and mp.UserID='" + UserID + "' order by Date desc  ", ref message);
                // dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "' and CreationDate BETWEEN '" + txtFrom.Text + "' and '" + txtTo.Text + "'  order by CreationDate desc", ref message);
            }
            else
            {
                dt = objDAL.Gettable("select mp.PaymentID,mp.UserID,mp.PayoutAmount,mp.TDS,mp.AdminCharge,mp.NetAmount,mp.Currency,mp.BTC,mp.PLUTO,mp.Date,mp.Status,MMR.BTC_Address from MemberPayment mp inner join MLM_UserDetail MMR ON MMR.UserID=mp.UserID  where (mp.Status='REQUEST' or mp.Status='APPROVED') and  mp.UserID='" + UserID + "' order by Date desc ", ref message);

                //dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "'  order by CreationDate desc", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                getDataForTrace();
                tracing();
                CreateExcelFile(dt);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //GetData();
        LoadData();

    }
    public void CreateExcelFile(DataTable Excel)
    {

        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=WithdrawalList.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {
            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {
                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";
            }

            Response.Write("\n");


        }
        Response.End();
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserID"] != null)
            {
                #region Unused


                //string UserID = Session["UserID"].ToString();
                //MLMUserDetailProperty MDP = new MLMUserDetailProperty();
                //if (txtFrom.Text != string.Empty)
                //{
                //    MDP.FromDate = txtFrom.Text;
                //}
                //if (txtTo.Text != string.Empty)
                //{
                //    MDP.ToDate = txtTo.Text;
                //}

                //con = new SqlConnection(connstring);
                //con.Open();
                //SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
                //da.SelectCommand.CommandType = CommandType.StoredProcedure;
                //da.SelectCommand.Parameters.AddWithValue("@UserID", UserID);
                //da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
                //da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
                //da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA_1");
                //DataTable dt = new DataTable();
                //da.Fill(dt);
                //if (dt.Rows.Count > 0)
                //{
                //    getDataForTrace();
                //    tracing();
                //    CreateExcelFile(dt);


                //}
                #endregion
                LoadData_Excel_Pdf();
            }
            else
            {

                Response.Redirect("Logout.aspx");
            }


        }
        catch (Exception ex)
        {
            getDataForTrace();
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'Excel Not Downloded Showing Error:'" + error + "'')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    //void CreatePdfFile(DataTable PDF)
    //{
    //    string filename = Guid.NewGuid() + ".pdf";
    //    string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);


    //    Document doc = new Document(PageSize.A4, 10, 10, 30, 10);

    //    Paragraph p = new Paragraph("Withdrawal List");
    //    p.Alignment = Element.ALIGN_CENTER;

    //    try
    //    {
    //        PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
    //        PdfPTable pdfPtable = new PdfPTable(11);

    //        pdfPtable.HorizontalAlignment = 1;
    //        pdfPtable.SpacingBefore = 20f;
    //        pdfPtable.SpacingAfter = 20f;

    //        doc.Open();
    //        DataTable dt = PDF;
    //        if (dt != null)
    //        {
    //            //---- Add Result of DataTable to PDF file With Header -----
    //            PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
    //            pdfTable.DefaultCell.Padding = 3;
    //            pdfTable.WidthPercentage = 100; // percentage
    //            pdfTable.DefaultCell.BorderWidth = 2;
    //            pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

    //            foreach (DataColumn column in dt.Columns)
    //            {
    //                pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
    //            }
    //            pdfTable.HeaderRows = 1; // this is the end of the table header
    //            pdfTable.DefaultCell.BorderWidth = 1;

    //            foreach (DataRow row in dt.Rows)
    //            {
    //                foreach (object cell in row.ItemArray)
    //                {
    //                    //assume toString produces valid output
    //                    pdfTable.AddCell(FormatPhrase(cell.ToString()));
    //                }
    //            }
    //            doc.Add(pdfTable);
    //        }

    //        doc.Close();
    //        byte[] content = File.ReadAllBytes(filepath);

    //        HttpContext context = HttpContext.Current;

    //        context.Response.BinaryWrite(content);
    //        context.Response.ContentType = "application/pdf";
    //        context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
    //        context.Response.End();
    //    }
    //    catch(Exception ex)
    //    {

    //    }
    //}
    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }

    protected void btnPdf_Click(object sender, EventArgs e)
    {

        try
        {
            if (Session["UserID"] != null)
            {
                #region Unused Code
                //string UserID = Session["UserID"].ToString();
                //MLMUserDetailProperty MDP = new MLMUserDetailProperty();
                //if (txtFrom.Text != string.Empty)
                //{
                //    MDP.FromDate = txtFrom.Text;
                //}
                //if (txtTo.Text != string.Empty)
                //{
                //    MDP.ToDate = txtTo.Text;
                //}

                //con = new SqlConnection(connstring);
                //con.Open();
                //SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
                //da.SelectCommand.CommandType = CommandType.StoredProcedure;
                //da.SelectCommand.Parameters.AddWithValue("@UserID", UserID);
                //da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
                //da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
                //da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA_1");
                //DataTable dt = new DataTable();
                //da.Fill(dt);
                //if (dt.Rows.Count > 0)
                //{
                //    getDataForTrace();
                //    tracingPdf();
                //    CreatePdfFile(dt);
                //}
                #endregion
                DataTable dt = new DataTable();
                string UserID = Session["UserID"].ToString();
                DAL objDAL = new DAL();
                if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtTo.Text)))
                {
                    dt = objDAL.Gettable("select mp.PaymentID,mp.UserID,mp.PayoutAmount,mp.TDS,mp.AdminCharge,mp.NetAmount,mp.Currency,mp.BTC,mp.PLUTO,mp.Date,mp.Status,MMR.BTC_Address from MemberPayment mp inner join MLM_UserDetail MMR ON MMR.UserID=mp.UserID  where (mp.Status='REQUEST' or mp.Status='APPROVED') and cast(mp.Date as date) BETWEEN '" + Convert.ToDateTime(txtFrom.Text).ToString("yyyy-MM-dd") + "'  AND '" + Convert.ToDateTime(txtTo.Text).ToString("yyyy-MM-dd") + "' and mp.UserID='" + UserID + "' order by Date desc  ", ref message);
                    // dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "' and CreationDate BETWEEN '" + txtFrom.Text + "' and '" + txtTo.Text + "'  order by CreationDate desc", ref message);
                }
                else
                {
                    dt = objDAL.Gettable("select mp.PaymentID,mp.UserID,mp.PayoutAmount,mp.TDS,mp.AdminCharge,mp.NetAmount,mp.Currency,mp.BTC,mp.PLUTO,mp.Date,mp.Status,MMR.BTC_Address from MemberPayment mp inner join MLM_UserDetail MMR ON MMR.UserID=mp.UserID  where (mp.Status='REQUEST' or mp.Status='APPROVED') and  mp.UserID='" + UserID + "' order by Date desc ", ref message);

                    //dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "'  order by CreationDate desc", ref message);
                }
                if (dt.Rows.Count > 0)
                {
                    getDataForTrace();
                    tracingPdf();
                    CreatePdfFile(dt);
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }

        catch (Exception ex)
        {
            getDataForTrace();
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'PDF Not Downloded Showing Error:'" + error + "'')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }
            ShowPopupMessage(ex.Message, PopupMessageType.Error);

        }
    }
    void CreatePdfFile(DataTable PDF)
    {
        string filename = "Withdrawallist.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);

        Document doc = new Document(PageSize.A4, 10, 10, 40, 10);

        Paragraph p = new Paragraph("");
        p.Alignment = Element.ALIGN_CENTER;

        try
        {

            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(7);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("Withdrawal List Report", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----      
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("../Company/images/Probuzimg.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------


            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "WithdrawalList/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void getDataForTrace()
    {

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("select UserID, Password from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Password = dt.Rows[0]["Password"].ToString();
                UserID = dt.Rows[0]["UserID"].ToString();

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void tracing()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'Excel File downloded Sucessfully for WithdrawalList..!!')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void tracingPdf()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'PDF File downloded Sucessfully for WithdrawalList..!!')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }

}