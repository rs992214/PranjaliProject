﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_Epin_TransferHistory : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            if (!IsPostBack)
            {
                GetData();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    private void GetData()
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtFrom.Text)))
            {
                dt = objDAL.Gettable("select Pg.ID,pg.PinNo,pack.PackageName,Pg.Status,pg.TransferBy,pg.TransferTo,pg.UpdationDate from PinGenerateNew Pg inner join PackageInfo pack on Pg.PackageID=pack.ID where (TransferTo = '" + UserID + "' OR TransferBy='" + UserID + "') And Status='Unused' And Cast(CreationDate as Date) between '" + txtFrom.Text+"' And '"+txtTo.Text+"'", ref message);
            }
            else
            {
                dt = objDAL.Gettable("select Pg.ID,pg.PinNo,pack.PackageName,Pg.Status,pg.TransferBy,pg.TransferTo,pg.UpdationDate from PinGenerateNew Pg inner join PackageInfo pack on Pg.PackageID=pack.ID where (TransferTo = '" + UserID + "' OR TransferBy='" + UserID + "') And Status='Unused'", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
           // ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        GetData();
    }
}