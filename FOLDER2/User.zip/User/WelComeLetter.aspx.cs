﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_WelComeLetter : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                GetMemberDetails();
                GetCompanyDetails();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void GetMemberDetails()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from MLM_Registration MR Inner Join MLM_UserDetail MU On MR.UserID=MU.UserID where MR.UserID='" + Session["UserID"].ToString() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                txtName.Text = dt.Rows[0]["Name"].ToString();
                txtUserid.Text = dt.Rows[0]["UserID"].ToString();
                string doj = dt.Rows[0]["JoinDate"].ToString();
                txtJoindate.Text = Convert.ToDateTime(doj).ToString("dd-MM-yyyy");
                txtAddress.Text = dt.Rows[0]["Address"].ToString();
                txtCity.Text = dt.Rows[0]["City"].ToString();
                txtPincode.Text = dt.Rows[0]["PostalCode"].ToString();
            }
            else
            {
                txtName.Text = string.Empty;
                txtUserid.Text = string.Empty;
                txtJoindate.Text = string.Empty;
                txtAddress.Text = string.Empty;
                txtCity.Text = string.Empty;
                txtPincode.Text = string.Empty;
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message.ToString() + "')", true);
        }
    }
    public void GetCompanyDetails()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from CompanyInfo", ref message);
            if (dt.Rows.Count > 0)
            {
                lbladdress.Text = dt.Rows[0]["Address"].ToString();
                lblemail.Text = dt.Rows[0]["Email"].ToString();
                lblmobno.Text = dt.Rows[0]["PhoneNo"].ToString();
                lblcompanyname1.Text = dt.Rows[0]["CompanyName"].ToString();
                lblcompanyname2.Text = dt.Rows[0]["CompanyName"].ToString();
                lblcompanyname3.Text = dt.Rows[0]["CompanyName"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    imglogo.ImageUrl = "data:image/png;base64," + base64String;
                }
                else
                {
                    imglogo.ImageUrl = "~/pages/images/logo.png";
                }
            }
            else
            {
                lbladdress.Text = string.Empty;
                lblemail.Text = string.Empty;
                lblmobno.Text = string.Empty;
                lblcompanyname1.Text = string.Empty;
                lblcompanyname2.Text = string.Empty;
                lblcompanyname3.Text = string.Empty;
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message.ToString() + "')", true);
        }
    }
}