﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Text;
using System.IO;
using System.Globalization;

public partial class customer_auth_profile : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShowStateName();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
                ShowProfile();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }


        }
    }
    public void ShowStateName()
    {
        try
        {
            drpstate.DataTextField = "StateName";
            drpstate.DataValueField = "StateID";
            State St = new State();

            DataTable dt = St.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                drpstate.DataSource = dt;
                drpstate.DataBind();
                drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));

            }
            else
            {
                drpstate.DataSource = null;
                drpstate.DataBind();
                drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));
            }
        }
        catch (Exception ex)
        {

            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    public void ShowCityName()
    {

        drpcity.DataTextField = "CityName";
        drpcity.DataValueField = "CityID";
        CityProperty Cp = new CityProperty();
        Cp.StateID = Convert.ToInt32(drpstate.SelectedValue);
        try
        {
            City cty = new City();
            DataTable dt = cty.GetData(Cp, ref message);
            if (dt.Rows.Count > 0)
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
            }
            else
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserID"] != null)
            {
                if (fupphoto.HasFile)
                {
                    string UserID = Session["UserID"].ToString();
                    string fileName = Path.GetFileName(fupphoto.PostedFile.FileName);
                    string extension = Path.GetExtension(fupphoto.PostedFile.FileName);

                    if (extension == ".jpg")
                    {
                        // fileName = string.Empty;
                        // fileName = UserID + ".jpg";
                    }
                    else if (extension == ".jpeg")
                    {
                        // fileName = string.Empty;
                        // fileName = UserID + ".jpeg";
                    }
                    else if (extension == ".png")
                    {
                        //fileName = string.Empty;
                        //fileName = UserID + ".png";
                    }
                    string filePath = Server.MapPath("../customer/customerphoto/" + fileName);
                    fupphoto.PostedFile.SaveAs(Server.MapPath("../customer/customerphoto/" + fileName));
                    Image1.ImageUrl = "../customer/customerphoto/" + fileName;

                    DAL dal = new DAL();
                    StringBuilder sb = new StringBuilder();
                    sb.AppendFormat("update MLM_UserDetail set PhotoPath='{0}' where UserID='{1}'", "../customer/customerphoto/" + fileName, Session["UserID"].ToString());
                    int rowaffected = dal.Executequery(sb.ToString(), ref message);
                    if (rowaffected > 0)
                    {
                        ShowPopupMessage("Profile Photo has been Updated.", PopupMessageType.Success);
                        ShowProfile();
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Warning);
                    }


                }
                else
                {
                    ShowPopupMessage("Please Select Profile Photo.", PopupMessageType.Message);
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    public void ShowProfile()
    {
        try
        {
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = Session["UserID"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            if (dt.Rows.Count > 0)
            {

                lblsponsoraccount.Text = dt.Rows[0]["SponsorID"].ToString();
                lblplaceaccountno.Text = dt.Rows[0]["PlaceunderID"].ToString();
                lblaccountno.Text = dt.Rows[0]["UserID"].ToString();
                // lbljoindate.Text = dt.Rows[0]["JoinDate"].ToString();
                //lblactivationdate.Text = Convert.ToDateTime(dt.Rows[0]["PackageDate"]).ToString("dd/MM/yyyy");
                // lblactivationdate.Text = dt.Rows[0]["PackageDate"].ToString();
                // lbldesignation.Text = dt.Rows[0]["PackInfo"].ToString();
                lblstatus.Text = dt.Rows[0]["Status"].ToString();
                txtname.Text = dt.Rows[0]["Name"].ToString();
                if (!string.IsNullOrEmpty(txtname.Text))
                {
                    // txtname.ReadOnly = true;
                }
                string Gender = dt.Rows[0]["Gender"].ToString();
                if (!string.IsNullOrEmpty(Gender))
                {
                    drpgender.ClearSelection();
                    drpgender.Items.FindByText(dt.Rows[0]["Gender"].ToString()).Selected = true;
                    // drpgender.Enabled = false;
                }
                string date = dt.Rows[0]["DOB"].ToString();
                DateTime d1 = Convert.ToDateTime(date);
                txtdob.Text = Convert.ToDateTime(date).ToString("yyyy-MM-dd");

                txtmobile.Text = dt.Rows[0]["Mobile"].ToString();
                if (!string.IsNullOrEmpty(txtdob.Text))
                {
                    //txtmobile.ReadOnly = true;
                }
                txtalternate.Text = dt.Rows[0]["AlternateMobile"].ToString();
                if (!string.IsNullOrEmpty(txtalternate.Text))
                {
                    //txtalternate.ReadOnly = true;
                }
                txtofficeno.Text = dt.Rows[0]["Office"].ToString();
                if (!string.IsNullOrEmpty(txtofficeno.Text))
                {
                    // txtofficeno.ReadOnly = true;
                }
                txtemail.Text = dt.Rows[0]["Email"].ToString();
                if (!string.IsNullOrEmpty(txtemail.Text))
                {
                    // txtemail.ReadOnly = true;
                }
                string Stateid = dt.Rows[0]["State"].ToString();
                if (!string.IsNullOrEmpty(Stateid))
                {
                  //  drpstate.ClearSelection();
                   // drpstate.Items.FindByValue(dt.Rows[0]["State"].ToString()).Selected = true;
                    // drpstate.Enabled = false;
                   // ShowCityName();
                   // drpcity.ClearSelection();
                   // drpcity.Items.FindByValue(dt.Rows[0]["City"].ToString()).Selected = true;
                    // drpcity.Enabled = false;
                }
                //else
                //{
                //    //if(drpstate.Items.Count<0)
                //    //{
                //    drpstate.ClearSelection();
                //    //ShowStateName();
                   
                //    //drpstate.SelectedIndex = 0;
                //    drpcity.Items.Insert(0, new ListItem("Select State", "0"));
                //    //drpstate.Items.FindByValue("0").Selected = true;
                //    //}
                //}
                txtcity.Text = dt.Rows[0]["District"].ToString();
                if (!string.IsNullOrEmpty(txtcity.Text))
                {
                    //txtcity.ReadOnly = true;
                }
                //else
                //{
                //    drpcity.Items.Insert(0, new ListItem("Select District", "0"));
                //    //drpcity.ClearSelection();
                //    ////ShowCityName();
                //    //drpcity.SelectedIndex = 0;
                //    //drpstate.Items.FindByValue("0").Selected = true;
                //}
                txtpostalcode.Text = dt.Rows[0]["PostalCode"].ToString();
                if (!string.IsNullOrEmpty(txtpostalcode.Text))
                {
                    // txtpostalcode.ReadOnly = true;
                }
                txtaddress.Text = dt.Rows[0]["Address"].ToString();
                if (!string.IsNullOrEmpty(txtaddress.Text) && !string.IsNullOrEmpty(txtname.Text))
                {
                    //txtaddress.ReadOnly = true;
                    btnpersonaldetail.Enabled = false;
                }
                txtpayeename.Text = dt.Rows[0]["PayeeName"].ToString();
                if (!string.IsNullOrEmpty(txtpayeename.Text))
                {
                    //txtpayeename.ReadOnly = true;
                }
                txtbankname.Text = dt.Rows[0]["BankName"].ToString();
                if (!string.IsNullOrEmpty(txtbankname.Text))
                {
                    // txtbankname.ReadOnly = true;
                }
                txtbranch.Text = dt.Rows[0]["Branch"].ToString();
                if (!string.IsNullOrEmpty(txtbranch.Text))
                {
                    // txtbranch.ReadOnly = true;
                }
                txtaccountno.Text = dt.Rows[0]["AccountNo"].ToString();
                if (!string.IsNullOrEmpty(txtaccountno.Text))
                {
                    //txtaccountno.ReadOnly = true;
                }
                string Accounttype = dt.Rows[0]["AccountType"].ToString();
                if (!string.IsNullOrEmpty(Accounttype))
                {
                    drpaccounttype.ClearSelection();
                    drpaccounttype.Items.FindByText(dt.Rows[0]["AccountType"].ToString()).Selected = true;
                    // drpaccounttype.Enabled = false;
                }
                txtifsc.Text = dt.Rows[0]["IFSCCode"].ToString();
                if (!string.IsNullOrEmpty(txtifsc.Text))
                {
                    // txtifsc.ReadOnly = true;
                }
                txtpanno.Text = dt.Rows[0]["PANNO"].ToString();
                if (!string.IsNullOrEmpty(txtpanno.Text) && !string.IsNullOrEmpty(txtaccountno.Text))
                {
                    // txtpanno.ReadOnly = true;
                    btnbankdetail.Enabled = false;
                }
                ShowSponsorName();
                string PhotoPath = dt.Rows[0]["PhotoPath"].ToString();
                if (PhotoPath != "")
                {
                    Image1.ImageUrl = dt.Rows[0]["PhotoPath"].ToString();
                }
                else if (PhotoPath == string.Empty)
                {
                    Image1.ImageUrl = "~/customer/assets/images/dummy-profile-pic.png";
                }
                else
                {
                    Image1.ImageUrl = "~/customer/assets/images/dummy-profile-pic.png";
                }
            }

            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowSponsorName()
    {
        //22/10/2019 ShowSponsorName  Check All  SponsorID

        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select Name From MLM_Registration where UserID='{0}'", lblsponsoraccount.Text);
            StringBuilder sba = new StringBuilder();
            sba.AppendFormat("select Name from MLM_Registration where UserID='{0}'", lblplaceaccountno.Text);
            object Sposorname = dal.Getscalar(sb.ToString(), ref message);
            object PlaceName = dal.Getscalar(sba.ToString(), ref message);
            if (Sposorname is DBNull)
            {
                lblsponsorname.Text = "Company";
            }
            else
            {
                if (Sposorname != null)
                {
                    lblsponsorname.Text = Sposorname.ToString();
                }
                else
                {
                    lblsponsorname.Text = "Company";
                }
            }
            if (PlaceName is DBNull)
            {
                lblplaceaccountname.Text = "Company";
            }
            else
            {
                if (PlaceName != null)
                {
                    lblplaceaccountname.Text = PlaceName.ToString();
                }
                else
                {
                    lblplaceaccountname.Text = "Company";
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void drpstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowCityName();
    }

    protected void btnpersonaldetail_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                CultureInfo MyCultureInfo = new CultureInfo("en-IN");
                DateTime date = DateTime.Parse(txtdob.Text, MyCultureInfo);
                DAL dal = new DAL();

                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("update MLM_UserDetail set Gender='{0}',DOB='{1}',AlternateMobile='{2}',Office='{3}',State='{4}',District='{5}',City='{6}',PostalCode='{7}',Address='{8}' where UserID='{9}'", drpgender.SelectedItem.Text, Convert.ToDateTime(date).ToString("yyyy-MM-dd"), txtalternate.Text, txtofficeno.Text, Convert.ToInt32(drpstate.SelectedValue), Convert.ToInt32(drpcity.SelectedValue), txtcity.Text, txtpostalcode.Text, txtaddress.Text, Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                StringBuilder sba = new StringBuilder();
                sba.AppendFormat("update MLM_Registration set Email='{0}',Name='{1}',Mobile='{2}' where UserID='{3}'", txtemail.Text, txtname.Text, txtmobile.Text, Session["UserID"].ToString());
                int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0 && rowaffected1 > 0)
                {
                    ShowPopupMessage("Personal Detail Updated Successfully", PopupMessageType.Success);
                    ShowProfile();

                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
            finally
            {
                ShowProfile();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    protected void btnbankdetail_Click(object sender, EventArgs e)
    {

        //   22/10/2019  Bank Detalis Upload 

        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("update MLM_UserDetail set PayeeName='{0}',BankName='{1}',Branch='{2}',AccountNo='{3}',AccountType='{4}',IFSCCode='{5}',PANNO='{6}' where UserID='{7}'", txtpayeename.Text, txtbankname.Text, txtbranch.Text, txtaccountno.Text, drpaccounttype.SelectedItem.Text, txtifsc.Text, txtpanno.Text, Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowPopupMessage("Bank Detail Update SuccessFully", PopupMessageType.Success);
                    ShowProfile();
                }
                else
                {
                    ShowPopupMessage("Some error occured...", PopupMessageType.Warning);
                }
            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
            finally
            {
                ShowProfile();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }

    }

    protected void btnaddressupdate_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select AddressProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object addressproofobject = dal.Getscalar(sb.ToString(), ref message);

                if (addressproofobject is DBNull)
                {
                    saveAddressProof();
                }
                else
                {
                    ImageDeleteFromFolder(addressproofobject.ToString());
                    saveAddressProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    public void saveAddressProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/customerphoto/");
            if (FileUpload1.HasFile)
            {
                int ContentLength = FileUpload1.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload1.PostedFile.FileName;
                    FileUpload1.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/customerphoto/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                sba.AppendFormat("update MLM_UserDetail set AddressProof='{0}',AddressProofvalue='{1}',AddressProofUrl='{2}',AddressProofvalidate='{3}' where UserID='{4}'", drpaddress.SelectedItem.Text, txtadressproofvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowPopupMessage("Aadhar Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }

    protected void btnidentityupdate_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select IdentityProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object identityproofobject = dal.Getscalar(sb.ToString(), ref message);

                if (identityproofobject is DBNull)
                {
                    saveIdentityProof();
                }
                else
                {
                    ImageDeleteFromFolder(identityproofobject.ToString());
                    saveIdentityProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    public void saveIdentityProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/IdentityProof/");
            if (FileUpload2.HasFile)
            {
                int ContentLength = FileUpload2.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload2.PostedFile.FileName;
                    FileUpload2.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/IdentityProof/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                sba.AppendFormat("update MLM_UserDetail set IdentityProof='{0}',IdentityProofvalue='{1}',IdentityProofUrl='{2}',IdentityProofvalidate='{3}' where UserID='{4}'", drpidentityproof.SelectedItem.Text, txtidentityvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowPopupMessage("PAN Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }

    protected void btnbankproofupdate_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select BankProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object Bankproofobject = dal.Getscalar(sb.ToString(), ref message);

                if (Bankproofobject is DBNull)
                {
                    saveBankProof();
                }
                else
                {
                    ImageDeleteFromFolder(Bankproofobject.ToString());
                    saveBankProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    public void saveBankProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/BankProof/");
            if (FileUpload3.HasFile)
            {
                int ContentLength = FileUpload3.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload3.PostedFile.FileName;
                    FileUpload3.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/BankProof/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                sba.AppendFormat("update MLM_UserDetail set BankProof='{0}',BankProofvalue='{1}',BankProofUrl='{2}',BankProofvalidate='{3}' where UserID='{4}'", drpbankproof.SelectedItem.Text, txtbankproofvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowPopupMessage("Bank Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }


    protected void btngstprrofupdate_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select GSTProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object GstProofObject = dal.Getscalar(sb.ToString(), ref message);

                if (GstProofObject is DBNull)
                {
                    saveGSTProof();
                }
                else
                {
                    ImageDeleteFromFolder(GstProofObject.ToString());
                    saveGSTProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    public void saveGSTProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/gstproof/");
            if (FileUpload4.HasFile)
            {
                int ContentLength = FileUpload4.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload4.PostedFile.FileName;
                    FileUpload4.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/gstproof/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                sba.AppendFormat("update MLM_UserDetail set GST='{0}',GSTProofvalue='{1}',GSTProofUrl='{2}',GSTProofvalidate='{3}' where UserID='{4}'", drpgstproof.SelectedItem.Text, txtgstproofvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowPopupMessage("GST Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }
    protected void btnapplication_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select ApplicationUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object ApplicationProofObject = dal.Getscalar(sb.ToString(), ref message);

                if (ApplicationProofObject is DBNull)
                {
                    saveApplicationProof();
                }
                else
                {
                    ImageDeleteFromFolder(ApplicationProofObject.ToString());
                    saveApplicationProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }


    }
    public void saveApplicationProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/ApplicationProof/");
            if (FileUpload5.HasFile)
            {
                int ContentLength = FileUpload5.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload5.PostedFile.FileName;
                    FileUpload5.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/ApplicationProof/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                sba.AppendFormat("update MLM_UserDetail set Application='{0}',Applicationvalue='{1}',ApplicationUrl='{2}',Applicationvalidate='{3}' where UserID='{4}'", drpapplication.SelectedItem.Text, txtapplicationvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowPopupMessage("Application Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }
    private void ImageDeleteFromFolder(string imagename)
    {
        string file_name = imagename;
        string path = Server.MapPath(imagename);
        if (File.Exists(path)) //check file exsit or not  
        {
            File.Delete(path);
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Photo Delete Successfully')", true);

        }
        else
        {
            // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('This File dose not exists in folder.')", true);
            return;
        }
    }

    protected void btnaddress1_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select Address2ProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object Address1ProofObject = dal.Getscalar(sb.ToString(), ref message);

                if (Address1ProofObject is DBNull)
                {
                    saveAddress1Proof();
                }
                else if (Address1ProofObject != null)
                {
                    ImageDeleteFromFolder(Address1ProofObject.ToString());
                    saveAddress1Proof();
                }
                else
                {
                    saveAddress1Proof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }

    }
    public void saveAddress1Proof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/customerphoto/");
            if (FileUpload6.HasFile)
            {
                int ContentLength = FileUpload6.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload6.PostedFile.FileName;
                    FileUpload6.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/customerphoto/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                sba.AppendFormat("update MLM_UserDetail set Address2='{0}',Address2value='{1}',Address2ProofUrl='{2}',Address2validate='{3}' where UserID='{4}'", drpaddress1.SelectedItem.Text, txtaddress1value.Text, SaveFilename, "0", Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowPopupMessage("Address Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }
}