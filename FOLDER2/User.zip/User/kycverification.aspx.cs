﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_kycverification : System.Web.UI.Page
{
    string message = string.Empty;
    string constr = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShowProfile();
                statuskyc();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }
    public void statuskyc()
    {
        try
        {
            string userID = Session["UserID"].ToString();
            DAL dal = new DAL();
            DataTable dt1 = dal.Gettable("Select KYC from MLM_UserDetail where UserID='" + userID.ToString() + "'", ref message);
            if (dt1.Rows.Count > 0)
            {
                string status = dt1.Rows[0]["KYC"].ToString();
                if (status == "Yes")
                {
                    lblstatus.Text = "Complete";
                }
                else
                {
                   lblstatus.Text = "InComplete";
                }
            }
        }
        catch (Exception ex)
        {

        }
    }


    private void ShowProfile()
    {
        MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = Session["UserID"].ToString() };
        MLMUserDetailLogic MDL = new MLMUserDetailLogic();
        DataTable dt = MDL.UserDetail(MDP, ref message);


        string pancard = dt.Rows[0]["IdentityProof"].ToString();
        if (!string.IsNullOrEmpty(pancard))
        {

            string validate = dt.Rows[0]["IdentityProofvalue"].ToString();
            if (validate == "1")
            {
                btnKycUpload.Enabled = false;
                //imgpan.ImageUrl = dt.Rows[0]["IdentityProofUrl"].ToString();
                //a2.HRef = dt.Rows[0]["IdentityProofUrl"].ToString();
                string Logo = dt.Rows[0]["IdentityProofUrl"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["IdentityProofUrl"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    imggst.ImageUrl = "data:image/png;base64," + base64String;
                //    a2.HRef = "data:image/png;base64," + base64String;
                }
                spankyc_approve.Visible = true;
            }
            else
            {
                btnKycUpload.Enabled = false;
                //imgpan.ImageUrl = dt.Rows[0]["IdentityProofUrl"].ToString();
                //a2.HRef = dt.Rows[0]["IdentityProofUrl"].ToString();
                string Logo = dt.Rows[0]["IdentityProofUrl"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["IdentityProofUrl"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    imggst.ImageUrl = "data:image/png;base64," + base64String;
                  //  a2.HRef = "data:image/png;base64," + base64String;
                }
                spankyc_Pending.Visible = true;
            }
        }
        else
        {
            btnKycUpload.Enabled = true;
            imggst.ImageUrl = "assets/images/dummy-profile-pic.png";
          //  a2.HRef = "assets/images/dummy-profile-pic.png";
        }
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/customer/assets/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void btnKycUpload_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            //string folderPath = Server.MapPath("../customer/kyc/");
            if (FileUpload1.HasFile)
            {
                int ContentLength = FileUpload1.PostedFile.ContentLength;
                if (ContentLength <= 8000000)
                {
                    #region Dummy Data
                    //string userid = string.Concat(Session["UserID"].ToString(), "_1");
                    //string extension = Path.GetExtension(ftpadharfront.FileName);
                    //if (extension == ".jpg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpg";
                    //}
                    //else if (extension == ".jpeg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpeg";
                    //}
                    //else if (extension == ".png")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".png";
                    //}
                    ////FileName = Session["UserID"].ToString() + ftpadharfront.PostedFile.FileName;
                    //ftpadharfront.SaveAs(folderPath + FileName);
                    //SaveFilename = "../customer/kyc/" + FileName;
                    #endregion

                    Stream fs = FileUpload1.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    byte[] AadharFront = bytes;
                    SqlConnection con = new SqlConnection(constr);
                    SqlCommand cmd = new SqlCommand("update MLM_UserDetail set  IdentityProof='KYC Identity',IdentityProofUrl=@image where UserID='" + Session["UserID"].ToString() + "'", con);
                    //sba.AppendFormat();
                    cmd.Parameters.AddWithValue("@image", AadharFront);
                    con.Open();
                    int rowaffected = cmd.ExecuteNonQuery();
                    if (rowaffected > 0)
                    {
                        con.Close();
                        ShowProfile();
                        ShowPopupMessage("KYC Proof Updated Successfully", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Warning);
                    }
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 800kb.", PopupMessageType.Warning);
                    return;
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
}