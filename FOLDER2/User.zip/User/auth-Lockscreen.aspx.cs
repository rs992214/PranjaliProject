﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_Lockscreen : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        Showdatalogo();

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                txtUsername.Text = Session["UserID"].ToString();
            showname();
                Showuserlogo();
            }
            else
            {
                if (Request.Cookies["UserName"] != null && Request.Cookies["Password"] != null)
                {
                    txtUsername.Text = Request.Cookies["UserName"].Value;
                    txtPassword.Attributes["value"] = Request.Cookies["Password"].Value;
                }
            }
               


        }
    }
    public void showname()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            //sb.AppendFormat("select Name,status,CAST(JoinDate as date) as JoinDate,CAST(PackageDate as date) as PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            sb.AppendFormat("select Name,status,JoinDate,PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblcustomername.Text = dt.Rows[0]["Name"].ToString();
                //lblUserName.Text = dt.Rows[0]["Name"].ToString();
                // lbljoindate.Text = Convert.ToDateTime(dt.Rows[0]["JoinDate"]).ToString("dd-MM-yyyy");
                //    lblactivationdate.Text = Convert.ToDateTime(dt.Rows[0]["PackageDate"]).ToString("dd-MM-yyyy");
            
            }
            else
            {
                lblcustomername.Text = "Company Associate";
            }
        }
        catch (Exception ex)
        {
            /// ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void Showuserlogo()
    {
        try
        {

            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select PhotoPath from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {



                string Logo = dt.Rows[0]["PhotoPath"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    //byte[] bytes = (byte[])dt.Rows[0]["PhotoPath"];
                    //string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    //// imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    //Image1.ImageUrl = "data:image/png;base64," + base64String;
                    Image1.ImageUrl = Logo.ToString();


                }
            }
            else
            {
            }
        }
        catch (Exception ex)
        {


        }
    }
    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {

                lblCompanyname.Text = dt.Rows[0]["CompanyName"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    // imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    imgLogo1.ImageUrl = "data:image/png;base64," + base64String;
                }
            }
            else
            {
            }
        }
        catch (Exception ex)
        {


        }
    }

    protected void btnUnlock_Click(object sender, EventArgs e)
    {

        try
        {  
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select UserID,IsBlock from MLM_Registration where UserID='{0}' and Password='{1}'", txtUsername.Text, txtPassword.Text);
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            string IsBlock = dt.Rows[0]["IsBlock"].ToString();
            if (IsBlock == "No")
            {
                Session["UserID"] = dt.Rows[0]["UserID"].ToString();
                Response.Redirect("auth-dashboard.aspx", false);
            }
            else if (IsBlock == "Yes")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your account has been blocked please contact Administrator')", true);
            }
        }
        else
        {
       
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Invalid Account Or Password.')", true);
        }
    }
        catch (Exception ex)
        {
            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
    var script = string.Format("alert({0});", errormessage);
    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
    }
}
}