﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;

public partial class customer_auth_gethelphistory : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string package = string.Empty;
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ProvideHelpList();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void ProvideHelpList()
    {
        try
        {
            // DataTable dt = dal.Gettable("SELECT ph.GH_ID,ph.GetAmount,ph.CreationDate,mr.Name,ph.Status FROM Donation ph inner join MLM_Registration mr on ph.GH_ID=mr.UserID WHERE ph.GH_ID='" + Session["UserID"].ToString() + "'", ref message);
            // DataTable dt = dal.Gettable("select ll.CR as GetAmount,ph.Status,ph.CreationDate from Ledger_Wallet ll inner join Donation ph on ll.UserID=ph.PH_ID WHERE ph.PH_ID='" + Session["UserID"].ToString() + "'  and Descriptions='Link Amount!'", ref message);
            // DataTable dt = dal.Gettable("select cr as GetAmount,CreationDate,Descriptions,TransferBy as Status from Ledger_Wallet where userid='" + Session["UserID"].ToString() + "' and Descriptions='Link Amount!'", ref message);
            //  DataTable dt = dal.Gettable("select cr as GetAmount,CreationDate,Descriptions,TransferBy as Status from Ledger_Wallet where userid='" + Session["UserID"].ToString() + "' and Descriptions='Link Amount!' or Descriptions='Direct Income!' ", ref message);

            DataTable dt = dal.Gettable("select * from Donation where GH_ID = '" + Session["UserID"].ToString() + "' ", ref message);



            if (dt.Rows.Count > 0)
            {
                GV_Donation_List.DataSource = dt;
                GV_Donation_List.DataBind();
            }
            else
            {
                GV_Donation_List.DataSource = null;
                GV_Donation_List.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void GV_Donation_List_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_Donation_List.PageIndex = e.NewPageIndex;
    }
    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=ProvideHelpReport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GV_Donation_List.AllowPaging = false;
                ProvideHelpList();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GV_Donation_List.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GV_Donation_List.HeaderRow.Cells)
                {
                    cell.BackColor = GV_Donation_List.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GV_Donation_List.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GV_Donation_List.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GV_Donation_List.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GV_Donation_List.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }

}