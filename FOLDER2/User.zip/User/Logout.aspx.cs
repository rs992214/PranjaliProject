﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Member_Logout : System.Web.UI.Page
{
    string Password = "";
    string UserID = "";
    string LoginIP = GetLocalIPAddress();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                getData();
                tracing();
                Session.Abandon();
                Session.Clear();
                Response.Redirect("auth-login.aspx");

            }
            else
            {
                Response.Redirect("auth-login.aspx");
            }
        }
    }
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void getData()
    {

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("select UserID, Password from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Password = dt.Rows[0]["Password"].ToString();
                UserID = dt.Rows[0]["UserID"].ToString();

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void tracing()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'Logout SucessFully..!!')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

}