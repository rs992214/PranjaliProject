﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;

public partial class customer_auth_activategreenwallet : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            btnSave.Enabled = false;
            if (!IsPostBack)
            {
                lbltimer.Text = DateTime.Now.ToString("hh:mm:ss tt");
                GetWalletBalance();
                timer();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    protected void GetTime(object sender, EventArgs e)
    {
        lbltimer.Text = DateTime.Now.ToString("hh:mm:ss tt");
    }
    private void GetWalletBalance()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions='Green Wallet'", ref message);
           // DataTable dtMinimum = objDAL.Gettable("Select COALESCE(MIN(Amount),0)As MinimunBalance From PackageInfo", ref message);
            if (dt.Rows.Count > 0)
            {
                lblWalletBalance.Text = dt.Rows[0]["WalletAmount"].ToString();
                decimal WalletBalance = Convert.ToDecimal(lblWalletBalance.Text);
                //decimal MinimumBalance = Convert.ToDecimal(dtMinimum.Rows[0]["MinimunBalance"]);
                //if (WalletBalance >= MinimumBalance)
                //{
                //    lblBalanceMSG.Visible = false;
                //}
                //else
                //{
                //    lblBalanceMSG.Visible = true;
                //}
            }
            else
            {
                lblWalletBalance.Text = "0";
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    private void timer()
    {

        DateTime timer = Convert.ToDateTime(lbltimer.Text);
        System.DateTime moment = timer;
        int hour = moment.Hour;
        if(hour == 23)
        {
            btnSave.Visible = false;
            btnCancel.Visible = false;
            txtuserid.ReadOnly = true;
            drplpackage.Enabled = true;
            lblmassage.Visible = true;
            lblmassage.Text = "System Is in Calculation Mode Hence Do Not Activate ID 11:00 PM - 12:10 AM";
            spnote.Visible = true;
        }




    }

    protected void txtuserid_TextChanged(object sender, EventArgs e)
    {
        try
        {
            string UserID = txtuserid.Text;
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Name from MLM_Registration where JoinType='Free' and UserID='" + UserID + "'", ref message);
            if (dt.Rows.Count > 0)
            {

                lblname.Text = dt.Rows[0]["Name"].ToString();
                //btnSave.Enabled = true;
                dropdown();

            }
            else
            {
                txtuserid.Text = string.Empty;
                ShowPopupMessage("Please Enter Correct ID", PopupMessageType.Warning);

            }

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    public void dropdown()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand com = new SqlCommand("Select ID,PackageName from PackageInfo", con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable ds = new DataTable();
        da.Fill(ds);
        drplpackage.DataTextField = "PackageName";
        drplpackage.DataValueField = "ID";
        drplpackage.DataSource = ds;
        drplpackage.DataBind();
        drplpackage.Items.Insert(0, new ListItem("--Select Package--", "0"));
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void drplpackage_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label2.Text = drplpackage.SelectedItem.Value;

        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select Amount from PackageInfo where ID='" + Label2.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            decimal pckamt = Convert.ToDecimal(dt.Rows[0]["Amount"].ToString());
            decimal maxamt = Convert.ToDecimal(lblWalletBalance.Text);
            Label1.Text = Convert.ToString(pckamt);
            if (maxamt >= pckamt)
            {
                btnSave.Enabled = true;
            }
            else
            {
                btnSave.Enabled = false;
                ShowPopupMessage("Wallet Balance Is Low", PopupMessageType.Warning);
            }
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (drplpackage.SelectedItem.Value != "0")
        {
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("USSERUPDATE_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", txtuserid.Text);
            cmd.Parameters.AddWithValue("@PackageName", drplpackage.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Mode", "UPD_STATUS");
            int flag = cmd.ExecuteNonQuery();
            if (flag > 0)
            {
                LedgerDebitUser();
                LedgerCredit();
                LedgerDebit();
                clear();
                ShowPopupMessage("User Activated Sucessfull", PopupMessageType.Success);

            }
        }
        else
        {
            //ShowPopupMessage("Please Select Package", PopupMessageType.Warning);
        }
    }
    private void LedgerCredit()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtuserid.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", Label1.Text);
        cmd.Parameters.AddWithValue("@DR", 0);
        cmd.Parameters.AddWithValue("@Descriptions", "Current Package Amount!");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }
    private void LedgerDebit()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtuserid.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "DR");
        cmd.Parameters.AddWithValue("@CR", 0);
        cmd.Parameters.AddWithValue("@DR", Label1.Text);
        cmd.Parameters.AddWithValue("@Descriptions", "Current Package Amount!");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();

    }
    private void LedgerDebitUser()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
        cmd.Parameters.AddWithValue("@TransactionType", "DR");
        cmd.Parameters.AddWithValue("@CR", 0);
        cmd.Parameters.AddWithValue("@DR", Label1.Text);
        cmd.Parameters.AddWithValue("@TransferBy", txtuserid.Text);
        cmd.Parameters.AddWithValue("@Descriptions", "Green Wallet");
        cmd.Parameters.AddWithValue("@Mode", "IN2");
        int flag = cmd.ExecuteNonQuery();

    }
    public void clear()
    {
        btnSave.Enabled = false;
        txtuserid.Text = string.Empty;
        drplpackage.SelectedValue = "0";
        lblname.Text = string.Empty;
        Label1.Text = string.Empty;

    }
}