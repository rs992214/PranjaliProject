﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Collections;

public partial class customer_auth_mydownline : System.Web.UI.Page
{
    string message = string.Empty;
    ArrayList UserIDRightList = new ArrayList();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShowMembersofteam();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        ShowMembersofteam();
    }
    public void ShowMembersofteamA(string Leftuserid)
    {
        //24/10/2019 Show of Team A Member

        try
        {
            List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
            string L = null;
            string R = null;
            string UserID = Leftuserid;
            DataTable dtUser1 = new DataTable();
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    dtUser1 = dal.Gettable("select UserID,Name,JoinType,Mobile,Email,Package,CONVERT(nvarchar,JoinDate,105)As JoinDate from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtUser1.Rows.Count > 0)
                    {
                        detail.Add(new MLMUserDetailProperty
                        {
                            UserID = dtUser1.Rows[0]["UserID"].ToString(),
                            Name = dtUser1.Rows[0]["Name"].ToString(),
                            Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                            Email = dtUser1.Rows[0]["Email"].ToString(),
                            Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                            JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            Package = dtUser1.Rows[0]["Package"].ToString(),
                        });
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }
            } while (UserID != null);
            GV_UserList_A.DataSource = detail.ToList();
            GV_UserList_A.DataBind();
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteamB(string Rightuserid)
    {
        try
        {
            List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
            string L = null;
            string R = null;
            DataTable dtUser1 = new DataTable();
            string UserID = Rightuserid;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    dtUser1 = dal.Gettable("select UserID,Name,JoinType,Mobile,Email,Package,CONVERT(nvarchar,JoinDate,105)As JoinDate from MLM_Registration where UserID='" + UserID + "'", ref message);
                    //   dtUser1 = dal.Gettable("select mm.UserID,mm.Name,mm.JoinType,mm.Mobile,mm.Email,CONVERT(nvarchar,mm.JoinDate,105)As JoinDate,pp.Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where mm.UserID='" + UserID + "'", ref message);
                    if (dtUser1.Rows.Count > 0)
                    {
                        detail.Add(new MLMUserDetailProperty
                        {
                            //UserID = dtUser1.Rows[0]["UserID"].ToString(),
                            //Name = dtUser1.Rows[0]["Name"].ToString(),
                            //Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                            //Email = dtUser1.Rows[0]["Email"].ToString(),
                            //Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                            //JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            UserID = dtUser1.Rows[0]["UserID"].ToString(),
                            Name = dtUser1.Rows[0]["Name"].ToString(),
                            Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                            Email = dtUser1.Rows[0]["Email"].ToString(),
                            JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                            Package = dtUser1.Rows[0]["Package"].ToString(),
                        });
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }

            } while (UserID != null);
            GV_UserList_B.DataSource = detail.ToList();
            GV_UserList_B.DataBind();
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteam()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            string LeftUser = null;
            string RightUser = null;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();

                if (LeftUser != null)
                {
                    ShowMembersofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowMembersofteamB(RightUser);
                }
            }

            //int Totalteamabbusiness = Convert.ToInt32(lblTotalateam.Text) + Convert.ToInt32(lblTotalbteam.Text);
            //lblTotalteamabbusiness.Text = Totalteamabbusiness.ToString();
        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void GV_UserList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_UserList_A.PageIndex = e.NewPageIndex;
    }
    protected void GV_UserList_B_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_UserList_B.PageIndex = e.NewPageIndex;
    }


    //// Modal PopUp Code Goes here
    //private void ShowPopupMessage(string message, PopupMessageType messageType)
    //{
    //    switch (messageType)
    //    {
    //        case PopupMessageType.Error:
    //            lblMessagePopupHeading.Text = "Error";
    //            //Render image in literal control
    //            ltrMessagePopupImage.Text = "<img src='" +
    //              Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
    //            break;
    //        case PopupMessageType.Message:
    //            lblMessagePopupHeading.Text = "Information";
    //            ltrMessagePopupImage.Text = "<img src='" +
    //              Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
    //            break;
    //        case PopupMessageType.Warning:
    //            lblMessagePopupHeading.Text = "Warning";
    //            ltrMessagePopupImage.Text = "<img src='" +
    //              Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
    //            break;
    //        case PopupMessageType.Success:
    //            lblMessagePopupHeading.Text = "Success";
    //            ltrMessagePopupImage.Text = "<img src='" +
    //              Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
    //            break;
    //        default:
    //            lblMessagePopupHeading.Text = "Information";
    //            ltrMessagePopupImage.Text = "<img src='" +
    //              Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
    //            break;
    //    }

    //    lblMessagePopupText.Text = message;
    //    mpeMessagePopup.Show();
    //}

    ///// <summary>
    ///// Message type enum
    ///// </summary>
    //public enum PopupMessageType
    //{
    //    Error,
    //    Message,
    //    Warning,
    //    Success
    //}
    //// Modal PopUp Code end here 
}