﻿using DataAccessLayer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class customer_auth_withdrawmywallet : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();

    ArrayList UserIDRightList = new ArrayList();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                // btnSave.Visible = false;
                Gettype();
                GetWalletBalance();
                walletmaster();
                RequestButton();
                // ShowMembersofteam();
                // btnSave.Visible = false;
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }



        }
    }
    public void walletmaster()
    {

        DAL dal = new DAL();
        string cn = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(cn);
        con.Open();
        SqlCommand cmd = new SqlCommand("select id,Amount  from wallet_amount_master", con);
        SqlDataReader dr = cmd.ExecuteReader();
        ddlSelectamount.DataSource = dr;
        ddlSelectamount.Items.Clear();
        ddlSelectamount.DataTextField = "Amount";
        ddlSelectamount.DataValueField = "id";
        ddlSelectamount.DataBind();
        ddlSelectamount.Items.Insert(0, new ListItem("--Select Denomination--", "0"));
        con.Close();

    }
    private void EnableFalse_Control()
    {
        txtAmount.Enabled = false;
        txtDescription.Enabled = false;
        btnSave.Enabled = false;
    }
    private void EnableTrue_Control()
    {
        txtAmount.Enabled = true;
        txtDescription.Enabled = true;
        btnSave.Enabled = true;
    }
    private void CheckWithdrawal_Request()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID,Status From WithdrawalRequest Where UserID='" + UserID + "' and Status='REQUEST' ", ref message);
        if (dt.Rows.Count > 0)
        {
            EnableFalse_Control();
            ShowPopupMessage("You have already request to admin.", PopupMessageType.Message);
        }
        else
        {
            // EnableTrue_Control();
            EnableFalse_Control();
        }
    }
    private void GetWalletBalance()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions in ('Matching Income','Matching Sponcor Income','Withdrawal Amount','2:1 OR 1:2') ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblWalletBalance.Text = dt.Rows[0]["WalletAmount"].ToString();
                decimal WalletBalance = Convert.ToDecimal(lblWalletBalance.Text);

                if (WalletBalance >= 0)
                {
                    EnableTrue_Control();
                }
                else
                {
                    EnableFalse_Control();
                    ShowPopupMessage("Wallet Balance is Low", PopupMessageType.Message);
                    // CheckWithdrawal_Request();
                }

            }
            else
            {
                lblWalletBalance.Text = "0";
                EnableFalse_Control();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }


    //sms gateway new
    public string sendSMS_new()
    {
        string UserID = Session["UserID"].ToString();
        DAL dal = new DAL();
        string website1 = "";
        string txtApiurl = "";
        string txtApikeys = "";
        string txtSender = "";
        string companyname = "";
        string name = "";
        string mobile = "";
        string message = string.Empty;

        DataTable dt = dal.Gettable("select api_key,url,sender,Status from Smsmaster Where Status='Active'", ref message);
        DataTable dt1 = dal.Gettable("Select CompanyName,Website from Companyinfo", ref message);
        DataTable dt2 = dal.Gettable("select Name,Mobile from MLM_Registration where UserID='" + UserID + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtApiurl = dt.Rows[0]["url"].ToString();
            txtApikeys = dt.Rows[0]["api_key"].ToString();
            txtSender = dt.Rows[0]["sender"].ToString();
            string status = dt.Rows[0]["Status"].ToString();
            website1 = dt1.Rows[0]["Website"].ToString();
            companyname = dt1.Rows[0]["CompanyName"].ToString();

            name = dt2.Rows[0]["Name"].ToString();
            mobile = dt2.Rows[0]["Mobile"].ToString();

        }

        //end
        String result;

        string apiKey = txtApikeys.ToString(); ;

        string numbers = mobile; // in a comma seperated list


        string sms = "Dear '" + name + " 'UPDATE :INR '" + txtAmount.Text + "' Debited from your account on '" + DateTime.Now.ToString() + "' Waiting from Admin To Approve Your Request and You Will Receive a Confirmation From Admin. For More Info Vists : '" + website1 + "' ";



        String url = "" + txtApiurl + "" + apiKey + "&numbers=" + numbers + "&message=" + sms + "&sender=" + txtSender;
        //refer to parameters to complete correct url string

        StreamWriter myWriter = null;
        HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

        objRequest.Method = "POST";
        objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
        objRequest.ContentType = "application/x-www-form-urlencoded";
        try
        {
            myWriter = new StreamWriter(objRequest.GetRequestStream());
            myWriter.Write(url);
        }
        catch (Exception e)
        {
            return e.Message;
        }
        finally
        {
            myWriter.Close();
        }

        HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
        using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
        {
            result = sr.ReadToEnd();

            sr.Close();
        }
        return result;
    }
    //minimum2 direct condition
    public void ShowMembersofteam()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            string LeftUser = null;
            string RightUser = null;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();

                if (LeftUser != null)
                {
                    ShowMembersofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowMembersofteamB(RightUser);
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteamA(string Leftuserid)
    {
        try
        {
            List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
            string L = null;
            string R = null;
            string UserID = Leftuserid;
            DataTable dtUser1 = new DataTable();
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    dtUser1 = dal.Gettable("select SponsorID,UserID,Name,JoinType,Mobile,Email,CONVERT(nvarchar,JoinDate,105)As JoinDate from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtUser1.Rows.Count > 0)
                    {
                        string sponsorid = dtUser1.Rows[0]["SponsorID"].ToString();
                        if (Session["UserID"].ToString().ToUpper() == sponsorid.ToUpper())
                        {
                            detail.Add(new MLMUserDetailProperty
                            {
                                UserID = dtUser1.Rows[0]["UserID"].ToString(),
                                Name = dtUser1.Rows[0]["Name"].ToString(),
                                Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                                Email = dtUser1.Rows[0]["Email"].ToString(),
                                Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                                JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            });
                        }
                        else
                        {
                            //
                        }
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
            GridView gvs = new GridView();
            gvs.DataSource = detail.ToList();
            gvs.DataBind();

            hfdirectcount.Value = gvs.Rows.Count.ToString();
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteamB(string Rightuserid)
    {
        try
        {
            List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
            string L = null;
            string R = null;
            DataTable dtUser1 = new DataTable();
            string UserID = Rightuserid;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    dtUser1 = dal.Gettable("select SponsorID,UserID,Name,JoinType,Mobile,Email,CONVERT(nvarchar,JoinDate,105)As JoinDate from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtUser1.Rows.Count > 0)
                    {
                        string sponsorid = dtUser1.Rows[0]["SponsorID"].ToString();
                        if (Session["UserID"].ToString().ToUpper() == sponsorid.ToUpper())
                        {
                            detail.Add(new MLMUserDetailProperty
                            {
                                UserID = dtUser1.Rows[0]["UserID"].ToString(),
                                Name = dtUser1.Rows[0]["Name"].ToString(),
                                Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                                Email = dtUser1.Rows[0]["Email"].ToString(),
                                Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                                JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            });
                        }
                        else
                        {
                            //
                        }
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }

            } while (UserID != null);
            GridView gvs1 = new GridView();
            gvs1.DataSource = detail.ToList();
            gvs1.DataBind();

            hdfright.Value = gvs1.Rows.Count.ToString();

        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (Convert.ToDouble(txtAmount.Text) > 0)
        {


            DAL dal = new DAL();
            string message = string.Empty;
            DataTable dtw = dal.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet where UserID='" + Session["UserID"].ToString() + "' and Descriptions in ('Matching Income','Matching Sponcor Income','Withdrawal Amount')", ref message);
            string minwallamts = dtw.Rows[0]["WalletAmount"].ToString();
            decimal minwallamtf = Convert.ToDecimal(minwallamts);

            try
            {
                if (Session["UserID"] != null)
                {
                    double WalletBalance = Convert.ToDouble(lblWalletBalance.Text);
                    double RequestAmount = Convert.ToDouble(txtAmount.Text);
                    double Balance = 0;

                    if (RequestAmount <= WalletBalance)
                    {
                        Balance = WalletBalance - RequestAmount;
                        if (RequestAmount >= 300)
                        {
                            DAL objDAL = new DAL();
                            DataTable dt = objDAL.Gettable("Select * from MLM_Registration Where SponsorID='" + Session["UserID"].ToString() + "'", ref message);
                            if (dt.Rows.Count > 0)
                            {
                                txtDescription.Text = "Withdrawal Amount";
                                string UserID = Session["UserID"].ToString();
                                double CR = 0;
                                double DR = Convert.ToDouble(txtAmount.Text);
                                double Admin = 0;
                                double TDS = 0;
                                double NetAmount = 0;
                                DataTable dtCharges = dal.Gettable("select ISNULL(Admin, 0) AS AdminCharge from AdminMaster", ref message);
                                if (dtCharges.Rows.Count > 0)
                                {
                                    Admin = Convert.ToDouble(dtCharges.Rows[0]["AdminCharge"].ToString());
                                    Admin = ((DR * Admin) / 100);
                                    DataTable dtCharges1 = dal.Gettable("select ISNULL(TDS, 0) AS TDSCharge from TDSMaster", ref message);
                                    if (dtCharges1.Rows.Count > 0)
                                    {
                                        TDS = Convert.ToDouble(dtCharges1.Rows[0]["TDSCharge"].ToString());
                                        TDS = ((DR * TDS) / 100);
                                        NetAmount = (DR - (TDS + Admin));
                                    }
                                }
                                else
                                {
                                    Admin = 0;
                                    TDS = 0;
                                    NetAmount = DR;
                                }

                                con = new SqlConnection(connstring);
                                con.Open();
                                cmd = new SqlCommand("WithdrawalRequest_ALL", con);
                                cmd.CommandType = CommandType.StoredProcedure;
                                //withdrawal request tbl
                                cmd.Parameters.AddWithValue("@UserID", UserID);
                                cmd.Parameters.AddWithValue("@Amount", txtAmount.Text);
                                cmd.Parameters.AddWithValue("@Admin", Admin);
                                cmd.Parameters.AddWithValue("@TDS", TDS);
                                cmd.Parameters.AddWithValue("@NetAmount", NetAmount);
                                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                                //ledger tbl
                                cmd.Parameters.AddWithValue("@TransactionType", "DR");
                                cmd.Parameters.AddWithValue("@CR", CR);
                                cmd.Parameters.AddWithValue("@DR", DR);
                                cmd.Parameters.AddWithValue("@Descriptions", txtDescription.Text);
                                cmd.Parameters.AddWithValue("@Mode", "Withdrawal");
                                int flag = cmd.ExecuteNonQuery();
                                if (flag > 0)
                                {
                                    GetWalletBalance();

                                    //string msg = string.Empty;
                                    //msg = "Your Request has been send to Admin.";
                                    //var errormessage = new JavaScriptSerializer().Serialize(msg.ToString());
                                    //var script = string.Format("alert({0});window.location='WithdrawalRequest.aspx';", errormessage);
                                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
                                    //ShowPopupMessage("Your Request has been send to Admin.", PopupMessageType.Success);
                                    //Response.Redirect("auth-withdrawallist.aspx?amount="+ txtAmount.Text); txtAmount.Text = "";
                                    Response.Redirect("Success.aspx?Link=auth-withdrawmywallet.aspx");
                                }
                                else
                                {
                                    txtAmount.Text = "";
                                    ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                                }
                            }
                            else
                            {
                                ShowPopupMessage("User must have at least one direct member.", PopupMessageType.Warning);
                            }
                        }
                        else
                        {
                            txtAmount.Text = "";
                            // ShowPopupMessage("User must have minimum Wallet Amount .", PopupMessageType.Message);
                            ShowPopupMessage("User must have minimum Withdrawal of 100.", PopupMessageType.Warning);
                        }
                    }
                    else
                    {
                        ShowPopupMessage("Invalid Amount.", PopupMessageType.Message);
                    }
                }
                else
                {
                    Response.Redirect("Logout.aspx");
                }
            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            ShowPopupMessage("Please Enter Positive Value.", PopupMessageType.Warning);
        }
    }

    public string sendSMSnew()
    {

        DAL dal = new DAL();
        string website1 = "";
        string txtApiurl = "";
        string txtApikeys = "";
        string txtSender = "";
        string companyname = "";
        string message = string.Empty;

        DataTable dt = dal.Gettable("select api_key,url,sender,Status from Smsmaster Where Status='Active'", ref message);
        DataTable dt1 = dal.Gettable("Select CompanyName,Website from Companyinfo", ref message);

        if (dt.Rows.Count > 0)
        {
            txtApiurl = dt.Rows[0]["url"].ToString();
            txtApikeys = dt.Rows[0]["api_key"].ToString();
            txtSender = dt.Rows[0]["sender"].ToString();
            string status = dt.Rows[0]["Status"].ToString();
            website1 = dt1.Rows[0]["Website"].ToString();
            companyname = dt1.Rows[0]["CompanyName"].ToString();

        }

        //end
        string result = "";

        string apiKey = txtApikeys.ToString(); ;

        DataTable dtDetail = dal.Gettable("select UserID,Password,Name, mobile from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dtDetail.Rows.Count > 0)
        {
            string numbers = dtDetail.Rows[0]["mobile"].ToString(); // in a comma seperated list
            string name = dtDetail.Rows[0]["Name"].ToString();
            string userid = dtDetail.Rows[0]["UserID"].ToString();
            string password = dtDetail.Rows[0]["Password"].ToString();

            string sms = "Congratulations, Dear '" + name + "' Welcome To " + companyname + " Your Account Created Successfully.Your Customer ID: '" + userid + "'Password:'" + password + "'.For More Info Visit '" + website1 + "'";
            String url = "" + txtApiurl + "" + apiKey + "&numbers=" + numbers + "&message=" + sms + "&sender=" + txtSender;
            //refer to parameters to complete correct url string

            StreamWriter myWriter = null;
            HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

            objRequest.Method = "POST";
            objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
            objRequest.ContentType = "application/x-www-form-urlencoded";
            try
            {
                myWriter = new StreamWriter(objRequest.GetRequestStream());
                myWriter.Write(url);
            }
            catch (Exception e)
            {
                return e.Message;
            }
            finally
            {
                myWriter.Close();
            }

            HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
            using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
            {
                result = sr.ReadToEnd();
                sr.Close();
            }

        }

        return result;

    }
    public void AddGhMemeber()
    {
        string message = string.Empty;
        string UserID = Session["UserID"].ToString();


        StringBuilder sbb = new StringBuilder();

        sbb.AppendLine("insert into GetHelp(UserID,Amount)");
        sbb.AppendFormat("values('{0}','{1}')", UserID, txtAmount.Text);
        int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);


    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-withdrawmywallet.aspx");
    }


    void Gettype()
    {
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select * from MLM_Registration Where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            string type = dt.Rows[0]["JoinType"].ToString();

            if(type == "Free")
            {
                div1.Visible = false;
                lblmsg1.Text = "You Are Free Member,Please Activate First.";
            }
            else
            {
                div1.Visible = true;
                lblmsg1.Visible = false;
                HyperLink1.Visible = false;
            }
        }
    }




    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void ddlSelectamount_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtAmount.Text = ddlSelectamount.SelectedItem.ToString();
        txtAmount.ReadOnly = true;
    }




    protected void txtAmount_TextChanged(object sender, EventArgs e)
    {
        if (txtAmount.Text != "")
        {
            string check = @"[0-9]{1,5}";

            if (Regex.IsMatch(txtAmount.Text, check) == true)
            {
                if (Convert.ToDouble(txtAmount.Text) >= 300)
                {
                    if (Convert.ToDecimal(txtAmount.Text) <= Convert.ToDecimal(lblWalletBalance.Text))
                    {
                        btnSave.Enabled = true;
                    }
                    else
                    {
                        txtAmount.Text = "";
                        ShowPopupMessage("Error : Insufficient Amount In wallet.", PopupMessageType.Error);
                    }
                }
                else
                {
                    txtAmount.Text = "";
                    ShowPopupMessage("Error : Withdrawl Request should be Greater than 300/- or Equal.", PopupMessageType.Error);
                }
            }
            else
            {
                ShowPopupMessage("Error : Please Enter Amount Only...", PopupMessageType.Error);
            }
            }
            else
            {
                ShowPopupMessage("Error : Please Enter Amount.", PopupMessageType.Error);
            }

    }

    protected void RequestButton()
    {
        DataTable dt = dal.Gettable("select UserID from WithdrawalRequest where UserID='" + Session["UserID"].ToString() + "' and status='REQUEST'", ref message);
        if (dt.Rows.Count > 0)
        {
            ShowPopupMessage("Warning : Already Withdrawl Request Pending.", PopupMessageType.Warning);
            txtAmount.Enabled = false;
            btnSave.Enabled = false;
        }

        else
        {
            btnSave.Enabled = false;
        }

    }
}