﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_KYCNEW : System.Web.UI.Page
{
    string message = string.Empty;
    string constr = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShowProfile();
                statuskyc();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }

    public void statuskyc()
    {
        try
        {
            string userID = Session["UserID"].ToString();
            DAL dal = new DAL();
            DataTable dt1 = dal.Gettable("Select KYC from MLM_UserDetail where UserID='" + userID.ToString() + "'", ref message);
            if (dt1.Rows.Count > 0)
            {
                string status = dt1.Rows[0]["KYC"].ToString();
                if (status == "Yes")
                {
                    lblstatus.Text = "Complete";
                }
                else
                {
                    lblstatus.Text = "InComplete";
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void ShowProfile()
    {

        try
        {
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = Session["UserID"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            //string UserID = Session["UserID"].ToString();
            //DAL objDAL = new DAL();
            ////DataTable dt = objDAL.Gettable("Select AddressProof,AddressProofvalue,AddressProofUrl,IdentityProof,IdentityProofvalue,IdentityProofUrl,BankProof,BankProofvalue,BankProofUrl,GST, GSTProofvalue, GSTProofUrl, Address2, Address2value, Address2ProofUrl from MLM_UserDetail UD INNER JOIN MLM_Registration mm ON UD.UserID = mm.UserID = '" + UserID + "'", ref message);
            //DataTable dt = objDAL.Gettable("Select UD.AddressProof,UD.AddressProofvalue,UD.AddressProofUrl,UD.IdentityProof,UD.IdentityProofvalue,UD.IdentityProofUrl,UD.BankProof,UD.BankProofvalue,UD.BankProofUrl,UD.GST,UD.GSTProofvalue,UD.GSTProofUrl,UD.Address2,UD.Address2value,UD.Address2ProofUrl from MLM_UserDetail UD INNER JOIN MLM_Registration mm ON UD.UserID=mm.UserID where UD.UserID= '" + UserID + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                string value = dt.Rows[0]["AddressProof"].ToString();
                if (!string.IsNullOrEmpty(value))
                {
                    string Adharproof = dt.Rows[0]["AddressProof"].ToString();
                    if (!string.IsNullOrEmpty(Adharproof))
                    {

                        string validate = dt.Rows[0]["AddressProofvalue"].ToString();
                        if (validate == "1")
                        {
                            //imgadharf.ImageUrl = dt.Rows[0]["AddressProofUrl"].ToString();
                            aimg5.HRef = dt.Rows[0]["AddressProofUrl"].ToString();
                            string Logo = dt.Rows[0]["AddressProofUrl"].ToString();
                            if (!string.IsNullOrEmpty(Logo))
                            {
                                byte[] bytes = (byte[])dt.Rows[0]["AddressProofUrl"];
                                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                                imgadharf.ImageUrl = "data:image/png;base64," + base64String;
                            }
                            brnadhar1.Enabled = false;
                            spanadharfront2.Visible = true;

                        }
                        else
                        {
                           // imgadharf.ImageUrl = dt.Rows[0]["AddressProofUrl"].ToString();
                            aimg5.HRef = dt.Rows[0]["AddressProofUrl"].ToString();
                            string Logo = dt.Rows[0]["AddressProofUrl"].ToString();
                            if (!string.IsNullOrEmpty(Logo))
                            {
                                byte[] bytes = (byte[])dt.Rows[0]["AddressProofUrl"];
                                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                                imgadharf.ImageUrl = "data:image/png;base64," + base64String;
                            }
                            brnadhar1.Enabled = false;
                            spanadharfront1.Visible = true;
                        }
                    }
                    else
                    {
                        //imgadharf.ImageUrl = dt.Rows[0]["AddressProofUrl"].ToString();
                        aimg5.HRef = dt.Rows[0]["AddressProofUrl"].ToString();
                        string Logo = dt.Rows[0]["AddressProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["AddressProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imgadharf.ImageUrl = "data:image/png;base64," + base64String;
                        }
                        brnadhar1.Enabled = false;
                        spanadharfront1.Visible = true;

                    }
                }
                else
                {
                    brnadhar1.Enabled = true;
                    imgadharf.ImageUrl = "assets/images/dummy-profile-pic.png";
                   aimg5.HRef = "assets/images/dummy-profile-pic.png";
                }
                string Addressproof = dt.Rows[0]["Address2"].ToString();
                if (!string.IsNullOrEmpty(Addressproof))
                {

                    string validate = dt.Rows[0]["Address2value"].ToString();
                    if (validate == "1")
                    {
                        //imgadharb.ImageUrl = dt.Rows[0]["Address2ProofUrl"].ToString();
                        
                        string Logo = dt.Rows[0]["Address2ProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["Address2ProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imgadharb.ImageUrl = "data:image/png;base64," + base64String;
                            a1.HRef = "data:image/png;base64," + base64String;
                        }
                        btnadharb.Enabled = false;
                        adharback.Visible = true;
                    }
                    else
                    {
                        //imgadharb.ImageUrl = dt.Rows[0]["Address2ProofUrl"].ToString();
                        //a1.HRef = dt.Rows[0]["Address2ProofUrl"].ToString();
                        string Logo = dt.Rows[0]["Address2ProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["Address2ProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imgadharb.ImageUrl = "data:image/png;base64," + base64String;
                            a1.HRef = "data:image/png;base64," + base64String;
                        }
                        btnadharb.Enabled = false;
                        adharback1.Visible = true;
                    }
                }
                else
                {
                    btnadharb.Enabled = true;
                    imgadharb.ImageUrl = "assets/images/dummy-profile-pic.png";
                    a1.HRef = "assets/images/dummy-profile-pic.png";
                }
                string pancard = dt.Rows[0]["IdentityProof"].ToString();
                if (!string.IsNullOrEmpty(pancard))
                {

                    string validate = dt.Rows[0]["IdentityProofvalue"].ToString();
                    if (validate == "1")
                    {
                        btnpancard.Enabled = false;
                        //imgpan.ImageUrl = dt.Rows[0]["IdentityProofUrl"].ToString();
                        //a2.HRef = dt.Rows[0]["IdentityProofUrl"].ToString();
                        string Logo = dt.Rows[0]["IdentityProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["IdentityProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imgpan.ImageUrl = "data:image/png;base64," + base64String;
                            a2.HRef = "data:image/png;base64," + base64String;
                        }
                        pan2.Visible = true;
                    }
                    else
                    {
                        btnpancard.Enabled = false;
                        //imgpan.ImageUrl = dt.Rows[0]["IdentityProofUrl"].ToString();
                        //a2.HRef = dt.Rows[0]["IdentityProofUrl"].ToString();
                        string Logo = dt.Rows[0]["IdentityProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["IdentityProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imgpan.ImageUrl = "data:image/png;base64," + base64String;
                            a2.HRef = "data:image/png;base64," + base64String;
                        }
                        pan1.Visible = true;
                    }
                }
                else
                {
                    btnpancard.Enabled = true;
                    imgpan.ImageUrl = "assets/images/dummy-profile-pic.png";
                    a2.HRef = "assets/images/dummy-profile-pic.png";
                }
                string bankproof = dt.Rows[0]["BankProof"].ToString();
                if (!string.IsNullOrEmpty(bankproof))
                {
                    string validate = dt.Rows[0]["BankProofvalue"].ToString();
                    if (validate == "1")
                    {
                        btnbank.Enabled = false;
                        //imgbank.ImageUrl = dt.Rows[0]["BankProofUrl"].ToString();
                        //a3.HRef = dt.Rows[0]["BankProofUrl"].ToString();
                        string Logo = dt.Rows[0]["BankProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["BankProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imgbank.ImageUrl = "data:image/png;base64," + base64String;
                            a3.HRef = "data:image/png;base64," + base64String;
                        }
                        bank2.Visible = true;
                    }
                    else
                    {
                        btnbank.Enabled = false;
                        //imgbank.ImageUrl = dt.Rows[0]["BankProofUrl"].ToString();
                        //a3.HRef = dt.Rows[0]["BankProofUrl"].ToString();
                        string Logo = dt.Rows[0]["BankProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["BankProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imgbank.ImageUrl = "data:image/png;base64," + base64String;
                            a3.HRef = "data:image/png;base64," + base64String;
                        }
                        bank1.Visible = true;
                    }
                }
                else
                {
                    btnbank.Enabled = true;
                    imgbank.ImageUrl = "assets/images/dummy-profile-pic.png";
                    a3.HRef = "assets/images/dummy-profile-pic.png";
                }
                string GSTproof = dt.Rows[0]["GST"].ToString();
                if (!string.IsNullOrEmpty(GSTproof))
                {

                    string validate = dt.Rows[0]["GSTProofvalue"].ToString();
                    if (validate == "1")
                    {
                        btngstprrofupdate.Enabled = false;
                        //imggst.ImageUrl = dt.Rows[0]["GSTProofUrl"].ToString();
                        //a4.HRef = dt.Rows[0]["GSTProofUrl"].ToString();
                        string Logo = dt.Rows[0]["GSTProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["GSTProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imggst.ImageUrl = "data:image/png;base64," + base64String;
                           // a4.HRef = "data:image/png;base64," + base64String;
                        }
                        gst2.Visible = true;
                        gst.Visible = false;
                    }
                    else
                    {
                        btngstprrofupdate.Enabled = false;
                        //imggst.ImageUrl = dt.Rows[0]["GSTProofUrl"].ToString();
                        //a4.HRef = dt.Rows[0]["GSTProofUrl"].ToString();
                        string Logo = dt.Rows[0]["GSTProofUrl"].ToString();
                        if (!string.IsNullOrEmpty(Logo))
                        {
                            byte[] bytes = (byte[])dt.Rows[0]["GSTProofUrl"];
                            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                            imggst.ImageUrl = "data:image/png;base64," + base64String;
                           // a4.HRef = "data:image/png;base64," + base64String;
                        }
                        gst1.Visible = true;
                        gst.Visible = false;
                    }
                }
                else
                {
                    btngstprrofupdate.Enabled = true;
                    imggst.ImageUrl = "assets/images/dummy-profile-pic.png";
                   // a4.HRef = "assets/images/dummy-profile-pic.png";
                    gst.Visible = true;
                }
            }
            else
            {
                imgadharf.ImageUrl = "assets/images/dummy-profile-pic.png";
                imgadharb.ImageUrl = "assets/images/dummy-profile-pic.png";
                imgpan.ImageUrl = "assets/images/dummy-profile-pic.png";
                imgbank.ImageUrl = "assets/images/dummy-profile-pic.png";
                imggst.ImageUrl = "assets/images/dummy-profile-pic.png";
                aimg5.HRef = "assets/images/dummy-profile-pic.png";
                a2.HRef = "assets/images/dummy-profile-pic.png";
                a3.HRef = "assets/images/dummy-profile-pic.png";
                //a4.HRef = "assets/images/dummy-profile-pic.png";
                a1.HRef = "assets/images/dummy-profile-pic.png";
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/customer/assets/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void brnadhar1_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            //string folderPath = Server.MapPath("../customer/kyc/");
            if (ftpadharfront.HasFile)
            {
                int ContentLength = ftpadharfront.PostedFile.ContentLength;
                if (ContentLength <= 8000000)
                {
                    //string userid = string.Concat(Session["UserID"].ToString(), "_1");
                    //string extension = Path.GetExtension(ftpadharfront.FileName);
                    //if (extension == ".jpg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpg";
                    //}
                    //else if (extension == ".jpeg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpeg";
                    //}
                    //else if (extension == ".png")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".png";
                    //}
                    ////FileName = Session["UserID"].ToString() + ftpadharfront.PostedFile.FileName;
                    //ftpadharfront.SaveAs(folderPath + FileName);
                    //SaveFilename = "../customer/kyc/" + FileName;

                    Stream fs = ftpadharfront.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    byte[] AadharFront = bytes;
                    SqlConnection con = new SqlConnection(constr);
                    SqlCommand cmd = new SqlCommand("update MLM_UserDetail set AddressProof='Adhar card',AddressProofUrl=@image where UserID='" + Session["UserID"].ToString() + "'",con);
                    //sba.AppendFormat();
                    cmd.Parameters.AddWithValue("@image",AadharFront);
                    con.Open();
                    int rowaffected = cmd.ExecuteNonQuery();
                    if (rowaffected > 0)
                    {
                        con.Close();
                        ShowProfile();
                        ShowPopupMessage("Aadhar Proof Updated Successfully", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Warning);
                    }
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 800kb.", PopupMessageType.Warning);
                    return;
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnadharb_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            //string folderPath = Server.MapPath("../customer/kyc/");
            if (ftpadharback.HasFile)
            {
                int ContentLength = ftpadharback.PostedFile.ContentLength;
                if (ContentLength <= 8000000)
                {
                    //string userid = string.Concat(Session["UserID"].ToString(), "_2");
                    //string extension = Path.GetExtension(ftpadharback.FileName);
                    //if (extension == ".jpg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpg";
                    //}
                    //else if (extension == ".jpeg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpeg";
                    //}
                    //else if (extension == ".png")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".png";
                    //}
                    ////FileName = Session["UserID"].ToString() + ftpadharback.PostedFile.FileName;
                    //ftpadharback.SaveAs(folderPath + FileName);
                    //SaveFilename = "../customer/kyc/" + FileName;

                    Stream fs = ftpadharback.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    byte[] AadharBack = bytes;
                    SqlConnection con = new SqlConnection(constr);
                    SqlCommand cmd = new SqlCommand("update MLM_UserDetail set Address2='Adhar Card',Address2ProofUrl=@image where UserID='"+ Session["UserID"].ToString() + "'",con);
                    cmd.Parameters.AddWithValue("@image", AadharBack);
                    con.Open();
                    int rowaffected = cmd.ExecuteNonQuery();
                    if (rowaffected > 0)
                    {
                        con.Close();
                        ShowProfile();
                        ShowPopupMessage("Adhar Proof Updated Successfully", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Warning);
                    }
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 800kb.", PopupMessageType.Warning);
                    return;
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnbank_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            //string folderPath = Server.MapPath("../customer/kyc/");
            if (ftpbankproof.HasFile)
            {
                int ContentLength = ftpbankproof.PostedFile.ContentLength;
                if (ContentLength <= 8000000)
                {
                    //string userid = string.Concat(Session["UserID"].ToString(), "_3");
                    //string extension = Path.GetExtension(ftpbankproof.FileName);
                    //if (extension == ".jpg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpg";
                    //}
                    //else if (extension == ".jpeg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpeg";
                    //}
                    //else if (extension == ".png")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".png";
                    //}
                    ////FileName = Session["UserID"].ToString() + ftpbankproof.PostedFile.FileName;
                    //ftpbankproof.SaveAs(folderPath + FileName);
                    //SaveFilename = "../customer/kyc/" + FileName;
                    Stream fs = ftpbankproof.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    byte[] bankProof = bytes;
                    SqlConnection con = new SqlConnection(constr);
                    SqlCommand cmd = new SqlCommand("update MLM_UserDetail set BankProof='Bank Passbook',BankProofUrl=@image where UserID='"+ Session["UserID"].ToString() + "'",con);
                    cmd.Parameters.AddWithValue("@image", bankProof);
                    con.Open();
                    int rowaffected = cmd.ExecuteNonQuery();
                    if (rowaffected > 0)
                    {
                        con.Close();
                        ShowProfile();
                        ShowPopupMessage("Bank Proof Updated Successfully", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Warning);
                    }

                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 800kb.", PopupMessageType.Warning);
                    return;
                }
               
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnpancard_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            //string folderPath = Server.MapPath("../customer/kyc/");
            if (ftppan.HasFile)
            {
                int ContentLength = ftppan.PostedFile.ContentLength;
                if (ContentLength <= 8000000)
                {
                    //string userid = string.Concat(Session["UserID"].ToString(), "_4");
                    //string extension = Path.GetExtension(ftppan.FileName);
                    //if (extension == ".jpg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpg";
                    //}
                    //else if (extension == ".jpeg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpeg";
                    //}
                    //else if (extension == ".png")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".png";
                    //}
                    ////FileName = Session["UserID"].ToString() + ftppan.PostedFile.FileName;
                    //ftppan.SaveAs(folderPath + FileName);
                    //SaveFilename = "../customer/kyc/" + FileName;

                    Stream fs = ftppan.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    byte[] PanProof = bytes;
                    SqlConnection con = new SqlConnection(constr);
                    SqlCommand cmd = new SqlCommand("update MLM_UserDetail set IdentityProof='Pan Card',IdentityProofUrl=@image where UserID='" + Session["UserID"].ToString() + "'", con);
                    cmd.Parameters.AddWithValue("@image", PanProof);
                    con.Open();
                    int rowaffected = cmd.ExecuteNonQuery();
                    if (rowaffected > 0)
                    {
                        con.Close();
                        ShowProfile();
                        ShowPopupMessage("Pan Details Updated Successfully", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Warning);
                    }
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 800kb.", PopupMessageType.Warning);
                    return;
                }
                
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btngstprrofupdate_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
           // string folderPath = Server.MapPath("../customer/kyc/");
            if (ftpgst.HasFile)
            {
                int ContentLength = ftpgst.PostedFile.ContentLength;
                if (ContentLength <= 8000000)
                {
                    //string userid = string.Concat(Session["UserID"].ToString(), "_5");
                    //string extension = Path.GetExtension(ftpgst.FileName);
                    //if (extension == ".jpg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpg";
                    //}
                    //else if (extension == ".jpeg")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".jpeg";
                    //}
                    //else if (extension == ".png")
                    //{
                    //    FileName = string.Empty;
                    //    FileName = userid + ".png";
                    //}
                    ////FileName = Session["UserID"].ToString() + ftpgst.PostedFile.FileName;
                    //ftpgst.SaveAs(folderPath + FileName);
                    //SaveFilename = "../customer/kyc/" + FileName;
                    Stream fs = ftpgst.PostedFile.InputStream;
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    byte[] GstProof = bytes;
                    SqlConnection con = new SqlConnection(constr);
                    SqlCommand cmd = new SqlCommand("update MLM_UserDetail set GST='GST',GSTProofUrl=@image where UserID='" + Session["UserID"].ToString() + "'", con);
                    cmd.Parameters.AddWithValue("@image", GstProof);
                    con.Open();
                    int rowaffected = cmd.ExecuteNonQuery();
                    if (rowaffected > 0)
                    {
                        con.Close();
                        ShowProfile();
                        ShowPopupMessage("GST Proof Updated Successfully", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Warning);
                    }
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 800kb.", PopupMessageType.Warning);
                    return;
                }
                
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
}
