﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.IO;
using System.Drawing;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
public partial class customer_auth_gethelp : System.Web.UI.Page
{
    string cn = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();




    DAL objDAL = new DAL();
    int index = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            GetData();
            //LedgerCredit();
        }
    }
    private void GetData()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DataTable dt = new DataTable();

            if (!(string.IsNullOrEmpty(txtfromdate.Text) && string.IsNullOrEmpty(txttodate.Text)))
            {
                string[] dte = txtfromdate.Text.Split('/');
                string[] dte1 = txttodate.Text.Split('/');
                string joinstring = "/";
                DateTime fromdate = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
                DateTime todate = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);
                //  dt = objDAL.Gettable("select * from Donation where GH_ID='" + UserID + "'  and Status!='Confirm'", ref message);

                // dt = objDAL.Gettable("SELECT ph.Photo,ph.GH_ID,ph.PH_ID,(select mobile from MLM_Registration where  UserID = ph.PH_ID) As Mobile,PayAmount,ph.Status, ph.CreationDate from Donation ph inner join MLM_Registration mr on ph.PH_ID = mr.UserID where mr.UserID = '" + UserID + "' and ph.Status = 'Pending'", ref message);



            }
            else
            {
                ///  dt = objDAL.Gettable("select * from Donation where GH_ID='" + UserID + "' and Status!='Confirm'", ref message);

                dt = objDAL.Gettable("SELECT ph.ID, ph.Photo,ph.GH_ID,ph.PH_ID,(select mobile from MLM_Registration where  UserID = ph.PH_ID) As Mobile,PayAmount,ph.Status, ph.CreationDate,ph.UpdationDate from Donation ph inner join MLM_Registration mr on ph.GH_ID = mr.UserID where mr.UserID='" + UserID + "' and ph.Status='Pending'", ref message);


            }
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        GetData();
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            GetData();
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=DonationLink.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GV_LedgerList.AllowPaging = false;
                GetData();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GV_LedgerList.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GV_LedgerList.HeaderRow.Cells)
                {
                    cell.BackColor = GV_LedgerList.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GV_LedgerList.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GV_LedgerList.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GV_LedgerList.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GV_LedgerList.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void btnUpdate_Command(object sender, CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        try
        {
            con = new SqlConnection(cn);
            cmd = new SqlCommand("Update Donation set status = 'Confirm', UpdationDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' where ID=" + id, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                // LedgerCredit();
                // UpdatePaid(id);
                // BRONZELEVEL(id);

                DAL dal = new DAL();
                string msg = string.Empty;


                Response.Write("<script>alert('Receipt Accepted Successfully.');window.location='auth-gethelp.aspx';</script>");



            }
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);

        }
    }
    protected void GV_LedgerList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        index = Convert.ToInt32(e.CommandArgument);
    }

    protected void btnReject_Command(object sender, CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        DataTable getid = dal.Gettable("select PH_ID,GH_ID,GetAmount from Donation where Id='" + id + "' ", ref message);

        string getidrejected = getid.Rows[0]["GH_ID"].ToString();
        string amt = getid.Rows[0]["GetAmount"].ToString();
        string phidrejected = getid.Rows[0]["PH_ID"].ToString();


        try
        {
            con = new SqlConnection(cn);
            cmd = new SqlCommand("Update Donation set status = 'Rejected', UpdationDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', Photo = 'images/warning.jpg' where ID=" + id, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {



                StringBuilder sbb = new StringBuilder();

                sbb.AppendLine("insert into GetHelp(UserID,Amount)");
                sbb.AppendFormat("values('{0}','{1}')", getidrejected, amt);
                int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);


                StringBuilder sbb1 = new StringBuilder();

                sbb1.AppendLine("insert into ProvideHelp(UserID,Amount)");
                sbb1.AppendFormat("values('{0}','{1}')", phidrejected, amt);
                int rowaffected3 = dal.Executequery(sbb1.ToString(), ref message);

                GetData();
                ShowPopupMessage("Receipt Rejected Successfully.", PopupMessageType.Success);
                //Response.Write("<script>alert('Receipt Rejected Successfully.');window.location='DonationAccept.aspx';</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
            //Note: Exception.Message returns a detailed message that describes the current exception. 
            //For security reasons, we do not recommend that you return Exception.Message to end users in 
            //production environments. It would be better to put a generic error message. 
        }
    }
    //private void LedgerCredit()
    //{
    //    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    //    SqlConnection con = new SqlConnection(connstring);
    //    con.Open();
    //    SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
    //    cmd.Parameters.AddWithValue("@TransactionType", "CR");
    //    cmd.Parameters.AddWithValue("@CR", "200");
    //    cmd.Parameters.AddWithValue("@DR", "0.00");
    //    cmd.Parameters.AddWithValue("@Descriptions", "Receipt Amount!");
    //    cmd.Parameters.AddWithValue("@Mode", "IN");
    //    int flag = cmd.ExecuteNonQuery();
    //    //Level Upgrade 300/- Debit
    //    if (flag > 0)
    //    {
    //        DAL dal = new DAL();
    //        string msg = string.Empty;
    //        DataTable dt = dal.Gettable("select * from Ledger_Wallet where CR=200 and UserID='" + Session["UserID"].ToString() + "'", ref message);
    //        if (dt.Rows.Count == 2)
    //        {
    //            //DataTable dtExist = dal.Gettable("select * from Ledger_Wallet where DR=300 and UserID='" + Session["UserID"].ToString() + "'", ref message);
    //            DataTable dtExist = dal.Gettable("select * from DonationNew where UserID='" + Session["UserID"].ToString() + "' and Amount='300'", ref message);
    //            if (dtExist.Rows.Count > 0)
    //            {
    //                //Not Deduct again
    //            }
    //            else
    //            {
    //                string id = "";
    //                DataTable dtFindSp = dal.Gettable("select SponsorID from MLM_Registration where UserID='"+ Session["UserID"].ToString() + "'", ref message);
    //                if (dtFindSp.Rows.Count > 0)
    //                {
    //                    id = dtFindSp.Rows[0]["SponsorID"].ToString();
    //                    string amount = "300";
    //                    // LedgerDebit(id, amount);
    //                    //LedgerCreditSpID(id, amount); //Instant created but not use
    //                    InsertReceiptAmount(id, amount);
    //                }
    //            }

    //        }
    //    }
    //    //Level Upgrade 300/- Debit End
    //}
    //private void LedgerDebit(string id, string amt)
    //{
    //    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    //    SqlConnection con = new SqlConnection(connstring);
    //    con.Open();
    //    SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.AddWithValue("@UserID", id);
    //    cmd.Parameters.AddWithValue("@TransactionType", "DR");
    //    cmd.Parameters.AddWithValue("@CR", "0.00");
    //    cmd.Parameters.AddWithValue("@DR", amt);
    //    cmd.Parameters.AddWithValue("@Descriptions", "Level Upgrade");
    //    cmd.Parameters.AddWithValue("@Mode", "IN");
    //    int flag = cmd.ExecuteNonQuery();
    //}
    //private void LedgerCreditSpID(string id, string amt)
    //{
    //    DAL dal = new DAL();
    //    string spidCR = "";
    //    DataTable dtsp = dal.Gettable("select SponsorID from MLM_Registration where UserID='"+ id + "'", ref message);
    //    if (dtsp.Rows.Count > 0)
    //    {
    //        spidCR = dtsp.Rows[0]["SponsorID"].ToString();
    //        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    //        SqlConnection con = new SqlConnection(connstring);
    //        con.Open();
    //        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.Parameters.AddWithValue("@UserID", spidCR);
    //        cmd.Parameters.AddWithValue("@TransactionType", "CR");
    //        cmd.Parameters.AddWithValue("@CR", amt);
    //        cmd.Parameters.AddWithValue("@DR", "0.00");
    //        cmd.Parameters.AddWithValue("@Descriptions", "Level Upgrade");
    //        cmd.Parameters.AddWithValue("@Mode", "IN");
    //        int flag = cmd.ExecuteNonQuery();
    //    }
    //}
    //private void LedgerDebitDonation(string id, string amt)
    //{
    //    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    //    SqlConnection con = new SqlConnection(connstring);
    //    con.Open();
    //    SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.AddWithValue("@UserID", id);
    //    cmd.Parameters.AddWithValue("@TransactionType", "DR");
    //    cmd.Parameters.AddWithValue("@CR", "0.00");
    //    cmd.Parameters.AddWithValue("@DR", amt);
    //    cmd.Parameters.AddWithValue("@Descriptions", "Donation To Trust");
    //    cmd.Parameters.AddWithValue("@Mode", "IN");
    //    int flag = cmd.ExecuteNonQuery();
    //}
    //private void LedgerCreditLevel(string useridB, string amount)
    //{
    //    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    //    SqlConnection con = new SqlConnection(connstring);
    //    con.Open();
    //    SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.AddWithValue("@UserID", useridB);
    //    cmd.Parameters.AddWithValue("@TransactionType", "CR");
    //    cmd.Parameters.AddWithValue("@CR", amount);
    //    cmd.Parameters.AddWithValue("@DR", "0.00");
    //    cmd.Parameters.AddWithValue("@Descriptions", "Receipt Amount!");
    //    cmd.Parameters.AddWithValue("@Mode", "IN");
    //    int flag = cmd.ExecuteNonQuery();

    //    //Level Upgrade 900/- Debit
    //    if (flag > 0)
    //    {
    //        DAL dal = new DAL();
    //        string msg = string.Empty;
    //        DataTable dt = dal.Gettable("select * from Ledger_Wallet where CR=300 and UserID='" + useridB + "'", ref message);
    //        if (dt.Rows.Count == 4)
    //        {
    //            //DataTable dtExist1 = dal.Gettable("select * from Ledger_Wallet where DR=900 and UserID='" + useridB + "'", ref message);
    //            DataTable dtExist1 = dal.Gettable("select * from DonationNew where  Amount='900' and UserID='" + useridB + "'", ref message);
    //            if (dtExist1.Rows.Count > 0)
    //            {
    //                //Not Again Deduct Amount
    //            }
    //            else
    //            {
    //                string id = "";
    //                DataTable dtFindSp300 = dal.Gettable("select SponsorID from DonationNew where UserID='" + useridB + "' and  Amount='300' ", ref message);
    //                if (dtFindSp300.Rows.Count > 0)
    //                {
    //                    id = dtFindSp300.Rows[0]["SponsorID"].ToString();
    //                    string amount1 = "900";
    //                    //LedgerDebit(id, amount1);
    //                    // LedgerCreditSpID(id, amount1);
    //                    //InsertReceiptAmount(id, amount1);
    //                    InsertReceiptAmount1(id, amount1, useridB);
    //                }
    //            }
    //        }


    //        //Level Upgrade 2500 /- or Trust Donation 200 /-
    //        DataTable dt2 = dal.Gettable("select * from Ledger_Wallet where CR=900 and UserID='" + useridB + "'", ref message);
    //        if (dt2.Rows.Count == 8)
    //        {
    //            //DataTable dtExist2 = dal.Gettable("select * from Ledger_Wallet where DR=2500 and UserID='" + useridB + "'", ref message);
    //            DataTable dtExist2 = dal.Gettable("select * from DonationNew where  Amount='2500' and UserID='" + useridB + "'", ref message);
    //            if (dtExist2.Rows.Count > 0)
    //            {
    //                //Not Again Deduct Amount
    //            }
    //            else
    //            {
    //                string id = "";
    //                DataTable dtFindSp900 = dal.Gettable("select SponsorID from DonationNew where UserID='" + useridB + "' and  Amount='900' ", ref message);
    //                if (dtFindSp900.Rows.Count > 0)
    //                {
    //                    id = dtFindSp900.Rows[0]["SponsorID"].ToString();
    //                    string amount1 = "2500";

    //                    InsertReceiptAmount1(id, amount1, useridB);
    //                    string amount2 = "200";
    //                   // InsertDonationTrustAmount(useridB, amount2);
    //                }

    //            }
    //        }
    //        //Level Upgrade 2500 /- or Trust Donation 200 /- End

    //        //Level Upgrade 20000 /- or Trust Donation 2000 /-
    //        DataTable dt3 = dal.Gettable("select * from Ledger_Wallet where CR=2500 and UserID='" + useridB + "'", ref message);
    //        if (dt3.Rows.Count == 16)
    //        {
    //            // DataTable dtExist3 = dal.Gettable("select * from Ledger_Wallet where DR=20000 and UserID='" + useridB + "'", ref message);
    //            DataTable dtExist3 = dal.Gettable("select * from DonationNew where  Amount='20000' and UserID='" + useridB + "'", ref message);
    //            if (dtExist3.Rows.Count > 0)
    //            {
    //                //Not Again Deduct Amount
    //            }
    //            else
    //            {
    //                string id = "";
    //                DataTable dtFindSp2500 = dal.Gettable("select SponsorID from DonationNew where UserID='" + useridB + "' and  Amount='2500' ", ref message);
    //                if (dtFindSp2500.Rows.Count > 0)
    //                {
    //                    id = dtFindSp2500.Rows[0]["SponsorID"].ToString();
    //                    string amount1 = "20000";
    //                    // LedgerDebit(id, amount1);
    //                    // LedgerCreditSpID(id, amount1);
    //                    // InsertReceiptAmount(id, amount1);
    //                    InsertReceiptAmount1(id, amount1, useridB);
    //                    string amount2 = "2000";
    //                    // LedgerDebitDonation(id, amount2);
    //                  //  InsertDonationTrustAmount(useridB, amount2);
    //                }
    //            }
    //        }
    //        //Level Upgrade 20000 /- or Trust Donation 2000 /- End

    //        //Level Upgrade 150000 /- or Trust Donation 20000 /-
    //        DataTable dt4 = dal.Gettable("select * from Ledger_Wallet where CR=20000 and UserID='" + useridB + "'", ref message);
    //        if (dt4.Rows.Count == 32)
    //        {
    //            // DataTable dtExist4 = dal.Gettable("select * from Ledger_Wallet where DR=150000 and UserID='" + useridB + "'", ref message);
    //            DataTable dtExist4 = dal.Gettable("select * from DonationNew where  Amount='150000' and  UserID='" + useridB + "'", ref message);
    //            if (dtExist4.Rows.Count > 0)
    //            {
    //                //Not Again Deduct Amount
    //            }
    //            else
    //            {
    //                //string id = useridB;
    //                string id = "";
    //                DataTable dtFindSp20000 = dal.Gettable("select SponsorID from DonationNew where UserID='" + useridB + "' and  Amount='20000' ", ref message);
    //                if (dtFindSp20000.Rows.Count > 0)
    //                {
    //                    id = dtFindSp20000.Rows[0]["SponsorID"].ToString();
    //                    string amount1 = "150000";
    //                    // LedgerDebit(id, amount1);
    //                    //LedgerCreditSpID(id, amount1);
    //                    //InsertReceiptAmount(id, amount1);
    //                    InsertReceiptAmount1(id, amount1, useridB);
    //                    string amount2 = "20000";
    //                    // LedgerDebitDonation(id, amount2);
    //                  //  InsertDonationTrustAmount(useridB, amount2);
    //                }
    //            }
    //        }
    //        //Level Upgrade 150000 /- or Trust Donation 20000 /- End

    //    }
    //    //Level Upgrade 900/- Debit End
    //}


    //private void UpdatePaid(int Uid)
    //{
    //    DAL dal = new DAL();
    //    string uid = "";
    //    DataTable dt = dal.Gettable("select UserID from DonationNew where Id='" + Uid + "' ", ref message);
    //    if (dt.Rows.Count > 0)
    //    {
    //        uid = dt.Rows[0]["UserID"].ToString();
    //        StringBuilder sb = new StringBuilder();
    //        sb.AppendFormat("Update MLM_Registration set JoinType='Paid',ActiveDate=getdate() where UserID='{0}'", uid);
    //        int rowaffected = dal.Executequery(sb.ToString(), ref message);
    //        if (rowaffected > 0)
    //        {
    //            //
    //        }
    //    }

    //}
    //private void BRONZELEVEL(int Uid)
    //{
    //    DAL dal = new DAL();
    //    string uid = "";
    //    string Amount = "";
    //    DataTable dt = dal.Gettable("select UserID from DonationNew where Id='" + Uid + "' ", ref message);
    //    if (dt.Rows.Count > 0)
    //    {
    //        uid = dt.Rows[0]["UserID"].ToString();
    //        DataTable dtall = dal.Gettable("select UserID,Lleg,Rleg from MLM_Registration where JoinType='Paid'", ref message);
    //        if (dtall.Rows.Count > 0)
    //        {
    //            string userid = "";
    //            string lleg = "";
    //            string rleg = "";
    //            for (int i = 0; i < dtall.Rows.Count; i++)
    //            {
    //                userid = dtall.Rows[i]["UserID"].ToString();
    //                lleg = dtall.Rows[i]["Lleg"].ToString();
    //                rleg = dtall.Rows[i]["Rleg"].ToString();

    //                string lleg1 = "";
    //                string rleg1 = "";
    //                string lleg2 = "";
    //                string rleg2 = "";

    //                //2nd Level Left Side
    //                DataTable dtlleg = dal.Gettable("select UserID,Lleg,Rleg from MLM_Registration where JoinType='Paid' and UserId='" + lleg + "'", ref message);
    //                if (dtlleg.Rows.Count > 0)
    //                {
    //                    lleg1 = dtlleg.Rows[0]["Lleg"].ToString();
    //                    rleg1 = dtlleg.Rows[0]["Rleg"].ToString();

    //                    if (lleg1.ToUpper() == uid.ToUpper())
    //                    {
    //                        Amount = "300";
    //                        LedgerCreditLevel(userid, Amount);
    //                    }
    //                    else if (rleg1.ToUpper() == uid.ToUpper())
    //                    {
    //                        Amount = "300";
    //                        LedgerCreditLevel(userid, Amount);
    //                    }

    //                    SILVERLEVEL(userid, lleg1, uid.ToUpper());
    //                    SILVERLEVEL(userid, rleg1, uid.ToUpper());

    //                }
    //                //2nd Level Left Side End

    //                //2nd Level Right Side
    //                DataTable dtrleg = dal.Gettable("select UserID,Lleg,Rleg from MLM_Registration where JoinType='Paid' and UserId='" + rleg + "'", ref message);
    //                if (dtrleg.Rows.Count > 0)
    //                {
    //                    lleg2 = dtrleg.Rows[0]["Lleg"].ToString();
    //                    rleg2 = dtrleg.Rows[0]["Rleg"].ToString();

    //                    if (lleg2.ToUpper() == uid.ToUpper())
    //                    {
    //                        Amount = "300";
    //                        LedgerCreditLevel(userid, Amount);
    //                    }
    //                    else if (rleg2.ToUpper() == uid.ToUpper())
    //                    {
    //                        Amount = "300";
    //                        LedgerCreditLevel(userid, Amount);
    //                    }

    //                    SILVERLEVEL(userid, lleg2, uid.ToUpper());
    //                    SILVERLEVEL(userid, rleg2, uid.ToUpper());
    //                }
    //                //2nd Level Right Side End
    //            }
    //        }
    //    }
    //}
    //private void SILVERLEVEL(string userid, string lrleg1, string equalID)
    //{
    //    DAL dal = new DAL();
    //    string lleg11 = "";
    //    string rleg11 = "";
    //    string lleg22 = "";
    //    string rleg22 = "";
    //    string lleg33 = "";
    //    string rleg33 = "";
    //    string lleg44 = "";
    //    string rleg44 = "";
    //    string Amount3 = "";
    //    //3rd Level 
    //    DataTable dtlrleg1 = dal.Gettable("select UserID,Lleg,Rleg from MLM_Registration where JoinType='Paid' and UserId='" + lrleg1 + "'", ref message);
    //    if (dtlrleg1.Rows.Count > 0)
    //    {
    //        lleg11 = dtlrleg1.Rows[0]["Lleg"].ToString();
    //        rleg11 = dtlrleg1.Rows[0]["Rleg"].ToString();
    //        if (lleg11.ToUpper() == equalID.ToUpper())
    //        {
    //            Amount3 = "900";
    //            LedgerCreditLevel(userid, Amount3);
    //        }
    //        else if (rleg11.ToUpper() == equalID.ToUpper())
    //        {
    //            Amount3 = "900";
    //            LedgerCreditLevel(userid, Amount3);
    //        }

    //        GOLDLEVEL(userid, lleg11, equalID.ToUpper());
    //        GOLDLEVEL(userid, rleg11, equalID.ToUpper());
    //    }
    //    //3rd Level End
    //}
    //private void GOLDLEVEL(string userid, string lrleg11, string equalID1)
    //{
    //    DAL dal = new DAL();
    //    string lleg111 = "";
    //    string rleg111 = "";
    //    string Amount4 = "";
    //    //4th Level 
    //    DataTable dtlrleg11 = dal.Gettable("select UserID,Lleg,Rleg from MLM_Registration where JoinType='Paid' and UserId='" + lrleg11 + "'", ref message);
    //    if (dtlrleg11.Rows.Count > 0)
    //    {
    //        lleg111 = dtlrleg11.Rows[0]["Lleg"].ToString();
    //        rleg111 = dtlrleg11.Rows[0]["Rleg"].ToString();
    //        if (lleg111.ToUpper() == equalID1.ToUpper())
    //        {
    //            Amount4 = "2500";
    //            LedgerCreditLevel(userid, Amount4);
    //        }
    //        else if (rleg111.ToUpper() == equalID1.ToUpper())
    //        {
    //            Amount4 = "2500";
    //            LedgerCreditLevel(userid, Amount4);
    //        }

    //        PLATINUMLEVEL(userid, lleg111, equalID1.ToUpper());
    //        PLATINUMLEVEL(userid, rleg111, equalID1.ToUpper());
    //    }
    //    //4th Level End
    //}
    //private void PLATINUMLEVEL(string userid, string lrleg111, string equalID11)
    //{
    //    DAL dal = new DAL();
    //    string lleg1111 = "";
    //    string rleg1111 = "";
    //    string Amount5 = "";

    //    //5th Level 
    //    DataTable dtlrleg111 = dal.Gettable("select UserID,Lleg,Rleg from MLM_Registration where JoinType='Paid' and UserId='" + lrleg111 + "'", ref message);
    //    if (dtlrleg111.Rows.Count > 0)
    //    {
    //        lleg1111 = dtlrleg111.Rows[0]["Lleg"].ToString();
    //        rleg1111 = dtlrleg111.Rows[0]["Rleg"].ToString();
    //        if (lleg1111.ToUpper() == equalID11.ToUpper())
    //        {
    //            Amount5 = "20000";
    //            LedgerCreditLevel(userid, Amount5);
    //        }
    //        else if (rleg1111.ToUpper() == equalID11.ToUpper())
    //        {
    //            Amount5 = "20000";
    //            LedgerCreditLevel(userid, Amount5);
    //        }

    //        TITANIUMLEVEL(userid, lleg1111, equalID11.ToUpper());
    //        TITANIUMLEVEL(userid, rleg1111, equalID11.ToUpper());
    //    }
    //    //5th Level End
    //}
    //private void TITANIUMLEVEL(string userid, string lrleg1111, string equalID111)
    //{
    //    //6th Level 
    //    DAL dal = new DAL();
    //    string lleg11111 = "";
    //    string rleg11111 = "";
    //    string Amount6 = "";

    //    DataTable dtlrleg1111 = dal.Gettable("select UserID,Lleg,Rleg from MLM_Registration where JoinType='Paid' and UserId='" + lrleg1111 + "'", ref message);
    //    if (dtlrleg1111.Rows.Count > 0)
    //    {
    //        lleg11111 = dtlrleg1111.Rows[0]["Lleg"].ToString();
    //        rleg11111 = dtlrleg1111.Rows[0]["Rleg"].ToString();
    //        if (lleg11111.ToUpper() == equalID111.ToUpper())
    //        {
    //            Amount6 = "150000";
    //            LedgerCreditLevel(userid, Amount6);
    //        }
    //        else if (rleg11111.ToUpper() == equalID111.ToUpper())
    //        {
    //            Amount6 = "150000";
    //            LedgerCreditLevel(userid, Amount6);
    //        }

    //        //End Function Call
    //    }
    //    //6th Level End
    //}
    //public void InsertReceiptAmount(string id, string amt)
    //{
    //    DAL dal = new DAL();
    //    string mob = "";
    //    string sid = "";

    //    DataTable dtsp = dal.Gettable("Select SponsorID from MLM_Registration Where UserID='" + id + "'", ref message);
    //    if (dtsp.Rows.Count > 0)
    //    {
    //        sid= dtsp.Rows[0]["SponsorID"].ToString();
    //        DataTable dtmob = dal.Gettable("Select Mobile from MLM_Registration Where UserID='" + sid + "' ", ref message);
    //        if (dtmob.Rows.Count > 0)
    //        {
    //            mob = dtmob.Rows[0]["Mobile"].ToString();
    //            StringBuilder sbb = new StringBuilder();
    //            // sbb.AppendLine("insert into MLM_UserDetail(UserID)");
    //            sbb.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo)");
    //            sbb.AppendFormat("values('{0}','{1}','{2}','{3}')", Session["UserID"].ToString(), sid, amt, mob);
    //            int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);
    //        }
    //        else
    //        {
    //            StringBuilder sbb = new StringBuilder();
    //            // sbb.AppendLine("insert into MLM_UserDetail(UserID)");
    //            sbb.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo)");
    //            sbb.AppendFormat("values('{0}','{1}','{2}','{3}')",Session["UserID"].ToString(), sid, amt, mob);
    //            int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);
    //        }
    //    }
    //}
    //public void InsertReceiptAmount1(string id, string amt,string idu)
    //{
    //    DAL dal = new DAL();
    //    string mob = "";
    //    string sid = "";

    //    DataTable dtsp = dal.Gettable("Select SponsorID from MLM_Registration Where UserID='" + id + "'", ref message);
    //    if (dtsp.Rows.Count > 0)
    //    {
    //        sid = dtsp.Rows[0]["SponsorID"].ToString();
    //        DataTable dtmob = dal.Gettable("Select Mobile from MLM_Registration Where UserID='" + sid + "' ", ref message);
    //        if (dtmob.Rows.Count > 0)
    //        {
    //            mob = dtmob.Rows[0]["Mobile"].ToString();
    //            StringBuilder sbb = new StringBuilder();
    //            // sbb.AppendLine("insert into MLM_UserDetail(UserID)");
    //            sbb.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo)");
    //            sbb.AppendFormat("values('{0}','{1}','{2}','{3}')", idu, sid, amt, mob);
    //            int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);
    //        }
    //        else
    //        {
    //            StringBuilder sbb = new StringBuilder();
    //            // sbb.AppendLine("insert into MLM_UserDetail(UserID)");
    //            sbb.AppendLine("insert into DonationNew(UserID,SponsorID,Amount,MobileNo)");
    //            sbb.AppendFormat("values('{0}','{1}','{2}','{3}')", idu, sid, amt, mob);
    //            int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);
    //        }
    //    }
    //}
    //public void InsertDonationTrustAmount(string id, string amt)
    //{
    //    DAL dal = new DAL();
    //    string mob = "";
    //    string sid = "";

    //    DataTable dtsp = dal.Gettable("Select SponsorID from MLM_Registration Where UserID='" + id + "'", ref message);
    //    if (dtsp.Rows.Count > 0)
    //    {
    //        sid = dtsp.Rows[0]["SponsorID"].ToString();
    //        DataTable dtmob = dal.Gettable("Select Mobile from MLM_Registration Where UserID='" + sid + "' ", ref message);
    //        if (dtmob.Rows.Count > 0)
    //        {
    //            mob = dtmob.Rows[0]["Mobile"].ToString();
    //            mob = "";
    //            StringBuilder sbb = new StringBuilder();
    //            // sbb.AppendLine("insert into MLM_UserDetail(UserID)");
    //            sbb.AppendLine("insert into DonationTrustNew(UserID,SponsorID,Amount,MobileNo)");
    //            sbb.AppendFormat("values('{0}','{1}','{2}','{3}')", id, "Main", amt, mob);
    //            int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);
    //        }
    //        else
    //        {
    //            StringBuilder sbb = new StringBuilder();
    //            // sbb.AppendLine("insert into MLM_UserDetail(UserID)");
    //            sbb.AppendLine("insert into DonationTrustNew(UserID,SponsorID,Amount,MobileNo)");
    //            sbb.AppendFormat("values('{0}','{1}','{2}','{3}')", id, "Main", amt, mob);
    //            int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);
    //        }
    //    }
    //}
}