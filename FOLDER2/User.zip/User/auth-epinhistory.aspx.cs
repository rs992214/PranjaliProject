﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;

public partial class customer_auth_epinhistory : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            
            if (!IsPostBack)
            {
                GetData();
              
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    private void GetData()
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtFrom.Text)))
            {
                dt = objDAL.Gettable("Select ph.UserID,ph.PIN,pp.PackageName,ph.Transferby,convert(nvarchar,ph.Date,105) as datehistory  from Pin_History ph INNER JOIN PackageInfo pp on ph.Package=pp.ID  where ph.UserID='" + UserID + "'", ref message);
            }
            else
            {
                dt = objDAL.Gettable("Select ph.UserID,ph.PIN,pp.PackageName,ph.Transferby,convert(nvarchar,ph.Date,105) as datehistory  from Pin_History ph INNER JOIN PackageInfo pp on ph.Package=pp.ID  where ph.UserID='" + UserID + "'", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
            
        }
    }
   
    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        GetData();
    }
   
}