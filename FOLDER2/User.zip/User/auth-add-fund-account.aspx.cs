﻿using DataAccessLayer;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_add_fund_account : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();
    HiddenField hf_Basic = new HiddenField();
    HiddenField hf_Bank_Account = new HiddenField();

    protected void Page_Load(object sender, EventArgs e)
    {
        GetApiCredential();

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                btnSave.Enabled = false;
                txtuserid_TextChanged(sender, e);
                GetAllContacts();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }

    protected void txtuserid_TextChanged(object sender, EventArgs e)
    {
        DataTable dtuserid = dal.Gettable("select UserID,Name from MLM_Registration where UserID ='" + Session["UserID"].ToString() + "' and JoinType='Paid'", ref message);
        if (dtuserid.Rows.Count > 0)
        {

            DataTable dtdata = dal.Gettable("select mm.UserID,mm.Name,ml.PayeeName,ml.AccountNo,ml.IFSCCode from MLM_Registration mm inner join MLM_UserDetail ml on mm.UserID=ml.UserID where mm.UserID='" + Session["UserID"].ToString() + "' and mm.JoinType='Paid'", ref message);
            if (dtdata.Rows.Count > 0)
            {
                txtuserid.Text = Session["UserID"].ToString();
                txtContactID.Text = Request.QueryString["cont_id"].ToString();
                txtName.Text = dtdata.Rows[0]["PayeeName"].ToString();
                txtAccountNumber.Text = dtdata.Rows[0]["AccountNo"].ToString();
                txtIfsc.Text = dtdata.Rows[0]["IFSCCode"].ToString();

                lbluserid.Visible = true;
                lbluserid.Text = dtuserid.Rows[0]["Name"].ToString();
                lblInvalidID.Visible = false;
                btnSave.Enabled = true;
            }
            else
            {
                btnSave.Enabled = false;
            }
        }
        else
        {
            btnSave.Enabled = false;
        }
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.RawUrl);
    }


    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }
    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var client = new RestClient("https://api.razorpay.com/v1/fund_accounts");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
            //request.AddHeader("Authorization", "Basic cnpwX3Rlc3RfUDQ2S3c1VjBCTmV2aFc6cXZhN3lRZGhJOTNwOVdnd0dKZ2g3UzJk");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "{\r\n  \"contact_id\":\"" + txtContactID.Text + "\",\r\n  \"account_type\":\"bank_account\",\r\n  \"bank_account\":{\r\n    \"name\":\"" + txtName.Text + "\",\r\n    \"ifsc\":\"" + txtIfsc.Text + "\",\r\n    \"account_number\":\"" + txtAccountNumber.Text + "\"\r\n  }\r\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            //Console.WriteLine(response.Content);

            string status = response.StatusCode.ToString();

            if (status == "Created" || status == "OK")
            {
                Fund_Account data = JsonConvert.DeserializeObject<Fund_Account>(response.Content);
                txtReId.Text = data.id;
                txtReContactID.Text = data.contact_id;
                txtReAccountType.Text = data.account_type;
                if (data.vpa == null)
                {
                    txtReName.Text = data.bank_account.name;
                    txtReBankName.Text = data.bank_account.bank_name;
                    txtReAccountNumber.Text = data.bank_account.account_number;
                    txtReIfsc.Text = data.bank_account.ifsc;
                }
                else
                {
                    txtReVpaUsername.Text = data.vpa.username;
                    txtReVpaHandle.Text = data.vpa.handle;
                    txtReVpaAddress.Text = data.vpa.address;
                };

                string status1 = data.active.ToString();
                rdStatus.Items.FindByValue(status1).Selected = true;

                DataTable dt = dal.Gettable("SELECT UserID, Fund_ID, Contact_ID FROM Razor_Fund_Account WHERE UserID='" + txtuserid.Text + "' AND Fund_ID='" + txtReId.Text + "' AND Contact_ID='" + txtReContactID.Text + "'", ref message);
                if (dt.Rows.Count > 0)
                {
                    Response.Write("<script>alert('Fund Account Already Created');</script>");
                }
                else
                {
                    int index = dal.Executequery("INSERT INTO Razor_Fund_Account(UserID, Fund_ID, Contact_ID, Created_Date) VALUES ('" + txtuserid.Text + "', '" + txtReId.Text + "', '" + txtReContactID.Text + "', GETDATE())", ref message);
                    Response.Write("<script>alert('Fund Account Created Successfully');</script>");
                }

                GetAllContacts();
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Could Not Save bank Details.')", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.ToString() + "')", true);
        }
    }

    protected void btnAddUpi_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(txtUpiAddress.Text))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter UPI Address')", true);
            }
            else
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                var client = new RestClient("https://api.razorpay.com/v1/fund_accounts");
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", "{\r\n  \"account_type\":\"vpa\",\r\n  \"contact_id\":\"" + txtContactID.Text + "\",\r\n  \"vpa\":{\r\n    \"address\":\"" + txtUpiAddress.Text + "\"\r\n  }\r\n}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                //Console.WriteLine(response.Content);

                string status = response.StatusCode.ToString();

                if (status == "Created" || status == "OK")
                {
                    Fund_Account data = JsonConvert.DeserializeObject<Fund_Account>(response.Content);
                    txtReId.Text = data.id;
                    txtReContactID.Text = data.contact_id;
                    txtReAccountType.Text = data.account_type;
                    if (data.vpa == null)
                    {
                        txtReName.Text = data.bank_account.name;
                        txtReBankName.Text = data.bank_account.bank_name;
                        txtReAccountNumber.Text = data.bank_account.account_number;
                        txtReIfsc.Text = data.bank_account.ifsc;
                    }
                    else
                    {
                        txtReVpaUsername.Text = data.vpa.username;
                        txtReVpaHandle.Text = data.vpa.handle;
                        txtReVpaAddress.Text = data.vpa.address;
                    };

                    string status1 = data.active.ToString();
                    rdStatus.Items.FindByValue(status1).Selected = true;

                    DataTable dt = dal.Gettable("SELECT UserID, Fund_ID, Contact_ID FROM Razor_Fund_Account WHERE UserID='" + txtuserid.Text + "' AND Fund_ID='" + txtReId.Text + "' AND Contact_ID='" + txtReContactID.Text + "'", ref message);
                    if (dt.Rows.Count > 0)
                    {
                        Response.Write("<script>alert('Fund Account Already Created');</script>");
                    }
                    else
                    {
                        int index = dal.Executequery("INSERT INTO Razor_Fund_Account(UserID, Fund_ID, Contact_ID, Created_Date) VALUES ('" + txtuserid.Text + "', '" + txtReId.Text + "', '" + txtReContactID.Text + "', GETDATE())", ref message);
                        Response.Write("<script>alert('Fund Account Created Successfully');</script>");
                    }
                    GetAllContacts();
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Could Not Save bank Details.')", true);
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.ToString() + "')", true);
        }
    }

    public void GetAllContacts()
    {
        DataTable dt = dal.Gettable("SELECT Fund_ID FROM Razor_Fund_Account WHERE UserID = '" + Session["UserID"].ToString() + "'", ref message);
        DataTable dtContact = new DataTable();

        if (dt.Rows.Count > 0)
        {
            dtContact.Columns.Add("Fund_UserID", typeof(string));
            dtContact.Columns.Add("Fund_ID", typeof(string));
            dtContact.Columns.Add("Fund_Contact_ID", typeof(string));
            dtContact.Columns.Add("Fund_Account_Type", typeof(string));
            dtContact.Columns.Add("Fund_Account_Holder_Name", typeof(string));
            dtContact.Columns.Add("Fund_Bank_Name", typeof(string));
            dtContact.Columns.Add("Fund_Account_No", typeof(string));
            dtContact.Columns.Add("Fund_IFSC", typeof(string));
            dtContact.Columns.Add("Fund_Username", typeof(string));
            dtContact.Columns.Add("Fund_Handle", typeof(string));
            dtContact.Columns.Add("Fund_UPI_Address", typeof(string));
            dtContact.Columns.Add("Fund_Status", typeof(bool));
            DataRow dtrow = null;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string id = dt.Rows[i]["Fund_ID"].ToString();
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                var client = new RestClient("https://api.razorpay.com/v1/fund_accounts/" + id);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
                IRestResponse response = client.Execute(request);

                string status = response.StatusCode.ToString();
                //Response.Write(response.Content);
                if (status == "Created" || status == "OK")
                {
                    Fund_Account data = JsonConvert.DeserializeObject<Fund_Account>(response.Content);
                    dtrow = dtContact.NewRow();

                    dtrow["Fund_UserID"] = Session["UserID"].ToString();
                    dtrow["Fund_ID"] = data.id;
                    dtrow["Fund_Contact_ID"] = data.contact_id;
                    dtrow["Fund_Account_Type"] = data.account_type;

                    if (data.vpa == null)
                    {
                        dtrow["Fund_Account_Holder_Name"] = data.bank_account.name;
                        dtrow["Fund_Bank_Name"] = data.bank_account.bank_name;
                        dtrow["Fund_Account_No"] = data.bank_account.account_number;
                        dtrow["Fund_IFSC"] = data.bank_account.ifsc;
                    }
                    else
                    {
                        dtrow["Fund_Username"] = data.vpa.username;
                        dtrow["Fund_Handle"] = data.vpa.handle;
                        dtrow["Fund_UPI_Address"] = data.vpa.address;
                    }
                    dtrow["Fund_Status"] = data.active;
                    dtContact.Rows.Add(dtrow);
                }
            }
        }

        GV_Contacts.DataSource = dtContact;
        GV_Contacts.DataBind();
    }

    protected void btnSelect_Command(object sender, CommandEventArgs e)
    {
        string id = e.CommandArgument.ToString();
        var client = new RestClient("https://api.razorpay.com/v1/fund_accounts/" + id);
        client.Timeout = -1;
        var request = new RestRequest(Method.GET);
        request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
        IRestResponse response = client.Execute(request);
        //Console.WriteLine(response.Content);
        string status = response.StatusCode.ToString();

        if (status == "Created" || status == "OK")
        {
            Fund_Account data = JsonConvert.DeserializeObject<Fund_Account>(response.Content);
            txtReId.Text = string.Empty;
            txtReContactID.Text = string.Empty;
            txtReAccountType.Text = string.Empty;
            txtReName.Text = string.Empty;
            txtReBankName.Text = string.Empty;
            txtReAccountNumber.Text = string.Empty;
            txtReIfsc.Text = string.Empty;
            txtReVpaUsername.Text = string.Empty;
            txtReVpaHandle.Text = string.Empty;
            txtReVpaAddress.Text = string.Empty;

            txtReId.Text = data.id;
            txtReContactID.Text = data.contact_id;
            txtReAccountType.Text = data.account_type;
            if (data.vpa == null)
            {
                txtReName.Text = data.bank_account.name;
                txtReBankName.Text = data.bank_account.bank_name;
                txtReAccountNumber.Text = data.bank_account.account_number;
                txtReIfsc.Text = data.bank_account.ifsc;
            }
            else
            {
                txtReVpaUsername.Text = data.vpa.username;
                txtReVpaHandle.Text = data.vpa.handle;
                txtReVpaAddress.Text = data.vpa.address;
            }
            string status1 = data.active.ToString();
            rdStatus.Items.FindByValue(status1).Selected = true;
            //GetAllContacts();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            var client = new RestClient("https://api.razorpay.com/v1/fund_accounts/" + txtReId.Text);
            client.Timeout = -1;
            var request = new RestRequest(Method.PATCH);
            request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "{\r\n\"active\": " + rdStatus.SelectedValue.ToLower().ToString() + "\r\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            //Console.WriteLine(response.Content);
            string status = response.StatusCode.ToString();

            if (status == "Created" || status == "OK")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Status Change Successfully.');window.location='../customer/auth-add-fund-account?cont_id=" + Request.QueryString["cont_id"].ToString() + "'", true);
            }
            GetAllContacts();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.ToString() + "')", true);
        }
    }

    protected void btnPayout_Command(object sender, CommandEventArgs e)
    {
        string fund_id = e.CommandArgument.ToString();
        Response.Redirect("Payout.aspx?Fund_ID=" + fund_id);
    }

    public void GetApiCredential()
    {
        DataTable dt = dal.Gettable("SELECT * FROM Razor_Credential_Master", ref message);
        string status = dt.Rows[0]["Razor_Status"].ToString();
        if (status == "Test")
        {
            string test_key = dt.Rows[0]["Razor_Test_Key"].ToString();
            string test_secrete = dt.Rows[0]["Razor_Test_Secrete"].ToString();
            string test_account = dt.Rows[0]["Razor_Test_Account"].ToString();

            //var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("rzp_test_Kpbhv00EJjZLkA:Lm7mdp3gHZpu3Ot80LeF3RqP");
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(test_key + ":" + test_secrete);
            string val = System.Convert.ToBase64String(plainTextBytes);
            hf_Basic.Value = val;
            hf_Bank_Account.Value = test_account;
        }
        else if (status == "Live")
        {
            string live_key = dt.Rows[0]["Razor_Live_Key"].ToString();
            string live_secrete = dt.Rows[0]["Razor_Live_Secrete"].ToString();
            string live_account = dt.Rows[0]["Razor_Live_Account"].ToString();

            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(live_key + ":" + live_secrete);
            string val = System.Convert.ToBase64String(plainTextBytes);
            hf_Basic.Value = val;
            hf_Bank_Account.Value = live_account;
        }
        else
        {
            hf_Basic.Value = "";
            hf_Bank_Account.Value = "";
        }
    }
}