﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using DataAccessLayer;
using System.Security.Cryptography;

public partial class customer_auth_transferEPIN : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            if (!IsPostBack)
            {
                string ID = Request.QueryString["id"];
                PINAMOUNT(ID);

            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    public void PINAMOUNT(string ID)
    {
        try
        {
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            SqlCommand cmd = new SqlCommand("Select pn.ID,pn.PinNo,pn.Status,pn.PackageID,pp.PackageName,pp.Amount From PinGenerateNew pn INNER JOIN PackageInfo pp ON pn.PackageID=pp.ID Where pn.ID='" + ID + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtPinNo.Text = dt.Rows[0]["PinNo"].ToString();
                lblid.Text= dt.Rows[0]["PackageID"].ToString();
                lblpakagename.Text= dt.Rows[0]["PackageName"].ToString();
                lblpackageamt.Text= dt.Rows[0]["Amount"].ToString();
            }
        }
        catch (Exception ex)
        {


        }

    }
    protected void txtUserID_TextChanged(object sender, EventArgs e)
    {
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID,Name From MLM_Registration Where UserID='" + txtUserID.Text + "' And UserID!='"+Session["UserID"]+"'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtUserID.Text = dt.Rows[0]["UserID"].ToString();
            lblMSG.Text= dt.Rows[0]["Name"].ToString();
            _Valid.Visible = true;
            btnProceed.Enabled = true;
        }
        else
        {
            lblMSG.Text = "You have entered invalid USERID.";
            _Valid.Visible = false;
            lblpakagename.Text = string.Empty;
            btnProceed.Enabled = false;
            lblpackageamt.Text = string.Empty;
        }
    }

    protected void btnProceed_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserID"] != null)
            {
                if (txtUserID.Text != "")
                {
                    string UserID = Session["UserID"].ToString();
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("PinGenerateNew_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@TransferBy", UserID);
                    cmd.Parameters.AddWithValue("@TransferTo", txtUserID.Text);
                    cmd.Parameters.AddWithValue("@ID", txtPinNo.Text);
                    cmd.Parameters.AddWithValue("@PackageID", lblid.Text);
                    cmd.Parameters.AddWithValue("@Mode", "TRANSFER_IN");
                    int flag = cmd.ExecuteNonQuery();
                    //int flag = 1;
                    con.Close();
                    if (flag > 0)
                    {
                        LedgerCredit();
                        LedgerDebit();
                        //GetData();

                       // ShowPopupMessage("Pin has been Transfered To Member.", PopupMessageType.Success);
                        Response.Redirect("success.aspx?Link=auth-transferEPIN.aspx");
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Pin has been Transfered To Member.');window.location ='auth-TransferE_Pin.aspx';", true);


                    }
                    else
                    {
                        //ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Some Error occurred..');window.location ='auth-TransferE_Pin.aspx';", true);
                    }
                }
                else
                {
                    ShowPopupMessage("Please Enter UserID.", PopupMessageType.Error);
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        finally
        {
            //Response.Redirect("auth-TransferE_Pin.aspx?Pin=" + txtPinNo.Text);
        }
    }
    private void LedgerCredit()
    {
        decimal CR = Convert.ToDecimal(lblpackageamt.Text);
        decimal DR = 0;
        string Description = "Pin Purchased.";
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", CR);
        cmd.Parameters.AddWithValue("@DR", DR);
        cmd.Parameters.AddWithValue("@Descriptions", Description);
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }
    private void LedgerDebit()
    {
        decimal CR = 0;
        decimal DR = Convert.ToDecimal(lblpackageamt.Text);
        string Description = "Pin Purchased.";
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "DR");
        cmd.Parameters.AddWithValue("@CR", CR);
        cmd.Parameters.AddWithValue("@DR", DR);
        cmd.Parameters.AddWithValue("@Descriptions", Description);
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/Red_Cross_Tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    /// </summary>
    /// </summary>
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void btnreset_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-TransferE_Pin.aspx");
    }
}