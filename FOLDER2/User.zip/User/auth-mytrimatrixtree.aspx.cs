﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

public partial class customer_auth_mytrimatrixtree : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    string L = null, R = null;
    ArrayList UserIDList = new ArrayList();
    ArrayList UserIDRightList = new ArrayList();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                btnback.Visible = false;
                Init();
                detail(Session["UserID"].ToString());

            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    DataTable dt = new DataTable();
    private void Init()
    {
        dt.Columns.Add("UserID", typeof(string));
        dt.Columns.Add("Count", typeof(int));
        ViewState["dtvalue"] = dt;
    }
    private void detail(string UserID)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        DataTable UserDetail = new DataTable();
        UserDetail = fillUserDetail(UserID);
        if (UserDetail.Rows.Count > 0)
        {
            LinkButton12.Text = UserID;
            lblname.Text = UserDetail.Rows[0]["Name"].ToString();
            Image12.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
            Image12.ToolTip += "Account No. : " + UserDetail.Rows[0]["UserID"].ToString() + "\n";
            Image12.ToolTip += "Join Date : " + UserDetail.Rows[0]["joindate"].ToString() + "\n";
            Image12.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
            Image12.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
            Image12.ToolTip += "Status : " + UserDetail.Rows[0]["Status"].ToString() + "\n";
            Image12.ToolTip += "Member Join : " + UserDetail.Rows[0]["Joining"].ToString() + "\n";

            string jointype = UserDetail.Rows[0]["JoinType"].ToString();
            string Status = UserDetail.Rows[0]["Status"].ToString();
            if (Status == "InActive")
            {
                Image12.ImageUrl = "assets/images/R.png";
            }
            if (jointype == "Paid")
            {
                Image12.ImageUrl = "assets/images/G.png";
            }
            else if (jointype == "Free")
            {
                Image12.ImageUrl = "assets/images/R.png";
            }
            else
            {
                Image12.ImageUrl = "assets/images/F.png";
            }
        }
        Clear();
        ShowNextFiveuser(UserID, 0);


    }

    private DataTable fillUserDetail(string UserID)
    {
        try
        {
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            con.Open();
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();

            //sb.AppendFormat("select UserID,Name,JoinType,JoinDate,isnull(Joining,0) as Joining,Package,Status from MLM_Registration_matrix where  UserID='{0}'", UserID);
            //DataTable dt = dal.Gettable("select UserID, Name, JoinType, JoinDate, isnull(Joining, 0) as Joining, Package, Status from MLM_Registration_matrix where UserID ="+ UserID+"", ref message);
            //sda.Fill(dt);

            string str = "select UserID, Name, JoinType, JoinDate, isnull(Joining, 0) as Joining, Package, Status from MLM_Registration_matrix where UserID ='" + UserID + "'";

            //string str = "select UserID, Name from MLM_Registration_tmatrix where UserID ='" + UserID + "'";


            //string str = "select UserID from MLM_Registration where UserID ='" + UserID + "'";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            sda.Fill(dt1);

            return dt1;
        }
        catch (Exception ex)
        {
            throw;
        }

    }

    private void ShowNextFiveuser(string UserID, int Count)
    {

        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Select UserID,Name,JoinType,JoinDate,isnull(Joining,0) as Joining,Package,Status FROM MLM_Registration_matrix where PlaceunderID = '{0}' ORDER BY DID OFFSET {1} ROWS FETCH NEXT 4 ROWS ONLY", UserID, Count);


        DataTable nextfiveuserdetail = dal.Gettable(sb.ToString(), ref message);
        if (nextfiveuserdetail.Rows.Count > 0)
        {
            for (int i = 0; i < nextfiveuserdetail.Rows.Count; i++)
            {
                LinkButton lnk = membercontainer.FindControl("LinkButton" + i) as LinkButton;
                lnk.Enabled = true;
                lnk.Text = nextfiveuserdetail.Rows[i]["UserID"].ToString();
                Image img = membercontainer.FindControl("Image" + i) as Image;
                img.ToolTip = "Name: " + nextfiveuserdetail.Rows[i]["Name"].ToString() + "\n";
                img.ToolTip += "Account No. : " + nextfiveuserdetail.Rows[i]["UserID"].ToString() + "\n";
                img.ToolTip += "Join Date : " + nextfiveuserdetail.Rows[i]["joindate"].ToString() + "\n";
                img.ToolTip += "Join Type : " + nextfiveuserdetail.Rows[i]["Jointype"].ToString() + "\n";
                img.ToolTip += "Package : " + nextfiveuserdetail.Rows[i]["Package"].ToString() + "\n";
                img.ToolTip += "Status : " + nextfiveuserdetail.Rows[i]["Status"].ToString() + "\n";
                img.ToolTip += "Member Join : " + nextfiveuserdetail.Rows[i]["Joining"].ToString() + "\n";
                string jointype = nextfiveuserdetail.Rows[i]["JoinType"].ToString();
                string Status = nextfiveuserdetail.Rows[i]["Status"].ToString();
                if (Status == "InActive")
                {
                    img.ImageUrl = "assets/images/R.png";
                }
                if (jointype == "Paid")
                {
                    img.ImageUrl = "assets/images/G.png";
                }
                else if (jointype == "Free")
                {
                    img.ImageUrl = "assets/images/R.png";
                }
                else
                {
                    img.ImageUrl = "assets/images/F.png";
                }
            }
            if (nextfiveuserdetail.Rows.Count == 5)
            {
                btnnext.Visible = true;
            }
            else
            {
                btnnext.Visible = false;
            }
        }
        else
        {
            btnnext.Visible = false;
        }
    }
    private void Clear()
    {

        LinkButton0.Text = "Vacant";
        LinkButton1.Text = "Vacant";
        LinkButton2.Text = "Vacant";
        // LinkButton3.Text = "Vacant";


        LinkButton0.Enabled = false;
        LinkButton1.Enabled = false;
        LinkButton2.Enabled = false;
        // LinkButton3.Enabled = false;


        Image0.ImageUrl = "assets/images/B.png";
        Image1.ImageUrl = "assets/images/B.png";
        Image2.ImageUrl = "assets/images/B.png";
        //Image3.ImageUrl = "images/B.png";


        Image0.ToolTip = "";
        Image1.ToolTip = "";
        Image2.ToolTip = "";
        // Image3.ToolTip = "";


        txtSearch.Text = string.Empty;
    }
    protected void btnnext_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["dtvalue"] != null)
        {
            dt = (DataTable)ViewState["dtvalue"];
        }
        DataRow[] FindUser = dt.Select("UserID='" + LinkButton12.Text + "'");
        if (FindUser.Length > 0)
        {
            foreach (DataRow item in FindUser)
            {
                string UserID = item["UserID"].ToString();
                int tempcount = Convert.ToInt32(item["Count"]);
                int setvalue = tempcount + 3;
                DataRow dr = dt.NewRow();
                dr["UserID"] = LinkButton12.Text;
                dr["Count"] = setvalue;
                dt.Rows.Add(dr);
                Clear();
                ShowNextFiveuser(UserID, setvalue);
            }
        }
        else
        {
            DataRow dr = dt.NewRow();
            dr["UserID"] = LinkButton12.Text;
            dr["Count"] = 0;
            dt.Rows.Add(dr);
            Clear();
            ShowNextFiveuser(LinkButton12.Text, 6);

        }
        btnback.Visible = true;
        ViewState["dtvalue"] = dt;
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        if (ViewState["dtvalue"] != null)
        {
            dt = (DataTable)ViewState["dtvalue"];
            int Dtcount = dt.Rows.Count;
            if (Dtcount > 0)
            {
                string UserID = dt.Rows[Dtcount - 1]["UserID"].ToString();
                int Count = Convert.ToInt32(dt.Rows[Dtcount - 1]["Count"]);
                dt.Rows.RemoveAt(Dtcount - 1);

                int rowcount = dt.Rows.Count;
                if (rowcount == 0)
                {
                    btnback.Visible = false;
                }
                Clear();
                if (Count > 0)
                {
                    ShowNextFiveuser(UserID, Count);
                }
                else
                {
                    detail(UserID);
                }

                ViewState["dtvalue"] = dt;
            }
            else
            {
                btnback.Visible = false;
            }
        }
    }

    protected void LinkButton0_Click(object sender, EventArgs e)
    {
        if (ViewState["dtvalue"] != null)
        {
            dt = (DataTable)ViewState["dtvalue"];
        }
        DataRow[] FindUser = dt.Select("UserID='" + LinkButton12.Text + "'");
        if (FindUser.Length > 0)
        {
            detail(LinkButton0.Text);
        }
        else
        {
            DataRow dr = dt.NewRow();
            dr["UserID"] = LinkButton12.Text;
            dr["Count"] = 0;
            dt.Rows.Add(dr);

            detail(LinkButton0.Text);
        }

        btnback.Visible = true;
        ViewState["dtvalue"] = dt;

    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        //string UserID = LinkButton1.Text;
        //detail(UserID);
        //btnback.Visible = true;

        if (ViewState["dtvalue"] != null)
        {
            dt = (DataTable)ViewState["dtvalue"];
        }
        DataRow[] FindUser = dt.Select("UserID='" + LinkButton12.Text + "'");
        if (FindUser.Length > 0)
        {
            detail(LinkButton1.Text);
        }
        else
        {
            DataRow dr = dt.NewRow();
            dr["UserID"] = LinkButton12.Text;
            dr["Count"] = 0;
            dt.Rows.Add(dr);

            detail(LinkButton1.Text);
        }

        btnback.Visible = true;
        ViewState["dtvalue"] = dt;
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        //string UserID = LinkButton2.Text;
        //detail(UserID);
        //btnback.Visible = true;

        if (ViewState["dtvalue"] != null)
        {
            dt = (DataTable)ViewState["dtvalue"];
        }
        DataRow[] FindUser = dt.Select("UserID='" + LinkButton12.Text + "'");
        if (FindUser.Length > 0)
        {
            detail(LinkButton2.Text);
        }
        else
        {
            DataRow dr = dt.NewRow();
            dr["UserID"] = LinkButton12.Text;
            dr["Count"] = 0;
            dt.Rows.Add(dr);

            detail(LinkButton2.Text);
        }

        btnback.Visible = true;
        ViewState["dtvalue"] = dt;
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        if (ViewState["dtvalue"] != null)
        {
            dt = (DataTable)ViewState["dtvalue"];
        }
        DataRow[] FindUser = dt.Select("UserID='" + LinkButton12.Text + "'");
        if (FindUser.Length > 0)
        {
            // detail(LinkButton3.Text);
        }
        else
        {
            DataRow dr = dt.NewRow();
            dr["UserID"] = LinkButton12.Text;
            dr["Count"] = 0;
            dt.Rows.Add(dr);

            //  detail(LinkButton3.Text);
        }

        btnback.Visible = true;
        ViewState["dtvalue"] = dt;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (txtSearch.Text != string.Empty)
        {
            string UserID = string.Empty;
            UserID = txtSearch.Text;

            DAL dal = new DAL();
            string message = string.Empty;
            DataTable dtLoginUser = dal.Gettable("Select DID From MLM_Registration_matrix Where UserID='" + Session["UserID"].ToString() + "'", ref message);
            DataTable dtSearchUser = dal.Gettable("Select DID From MLM_Registration_matrix Where UserID='" + UserID + "'", ref message);

            if (dtLoginUser.Rows.Count > 0 && dtSearchUser.Rows.Count > 0)
            {
                int LoginUser_DID = Convert.ToInt32(dtLoginUser.Rows[0]["DID"]);
                int SearchUser_DID = Convert.ToInt32(dtSearchUser.Rows[0]["DID"]);

                if (SearchUser_DID >= LoginUser_DID)
                {
                    DataTable UserDetail = new DataTable();
                    UserDetail = fillUserDetail(UserID);
                    if (UserDetail.Rows.Count > 0)
                    {
                        LinkButton12.Text = UserID;
                        lblname.Text = UserDetail.Rows[0]["Name"].ToString();
                        Image12.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                        Image12.ToolTip += "Account No. : " + UserDetail.Rows[0]["UserID"].ToString() + "\n";
                        Image12.ToolTip += "Join Date : " + UserDetail.Rows[0]["joindate"].ToString() + "\n";
                        Image12.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                        Image12.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                        Image12.ToolTip += "Status : " + UserDetail.Rows[0]["Status"].ToString() + "\n";
                        Image12.ToolTip += "Member Join : " + UserDetail.Rows[0]["Joining"].ToString() + "\n";

                        string jointype = UserDetail.Rows[0]["JoinType"].ToString();
                        string Status = UserDetail.Rows[0]["Status"].ToString();
                        if (Status == "InActive")
                        {
                            Image12.ImageUrl = "assets/images/R.png";
                        }
                        if (jointype == "Paid")
                        {
                            Image12.ImageUrl = "assets/images/G.png";
                        }
                        else if (jointype == "Free")
                        {
                            Image12.ImageUrl = "assets/images/R.png";
                        }
                        else
                        {
                            Image12.ImageUrl = "assets/images/F.png";
                        }
                        lblMSG.Visible = false;
                    }
                    else
                    {
                        lblMSG.Visible = true;
                    }
                    Clear();
                    ShowNextFiveuser(UserID, 0);
                }
                else
                {
                    lblMSG.Visible = true;
                }

            }
            else
            {

            }


        }
        else if (txtSearch.Text == string.Empty)
        {

        }
    }




}