﻿using DataAccessLayer;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_Payout : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();
    HiddenField hf_Basic = new HiddenField();
    HiddenField hf_Bank_Account = new HiddenField();

    protected void Page_Load(object sender, EventArgs e)
    {
        GetApiCredential();

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                GetAllContacts();
                string status = Request.QueryString["Type"].ToString();
                bool amt = GetWalletBalance();
                if (status == "bank_account" && amt == true)
                {
                    divBank.Visible = true;
                    divUpi.Visible = false;
                }
                else if (status == "vpa" && amt == true)
                {
                    divBank.Visible = false;
                    divUpi.Visible = true;
                }
                else
                {
                    divBank.Visible = false;
                    divUpi.Visible = false;
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Invalid Account Status/Low Balance.')", true);
                }

                btnBank.Enabled = false;
                btnUpi.Enabled = false;
                txtuserid_TextChanged(sender, e);
                //GetAllContacts();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }

    private bool GetWalletBalance()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions in ('Matching Income','Matching Sponcor Income','Withdrawal Amount','2:1 OR 1:2')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblWalletBalance.Text = dt.Rows[0]["WalletAmount"].ToString();
                decimal WalletBalance = Convert.ToDecimal(lblWalletBalance.Text);

                if (WalletBalance > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                lblWalletBalance.Text = "0";
                return false;
            }
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    public string GetCompanyName()
    {
        DataTable dt = dal.Gettable("SELECT CompanyName FROM CompanyInfo", ref message);
        string CompanyName = dt.Rows[0]["CompanyName"].ToString();

        return CompanyName;
    }

    protected void txtuserid_TextChanged(object sender, EventArgs e)
    {
        DataTable dtuserid = dal.Gettable("select UserID,Name from MLM_Registration where UserID ='" + Session["UserID"].ToString() + "' and JoinType='Paid'", ref message);
        if (dtuserid.Rows.Count > 0)
        {

            DataTable dtdata = dal.Gettable("select mm.UserID,mm.Name,ml.PayeeName,ml.AccountNo,ml.IFSCCode from MLM_Registration mm inner join MLM_UserDetail ml on mm.UserID=ml.UserID where mm.UserID='" + Session["UserID"].ToString() + "' and mm.JoinType='Paid'", ref message);
            if (dtdata.Rows.Count > 0)
            {
                txtuserid.Text = Session["UserID"].ToString();
                txtFundAccountID.Text = Request.QueryString["Fund_ID"].ToString();

                lbluserid.Visible = true;
                lbluserid.Text = dtuserid.Rows[0]["Name"].ToString();
                lblInvalidID.Visible = false;
                btnBank.Enabled = true;
                btnUpi.Enabled = true;
            }
            else
            {
                btnBank.Enabled = false;
                btnUpi.Enabled = false;
            }
        }
        else
        {
            btnBank.Enabled = false;
            btnUpi.Enabled = false;
        }
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.RawUrl);
    }

    protected void btnBank_Click(object sender, EventArgs e)
    {
        try
        {
            if (Convert.ToDouble(txtAmount.Text) <= Convert.ToDouble(lblWalletBalance.Text))
            {

            if (string.IsNullOrEmpty(txtAmount.Text))
            {
                Response.Write("<script>alert('Please Enter Amount.');</script>");
            }
            else
            {
                double amount = Convert.ToDouble(txtAmount.Text);
                double Amount = (amount * 100);

                var client = new RestClient("https://api.razorpay.com/v1/payouts");
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
                //request.AddHeader("Authorization", "Basic cnpwX3Rlc3RfUDQ2S3c1VjBCTmV2aFc6cXZhN3lRZGhJOTNwOVdnd0dKZ2g3UzJk");
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", "{\r\n  \"account_number\": \"" + hf_Bank_Account.Value.ToString() + "\",\r\n  \"fund_account_id\": \"" + txtFundAccountID.Text + "\",\r\n  \"amount\": " + Amount + ",\r\n  \"currency\": \"INR\",\r\n  \"mode\": \"IMPS\",\r\n  \"purpose\": \"refund\",\r\n  \"queue_if_low_balance\": true,\r\n  \"reference_id\": \"" + txtuserid.Text + "\",\r\n  \"narration\": \"" + GetCompanyName() + "\",\r\n  \"notes\": {\r\n    \"notes_key_1\":\"Withdrawal Amount\"\r\n  }\r\n}", ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                //Console.WriteLine(response.Content);
                string status = response.StatusCode.ToString();

                if (status == "Created" || status == "OK")
                {
                    Payout payout = JsonConvert.DeserializeObject<Payout>(response.Content);

                    string UserID = Session["UserID"].ToString();
                    decimal CR = 0;
                    decimal DR = Convert.ToDecimal(txtAmount.Text);
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("WithdrawalRequest_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    //withdrawal request tbl
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    cmd.Parameters.AddWithValue("@Amount", txtAmount.Text);
                    cmd.Parameters.AddWithValue("@Description", "Withdrawal Amount");
                    //ledger tbl
                    cmd.Parameters.AddWithValue("@TransactionType", "DR");
                    cmd.Parameters.AddWithValue("@CR", CR);
                    cmd.Parameters.AddWithValue("@DR", DR);
                    cmd.Parameters.AddWithValue("@Descriptions", "Withdrawal Amount");
                    cmd.Parameters.AddWithValue("@Mode", "IN");

                    int flag = cmd.ExecuteNonQuery();

                    int index = dal.Executequery("INSERT INTO Razor_Payout(UserID,Fund_ID,Payout_ID,Created_Date) VALUES ('" + txtuserid.Text + "', '" + payout.fund_account_id + "', '" + payout.id + "', GETDATE())", ref message);
                    txtAmount.Text = string.Empty;
                    Page_Load(sender, e);
                    Response.Write("<script>alert('Amount Transfer Successfully.');window.location='Payout?Fund_ID="+txtFundAccountID.Text+"&Type="+ Request.QueryString["Type"].ToString() + "'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Could Not Transfer Amount.');</script>");
                }

               
                Page_Load(sender, e);
            }
            }
            else
            {
                Response.Write("<script>alert('Invalid Transfer Amount.');</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Please Enter Valid Amount.');</script>");
        }
    }

    public void GetAllContacts()
    {
        DataTable dt = dal.Gettable("SELECT Payout_ID FROM Razor_Payout WHERE UserID = '" + Session["UserID"].ToString() + "'", ref message);
        DataTable dtContact = new DataTable();

        if (dt.Rows.Count > 0)
        {
            dtContact.Columns.Add("Payout_UserID", typeof(string));
            dtContact.Columns.Add("Payout_ID", typeof(string));
            dtContact.Columns.Add("Payout_Fund_ID", typeof(string));
            dtContact.Columns.Add("Payout_Amount_Paisa", typeof(int));
            dtContact.Columns.Add("Payout_Amount_Rupee", typeof(int));
            dtContact.Columns.Add("Payout_Currency", typeof(string));
            dtContact.Columns.Add("Payout_Status", typeof(string));
            dtContact.Columns.Add("Payout_Mode", typeof(string));
            dtContact.Columns.Add("Payout_Reference_ID", typeof(string));
            dtContact.Columns.Add("Payout_Narration", typeof(string));
            dtContact.Columns.Add("Payout_Failure_Reason", typeof(string));
            DataRow dtrow = null;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string id = dt.Rows[i]["Payout_ID"].ToString();
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                var client = new RestClient("https://api.razorpay.com/v1/payouts/" + id);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
                IRestResponse response = client.Execute(request);

                string status = response.StatusCode.ToString();
                //Response.Write(response.Content);
                if (status == "Created" || status == "OK")
                {
                    Payout data = JsonConvert.DeserializeObject<Payout>(response.Content);
                    dtrow = dtContact.NewRow();

                    dtrow["Payout_UserID"] = Session["UserID"].ToString();
                    dtrow["Payout_ID"] = data.id;
                    dtrow["Payout_Fund_ID"] = data.fund_account_id;
                    dtrow["Payout_Amount_Paisa"] = data.amount;
                    dtrow["Payout_Amount_Rupee"] = (data.amount / 100);
                    dtrow["Payout_Currency"] = data.currency;
                    dtrow["Payout_Status"] = data.status;
                    dtrow["Payout_Mode"] = data.mode;
                    dtrow["Payout_Reference_ID"] = data.reference_id;
                    dtrow["Payout_Narration"] = data.narration;
                    dtrow["Payout_Failure_Reason"] = data.failure_reason;

                    dtContact.Rows.Add(dtrow);
                }
            }
        }

        GV_Contacts.DataSource = dtContact;
        GV_Contacts.DataBind();
    }

    protected void btnUpi_Click(object sender, EventArgs e)
    {
        try
        {
            double amount = Convert.ToDouble(txtAmount.Text);
            double Amount = (amount * 100);

            var client = new RestClient("https://api.razorpay.com/v1/payouts");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
            //request.AddHeader("Authorization", "Basic cnpwX3Rlc3RfUDQ2S3c1VjBCTmV2aFc6cXZhN3lRZGhJOTNwOVdnd0dKZ2g3UzJk");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "{\r\n  \"account_number\": \"" + hf_Bank_Account.Value.ToString() + "\",\r\n  \"fund_account_id\": \"" + txtFundAccountID.Text + "\",\r\n  \"amount\": " + Amount + ",\r\n  \"currency\": \"INR\",\r\n  \"mode\": \"UPI\",\r\n  \"purpose\": \"refund\",\r\n  \"queue_if_low_balance\": true,\r\n  \"reference_id\": \"" + txtuserid.Text + "\",\r\n  \"narration\": \"" + GetCompanyName() + "\",\r\n  \"notes\": {\r\n    \"notes_key_1\":\"Withdrawal Amount\"\r\n  }\r\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            //Console.WriteLine(response.Content);
            string status = response.StatusCode.ToString();

            if (status == "Created" || status == "OK")
            {
                Payout payout = JsonConvert.DeserializeObject<Payout>(response.Content);

                string UserID = Session["UserID"].ToString();
                decimal CR = 0;
                decimal DR = Convert.ToDecimal(txtAmount.Text);
                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("WithdrawalRequest_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //withdrawal request tbl
                cmd.Parameters.AddWithValue("@UserID", UserID);
                cmd.Parameters.AddWithValue("@Amount", txtAmount.Text);
                cmd.Parameters.AddWithValue("@Description", "Withdrawal Amount");
                //ledger tbl
                cmd.Parameters.AddWithValue("@TransactionType", "DR");
                cmd.Parameters.AddWithValue("@CR", CR);
                cmd.Parameters.AddWithValue("@DR", DR);
                cmd.Parameters.AddWithValue("@Descriptions", "Withdrawal Amount");
                cmd.Parameters.AddWithValue("@Mode", "IN");

                int flag = cmd.ExecuteNonQuery();

                int index = dal.Executequery("INSERT INTO Razor_Payout(UserID,Fund_ID,Payout_ID,Created_Date) VALUES ('" + txtuserid.Text + "', '" + payout.fund_account_id + "', '" + payout.id + "', GETDATE())", ref message);
                txtAmount.Text = string.Empty;
                Page_Load(sender, e);
                Response.Write("<script>alert('Amount Transfer Successfully.');window.location='Payout?Fund_ID=" + txtFundAccountID.Text + "&Type=" + Request.QueryString["Type"].ToString() + "'</script>");
            }
            else
            {
                Response.Write("<script>alert('Could Not Transfer Amount.');</script>");
            }
            Page_Load(sender, e);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.ToString() + "')", true);
        }
    }

    public void GetApiCredential()
    {
        DataTable dt = dal.Gettable("SELECT * FROM Razor_Credential_Master", ref message);
        string status = dt.Rows[0]["Razor_Status"].ToString();
        if (status == "Test")
        {
            string test_key = dt.Rows[0]["Razor_Test_Key"].ToString();
            string test_secrete = dt.Rows[0]["Razor_Test_Secrete"].ToString();
            string test_account = dt.Rows[0]["Razor_Test_Account"].ToString();

            //var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("rzp_test_Kpbhv00EJjZLkA:Lm7mdp3gHZpu3Ot80LeF3RqP");
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(test_key + ":" + test_secrete);
            string val = System.Convert.ToBase64String(plainTextBytes);
            hf_Basic.Value = val;
            hf_Bank_Account.Value = test_account;
        }
        else if (status == "Live")
        {
            string live_key = dt.Rows[0]["Razor_Live_Key"].ToString();
            string live_secrete = dt.Rows[0]["Razor_Live_Secrete"].ToString();
            string live_account = dt.Rows[0]["Razor_Live_Account"].ToString();

            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(live_key + ":" + live_secrete);
            string val = System.Convert.ToBase64String(plainTextBytes);
            hf_Basic.Value = val;
            hf_Bank_Account.Value = live_account;
        }
        else
        {
            hf_Basic.Value = "";
            hf_Bank_Account.Value = "";
        }
    }
}