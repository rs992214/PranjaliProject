﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using DataAccessLayer;
using System.Security.Cryptography;

public partial class customer_auth_pingenerate : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["UserID"] != null)
        {
            if (!IsPostBack)
            {
                string ID = Request.QueryString["id"];
                txtUserID.Text = Session["UserID"].ToString();
                GetWalletBalance();
                PINAMOUNT(ID);
                DAL dal = new DAL();
                DataTable dtRequest = dal.Gettable("select TOP 1 UserID from WithdrawalRequest where UserID='" + Session["UserID"].ToString() + "' and Status='REQUEST' order by id desc ", ref message);
                if (dtRequest.Rows.Count > 0)
                {
                    ShowPopupMessage("NOTE : If You Create E-Pin Then Your Withdrawal Request Will Be Reject.", PopupMessageType.Success);
                }
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }

    }
    private void HowManyPinGenerate()
    {
        decimal WalletBalance = Convert.ToDecimal(lblWalletBalance.Text);
        decimal PackageAmount = Convert.ToDecimal(lblPackageAmount.Text);

        decimal Remain = WalletBalance % PackageAmount;
        WalletBalance = WalletBalance - Remain;
        decimal TotalPin = WalletBalance / PackageAmount;
        Label1.Text = TotalPin.ToString();
       string MSG = "You Can Generate Max. " + Math.Round(TotalPin).ToString() + " Pins";
        lblPinMSG.Text = MSG;
       
    }
    private void GetWalletBalance()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' And Descriptions in ('Matching Income','Direct Income','2:1 OR 1:2','Withdrawal Amount','Pin Purchased.')", ref message);
            DataTable dtMinimum = objDAL.Gettable("Select COALESCE(MIN(Amount),0)As MinimunBalance From PackageInfo", ref message);
            if (dt.Rows.Count > 0)
            {
                lblWalletBalance.Text = dt.Rows[0]["WalletAmount"].ToString();
                decimal WalletBalance = Convert.ToDecimal(lblWalletBalance.Text);
                decimal MinimumBalance = Convert.ToDecimal(dtMinimum.Rows[0]["MinimunBalance"]);
                if (WalletBalance >= MinimumBalance)
                {
                    lblBalanceMSG.Visible = false;
                }
                else
                {
                    lblBalanceMSG.Visible = true;
                }
            }
            else
            {
                lblWalletBalance.Text = "0";
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void PINAMOUNT(string ID)
    {
        try
        {
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            SqlCommand cmd = new SqlCommand("Select ID,Amount from PackageInfo where ID='" + ID + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                lblPackageAmount.Text = dt.Rows[0]["Amount"].ToString();
                Label2.Text = dt.Rows[0]["ID"].ToString();
                HowManyPinGenerate();

            }
        }
        catch (Exception ex)
        {

        }

    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/customer/assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserID"] != null)
            {
                if (txtPinQty.Text != "")
                {
                    int Qty = Convert.ToInt32(txtPinQty.Text);
                    int _Count = 0;
                    for (int i = 0; i < Qty; i++)
                    {
                        GetPinNo();
                        con = new SqlConnection(connstring);
                        con.Open();
                        cmd = new SqlCommand("PinGenerateNew_ALL", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
                        cmd.Parameters.AddWithValue("@PackageID", Label2.Text);
                        cmd.Parameters.AddWithValue("@PinNo", lblPinNo.Text);
                        cmd.Parameters.AddWithValue("@Mode", "IN");
                        int flag = cmd.ExecuteNonQuery();
                        con.Close();
                        if (flag > 0)
                        {
                            InsertWalletLedger_DR();
                            _Count = _Count + flag;
                        }
                        else
                        {
                            _Count = _Count + flag;
                        }

                    }
                    if (_Count == Qty)
                    {
                        GetWalletBalance();
                        RejectWithdrawalRequest();
                        txtPinQty.Text = "";
                        Response.Redirect("success.aspx?Link=auth-pingenerate.aspx");
                        //  ShowPopupMessage("Pin has been Created successfully.", PopupMessageType.Success);
                        Response.Redirect("auth-activateepin.aspx");
                    }
                }
                else
                {
                    ShowPopupMessage("Error: Please Enter Pin Qty.", PopupMessageType.Error);
                }
               
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        finally
        {
            //Response.Redirect("auth-createepin.aspx");
        }
    }
    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }
    private void GetPinNo()
    {
        int flag = 1;
        con = new SqlConnection(connstring);
        con.Open();
        while (flag == 1)
        {
            string PinNo = GetUniqueKey(6);
            cmd = new SqlCommand("PinGenerateNew_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PinNo", PinNo);
            cmd.Parameters.AddWithValue("@Mode", "CHECK_PIN_NO");
            flag = (int)cmd.ExecuteScalar();
            lblPinNo.Text = PinNo;
        }
        con.Close();
    }
    private void InsertWalletLedger_DR()
    {
        decimal CR = 0;
        decimal DR = Convert.ToDecimal(lblPackageAmount.Text);
        string Description = "Pin Purchased.";
        con = new SqlConnection(connstring);
        con.Open();
        cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "DR");
        cmd.Parameters.AddWithValue("@CR", CR);
        cmd.Parameters.AddWithValue("@DR", DR);
        cmd.Parameters.AddWithValue("Descriptions", Description);
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
        con.Close();

    }
    protected void txtPinQty_TextChanged(object sender, EventArgs e)
    {
        try
        {
            int Qty = Convert.ToInt32(txtPinQty.Text);
            int MaxAllow = Convert.ToInt32(Label1.Text);
            if (Qty <= MaxAllow && Qty != 0)
            {
                btnsubmit.Enabled = true;
                lblPinMSG1.Visible = false;
                
            }
            else
            {
                txtPinQty.Text = "";
                btnsubmit.Enabled = false;
                lblPinMSG1.Visible = true;
                
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void RejectWithdrawalRequest()
    {
        try
        {
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Ledger_Wallet_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
            cmd.Parameters.AddWithValue("@Mode", "Reject");
            int flag = cmd.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {

        }
       
    }
}