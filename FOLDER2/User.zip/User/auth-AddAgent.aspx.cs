﻿using DataAccessLayer;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_AddAgent : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();


    //string key = "304143904755886";
    //string mode = "0";
    //string service = "7972947432";
    //string Name = "Probuz";
    //string Address = "Nagpur";
    //string Email= "probuzcare@gmail.com";

    public string key = "";
    public string mode = "";
    public string service = "";
    public string Name = "";
    public string Address = "";
    public string Email = "";
    public string AccountNo = "";
    public string IFSCcode = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                btnSave.Enabled = false;
                JoloGetAPIKEY();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }

    protected void txtuserid_TextChanged(object sender, EventArgs e)
    {
        DataTable dtuserid = dal.Gettable("select UserID,Name from MLM_Registration where UserID ='" + txtuserid.Text + "' and JoinType='Paid'", ref message);
        if (dtuserid.Rows.Count > 0)
        {

            DataTable dtdata = dal.Gettable("select mm.UserID,mm.Name,mm.Mobile,mm.Email,ml.Address from MLM_Registration mm inner join MLM_UserDetail ml on mm.UserID=ml.UserID where mm.UserID='" + txtuserid.Text + "' and mm.JoinType='Paid'", ref message);
            if (dtdata.Rows.Count > 0)
            {
                txtBeneficiaryName.Text = dtdata.Rows[0]["Name"].ToString();
                txtmobile.Text = dtdata.Rows[0]["Mobile"].ToString();
                txtemail.Text = dtdata.Rows[0]["Email"].ToString();
                txtaddress.Text = dtdata.Rows[0]["address"].ToString();

                lbluserid.Visible = true;
                lbluserid.Text = dtuserid.Rows[0]["Name"].ToString();
                lblInvalidID.Visible = false;
                btnSave.Enabled = true;
            }
            else
            {
                clear();
            }
        }
        else
        {
            clear();
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        JoloGetAPIKEY();
        Getdata();
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-AddAgent.aspx");
    }

    protected void JoloGetAPIKEY()
    {
        DataTable dt = dal.Gettable("select APIKey,Mode from JoloGetway where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            key = dt.Rows[0]["APIKey"].ToString();
            mode = dt.Rows[0]["Mode"].ToString();
        }
        else
        {
            btnSave.Enabled = false;
            ShowPopupMessage("Error : Payment Getway Could Not Be Working .", PopupMessageType.Success);
        }
    }

    protected void Getdata()
    {
        DataTable dtdata = dal.Gettable("select mm.UserID,mm.Name,mm.Mobile,mm.Email,ml.Address,ml.AccountNo,ml.IFSCCode from MLM_Registration mm inner join MLM_UserDetail ml on mm.UserID=ml.UserID where mm.UserID='" + txtuserid.Text + "' and mm.JoinType='Paid'", ref message);
        if (dtdata.Rows.Count > 0)
        {
            Name = dtdata.Rows[0]["Name"].ToString();
            service = dtdata.Rows[0]["Mobile"].ToString();
            Email = dtdata.Rows[0]["Email"].ToString();
            Address = dtdata.Rows[0]["address"].ToString();
            Address = dtdata.Rows[0]["address"].ToString();
            if (Address == "")
            {
                Address = txtaddress.Text;
            }
            Address = txtaddress.Text;
            if (Name != "" && service != "" && Email != "" && Address != "")
            {
                StreamReader objReader;
                string sURL = "http://jolosoft.com/dmr/cdmr_signup.php?mode=" + mode + "&key=" + key + "&service=" + service + "&name=" + Name + "&address=" + Address + "&email=" + Email + "";
                //Response.Redirect("https://jolosoft.com/dmr/cdmr_signup.php?mode=" + mode + "&key=" + key + "&service=" + service + "&name=" + Name + "&address=" + Address + "&email=" + Email + "");
                WebRequest wrGETURL;
                string jsonValue = "";
                wrGETURL = WebRequest.Create(sURL);
                try
                {
                    Stream objStream;
                    objStream = wrGETURL.GetResponse().GetResponseStream();
                    objReader = new StreamReader(objStream);
                    jsonValue = objReader.ReadToEnd();
                    var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                    string status = myDetails.status;
                    string er = myDetails.error;
                    if (status == "FAILED")
                    {
                        btnSave.Enabled = false;
                        txtBeneficiaryName.Text = "";
                        txtmobile.Text = "";
                        txtemail.Text = "";
                        txtaddress.Text = "";

                        txtuserid.Text = "";
                        lbluserid.Visible = false;
                        lblInvalidID.Visible = true;
                        lblInvalidID.Text = "";
                        btnSave.Enabled = false;
                        
                        // Response.Redirect("success.aspx?Link=auth-AddAgent.aspx");
                        ShowPopupMessage("Error :Account Not be Created (" + er + ").", PopupMessageType.Success);
                        //ShowPopupMessage(error, PopupMessageType.Success);
                    }
                    else
                    {
                        Response.Write(status + "/" + service);
                        //Response.End();
                        Response.Redirect("auth-AgentVerify.aspx?userid=" + txtuserid.Text + "");
                    }
                    objReader.Close();
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            else
            {
                btnSave.Enabled = false;
               
                 ShowPopupMessage("Error :User Deatil Not Get Plz Update Your Profile .", PopupMessageType.Success);
            }

        }
        else
        {
            btnSave.Enabled = false;
           
             ShowPopupMessage("Error :User Deatil Not Get Plz Update Your Profile.", PopupMessageType.Success);
        }
    }

    protected void clear()
    {
        txtBeneficiaryName.Text = "";
        txtmobile.Text = "";
        txtemail.Text = "";
        txtaddress.Text = "";

        txtuserid.Text = "";
        lbluserid.Visible = false;
        lblInvalidID.Visible = true;
        lblInvalidID.Text = "Invalid UserID";
        btnSave.Enabled = false;
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }
    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here
    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
        public string error
        {
            get;
            set;
        }

        public string service
        {
            get;
            set;
        }

    }
}