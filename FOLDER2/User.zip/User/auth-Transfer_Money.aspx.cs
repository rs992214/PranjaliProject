﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_Transfer_Money : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(connstring);
        cmd = new SqlCommand();
        cmd.Connection = con;
        if (Session["UserID"] != null)
        {
            UpgradeWallet();
            if (!IsPostBack)
            {
               
                //string ID = Request.QueryString["id"];
               // PINAMOUNT(ID);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    public void UpgradeWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('UPGRADE WALLET','Current Package Amount!','Transfer Money Debit','Transfer Money Credit')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblWallet.Text = dt.Rows[0]["WalletAmount"].ToString();
                //    lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblWallet.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void txtUserID_TextChanged(object sender, EventArgs e)
    {
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID,Name From MLM_Registration Where UserID='" + txtUserID.Text + "' And UserID!='" + Session["UserID"] + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtUserID.Text = dt.Rows[0]["UserID"].ToString();
            lblMSG.Text = dt.Rows[0]["Name"].ToString();
            _Valid.Visible = true;
            btnProceed.Enabled = true;
        }
        else
        {
            lblMSG.Text = "You have entered invalid USERID.";
            _Valid.Visible = false;
            lblpakagename.Text = string.Empty;
            btnProceed.Enabled = false;
            lblpackageamt.Text = string.Empty;
        }
    }

    protected void btnProceed_Click1(object sender, EventArgs e)
    {
        //string UserID = Session["UserID"].ToString();
        try
        {
            //string UserID = Session["UserID"].ToString();
            if (txtAmount.Text!=string.Empty && txtUserID.Text!=string.Empty)
            {
                decimal amount_temp = Convert.ToDecimal(txtAmount.Text);
                if (amount_temp > 0)
                {
                    DAL objDAL = new DAL();
                    DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('UPGRADE WALLET','Current Package Amount!','Transfer Money Debit','Transfer Money Credit')", ref message);
                    if (dt.Rows.Count > 0)
                    {
                        decimal UpgradeWallet_Amount = Convert.ToDecimal(dt.Rows[0]["WalletAmount"]);
                        decimal amount = Convert.ToDecimal(txtAmount.Text);
                        if (UpgradeWallet_Amount >= amount)
                        {

                            con = new SqlConnection(connstring);
                            con.Open();
                            cmd = new SqlCommand("sp_Transfer_Money", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
                            cmd.Parameters.AddWithValue("@TransferBy", Session["UserID"].ToString());
                            cmd.Parameters.AddWithValue("@TransferTo", txtUserID.Text);
                            cmd.Parameters.AddWithValue("@Amount", txtAmount.Text);
                            cmd.Parameters.AddWithValue("@Mode", "Insert");
                            int flag = cmd.ExecuteNonQuery();
                            con.Close();
                            if (flag > 0)
                            {
                                LedgerDebit();
                                LedgerCredit();
                                Response.Redirect("success.aspx?Link=auth-Transfer_Money.aspx");
                            }

                        }
                        else
                        {
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Insufficient Balance')", true);
                        }
                        //    lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Amount Should be greater than zero')", true);

                }
            }
        }
        catch (Exception ex)
        {
        }
    }
    private void LedgerCredit()
    {
        decimal CR = Convert.ToDecimal(txtAmount.Text);
        decimal DR = 0;
        string Description = "Transfer Money Credit";
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", CR);
        cmd.Parameters.AddWithValue("@DR", DR);
        cmd.Parameters.AddWithValue("@Descriptions", Description);
        cmd.Parameters.AddWithValue("@TransferBy", Session["UserID"].ToString());
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }
    private void LedgerDebit()
    {
        string debit_user=Session["UserID"].ToString();
        decimal CR = 0;
        decimal DR = Convert.ToDecimal(txtAmount.Text);
        string Description = "Transfer Money Debit";
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", debit_user);
        cmd.Parameters.AddWithValue("@TransactionType", "DR");
        cmd.Parameters.AddWithValue("@CR", CR);
        cmd.Parameters.AddWithValue("@DR", DR);
        cmd.Parameters.AddWithValue("@Descriptions", Description);
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtAmount.Text = string.Empty;
        txtUserID.Text = string.Empty;
    }
}