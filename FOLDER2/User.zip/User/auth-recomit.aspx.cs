﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
public partial class customer_auth_recomit : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DAL dal = new DAL();
    string message = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            txtUserID.Text = Session["UserID"].ToString();
            //if (!IsPostBack)
            //{
            //   // GetData();

            //    //CheckPackageValidity();
            //    // btnProceed.Enabled = false;
            //}
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }

    }

 

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here
    protected void txtPinNo_TextChanged(object sender, EventArgs e)
    {
        DAL dal = new DAL();
        DataTable dt = dal.Gettable("select pi.PackageName,pi.Amount,pi.DonationAmount from PinGenerateNew pg inner join PackageInfo pi on pg.PackageID=pi.ID where pg.PinNo='" + txtPinNo.Text + "' and Status='Unused'", ref message);
        //  DataTable dt1 = dal.Gettable("select * from PinGenerateNew  where PinNo='" + txtPinNo.Text + "' and Status='Unused'", ref message);


        if (dt.Rows.Count > 0)
        {
            // DataTable dt = dal.Gettable("select pi.PackageName,pi.Amount,pi.DonationAmount from PinGenerateNew pg inner join PackageInfo pi on pg.PackageID=pi.ID where pg.PinNo='" + txtPinNo.Text + "' and Status='Unused'", ref message);

            lblPackageAmount.Text = dt.Rows[0]["Amount"].ToString();
            lblPackageName.Text = dt.Rows[0]["PackageName"].ToString();
            lblDonationamt.Text = dt.Rows[0]["DonationAmount"].ToString();
            Wrong.Visible = false;
            Right.Visible = true;
            btnProceed.Enabled = true;
        }
        else
        {
            txtPinNo.Text = "";
            btnProceed.Enabled = false;
            Wrong.Visible = true;
            Right.Visible = false;
            ShowPopupMessage("Pin Already Used", PopupMessageType.Warning);
            // lblPackageAmount.Text = "0";
            // lblPackageName.Text = string.Empty;
        }
    }

    protected void txtUserID_TextChanged(object sender, EventArgs e)
    {

        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID From MLM_Registration Where UserID='" + txtUserID.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtUserID.Text = dt.Rows[0]["UserID"].ToString();
            //getnamepackage();
            _Valid.Visible = true;
            lblMSG.Visible = false;
            //  btnupdate.Visible = false;
        }
        else
        {
            txtUserID.Text = string.Empty;
            _Valid.Visible = false;
            lblMSG.Visible = true;
        }
    }
    private void LedgerCredit()
    {
        DataTable dt = dal.Gettable("SELECT Amount, PackageName FROM PinGenerateNew as pin INNER JOIN PackageInfo as p ON p.ID = pin.PackageID WHERE pin.PinNo = '" + txtPinNo.Text + "'", ref message);
        decimal PackageAmount = Convert.ToDecimal(dt.Rows[0]["Amount"].ToString());
        lblPackageName.Text = dt.Rows[0]["PackageName"].ToString();

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", PackageAmount);
        cmd.Parameters.AddWithValue("@DR", 0);
        cmd.Parameters.AddWithValue("@Descriptions", "Current Package Amount!");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }
    private void LedgerDebit()
    {
        DataTable dt = dal.Gettable("SELECT Amount, PackageName FROM PinGenerateNew as pin INNER JOIN PackageInfo as p ON p.ID = pin.PackageID WHERE pin.PinNo = '" + txtPinNo.Text + "'", ref message);
        decimal PackageAmount = Convert.ToDecimal(dt.Rows[0]["Amount"].ToString());
        lblPackageName.Text = dt.Rows[0]["PackageName"].ToString();

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "DR");
        cmd.Parameters.AddWithValue("@CR", 0);
        cmd.Parameters.AddWithValue("@DR", PackageAmount);
        cmd.Parameters.AddWithValue("@Descriptions", "Current Package Amount!");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();

        if (flag > 0)
        {
            string spid = "";
            DataTable dtsp = dal.Gettable("select SponsorID from MLM_Registration Where UserID='" + txtUserID.Text + "'", ref message);
            if (dtsp.Rows.Count > 0)
            {
                spid = dtsp.Rows[0]["SponsorID"].ToString();
                // CreditSponsorIncome(spid, PackageAmount);
            }

        }
    }

    public void UpdatePackage()
    {
        try
        {


            int flag = dal.Executequery("UPDATE MLM_Registration SET recomitstatus='Yes', Package = '" + lblPackageName.Text + "' WHERE UserID = '" + txtUserID.Text + "'", ref message);

            //     int flag2 = dal.Executequery("UPDATE  SET recomitstatus='Yes', Package = '" + lblPackageName.Text + "' WHERE UserID = '" + txtUserID.Text + "'", ref message);



        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void addph()
    {
        int flag = dal.Executequery("INSERT INTO ProvideHelp (UserID,Amount) VALUES ('" + txtUserID.Text + "','" + lblDonationamt.Text + "')", ref message);

    }

    protected void btnProceed_Click(object sender, EventArgs e)
    {

        if (Session["UserID"] != null)
        {
            //  DataTable dt = dal.Gettable("SELECT UserID,Status FROM PinGenerateNew WHERE UserID='" + txtUserID.Text + "' AND Status='Unused'", ref message);
            //  if (dt.Rows.Count > 0)
            // {
            //    ShowPopupMessage("User already Activated.", PopupMessageType.Warning);
            //}
            //else
            //{
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("PinGenerateNew_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
            cmd.Parameters.AddWithValue("@PinNo", txtPinNo.Text);
            cmd.Parameters.AddWithValue("@PackageName", lblPackageName.Text);
            cmd.Parameters.AddWithValue("@Mode", "UPD_STATUS");
            int flag = cmd.ExecuteNonQuery();
            if (flag > 0)
            {



              
                //CheckPackageValidity();
                // LedgerCredit();
                // LedgerDebit();
                UpdatePackage();
                addph();
                txtPinNo.Text = string.Empty;
                txtUserID.Text = string.Empty;
                _Valid.Visible = false;
                Right.Visible = false;
                Wrong.Visible = false;
                btnupdate.Visible = false;
                ShowPopupMessage("Recommitment Successful.", PopupMessageType.Success);
                con.Close();
            }
            else
            {
                ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
            }
            //    }
            //}
            //else
            //{
            //    Response.Redirect("Logout.aspx");
            //}


        }
    }
}