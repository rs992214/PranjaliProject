﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;
using System.Drawing;
using System.Net;
using System.Configuration;

public partial class customer_auth_postquery : System.Web.UI.Page
{
    string Password = "";
    string UserID = "";
    string LoginIP = GetLocalIPAddress();
    DAL dal = new DAL();
    string message = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                SetDefaultButton(txtQuery, btnSave);
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    private void SetDefaultButton(TextBox txt, Button defaultButton)
    {
        txtQuery.Attributes.Add("onkeypress", "funfordefautenterkey1(" + btnSave.ClientID + ",event)");
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if(txtQuery.Text!=string.Empty)
        { 
           try
           {
               int flag = dal.Executequery("insert into Helpdesk (UserID,Query) values ('" + Session["UserID"].ToString() + "','" + txtQuery.Text + "')", ref message);
               if (flag > 0)
               {
                    getDataForTrace();
                    Querytrace();
                    lblmsg.Text = "Query has been sent successfully.";
                    lblmsg.ForeColor = Color.Green;
                    txtQuery.Text = string.Empty;
                    // ShowMessage("Query has been sent successfully.", MessageType.Success);
                    Response.Redirect("success.aspx?Link=auth-postquery.aspx");
                    Response.Redirect("auth-greviancedetails.aspx");
               }
               else
               {
                    
                    ShowMessage(message, MessageType.Error);
                    lblmsg.Text = message;
                    lblmsg.ForeColor = Color.Red;


                    
                }
           }
           catch (Exception ex)
           {
                getDataForTrace();
                string error = ex.ToString();
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'Error:'"+ error + "'')", con);
                    cmd.CommandType = CommandType.Text;

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {

                    }
                }
                catch (Exception ex1)
                {
                }
                finally
                {
                    con.Close();
                }


                ShowMessage(ex.Message, MessageType.Error);
                lblmsg.Text = ex.Message;
                lblmsg.ForeColor = Color.Red;
            }
        }
        else
        {
            ShowMessage("Please Enter Query", MessageType.Error);
            lblmsg.Text = "Please Enter Query";
            lblmsg.ForeColor = Color.Red;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-postquery.aspx");
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/Red_Cross_Tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here
    public enum MessageType { Success, Error, Info, Warning };

    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    public void getDataForTrace()
    {

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("select UserID, Password from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Password = dt.Rows[0]["Password"].ToString();
                UserID = dt.Rows[0]["UserID"].ToString();

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

    public void Querytrace()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'Query Send to Admin panel Sucessfully..!!')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }

}