﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_loginash : System.Web.UI.Page
{
    string loginip = GetLocalIPAddress();
    DAL dal = new DAL();
    string message = string.Empty;
    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    string lblCompanyname = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        Showdatalogo();
        GetLocalIPAddress();
        lblipaddress.Text = GetLocalIPAddress();
        if (!IsPostBack)
        {
            if (Request.Cookies["UserName"] != null && Request.Cookies["Password"] != null)
            {
                txtuser.Text = Request.Cookies["UserName"].Value;
                txtpwd.Attributes["value"] = Request.Cookies["Password"].Value;
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {

            //rememberme
            if (chkRememberMe.Checked)
            {
                Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(30);
                Response.Cookies["Password"].Expires = DateTime.Now.AddDays(30);
            }
            else
            {
                Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
                Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);

            }
            Response.Cookies["UserName"].Value = txtuser.Text.Trim();
            Response.Cookies["Password"].Value = txtpwd.Text.Trim();
            //end
           
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select UserID,IsBlock from MLM_Registration where UserID='{0}' and Password='{1}'", txtuser.Text, txtpwd.Text);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                string IsBlock = dt.Rows[0]["IsBlock"].ToString();
                if (IsBlock == "No")
                {
                    GetLoginDetail();
                    Session["UserID"] = dt.Rows[0]["UserID"].ToString();
                    Response.Redirect("dashboardnew.aspx", false);
                }
                else if (IsBlock == "Yes")
                {

                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your account has been blocked please contact Administrator')", true);
                    //sb.AppendFormat("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + txtUsername.Text + "','" + txtPassword.Text + "','" + loginip + "',GETDATE(),'Login Faild:Your account has been blocked please contact Administrator..!!')");
                    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                    SqlConnection con = new SqlConnection(connstring);
                    try
                    {

                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + txtuser.Text + "','" + txtpwd.Text + "','" + loginip + "',GETDATE(),'Login Failed:Your account has been blocked please contact Administrator..!!')", con);
                        cmd.CommandType = CommandType.Text;

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {

                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            else
            {
                // sweetAlert('Congratulations!', 'Your message has been successfully sent', 'success');
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Invalid Account Or Password.')", true);
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + txtuser.Text + "','" + txtpwd.Text + "','" + loginip + "',GETDATE(),'Login Failed:Invalid Account Or Password.!!')", con);
                    cmd.CommandType = CommandType.Text;

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {

                    }

                }
                catch (Exception ex)
                {

                }
                finally
                {
                    con.Close();
                }

            }
        }
        catch (Exception ex)
        {
            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + txtuser.Text + "','" + txtpwd.Text + "','" + loginip + "',GETDATE(),'Error:'" + errormessage + "'')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }

            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

        }
    }

    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                Session["Company"] = dt.Rows[0]["CompanyName"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    // imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    imgLogo.ImageUrl = "data:image/png;base64," + base64String;
                }
            }
            else
            {

            }
        }
        catch (Exception ex)
        {

        }
    }

    private void GetLoginDetail()
    {

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + txtuser.Text + "','" + txtpwd.Text + "','" + loginip + "',GETDATE(),'Login SuccessFully..!!')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
}