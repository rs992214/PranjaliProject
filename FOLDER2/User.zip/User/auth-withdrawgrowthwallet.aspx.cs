﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Collections;
public partial class customer_auth_withdrawgrowthwallet : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();


    ArrayList UserIDRightList = new ArrayList();

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            // btnSave.Visible = false;
            GetWalletBalance();
            ShowMembersofteam();
            walletmaster();
            //  btnSave.Visible = false;

        }
    }

    public void walletmaster()
    {
       
            DAL dal = new DAL();
            string cn = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(cn);
            con.Open();
            SqlCommand cmd = new SqlCommand("select id,Amount  from wallet_amount_master", con);
            SqlDataReader dr = cmd.ExecuteReader();
        ddlSelectamount.DataSource = dr;
        ddlSelectamount.Items.Clear();
        ddlSelectamount.DataTextField = "Amount";
        ddlSelectamount.DataValueField = "id";
        ddlSelectamount.DataBind();
        ddlSelectamount.Items.Insert(0, new ListItem("--Select Denomination--", "0"));
            con.Close();
        
    }
    private void EnableFalse_Control()
    {
        txtAmount.Enabled = false;
        txtDescription.Enabled = false;
        btnSave.Enabled = false;
    }
    private void EnableTrue_Control()
    {
        txtAmount.Enabled = true;
        txtDescription.Enabled = true;
        btnSave.Enabled = true;
    }
    private void CheckWithdrawal_Request()
    {
        string UserID = Session["UserID"].ToString();
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID,Status From WithdrawalRequest Where UserID='" + UserID + "' and Status='REQUEST' ", ref message);
        if (dt.Rows.Count > 0)
        {
            // EnableFalse_Control();
            ShowPopupMessage("You have already request to admin.", PopupMessageType.Message);
        }
        else
        {
            //  EnableTrue_Control();
            EnableFalse_Control();
        }
    }
    private void GetWalletBalance()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions in ('Growth Income','Activation') ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblWalletBalance.Text = dt.Rows[0]["WalletAmount"].ToString();
                decimal WalletBalance = Convert.ToDecimal(lblWalletBalance.Text);


                if (WalletBalance > 0 && WalletBalance <= 10000)
                {

                    var currentTime = DateTime.Now.TimeOfDay;
                    var start = new TimeSpan(6, 0, 0);
                    var end = new TimeSpan(9, 0, 0);
                    var midnight = new TimeSpan(12, 0, 0);

                    if (currentTime >= start && currentTime <= end)
                    {





                        EnableTrue_Control();
                        //   ShowPopupMessage("Withdrawal Can Be Done From 6AM To 9AM Only. ", PopupMessageType.Message);
                        // CheckWithdrawal_Request();

                    }
                    else
                    {
                        EnableFalse_Control();
                        ShowPopupMessage("Withdrawal Can Be Done From 6AM To 9AM Only. ", PopupMessageType.Message);
                        //Response.Redirect("Success.aspx?Link=auth-withdrawgrowthwallet.aspx");
                        // CheckWithdrawal_Request();
                    }
                }
                else
                {
                    ShowPopupMessage("Insufficient Funds for Withdrawal.", PopupMessageType.Warning);

                }



            }
            else
            {
                lblWalletBalance.Text = "0";
                EnableFalse_Control();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    //minimum2 direct condition
    public void ShowMembersofteam()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            string LeftUser = null;
            string RightUser = null;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();

                if (LeftUser != null)
                {
                    ShowMembersofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowMembersofteamB(RightUser);
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteamA(string Leftuserid)
    {
        try
        {
            List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
            string L = null;
            string R = null;
            string UserID = Leftuserid;
            DataTable dtUser1 = new DataTable();
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    dtUser1 = dal.Gettable("select SponsorID,UserID,Name,JoinType,Mobile,Email,CONVERT(nvarchar,JoinDate,105)As JoinDate from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtUser1.Rows.Count > 0)
                    {
                        string sponsorid = dtUser1.Rows[0]["SponsorID"].ToString();
                        if (Session["UserID"].ToString().ToUpper() == sponsorid.ToUpper())
                        {
                            detail.Add(new MLMUserDetailProperty
                            {
                                UserID = dtUser1.Rows[0]["UserID"].ToString(),
                                Name = dtUser1.Rows[0]["Name"].ToString(),
                                Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                                Email = dtUser1.Rows[0]["Email"].ToString(),
                                Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                                JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            });
                        }
                        else
                        {
                            //
                        }
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
            GridView gvs = new GridView();
            gvs.DataSource = detail.ToList();
            gvs.DataBind();

            hfdirectcount.Value = gvs.Rows.Count.ToString();
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteamB(string Rightuserid)
    {
        try
        {
            List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
            string L = null;
            string R = null;
            DataTable dtUser1 = new DataTable();
            string UserID = Rightuserid;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    dtUser1 = dal.Gettable("select SponsorID,UserID,Name,JoinType,Mobile,Email,CONVERT(nvarchar,JoinDate,105)As JoinDate from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtUser1.Rows.Count > 0)
                    {
                        string sponsorid = dtUser1.Rows[0]["SponsorID"].ToString();
                        if (Session["UserID"].ToString().ToUpper() == sponsorid.ToUpper())
                        {
                            detail.Add(new MLMUserDetailProperty
                            {
                                UserID = dtUser1.Rows[0]["UserID"].ToString(),
                                Name = dtUser1.Rows[0]["Name"].ToString(),
                                Mobile = dtUser1.Rows[0]["Mobile"].ToString(),
                                Email = dtUser1.Rows[0]["Email"].ToString(),
                                Jointype = dtUser1.Rows[0]["JoinType"].ToString(),
                                JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
                            });
                        }
                        else
                        {
                            //
                        }
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }

            } while (UserID != null);
            GridView gvs1 = new GridView();
            gvs1.DataSource = detail.ToList();
            gvs1.DataBind();

            hdfright.Value = gvs1.Rows.Count.ToString();

        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        DataTable dtw = dal.Gettable("select c from wallet_master", ref message);
        string minwallamts = dtw.Rows[0]["minwalletamt"].ToString();
        decimal minwallamtf = Convert.ToDecimal(minwallamts);


        try
        {
            //string directcount = hfdirectcount.Value;

            //int dcount = Convert.ToInt32(directcount) + Convert.ToInt32(hdfright.Value);

            //int directcount1 = Convert.ToInt32(dcount);
            //if (directcount1 >= 2)
            //{





            if (Session["UserID"] != null)
            {
                decimal WalletBalance = Convert.ToDecimal(lblWalletBalance.Text);
                decimal RequestAmount = Convert.ToDecimal(txtAmount.Text);
                decimal Balance = 0;

                if (RequestAmount <= WalletBalance)
                {
                    Balance = WalletBalance - RequestAmount;
                    //if (Balance >= 0 && Balance < 10000)
                    //{
                        if (Balance >= minwallamtf)
                        {

                        string UserID = Session["UserID"].ToString();
                        decimal CR = 0;
                        decimal DR = Convert.ToDecimal(txtAmount.Text);
                        con = new SqlConnection(connstring);
                        con.Open();
                        cmd = new SqlCommand("WithdrawalRequest_ALL", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        //withdrawal request tbl
                        cmd.Parameters.AddWithValue("@UserID", UserID);
                        cmd.Parameters.AddWithValue("@Amount", txtAmount.Text);
                        cmd.Parameters.AddWithValue("@Description", "Growth Income");
                        //ledger tbl
                        cmd.Parameters.AddWithValue("@TransactionType", "DR");
                        cmd.Parameters.AddWithValue("@CR", CR);
                        cmd.Parameters.AddWithValue("@DR", DR);
                        cmd.Parameters.AddWithValue("@Descriptions", "Growth Income");
                        cmd.Parameters.AddWithValue("@Mode", "IN");
                        int flag = cmd.ExecuteNonQuery();
                        if (flag > 0)
                        {
                            //AddGhMemeber();
                            GetWalletBalance();
                            ShowPopupMessage("Your Request has been sent to Admin.", PopupMessageType.Success);
                            btnSave.Visible = false;
                        }
                        else
                        {
                            ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                        }
                    }
                    //else
                    //{
                    //    ShowPopupMessage("Balance is less than 500.", PopupMessageType.Message);
                    //}
                }
                else
                {
                    ShowPopupMessage("Requested Amount is more than Wallet Amount .", PopupMessageType.Message);
                }


            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
            //}
            //else
            //{
            //    ShowPopupMessage("Withdrawal Can Be Done After 2 Directs only.", PopupMessageType.Message);
            //}


        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }


    public void AddGhMemeber()
    {
        string message = string.Empty;
        string UserID = Session["UserID"].ToString();


        StringBuilder sbb = new StringBuilder();

        sbb.AppendLine("insert into GetHelp(UserID,Amount)");
        sbb.AppendFormat("values('{0}','{1}')", UserID, txtAmount.Text);
        int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);


    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("WithdrawalRequest.aspx");
    }



    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here






    protected void ddlSelectamount_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtAmount.Text = ddlSelectamount.SelectedItem.ToString();
        txtAmount.ReadOnly = true;
    }
}