﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Net.Mail;
using System.Net;
using System.IO;
using Newtonsoft.Json;

public partial class customer_auth_activateepinaspx : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DAL dal = new DAL();

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            // txtUserID.Text = Session["UserID"].ToString();
            if (!IsPostBack)
            {
                BindPackages();
                GetData();
                showname();
                UpgradeWallet();
                //CheckPackageValidity();
                // btnProceed.Enabled = false;

                lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
                string time = DateTime.Now.AddHours(0).ToString("hh:mm:ss tt");
                Label1.Text = DateTime.Now.AddHours(0).ToString("hh");
                Label2.Text = Convert.ToDateTime(time).ToString("tt");
                if (Label1.Text == "10" && Label2.Text == "PM")
                {
                    btnProceed.Visible = false;
                    lblValidityMSG2.Text = "Member Can't be Activate Because System In Calculation Mode 10.00 PM to 12.00";
                }
                else if (Label1.Text == "11" && Label2.Text == "PM")
                {
                    btnProceed.Visible = false;
                    lblValidityMSG2.Text = "Member Can't be Activate Because System In Calculation Mode 10.00 PM to 12.00";
                }
                else
                {
                    btnProceed.Visible = true;
                    lblValidityMSG2.Text = "";
                }
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    public void UpgradeWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('UPGRADE WALLET','Current Package Amount!','Transfer Money Debit','Transfer Money Credit')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblTopup.Text = dt.Rows[0]["WalletAmount"].ToString();
                //    lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblTopup.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }


    protected void GetTime(object sender, EventArgs e)
    {
        lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
    }
    private void CheckPackageValidity()
    {

        //  <---22/10/2019 CheckPakage validtiy change Package Valid.-->
        try
        {
            if (Session["UserID"] != null)
            {
                string UserID = Session["UserID"].ToString();
                DAL objDAL = new DAL();
                DataTable dt = objDAL.Gettable("Select PG.ID, PG.UserID, PG.PackageID, PK.Validity, ISNULL(DATEDIFF(DAY, PG.ActivationDate, GETDATE()), 0) As TotalDays From PinGenerateNew PG Inner Join PackageInfo PK On PK.ID = PG.PackageID Where UserID = '" + UserID + "' and Status = 'Unused'", ref message);
                if (dt.Rows.Count > 0)
                {
                    string ID = dt.Rows[0]["ID"].ToString();
                    int _TotalDays = Convert.ToInt32(dt.Rows[0]["TotalDays"].ToString());
                    int _Validity = Convert.ToInt32(dt.Rows[0]["Validity"].ToString());
                    int Calculate = _Validity - _TotalDays;
                    lblValidity.Text = Calculate.ToString();
                    if (_TotalDays > _Validity)
                    {
                        btnProceed.Enabled = true;
                        lblValidity.Visible = false;
                        lblValidityMSG2.Text = string.Empty;
                    }
                    else if (_TotalDays <= _Validity)
                    {
                        btnProceed.Enabled = false;
                        lblValidityMSG1.Text = "Your Package Validity will be expired after";
                        lblValidity.Visible = true;
                        lblValidityMSG2.Text = "Days. After that you can select Package and activate your pin.";
                    }
                    if (_TotalDays > _Validity)
                    {
                        con = new SqlConnection(connstring);
                        con.Open();
                        cmd = new SqlCommand("PinGenerateNew_ALL", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserID", UserID);
                        cmd.Parameters.AddWithValue("ID", ID);
                        cmd.Parameters.AddWithValue("@Mode", "UPD_VALIDITY_STATUS");
                        int flag = cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                else
                {
                    btnProceed.Enabled = true;
                    lblValidity.Visible = false;
                    lblValidityMSG2.Text = string.Empty;
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void GetData()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            //DataTable dt = objDAL.Gettable("Select ID,PinNo,Status,CONVERT(nvarchar,CreationDate,105)As CreationDate,PackageID From PinGenerateNew Where TransferTo='" + UserID + "' and Status='Unused'", ref message);
            DataTable dt = objDAL.Gettable("Select pp.ID,pp.PinNo,pf.PackageName,Status,CONVERT(nvarchar,pp.CreationDate,105)As CreationDate,pp.PackageID From PinGenerateNew pp inner join PackageInfo pf on pf.ID=pp.PackageID Where TransferTo='" + UserID + "' and Status='Unused'", ref message);
            if (dt.Rows.Count > 0)
            {
                GV_PinNoList.DataSource = dt;
                GV_PinNoList.DataBind();
            }
            else
            {
                GV_PinNoList.DataSource = null;
                GV_PinNoList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        //try
        //{
        //    string UserID = Session["UserID"].ToString();
        //    DAL objDAL = new DAL();
        //    DataTable dt = objDAL.Gettable("Select ID,PinNo,Status,CONVERT(nvarchar,CreationDate,105)As CreationDate,PackageID From PinGenerateNew Where UserID='" + UserID + "' and Status='Unused'", ref message);
        //    if (dt.Rows.Count > 0)
        //    {
        //        GV_PinNoList.DataSource = dt;
        //        GV_PinNoList.DataBind();
        //    }
        //    else
        //    {
        //        GV_PinNoList.DataSource = dt;
        //        GV_PinNoList.DataBind();
        //    }
        //}
        //catch (Exception ex)
        //{
        //    ShowPopupMessage(ex.Message, PopupMessageType.Error);
        //}
    }
    public void showname()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select Name from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            object Name = dal.Getscalar(sb.ToString(), ref message);
            if (Name is DBNull)
            {
                //lblname.Text = "Demo";
            }
            else
            {
                if (Name != null)
                {
                    //lblname.Text = Name.ToString();
                }
                else
                {
                    //    lblname.Text = "Demo";
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void GV_PinNoList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        // <--22/10/2019 Stauts Check GridView In --->

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton btnSelect = e.Row.FindControl("btnSelect") as LinkButton;
            Label lblStatus = e.Row.FindControl("lblStatus") as Label;
            if (lblStatus.Text == "Unused")
            {
                btnSelect.Enabled = true;
                btnSelect.CssClass = "btn btn-sm btn-bitbucket";
            }
            else
            {
                btnSelect.Enabled = false;
                btnSelect.CssClass = "btn btn-sm btn-bitbucket disabled";
            }
        }
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    LinkButton btnSelect = e.Row.FindControl("btnSelect") as LinkButton;
        //    Label lblStatus = e.Row.FindControl("lblStatus") as Label;
        //    if (lblStatus.Text == "Unused")
        //    {
        //        btnSelect.Enabled = true;
        //        btnSelect.CssClass = "btn btn-sm btn-bitbucket";
        //    }
        //    else
        //    {
        //        btnSelect.Enabled = false;
        //        btnSelect.CssClass = "btn btn-sm btn-bitbucket disabled";
        //    }
        //}
    }
    int packageID;
    string pkgmssge;

    protected void txtUserID_TextChanged(object sender, EventArgs e)
    {
        if (ddlPackage.SelectedIndex>0)
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Name From MLM_Registration Where UserID='" + txtUserID.Text.Trim() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                txtUserID.Text = dt.Rows[0]["UserID"].ToString();
                lblname.Text = dt.Rows[0]["Name"].ToString();
                lblname.Visible = true;
                //getnamepackage();
                _Valid.Visible = true;
                lblMSG.Visible = false;
                //btnupdate.Visible = false;
                //PackageID =2
                DataTable dt5 = dal.Gettable("select MAX(packageID) as PackageID from [MemberActivation] where TransferTO='" + txtUserID.Text + "' ", ref message);
                if (dt5.Rows.Count > 0 && dt5.Rows[0]["PackageID"] != DBNull.Value)
                {
                    if (dt5.Rows[0]["PackageID"] != DBNull.Value)
                    {
                        packageID = Convert.ToInt32(dt5.Rows[0]["PackageID"]);
                        DataTable dt6 = dal.Gettable("select PackageName from [MemberActivation] where PackageID=" + packageID + " ", ref message);
                        ViewState["PackageName"] = dt6.Rows[0]["PackageName"].ToString();
                    }

                    if (ddlPackage.SelectedIndex > packageID)  //p=1 , s=2
                    {
                        #region Code for Sequencily Select Package
                        //int temp = packageID + 1;
                        //if (ddlPackage.SelectedIndex == temp)
                        //{
                        //    btnProceed.Enabled = true;
                        //    lblpackageName1.Text = ViewState["PackageName"].ToString();
                        //}
                        //else
                        //{
                        //    txtUserID.Text = string.Empty;
                        //    btnProceed.Enabled = false;
                        //    lblname.Text = string.Empty;
                        //    lblpackageName1.Text = string.Empty;
                        //    ShowPopupMessage("Select Package In Sequence ! Current Package is (" + ViewState["PackageName"].ToString() + ")", PopupMessageType.Warning);
                        //}
                        #endregion
                    }

                    else
                    {
                        txtUserID.Text = string.Empty;
                        lblname.Visible = false;
                        ShowPopupMessage("Already Registerd on this Package" + ViewState["PackageName"].ToString(), PopupMessageType.Warning);
                    }
                }
                #region Select First Package
                //else
                //{
                //   // txtUserID.Text = string.Empty;
                //    if (ddlPackage.SelectedIndex > 1)
                //    {
                //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", "alert('Please select First Package')", true);
                //        //ShowPopupMessage("Please select First Package", PopupMessageType.Warning);
                //        txtUserID.Text = string.Empty;
                //        lblname.Text = string.Empty;
                //        lblpackageName1.Text = string.Empty;
                //    }

                //}
                #endregion
            }
            else
            {
                txtUserID.Text = string.Empty;
                _Valid.Visible = false;
                lblMSG.Visible = true;
                lblname.Visible = false;
                clear();
            }

        }
        else
        {
           ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Select Packge !')", true);
            txtUserID.Text = string.Empty;
        }


    }

    string PkgName = null;
    bool flag = false;
    #region Check Package eligbilty
    //private void Check_Package_Eligibility()
    //{
    //    string message = string.Empty;
    //    DAL dal = new DAL();
    //    DataTable dt = dal.Gettable("select MAX(PackageID) as PackageID from MemberActivation where UserID='"+txtUserID.Text+"' ", ref message);
    //    if (dt.Rows.Count>0)
    //    {
    //        int PkgID = Convert.ToInt32(dt.Rows[0]["PackageID"]);
    //        if(PkgID==1)
    //        {
    //            PkgName = "BRONZE-100";
    //        }
    //        else if (PkgID == 2)
    //        {
    //            PkgName = "SILVER-500";
    //        }
    //        else if (PkgID == 3)
    //        {
    //            PkgName = "GOLD-1000";
    //        }
    //        else if (PkgID == 4)
    //        {
    //            PkgName = "PLATINUM-2000";
    //        }
    //        else if (PkgID == 5)
    //        {
    //            PkgName = "DIAMOND-5000";
    //        }
    //        else if (PkgID == 6)
    //        {
    //            PkgName = "CROWN-10000";
    //        }
    //        #region Checking Package Name
    //        if (ddlPackage.SelectedItem.Text == PkgName)//Package_Name
    //        {
    //           ShowPopupMessage("Please Select Higher Package", PopupMessageType.Warning);
    //        }
    //        else
    //        {
    //            flag = true;
    //        }
    //        #endregion
    //    }
    //    else
    //    {
    //       // ShowPopupMessage("Please Select Higher Package", PopupMessageType.Warning);
    //    }
    //}

    #endregion
    public void getnamepackage()
    {
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("select distinct pin.ID, pin.Status, pkg.Packagename, pkg.amount from pingeneratenew as pin inner join mlm_registration as ml on ml.userid = pin.userid inner join PackageInfo as pkg on pkg.packagename = ml.package where pin.UserID = '" + txtUserID.Text + "' AND pin.Status = 'Used'", ref message);
        // DataTable dt = objDAL.Gettable("select * from PinGenerateNew where UserID='" + txtUserID.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            // txtUserID.Text = dt.Rows[0]["ID"].ToString();
            lblpackageName1.Text = dt.Rows[0]["PackageName"].ToString();
            lblpackageamount1.Text = dt.Rows[0]["Amount"].ToString();
            _Valid.Visible = true;
            lblMSG.Visible = false;
            btnProceed.Visible = false;
        }
        else
        {
            _Valid.Visible = false;
            lblMSG.Visible = true;
        }
    }
    protected void btnSelect_Click(object sender, EventArgs e)
    {
        // <-- 22/10/2019 Select Activate Pin --->//

        int rowIndex = Convert.ToInt32(((sender as LinkButton).NamingContainer as GridViewRow).RowIndex);
        GridViewRow row = GV_PinNoList.Rows[rowIndex];
        Label lblPinNo = row.FindControl("lblPinNo") as Label;
        txtPinNo.Text = lblPinNo.Text;
        LinkButton btn = (LinkButton)(sender);
        Label lblpackage = row.FindControl("lblpackageid") as Label;
        lblPackage_ID.Text = lblpackage.Text;
        Right.Visible = true;
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select ID, PackageName, Amount From PackageInfo Where ID = '" + lblPackage_ID.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            lblPackageName.Text = dt.Rows[0]["PackageName"].ToString();
        }
        #region Dummy
        //int rowIndex = Convert.ToInt32(((sender as LinkButton).NamingContainer as GridViewRow).RowIndex);
        //GridViewRow row = GV_PinNoList.Rows[rowIndex];

        //Label lblPinNo = row.FindControl("lblPinNo") as Label;
        //txtPinNo.Text = lblPinNo.Text;
        //LinkButton btn = (LinkButton)(sender);
        ////lblPackage_ID.Text = btn.CommandArgument;
        //Label lblpackage = row.FindControl("lblpackageid") as Label;
        //lblPackage_ID.Text = lblpackage.Text;
        //Right.Visible = true;

        //DAL objDAL = new DAL();
        //DataTable dt = objDAL.Gettable("Select ID,PackageName,Amount From PackageInfo Where ID='" + lblPackage_ID.Text + "'", ref message);
        //if (dt.Rows.Count > 0)
        //{
        //    lblPackageName.Text = dt.Rows[0]["PackageName"].ToString();
        //    lblPackageAmount.Text = dt.Rows[0]["Amount"].ToString();
        //}

        #endregion

    }
    public void PartialPinRS2000()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("PinGenerateNew_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@PinNo", txtPinNo.Text);
        cmd.Parameters.AddWithValue("@PackageName", lblPackageName.Text);
        cmd.Parameters.AddWithValue("@Mode", "Pin2000Active");
        cmd.ExecuteNonQuery();
        // ShowPopupMessage("Pin has been Activated.", PopupMessageType.Success);
        Response.Redirect("Success.aspx?Link=auth-activateepin.aspx");
        btnProceed.Visible = false;
    }


    private void SponsorIncome()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("SPONSERINCOME_SAKSHI", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@user_id",txtUserID.Text);
        // cmd.Parameters.AddWithValue("@PinNo", txtPinNo.Text);
      //  cmd.Parameters.AddWithValue("@sponsorid", sponsor);
        cmd.Parameters.AddWithValue("@package", Convert.ToDecimal(txtPinNo.Text));
        if (cmd.ExecuteNonQuery() > 0)
        {

        }
        else
        {

        }
    }
    protected void btnProceed_Click(object sender, EventArgs e)
    {
        if (txtUserID.Text != string.Empty && txtPinNo.Text != string.Empty && ddlPackage.SelectedIndex>0)
        {
            try
            {
                if (Session["UserID"] != null)
                {
                    #region Select Higher Package
                    //  DataTable dt2 = dal.Gettable("select MAX(PackageID) PackageID,MAX(PackageAmount) PackageAmount  from [dbo].[MemberActivation] where UserID='" + txtUserID.Text.Trim() + "' ", ref message);

                    //if(Convert.ToDecimal(dt2.Rows[0]["PackageAmount"]) >Convert.ToDecimal(txtPinNo.Text)   ||   (dt2.Rows[0]["PackageAmount"]==null && dt2.Rows[0]["PackageID"] == null))
                    //{

                    //}
                    //else
                    //{
                    //    clear();
                    //    ScriptManager.RegisterStartupScript(this, GetType(),"","alert('Select Highest Package')",true);
                    //}
                    #endregion
                    DataTable dt4 = dal.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('UPGRADE WALLET','Current Package Amount!','Transfer Money Credit','Transfer Money Debit')", ref message);
                    decimal UpgradeWallet = Convert.ToDecimal(dt4.Rows[0]["WalletAmount"]);
                    if (UpgradeWallet >= Convert.ToDecimal(txtPinNo.Text))
                    {
                        DataTable dt1 = dal.Gettable("SELECT JoinType FROM MLM_Registration WHERE UserID='" + txtUserID.Text.Trim() + "' ", ref message);
                        if (dt1.Rows[0]["JoinType"].ToString() == "Free")
                        {
                            con = new SqlConnection(connstring);
                            con.Open();
                            cmd = new SqlCommand("PinGenerateNew_ALL", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
                            cmd.Parameters.AddWithValue("@TransferTo", txtUserID.Text.Trim());
                            cmd.Parameters.AddWithValue("@TransferBy", Session["UserID"].ToString());
                            cmd.Parameters.AddWithValue("PackageAmount", txtPinNo.Text);
                            cmd.Parameters.AddWithValue("@PackageName", ddlPackage.SelectedItem.Text);
                            cmd.Parameters.AddWithValue("@PackageID", Convert.ToInt32(ddlPackage.SelectedValue));
                            cmd.Parameters.AddWithValue("@Mode", "UPD_STATUS1");
                            int flag = cmd.ExecuteNonQuery();
                            if (flag > 0)
                            {
                                decimal plutocoin = 0;
                                DataTable dt3 = dal.Gettable("Select Max(Id) Id from [MemberActivation] where TransferBy='" + Session["UserID"].ToString() + "'", ref message);
                                if (dt3.Rows.Count > 0)
                                {
                                    DAL dal = new DAL();
                                    DataTable dtPluto = dal.Gettable("Select PlutoCoin,Dollar from Pluto_Master", ref message);
                                    if (dtPluto.Rows.Count>0)
                                    {
                                       decimal  plutodollar =Convert.ToDecimal(dtPluto.Rows[0]["Dollar"]);
                                        plutocoin = Convert.ToDecimal(txtPinNo.Text) / plutodollar;
                                        int ID = Convert.ToInt32(dt3.Rows[0]["Id"]);
                                        LedgerDebit(ID);
                                        LedgerCredit_Plutocoin(plutocoin);
                                        SponsorIncome();
                                    }
                                   
                                }
                                Response.Redirect("Success.aspx?Link=auth-activateepin.aspx");
                                con.Close();
                            }
                            else
                            {
                                clear();
                                ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                            }
                        }
                        else
                        {
                            DataTable dt2 = dal.Gettable("select MAX(PackageID) PackageID,MAX(PackageAmount) PackageAmount  from [dbo].[MemberActivation] where TransferTO='" + txtUserID.Text.Trim() + "' ", ref message);
                            if (Convert.ToDecimal(dt2.Rows[0]["PackageAmount"]) < Convert.ToDecimal(txtPinNo.Text))  //|| (dt2.Rows[0]["PackageAmount"] == null && dt2.Rows[0]["PackageID"] == null)
                            {
                                con = new SqlConnection(connstring);
                                con.Open();
                                cmd = new SqlCommand("PinGenerateNew_ALL", con);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
                                cmd.Parameters.AddWithValue("@TransferTo", txtUserID.Text.Trim());
                                cmd.Parameters.AddWithValue("@TransferBy", Session["UserID"].ToString());
                                cmd.Parameters.AddWithValue("@PackageAmount", Convert.ToDecimal(txtPinNo.Text));
                                cmd.Parameters.AddWithValue("@PackageName", ddlPackage.SelectedItem.Text);
                                cmd.Parameters.AddWithValue("@PackageID", Convert.ToInt32(ddlPackage.SelectedValue));
                                cmd.Parameters.AddWithValue("@Mode", "UPD_STATUS12");
                                int flag = cmd.ExecuteNonQuery();
                                if (flag > 0)
                                {
                                    DataTable dt3 = dal.Gettable("Select Max(Id) Id from [MemberActivation] where TransferBy='" + Session["UserID"].ToString() + "'", ref message);
                                    if (dt3.Rows.Count > 0)
                                    {
                                        //int ID = Convert.ToInt32(dt3.Rows[0]["Id"]);
                                        //LedgerDebit(ID);
                                        //SponsorIncome();
                                        decimal plutocoin = 0;
                                        DAL dal = new DAL();
                                        DataTable dtPluto = dal.Gettable("Select PlutoCoin,Dollar from Pluto_Master", ref message);
                                        if (dtPluto.Rows.Count > 0)
                                        {
                                            decimal plutodollar = Convert.ToDecimal(dtPluto.Rows[0]["Dollar"]);
                                            plutocoin = Convert.ToDecimal(txtPinNo.Text) / plutodollar;
                                            int ID = Convert.ToInt32(dt3.Rows[0]["Id"]);
                                            LedgerDebit(ID);
                                            LedgerCredit_Plutocoin(plutocoin);
                                            SponsorIncome();
                                        }
                                    }
                                    Response.Redirect("Success.aspx?Link=auth-activateepin.aspx");
                                    con.Close();
                                }
                                else
                                {
                                    clear();
                                    ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                                }

                            }
                            else
                            {
                                clear();
                                ShowPopupMessage("Select Higher Package", PopupMessageType.Warning);
                            }

                        }
                    }
                    else
                    {
                        clear();
                        ShowPopupMessage("Insufficient  Wallet Amount", PopupMessageType.Warning);
                    }
                    #region PinGenerate
                    //DataTable dt = dal.Gettable("SELECT UserID,Status FROM PinGenerateNew WHERE UserID='" + txtUserID.Text.Trim() + "' AND Status='Used'", ref message);
                    //if (dt.Rows.Count > 0)
                    //{
                    //    clear();
                    //    ShowPopupMessage("User already Activated.", PopupMessageType.Warning);
                    //}
                    //else
                    //{
                    //    con = new SqlConnection(connstring);
                    //    con.Open();
                    //    cmd = new SqlCommand("PinGenerateNew_ALL", con);
                    //    cmd.CommandType = CommandType.StoredProcedure;
                    //    cmd.Parameters.AddWithValue("@UserID", txtUserID.Text.Trim());
                    //    cmd.Parameters.AddWithValue("@PinNo", txtPinNo.Text);
                    //    cmd.Parameters.AddWithValue("@PackageName", lblPackageName.Text);
                    //    cmd.Parameters.AddWithValue("@Mode", "UPD_STATUS");
                    //    int flag = cmd.ExecuteNonQuery();
                    //    if (flag > 0)
                    //    {
                    //        GetData();
                    //        CheckPackageValidity();//na
                    //        LedgerCredit();//na
                    //        LedgerDebit();
                    //        UpdatePackage_My();
                    //        //UpdatePackage();//Today
                    //        GetData1();
                    //        SendMail(Email, Name, pass);
                    //        SendMsg();
                    //        txtPinNo.Text = string.Empty;
                    //        txtUserID.Text = string.Empty;
                    //        _Valid.Visible = false;
                    //        Right.Visible = false;
                    //        Wrong.Visible = false;
                    //        btnupdate.Visible = false;
                    //        lblname.Text = string.Empty;
                    //        lblPackageName.Text = string.Empty;
                    //        // ShowPopupMessage("UserID has been Activated.", PopupMessageType.Success);
                    //        Response.Redirect("Success.aspx?Link=auth-activateepin.aspx");
                    //        con.Close();
                    //    }
                    //    else
                    //    {
                    //        clear();
                    //        ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                    //    }
                    //}
                    #endregion
                }
                else
                {
                    Response.Redirect("Logout.aspx");
                }
            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
                clear();
            }
        }
        else
        {
            clear();
            ShowPopupMessage("Enter All Data.", PopupMessageType.Error);
        }
    }
    public void DirectIncome()
    {
        //     try
        //     {
        //         string UserID = txtUserID.Text;
        //         //string UserID = "RAJA001";
        //         string SpID = null;
        //         string SpMobile = null;
        //         DataTable dt = dal.Gettable("select sponsorid from MLM_Registration where userid='" + UserID + "'", ref message);

        //         if (dt.Rows.Count > 0)
        //         {
        //             SpID = dt.Rows[0]["sponsorid"].ToString();
        //             DataTable dtMob = dal.Gettable("select Mobile from MLM_Registration where userid='" + SpID + "'", ref message);
        //             if (dt.Rows.Count > 0)
        //             {
        //                 SpMobile = dtMob.Rows[0]["Mobile"].ToString();
        //             }

        //         }
        //     string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        //     SqlConnection con = new SqlConnection(connstring);
        //     con.Open();
        //     SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        //     cmd.CommandType = CommandType.StoredProcedure;
        //     cmd.Parameters.AddWithValue("@UserID", SpID);
        //     cmd.Parameters.AddWithValue("@TransactionType", "CR");
        //     cmd.Parameters.AddWithValue("@CR", 600);
        //     cmd.Parameters.AddWithValue("@DR", 0);
        //     cmd.Parameters.AddWithValue("@Descriptions", "Direct Income");
        ////     cmd.Parameters.AddWithValue("@TransferBy",SpID);
        //     cmd.Parameters.AddWithValue("@Mode", "IN1");
        //     int flag = cmd.ExecuteNonQuery();
        //     //   con = new SqlConnection(connstring);
        //     //  string str = "Insert into Ledger_Wallet (UserID,TransactionType,CR,Descriptions,TransferBy,) values ('"+UserID+"','CR','"+600+"','Ashish',"+SpID+")";
        //     //   string str = "Insert into Ledger_Wallet (UserID,SponsorID,CR,TransactionType,Descriptions) values ('" + UserID + "','" + SpID + "','" + 600 + "','CR','Direct Income')";
        //  //   cmd = new SqlCommand(str, con);
        //    //     con.Open();
        //    //     cmd.ExecuteNonQuery();
        //    //     Donation4000(SpID);
        //         con.Close();
        //     }
        //     catch (Exception ex)
        //     {
        //     }
    }
    private void LedgerCredit()
    {
        DataTable dt = dal.Gettable("SELECT Amount, PackageName FROM PinGenerateNew as pin INNER JOIN PackageInfo as p ON p.ID = pin.PackageID WHERE pin.PinNo = '" + txtPinNo.Text + "'", ref message);
        decimal PackageAmount = Convert.ToDecimal(dt.Rows[0]["Amount"].ToString());
        lblPackageName.Text = dt.Rows[0]["PackageName"].ToString();

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", PackageAmount);
        cmd.Parameters.AddWithValue("@DR", 0);
        cmd.Parameters.AddWithValue("@Descriptions", "Current Package Amount!");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }
    private void LedgerCredit_Plutocoin(decimal plutocoin)
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.Parameters.Clear();
        con.Open();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", plutocoin);
        cmd.Parameters.AddWithValue("@DR", 0);
        cmd.Parameters.AddWithValue("@Descriptions", "UPGRADE PLUTO");
        cmd.Parameters.AddWithValue("@TransferBy", Session["UserID"].ToString());
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }
    private void LedgerDebit(int ID)
    {
        DataTable dt = dal.Gettable("select TOP(1)  Id,PackageName,PackageAmount from [dbo].[MemberActivation] where Id=" + ID + " Order by ActivationDate desc", ref message);
        decimal PackageAmount = Convert.ToDecimal(dt.Rows[0]["PackageAmount"].ToString());
        lblPackageName.Text = dt.Rows[0]["PackageName"].ToString();

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
        cmd.Parameters.AddWithValue("@TransactionType", "DR");
        cmd.Parameters.AddWithValue("@CR", 0);
        cmd.Parameters.AddWithValue("@DR", PackageAmount);
        cmd.Parameters.AddWithValue("@Descriptions", "Current Package Amount!");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();

        if (flag > 0)
        {
            string spid = "";
            DataTable dtsp = dal.Gettable("select SponsorID from MLM_Registration Where UserID='" + txtUserID.Text + "'", ref message);
            if (dtsp.Rows.Count > 0)
            {
                spid = dtsp.Rows[0]["SponsorID"].ToString();
                // CreditSponsorIncome(spid, PackageAmount);
            }

        }
    }
    //protected void txtPinNo_TextChanged(object sender, EventArgs e)
    //{
    //    DAL dal = new DAL();
    //    DataTable dt = dal.Gettable("select pi.PackageName,pi.Amount from PinGenerateNew pg inner join PackageInfo pi on pg.PackageID=pi.ID where pg.PinNo='" + txtPinNo.Text + "' and Status='Unused'", ref message);
    //    if (dt.Rows.Count > 0)
    //    {
    //        // lblPackageAmount.Text = dt.Rows[0]["Amount"].ToString();
    //        //lblPackageName.Text = dt.Rows[0]["PackageName"].ToString();
    //        Wrong.Visible = false;
    //        Right.Visible = true;
    //        btnProceed.Enabled = true;
    //    }
    //    else
    //    {
    //        txtPinNo.Text = "";
    //        btnProceed.Enabled = false;
    //        Wrong.Visible = true;
    //        Right.Visible = false;
    //        ShowPopupMessage("Pin Already Used", PopupMessageType.Warning);
    //        clear();
    //        // lblPackageAmount.Text = "0";
    //        // lblPackageName.Text = string.Empty;
    //    }
    //    //DataTable dt1 = dal.Gettable("select PackageID,PackageName, Amount from PackageInfo inner join PinGenerateNew on PackageInfo.ID = PinGenerateNew.PackageID where PinNo = '" + txtPinNo.Text+"'", ref message);
    //    //if (dt1.Rows.Count > 0)
    //    //{
    //    //    lblPackageName.Text = dt1.Rows[0]["PackageName"].ToString();
    //    //    lblPackageAmount.Text = dt1.Rows[0]["Amount"].ToString();
    //    //    lblPackage_ID.Text = dt1.Rows[0]["PackageID"].ToString();
    //    //}         
    //}
    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-activateepin.aspx");
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/Red_Cross_Tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/Company/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here
    public void CreditSponsorIncome(string sponsor, decimal amount)
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", sponsor.ToUpper());
            cmd.Parameters.AddWithValue("@TransactionType", "CR");
            cmd.Parameters.AddWithValue("@CR", amount * 5 / 100);
            cmd.Parameters.AddWithValue("@DR", "0");
            cmd.Parameters.AddWithValue("@Descriptions", "Direct Income !");
            cmd.Parameters.AddWithValue("@Mode", "IN");
            int flag = cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        //TopUpPin2999();
    }

    public void UpdatePackage_My()
    {
        try
        {
            DataTable dt = dal.Gettable("UPDATE MLM_Registration SET Package = '" + ddlPackage.SelectedItem.Text + "',JoinType='Paid',PackageDate=CAST(GETDATE() as date),recomitstatus='Yes' WHERE UserID = '" + txtUserID.Text + "'", ref message);
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    //public void UpdatePackage()  //   Today
    //{
    //    try
    //    {
    //        DataTable dt = dal.Gettable("UPDATE MLM_Registration SET Package = '" + lblPackageName.Text + "' WHERE UserID = '" + txtUserID.Text + "'", ref message);
    //    }
    //    catch (Exception ex)
    //    {
    //        ShowPopupMessage(ex.Message, PopupMessageType.Error);
    //    }
    //}

    void clear()
    {
        ddlPackage.SelectedIndex = 0;
        txtPinNo.Text = string.Empty;
        txtUserID.Text = string.Empty;
        _Valid.Visible = false;
        Right.Visible = false;
        Wrong.Visible = false;
        btnupdate.Visible = false;
        lblname.Text = string.Empty;
        lblPackageName.Text = string.Empty;

    }

    string company = string.Empty;
    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                company = dt.Rows[0]["CompanyName"].ToString();
            }
            else
            {
            }
        }
        catch (Exception ex)
        {

        }
    }

    string Mobile = string.Empty;
    string pass = string.Empty;
    string UserID = string.Empty;
    string Name = string.Empty;
    string Email = string.Empty;
    void GetData1()
    {
        DAL dal = new DAL();
        string message1 = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from MLM_Registration where UserID='" + txtUserID.Text + "'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message1);
        if (dt.Rows.Count > 0)
        {
            Mobile = dt.Rows[0]["Mobile"].ToString();
            pass = dt.Rows[0]["Password"].ToString();
            UserID = dt.Rows[0]["UserID"].ToString();
            Name = dt.Rows[0]["Name"].ToString();
            Email = dt.Rows[0]["Email"].ToString();
        }
    }

    public void SendMail(string mailID, string Username1, string userPassword)
    {
        DAL dal = new DAL();
        string email = "";
        string password = "";
        string smtp = "";
        int port = 0;
        Boolean ssl = false;
        string logolink = "";
        string loginlink = "";
        Showdatalogo();
        string message = string.Empty;
        DataTable dt2 = dal.Gettable("Select RegistrationSMS,RegistrationEmail,Withdrawal_SystemEmail,Withdrawal_SystemSMS,E_PinSMS,E_PinEmail from SMS_Email_Notification", ref message);
        smsstatus = dt2.Rows[0]["E_PinSMS"].ToString();
        emailstatus = dt2.Rows[0]["E_PinEmail"].ToString();

        string message1 = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select EmailID,Password,SMTP,PortNo,EnableSSl,Logolink,Loginlink from EmailConfig where Status='" + emailstatus + "'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message1);
        if (dt.Rows.Count > 0)
        {
            email = dt.Rows[0]["EmailID"].ToString();
            password = dt.Rows[0]["Password"].ToString();
            smtp = dt.Rows[0]["SMTP"].ToString();
            port = Convert.ToInt32(dt.Rows[0]["PortNo"].ToString());
            ssl = Convert.ToBoolean(dt.Rows[0]["EnableSSl"].ToString());
            logolink = dt.Rows[0]["Logolink"].ToString();
            loginlink = dt.Rows[0]["Loginlink"].ToString();

            //gather email from form textbox
            string remail = mailID;

            //MailAddress from = new MailAddress("info@paxpluewealth.com");
            MailAddress from = new MailAddress(email);

            MailAddress to = new MailAddress(remail);
            MailMessage message2 = new MailMessage(from, to);

            message2.Subject = company;

            //string note = "<div>Hello! <b>'" + txtname.Text + "'</b> </div>";
            //note += "<div><br><p>Your Registerd Username IS : <b>'" + Username1 + "'</b> AND Password IS : <b>'" + userPassword + "'</b>. Keep it secured.<br>Thank You.</p></div>";
            //note += "<div><br>Regards<br><a href='http://www.paxpluewealth.com/Member/login.aspx'>http://www.paxpluewealth.com</a></div>";

            //string note = MailBody(Username1, userPassword, TransactionPassword);

            string note = "<!DOCTYPE html>";
            note += "<html><body>";
            note += "<h1><img src='" + logolink + "' height=100px width=100px></h1>";
            note += "<p>Hello <b>'" + Name + "'</b>,</p>";
            note += "<p>Welcome to <b>" + company + "</b>, You Are Activated successfully. We provide you your login Credentials. Please Keep it secure.</p>";
            note += "<p>Following are the log-in Credential.</p>";
            note += "<p><blink><a href='" + loginlink + "' target='_blank'>Click Here</a></blink></p>";
            note += "<p>Username : <b>'" + Username1 + "'</b></p>";
            note += "<p>Password : <b>'" + userPassword + "'</b></p>";
            note += "<br><br><br>";
            note += "<p>Regards</p>";
            note += "<p><a href='" + loginlink + "' target='_blank'>" + company + "</a><p>";
            note += "</body></html>";

            message2.Body = note;
            message2.BodyEncoding = System.Text.Encoding.UTF8;
            message2.IsBodyHtml = true;

            //SmtpClient client = new SmtpClient("smtp.paxpluewealth.com", 587);
            SmtpClient client = new SmtpClient(smtp, port);
            client.UseDefaultCredentials = false;
            client.EnableSsl = ssl;
            //client.Credentials = new NetworkCredential("info@paxpluewealth.com", "aXGU(nT0");
            client.Credentials = new NetworkCredential(email, password);

            try
            {
                client.Send(message2);
            }
            catch (Exception ex)
            {
                //error message?
            }
            finally
            {

            }
        }
    }

    protected void SMSdebit()
    {
        int sms = 0;
        int smsAvailable = 0;
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());
            smsAvailable = sms - 2;

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update SmsmasterNew set CreditSMS='{0}'", smsAvailable);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {

                }
                else
                {
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {

            }

        }


    }
    protected void SMSHistory(string userid, string name, string mobile, string msg, string sts)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sba = new StringBuilder();
        sba.AppendLine("insert into SMSHistory(UserID,Name,Mobileno,Message,Status)");
        sba.AppendFormat("values('{0}','{1}','{2}','{3}','{4}')", userid, name, mobile, msg, sts);
        int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
        if (rowaffected1 > 0)
        {

        }

    }
    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
    }

    string smsstatus = string.Empty;
    string emailstatus = string.Empty;
    public void SendMsg()
    {
        DAL dal = new DAL();

        string url = "";
        string username = "";
        string key = "";
        string request = "";
        string sender = "";
        string route = "";
        int sms = 0;
        string status = "";

        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='" + smsstatus + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            url = dt.Rows[0]["APIurl"].ToString();
            username = dt.Rows[0]["Username"].ToString();
            key = dt.Rows[0]["APIkey"].ToString();
            request = dt.Rows[0]["APIrequest"].ToString();
            sender = dt.Rows[0]["Sender"].ToString();
            route = dt.Rows[0]["Route"].ToString();
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());

            if (sms != 0)
            {

                string text = "Dear Customer You Are Successfully Activated.";
                try
                {
                    string jsonValue = "";
                    string sURL;
                    StreamReader objReader;
                    // sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + username + "&password=" + password + "&sender=" + senderId + "&to=" + txtmobileNo.Text + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + routeId + "";
                    // sURL = "http://sms.probuztech.com/sms-panel/api/http/index.php?username=WYSE&apikey=FC144-3DD84&apirequest=Text&sender=PROBUZ&mobile=8055002299&message=TEST&route=TRANS&format=JSON";
                    sURL = "" + url + ""; //"?username=" + username + "&apikey=" + key + "&apirequest=" + request + "&sender=" + sender + "&mobile=" + txtmobileNo.Text + "&message=" + text + "&route=" + route + "&format=JSON";
                    WebRequest wrGETURL;
                    wrGETURL = WebRequest.Create(sURL);
                    try
                    {
                        Stream objStream;
                        objStream = wrGETURL.GetResponse().GetResponseStream();
                        objReader = new StreamReader(objStream);
                        jsonValue = objReader.ReadToEnd();
                        var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                        string status1 = myDetails.status;
                        if (status1 == "error")
                        {
                            SMSHistory(txtUserID.Text, Name, Mobile, text, "Not Send");
                        }
                        else
                        {
                            SMSdebit();
                            SMSHistory(txtUserID.Text, Name, Mobile, text, "Send");
                        }

                        objReader.Close();
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
    }

    private void BindPackages()
    {
        con = new SqlConnection(connstring);
        cmd = new SqlCommand("Select PackageName,Amount,ID from PackageInfo", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            ddlPackage.DataSource = dt;
            ddlPackage.DataTextField = "PackageName";
            ddlPackage.DataValueField = "ID";
            ddlPackage.DataBind();
            ddlPackage.Items.Insert(0, new ListItem("Select Package"));
        }
        else
        {

        }
    }
    string Package_Name = null;
    protected void ddlPackage_TextChanged(object sender, EventArgs e)
    {
        if (ddlPackage.SelectedIndex > 0)
        {
            con = new SqlConnection(connstring);
            cmd = new SqlCommand("Select PackageName,Amount from PackageInfo where ID=" + ddlPackage.SelectedValue, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtPinNo.Text = dt.Rows[0]["Amount"].ToString();
                Package_Name = dt.Rows[0]["PackageName"].ToString();
                txtUserID.Text = string.Empty;
                lblname.Text = string.Empty;
                lblpackageName1.Text = string.Empty;
            }
            else
            {

            }
        }

    }
}
