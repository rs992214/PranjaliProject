﻿using System;
using System.Collections.Generic;
using System.Data;
using DataAccessLayer;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class customer_auth_BTC_Withraw : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    SqlConnection con;
    SqlCommand cmd;
    string constr = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(constr);
        cmd = new SqlCommand();
        cmd.Connection = con;
        // cmd.Connection = ;
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShowBTTAddress();
                Wallet();
                Pluto_Wallet();
                PopupBTC();
                ROI_Wallet();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    private void PopupBTC()
    {
        if (txtAddress.Text!=string.Empty)
        {

        }
        else
        {
                Response.Write("<script>alert('BTC address required.Please fill Personal Details.')</script>");
        }
    }

    public void Wallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('MATCHING INCOME','2:1 OR 1:2','DIRECT INCOME','ROI INCOME','Withdrawal Amount','Pin Purchased.','Withdrawal Request','SPONSER INCOME')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblAvailableBalance.Text = dt.Rows[0]["WalletAmount"].ToString();
                //lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblAvailableBalance.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }


    public void Pluto_Wallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('Withdrawal Request Pluto','UPGRADE PLUTO')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblAvailableBalancePluto.Text = dt.Rows[0]["WalletAmount"].ToString();
                //lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblAvailableBalancePluto.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }


    public void ROI_Wallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('Withdrawal Request ROI','ROI INCOME')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblAvailableBalanceROI.Text = dt.Rows[0]["WalletAmount"].ToString();
                //lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblAvailableBalanceROI.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }



    private void ShowBTTAddress()
    {
        string message = string.Empty;
        DataTable dt = dal.Gettable("Select BTC_Address from MLM_UserDetail where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows[0]["BTC_Address"] != DBNull.Value)
        {
            txtAddress.Text = dt.Rows[0]["BTC_Address"].ToString();
            txtAddress.ReadOnly = true;
        }
        else
        {

        }
    }
    decimal netamnt=0;
    decimal btc=0;
    decimal pluto=0;
    string currency;
    decimal admincharge;
    decimal tds;
    decimal tempadmincharge;
    decimal temptds;
    decimal final_btc;
    decimal final_roi=0;
    decimal final_pluto=0;

    protected void btnWithdrawl_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtAddress.Text != string.Empty)
            {
                if (txtAddress.Text != string.Empty && txtAmnt.Text != string.Empty && ddlCurrency.SelectedIndex > 0)
                {
                    if (Convert.ToDecimal(lblAvailableBalance.Text) >= Convert.ToDecimal(txtAmnt.Text) || Convert.ToDecimal(lblAvailableBalancePluto.Text) >= Convert.ToDecimal(txtAmnt.Text))
                    {
                        DAL dal = new DAL();
                        DataTable dt = dal.Gettable("select UserID,PayoutAmount,NetAmount,Status from  MemberPayment where UserID='" + Session["UserID"].ToString() + "' and Status='REQUEST' ", ref message);
                        if (dt.Rows.Count > 0)
                        {
                            Response.Write("<script>alert('Your Payment Status Already Pending')</script>");
                        }
                        else
                        {
                            DAL dal1 = new DAL();
                            DataTable dt1 = dal.Gettable(" select AdminCharge,TDS from PlanSetting", ref message);
                            if (dt1.Rows.Count > 0)
                            {

                                if (ddlCurrency.SelectedItem.Text == "Dollar")
                                {
                                    if (dt1.Rows[0]["AdminCharge"] != DBNull.Value && dt1.Rows[0]["TDS"] != DBNull.Value)
                                    {
                                        DAL dal_ = new DAL();
                                        DataTable dtbtc = dal_.Gettable("select BtcCoin,Dollar from BTC_Master", ref message);
                                        if (dtbtc.Rows.Count > 0)
                                        {
                                            btc = Convert.ToDecimal(dtbtc.Rows[0]["Dollar"]);
                                            tempadmincharge = Convert.ToDecimal(dt1.Rows[0]["AdminCharge"]);
                                            admincharge = (Convert.ToDecimal(txtAmnt.Text) * tempadmincharge) / 100;
                                            temptds = Convert.ToDecimal(dt1.Rows[0]["TDS"]);
                                            tds = (Convert.ToDecimal(txtAmnt.Text) * temptds) / 100;
                                            netamnt = Convert.ToDecimal(txtAmnt.Text) - (admincharge + tds);
                                            final_btc = netamnt / btc;
                                        }
                                        else
                                        {
                                            final_btc = 0;
                                            admincharge = 0;
                                            tds = 0;
                                            netamnt = Convert.ToDecimal(txtAmnt.Text);
                                        }

                                        cmd.CommandText = "WithdrawalRequest_ALL";
                                        con.Open();
                                        cmd.CommandType = CommandType.StoredProcedure;
                                        cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
                                        cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtAmnt.Text));
                                        cmd.Parameters.AddWithValue("@Admin", admincharge);
                                        cmd.Parameters.AddWithValue("@TDS", tds);
                                        cmd.Parameters.AddWithValue("@NetAmount", netamnt);
                                        cmd.Parameters.AddWithValue("@Currency", ddlCurrency.SelectedItem.Text);
                                        cmd.Parameters.AddWithValue("@BTC", final_btc);
                                        //   cmd.Parameters.AddWithValue("@PLUTO", 0);
                                        cmd.Parameters.AddWithValue("@Mode", "IN1");
                                        if (cmd.ExecuteNonQuery() > 0)
                                        {
                                            Response.Redirect("Success.aspx?Link=auth-BTC_Withraw.aspx");
                                            con.Close();
                                        }

                                    }
                                }
                                else if (ddlCurrency.SelectedItem.Text == "Pluto")
                                {
                                    if (dt1.Rows[0]["AdminCharge"] != DBNull.Value && dt1.Rows[0]["TDS"] != DBNull.Value)
                                    {
                                        DAL dal_ = new DAL();
                                        DataTable dtpluto = dal_.Gettable("select PlutoCoin,Dollar from Pluto_Master", ref message);
                                        if (dtpluto.Rows.Count > 0)
                                        {
                                            DAL dalbtc = new DAL();
                                            DataTable dtbtc = dalbtc.Gettable("select BtcCoin,Dollar from BTC_Master", ref message);

                                            if (dtbtc.Rows.Count > 0)
                                            {
                                                decimal temp_btcdollar = Convert.ToDecimal(dtbtc.Rows[0]["Dollar"]);
                                                pluto = Convert.ToDecimal(txtAmnt.Text) * Convert.ToDecimal(dtpluto.Rows[0]["Dollar"]);
                                                // decimal temp_dollar_btc_coin = pluto / temp_btcdollar;  //btc coin
                                                //  decimal temp_dollar_btc = temp_dollar_btc_coin * temp_btcdollar; //btc dollar

                                                tempadmincharge = Convert.ToDecimal(dt1.Rows[0]["AdminCharge"]);
                                                admincharge = (Convert.ToDecimal(txtAmnt.Text) * tempadmincharge) / 100;
                                                temptds = Convert.ToDecimal(dt1.Rows[0]["TDS"]);
                                                tds = (Convert.ToDecimal(txtAmnt.Text) * temptds) / 100;
                                                //  netamnt = Convert.ToDecimal(txtAmnt.Text) - (admincharge + tds);
                                                netamnt = pluto - (admincharge + tds);
                                                final_pluto = netamnt / temp_btcdollar;  //   btc coin     
                                            }

                                        }
                                        else
                                        {
                                            final_pluto = 0;
                                            admincharge = 0;
                                            tds = 0;
                                            netamnt = Convert.ToDecimal(txtAmnt.Text);
                                        }

                                        cmd.CommandText = "WithdrawalRequest_ALL";
                                        con.Open();
                                        cmd.CommandType = CommandType.StoredProcedure;
                                        cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
                                        cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtAmnt.Text));
                                        cmd.Parameters.AddWithValue("@Admin", admincharge);
                                        cmd.Parameters.AddWithValue("@TDS", tds);
                                        cmd.Parameters.AddWithValue("@NetAmount", netamnt);
                                        cmd.Parameters.AddWithValue("@Currency", ddlCurrency.SelectedItem.Text);
                                        cmd.Parameters.AddWithValue("@BTC", final_pluto);
                                        //   cmd.Parameters.AddWithValue("@PLUTO", final_pluto);
                                        cmd.Parameters.AddWithValue("@Mode", "IN1");
                                        if (cmd.ExecuteNonQuery() > 0)
                                        {
                                            Response.Redirect("Success.aspx?Link=auth-BTC_Withraw.aspx");
                                            con.Close();
                                        }
                                    }
                                }
                                else if(ddlCurrency.SelectedItem.Text=="ROI")
                                {
                                    if (ddlCurrency.SelectedItem.Text == "ROI")
                                    {
                                        if (dt1.Rows[0]["AdminCharge"] != DBNull.Value && dt1.Rows[0]["TDS"] != DBNull.Value)
                                        {
                                            DAL dal_ = new DAL();
                                            DataTable dtbtc = dal_.Gettable("select BtcCoin,Dollar from BTC_Master", ref message);
                                            if (dtbtc.Rows.Count > 0)
                                            {
                                                btc = Convert.ToDecimal(dtbtc.Rows[0]["Dollar"]);
                                                tempadmincharge = Convert.ToDecimal(dt1.Rows[0]["AdminCharge"]);
                                                admincharge = (Convert.ToDecimal(txtAmnt.Text) * tempadmincharge) / 100;
                                                temptds = Convert.ToDecimal(dt1.Rows[0]["TDS"]);
                                                tds = (Convert.ToDecimal(txtAmnt.Text) * temptds) / 100;
                                                netamnt = Convert.ToDecimal(txtAmnt.Text) - (admincharge + tds);
                                                final_roi = netamnt / btc;
                                            }
                                            else
                                            {
                                                final_roi = 0;
                                                admincharge = 0;
                                                tds = 0;
                                                netamnt = Convert.ToDecimal(txtAmnt.Text);
                                            }

                                            cmd.CommandText = "WithdrawalRequest_ALL";
                                            con.Open();
                                            cmd.CommandType = CommandType.StoredProcedure;
                                            cmd.Parameters.AddWithValue("@UserID", Session["UserID"].ToString());
                                            cmd.Parameters.AddWithValue("@Amount", Convert.ToDecimal(txtAmnt.Text));
                                            cmd.Parameters.AddWithValue("@Admin", admincharge);
                                            cmd.Parameters.AddWithValue("@TDS", tds);
                                            cmd.Parameters.AddWithValue("@NetAmount", netamnt);
                                            cmd.Parameters.AddWithValue("@Currency", ddlCurrency.SelectedItem.Text);
                                            cmd.Parameters.AddWithValue("@BTC", final_roi);
                                            //   cmd.Parameters.AddWithValue("@PLUTO", 0);
                                            cmd.Parameters.AddWithValue("@Mode", "IN1");
                                            if (cmd.ExecuteNonQuery() > 0)
                                            {
                                                Response.Redirect("Success.aspx?Link=auth-BTC_Withraw.aspx");
                                                con.Close();
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                    else
                    {
                        txtAmnt.Text = string.Empty;
                        Response.Write("<script>alert('Insufficent Balance')</script>");
                    }
                }
            }
            else
            {
                Response.Write("<script>alert('BTC address required.Please fill Personal Details.')</script>");
            }
        }
        catch (Exception ex)
        {

        }

    }

    protected void txtAmnt_TextChanged(object sender, EventArgs e)
    {
        if (txtAmnt.Text != string.Empty)
        {
            if (ddlCurrency.SelectedIndex == 1)
            {
                if (Convert.ToDecimal(lblAvailableBalance.Text) >= Convert.ToDecimal(txtAmnt.Text))
                {
                    decimal amount = Convert.ToDecimal(txtAmnt.Text);
                    if (amount > 0)
                    {
                        lblamnt.Text = string.Empty;
                    }
                    else
                    {
                        txtAmnt.Text = string.Empty;
                        lblamnt.Text = "Amount should be greater than Zero";
                    }
                }
                else
                {
                    txtAmnt.Text = string.Empty;
                    Response.Write("<script>alert('Insufficent Balance')</script>");
                }
            }
            if (ddlCurrency.SelectedIndex == 2)
            {
                if (Convert.ToDecimal(lblAvailableBalancePluto.Text) >= Convert.ToDecimal(txtAmnt.Text))
                {
                    decimal amount = Convert.ToDecimal(txtAmnt.Text);
                    if (amount > 0)
                    {
                        lblamnt.Text = string.Empty;
                    }
                    else
                    {
                        txtAmnt.Text = string.Empty;
                        lblamnt.Text = "Amount should be greater than Zero";
                    }
                }
                else
                {
                    txtAmnt.Text = string.Empty;
                    Response.Write("<script>alert('Insufficent Balance')</script>");
                }
            }
        }
        else
        {

        }
    }

    protected void ddlCurrency_TextChanged(object sender, EventArgs e)
    {
        if (ddlCurrency.SelectedItem.Text=="Pluto" || ddlCurrency.SelectedItem.Text == "ROI"  )
        {
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("Select MIN(PackageID) as PackageID,ActivationDate from MemberActivation  Where TransferTO='" + Session["UserID"].ToString() + "' group by ActivationDate", ref message);
            if (dt.Rows.Count > 0)
            {
                DateTime activationdate = Convert.ToDateTime(dt.Rows[0]["ActivationDate"]);
                DateTime expiryDate = activationdate.AddDays(30);
                if (DateTime.Now > expiryDate)
                {

                }
                else
                {
                    btnWithdrawl.Enabled = false;
                    txtAmnt.Text = string.Empty;
                    string msg = "You are not eligible. Please wait 30 days from Activation Date !";
                    ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + msg + "');", true);
                }
            }
           
        }
        else
        {
            btnWithdrawl.Enabled = true;
        }



    }
}