﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.IO;
using System.Net;
//using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;

public partial class customer_Dashboard : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    ArrayList UserIDRightList = new ArrayList();
    ArrayList UserIDRightList1 = new ArrayList();
    ArrayList UserIDRightList2 = new ArrayList();
    string message = string.Empty;
    public int countA = 0;
    public int countB = 0;
    string websitename = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // if (Request.QueryString["UserID"] != null && Request.QueryString["UserID"] != string.Empty)

            if (Session["UserID"] != null)
            {
                string msg = "";
                DAL dal = new DAL();
                DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
                if (dt.Rows.Count > 0)
                {
                    websitename = dt.Rows[0]["Website"].ToString();
                }
            

                string text = "" + websitename + "/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString();

                //   lnkReferalLink.Text = text;
                //   lnkReferalLink.NavigateUrl = text;
                //   lnksend.Text = text;
                GetLink();
                showname();
                ShowBreakingNews();
                ShowPaidFreeMember();
                //activationtimer();
                UpgradeWallet();
                Showuserlogo();
                GrowthWallet();
                Wallet();
                ROI_Bonus();
                directincome();
                matchingincome();
                latesttransactions();
                ShowleftrightTOTAL();
                date();
                //directincome();
                ShoppingFund();
                showstatus();
                GrowthFund();
                graph();
                Shopachieve();
                Growthachieve();
                RepurchaseIncome();
                GetCurrency();
                lastLogin();
                ProductStatus();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void ROI_Bonus()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions ='ROI INCOME'", ref message);
            if (dt.Rows.Count > 0)
            {
                lblRoibonus.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblRoibonus.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }


    public void ProductStatus()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Package, ProductDeliveryStatus from MLM_Registration where UserID='" + Session["UserID"] + "'", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                lblProductName.Visible = true;
                lblProductName.Text = dt.Rows[0]["Package"].ToString();
                lblStatus.Visible = true;
                lblStatus.Text = dt.Rows[0]["ProductDeliveryStatus"].ToString();
            }
            else
            {
                Label1.Visible = false;
                lblProductName.Visible = false;
                lblStatus.Visible = false;
                Label3.Visible = false;
            }
        }
        catch (Exception ex)
        {
        }

        finally
        {
            con.Close();
        }
    }
    public void Showuserlogo()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select PhotoPath from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                string Logo = dt.Rows[0]["PhotoPath"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    //byte[] bytes = (byte[])dt.Rows[0]["PhotoPath"];
                    //string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    //// imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    //Image1.ImageUrl = "data:image/png;base64," + base64String;
                    Image1.ImageUrl = Logo.ToString();
                }
            }
            else
            {

            }
        }
        catch (Exception ex)
        {

        }
    }
    string symbol = string.Empty;
    void GetCurrency()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from CurrencyList");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
             symbol = dt.Rows[0]["currency"].ToString();

            if(symbol == "Rs")
            {
                lblrupees1.Text = "₹";
                lblRupees2.Text = "₹";
                lblRupees3.Text = "₹";
                lblRupees4.Text = "₹";
                lblRupees5.Text = "₹";
                lblRupees6.Text = "₹";
                lblRupees7.Text = "₹";
                lblRupees8.Text = "₹";

            }
            else
            {
                lblrupees1.Text = symbol;
                lblRupees2.Text = symbol;
                lblRupees3.Text = symbol;
                lblRupees4.Text = symbol;
                lblRupees5.Text = symbol;
                lblRupees6.Text = symbol;
                lblRupees7.Text = symbol;
                lblRupees8.Text = symbol;
            }
            
        }
    }
    public void activationtimer()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {

                string dateInString = dt.Rows[0]["PackageDate"].ToString();

                DateTime startDate = DateTime.Parse(dateInString);
                DateTime expiryDate = startDate.AddDays(0);
                DateTime expiryDate1 = startDate.AddDays(15);
                DateTime upgradetime = startDate.AddDays(5);

                lblTimer.Text = expiryDate.ToString();
              


                //  lblUpgradetime.Text = upgradetime.ToString();


                if (DateTime.Now > expiryDate1)
                {
                    //... trial expired
                 //   lblTimer.Text = "Activation Time Expired";
                    Response.Redirect("auth-recomit.aspx");

                }
                if (DateTime.Now > upgradetime)
                {
                 //   lblUpgradetime.Text = "Booster Time Expired";

                }
            }
            else
            {
             //   lblname.Text = "Demo";
            }
        }
        catch (Exception ex)
        {
          //  ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }
    public void showname()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            //sb.AppendFormat("select Name,status,CAST(JoinDate as date) as JoinDate,CAST(PackageDate as date) as PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            sb.AppendFormat("select Name,status,JoinDate,PackageDate,PlutoAddress from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblcustomername.Text = dt.Rows[0]["Name"].ToString();
                lblplutoaddress.Text = dt.Rows[0]["PlutoAddress"].ToString();
                lblplutoaddress.ForeColor = System.Drawing.Color.Red;
                //lblUserName.Text = dt.Rows[0]["Name"].ToString();
                // lbljoindate.Text = Convert.ToDateTime(dt.Rows[0]["JoinDate"]).ToString("dd-MM-yyyy");
                //    lblactivationdate.Text = Convert.ToDateTime(dt.Rows[0]["PackageDate"]).ToString("dd-MM-yyyy");
                string status = dt.Rows[0]["status"].ToString();
                if (status == "InActive")
                {
                    Response.RedirectPermanent("~/pages/Status.html");
                }
            }
            else
            {
                lblcustomername.Text = "Company Associate";
            }
        }
        catch (Exception ex)
        {
           /// ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowPaidFreeMember()
    {
        try
        {
            DAL dal = new DAL();
            string LeftUser = null;
            string RightUser = null;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();

                if (LeftUser != null)
                {
                    ShowPaidFreeofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowPaidFreeofteamB(RightUser);
                }

                //lbldownlines.Text = (Convert.ToInt32(lblFree_A.Text) + Convert.ToInt32(lblPaid_A.Text) + Convert.ToInt32(lblPaid_B.Text) + Convert.ToInt32(lblFree_B.Text)).ToString();
            }
        }
        catch (Exception ex)
        {
            //ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowPaidFreeofteamA(string Leftuserid)
    {
        try
        {
            string L = null;
            string R = null;
            string UserID = Leftuserid;
            int membercountpaid = 0;
            int membercountfree = 0;
            double TotalBusinessTeamA = 0;
            double CurrentTotalBusinessTeamA = 0;

            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    object dtcountpaid = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtcountpaid != null)
                    {
                        membercountpaid += Convert.ToInt32(dtcountpaid);
                    }
                    object dtcountfree = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtcountfree != null)
                    {
                        membercountfree += Convert.ToInt32(dtcountfree);
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
         lblleft.Text = membercountfree.ToString();
          //  lblMyteamcount.Text = membercountpaid.ToString();

        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowPaidFreeofteamB(string Rightuserid)
    {
        try
        {
            string L = null;
            string R = null;
            string UserID = Rightuserid;
            int membercountpaid = 0;
            int membercountfree = 0;
            double TotalBusinessTeamB = 0;
            double CurrentTotalBusinessTeamB = 0;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    object dtcountpaid = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtcountpaid != null)
                    {
                        membercountpaid += Convert.ToInt32(dtcountpaid);
                    }
                    object dtcountfree = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtcountfree != null)
                    {
                        membercountfree += Convert.ToInt32(dtcountfree);
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }

            } while (UserID != null);
           lblright.Text = membercountfree.ToString();
            //lblMyteamcount.Text = membercountpaid.ToString();
        }
        catch (Exception)
        {
            throw;
        }
    }
    private void showmydownlines()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            string LeftUser = null;
            string RightUser = null;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();

                if (LeftUser != null)
                {
                    ShowMembersofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowMembersofteamB(RightUser);
                }
                //int totalcount = Convert.ToInt32(hdfleft.Value) + Convert.ToInt32(hdfright.Value);
                //   lbldownlines.Text = totalcount.ToString();
            }
        }
        catch (Exception ex)
        {
            //ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowMembersofteamA(string Leftuserid)
    {
        try
        {
            string L = null;
            string R = null;
            string UserID = Leftuserid;
            int membercount = 0;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    object dtcount = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtcount != null)
                    {
                        membercount += Convert.ToInt32(dtcount);
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
            //hdfleft.Value = membercount.ToString();

        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteamB(string Rightuserid)
    {
        try
        {
            string L = null;
            string R = null;
            string UserID = Rightuserid;
            int membercount = 0;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    object dtcount = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtcount != null)
                    {
                        membercount += Convert.ToInt32(dtcount);
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }

            } while (UserID != null);
            //hdfright.Value = membercount.ToString();
        }
        catch (Exception)
        {
            throw;
        }
    }
 
    public void ShowBreakingNews()
    {
        DAL dal = new DAL();
        try
        {
            DataTable dt = dal.Gettable("select * from News where NewsType='Breaking News' order by ID desc", ref message);
            if (dt.Rows.Count > 0)
            {
                string text = string.Empty;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    text += i + 1 + ". " + dt.Rows[i]["News"].ToString();
                    text += "..&nbsp;";
                }
                breakingnews.Text = text;
            }
            else
            {
                breakingnews.Text = "No News Today!";
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "'" + ex.Message + "'", true);
        }
    }
    private void latesttransactions()
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
          
                dt = objDAL.Gettable("Select top 10 ID,UserID,TransactionType,CR,DR,Descriptions,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions Not In ('Current Package Amount!','Pin Purchased.') order by CreationDate desc", ref message);
           
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
           
        }
    }
    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        latesttransactions();
    }

    public void UpgradeWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('UPGRADE WALLET','Current Package Amount!')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblupgradewallet.Text = dt.Rows[0]["WalletAmount"].ToString();
            //    lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblupgradewallet.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void Wallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and  Descriptions in ('MATCHING INCOME','2:1 OR 1:2','DIRECT INCOME','ROI INCOME','Withdrawal Amount','Pin Purchased.')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblMywallet.Text = dt.Rows[0]["WalletAmount"].ToString();
                lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblMywallet.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void GrowthWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions in ('Pair 7','Pair 15','Pair 25','Pair 50','Pair 100','Pair 250','Pair 500','Pair 750','Pair 1000') ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblGrowthwallet.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblGrowthwallet.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void ShoppingFund()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions in ('Shopping Fund','Shopping from Ecommerce via Shopping Fund')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblLevelincome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblLevelincome.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void directincome()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions='DIRECT INCOME' ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblDirectIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblDirectIncome.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void matchingincome()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions IN ('Matching INCOME','2:1 OR 1:2')", ref message);
            if (dt.Rows.Count > 0)
            {
                lblMatchingIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblMatchingIncome.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void ShowleftrightTOTAL()
    {
        string USERID = Session["UserID"].ToString();
        SqlConnection con = new SqlConnection(connstring);
        SqlCommand mcmd1 = new SqlCommand("auth_total_Dashboard", con);
        mcmd1.CommandType = CommandType.StoredProcedure;
        mcmd1.Parameters.AddWithValue("@SessionID", USERID);
        SqlDataAdapter sda = new SqlDataAdapter(mcmd1);
        DataTable dtd = new DataTable();
        sda.Fill(dtd);
        if (dtd.Rows.Count > 0)
        {
            int count =  Convert.ToInt32(dtd.Rows[0]["TOTAL"]);
            lblMyteamcount.Text = count.ToString();
        }
    }

    public void lastLogin()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("select Date from MemberLoginDteail where UserID='" + Session["UserID"].ToString() + "' order by id desc ", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                lblLastLogin.Visible = true;
                lblLastLogin.ForeColor = Color.Red;
                lblLastLogin.Text = dt.Rows[0]["Date"].ToString();
            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void date()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select convert(nvarchar,PackageDate,105) as joindate,JoinType from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                string type = dt.Rows[0]["JoinType"].ToString();
                if (type == "Paid")
                {
                    lblTimer.Text = dt.Rows[0]["joindate"].ToString();
                }
                else
                {
                    div1.Visible = false;
                }
            }
            else
            {
                lblTimer.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void showstatus()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Select JoinType from MLM_Registration where UserID ='" + Session["UserID"].ToString() + "'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            string Status = dt.Rows[0]["JoinType"].ToString();
            if (Status == "Paid")
            {
                lblactive.Text = "Active";
                imgstatus.ImageUrl = "assets/images/G.png";
                imgstatus.ToolTip = "Active ";

            }
            else
            {
                lblactive.Text = "InActive";
                imgstatus.ImageUrl = "assets/images/R.png";
                imgstatus.ToolTip = "InActive";
            }

        }
        else
        {
            lblactive.Text = "INACTIVE";
            imgstatus.ImageUrl = "assets/images/R.png";
            imgstatus.ToolTip = "InActive";
        }
    }

    public void GrowthFund()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions ='Growth Fund'", ref message);
            if (dt.Rows.Count > 0)
            {
                lblgrowthfund.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblgrowthfund.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void graph()
    {
        //string updateProgress = "25";
        //string updateProgress1 = "25";
        //string updateProgress2 = "25";
        //string updateProgress3 = "25";

        string updateProgress = lblMatchingIncome.Text;
        string updateProgress1 = lblDirectIncome.Text;
        string updateProgress2 = lblRoibonus.Text;
        string updateProgress4 = lblgrowthfund.Text;
       string updateProgress3 = lblroi.Text;
        //string updateProgress3 = lblRoibonus.Text;
        ClientScript.RegisterStartupScript(this.GetType(), "updateProgress", "functionName(" + updateProgress + "," + updateProgress1 + "," + updateProgress2 + "," + updateProgress3 + ");ColumnfunctionName1(" + updateProgress + "," + updateProgress1 + "," + updateProgress2 + "," + updateProgress3 + ");", true);
    }

    protected void Shopachieve()
    {
        DAL dal = new DAL();
        DataTable dt = dal.Gettable("select UserID from AutoPool_ShoppingFund where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            lblshopachieve1.Text = "ACHIEVED";
            lblshopachieve.Visible = false;
        }
        else
        {
            lblshopachieve.Text = "NOT ACHIEVE";
            lblshopachieve1.Visible = false;

        }
    }

    protected void Growthachieve()
    {
        DAL dal = new DAL();
        DataTable dt = dal.Gettable("select UserID from AutoPool_GrowthFund where UserID='" + Session["UserID"].ToString() + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            lblgrowthachiev1.Text = "ACHIEVED";
            lblgrowthachiev.Visible = false;
        }
        else
        {
            lblgrowthachiev.Text = "NOT ACHIEVE";
            lblgrowthachiev1.Visible = false;

        }
    }

    public void RepurchaseIncome()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions ='REPURCHASE INCOME'", ref message);
            if (dt.Rows.Count > 0)
            {
                lblrepurchase.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblrepurchase.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }
    string strRes = string.Empty;
    void GetLink()
    {
        getcompanyurl();
        //string str = "https://wa.me/?text=";
        string str1 = Company;
        string str2 = "/pages/registration.aspx?Refferalid=" + Session["UserID"].ToString();
        strRes = String.Concat(str1, str2);
        ViewState["str"] = strRes;
    }
    string Company = string.Empty;
    public void getcompanyurl()
    {
        try
        {
            DAL objDAL = new DAL();
            string message = string.Empty;
            DataTable dt = objDAL.Gettable("Select * From CompanyInfo", ref message);
            if (dt.Rows.Count > 0)
            {
                Company = dt.Rows[0]["Website"].ToString();
            }
            else
            {
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    double CR;
    double DR;
    protected void GV_LedgerList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            // add the UnitPrice and QuantityTotal to the running total variables

           // CR = Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "CR"));
            ((Label)e.Row.FindControl("lblcr")).Text = symbol;

          //  DR = Convert.ToDouble(DataBinder.Eval(e.Row.DataItem, "DR"));
            ((Label)e.Row.FindControl("lbldr")).Text = symbol ;

        }
    }
}