﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Net;

public partial class customer_auth_ledger : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    string message = string.Empty;
    string Password = "";
    string UserID = "";
    string LoginIP = GetLocalIPAddress();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            if (!IsPostBack)
            {
                GetWalletBalance();
                GetData();
                GetCurrency();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    void GetCurrency()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from CurrencyList");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            string symbol = dt.Rows[0]["currency"].ToString();

            if (symbol == "Rs")
            {
                lblrupees1.Text = "₹";

            }
            else
            {
                lblrupees1.Text = symbol;
               
            }

        }
    }
    private void GetWalletBalance()
        {
            try
            {
                string UserID = Session["UserID"].ToString();
                DAL objDAL = new DAL();
                DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + UserID + "' and Descriptions in ('Matching Income','2:1 OR 1:2','DIRECT INCOME','ROI INCOME','Withdrawal Amount','Pin Purchased.','Withdrawal Request','SPONSER INCOME') ", ref message);
                if (dt.Rows.Count > 0)
                {
                    lblWalletBalance.Text = dt.Rows[0]["WalletAmount"].ToString();
                }
                else
                {
                    lblWalletBalance.Text = "0";
                }
            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        private void GetData()
        {
            try
            {
                DataTable dt = new DataTable();
                string UserID = Session["UserID"].ToString();
                DAL objDAL = new DAL();
                if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtTo.Text)))
                {
                    dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "' and CreationDate BETWEEN '" + txtFrom.Text + "' and '" + txtTo.Text + "'  order by CreationDate desc", ref message);
                }
                else
                {
                    dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "'  order by CreationDate desc", ref message);
                }
                if (dt.Rows.Count > 0)
                {
                    GV_LedgerList.DataSource = dt;
                    GV_LedgerList.DataBind();
                }
                else
                {
                    GV_LedgerList.DataSource = dt;
                    GV_LedgerList.DataBind();
                }
            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            GetData();
        }
        protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GV_LedgerList.PageIndex = e.NewPageIndex;
            GetData();
        }




        // Modal PopUp Code Goes here
        private void ShowPopupMessage(string message, PopupMessageType messageType)
        {
            switch (messageType)
            {
                case PopupMessageType.Error:
                    lblMessagePopupHeading.Text = "Error";
                    //Render image in literal control
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("~/Company/images/Red_Cross_Tick.png") + "' alt='' height=20px width=22px />";
                    break;
                case PopupMessageType.Message:
                    lblMessagePopupHeading.Text = "Information";
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                    break;
                case PopupMessageType.Warning:
                    lblMessagePopupHeading.Text = "Warning";
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                    break;
                case PopupMessageType.Success:
                    lblMessagePopupHeading.Text = "Success";
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                    break;
                default:
                    lblMessagePopupHeading.Text = "Information";
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                    break;
            }

            lblMessagePopupText.Text = message;
            mpeMessagePopup.Show();
        }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-ledger.aspx");
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["UserID"] != null)
            {
                string UserID = Session["UserID"].ToString();
                DataTable dt = new DataTable();
                DAL objDAL = new DAL();
                if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtTo.Text)))
                {
                    dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "' and CreationDate BETWEEN '" + txtFrom.Text + "' and '" + txtTo.Text + "'  order by CreationDate desc", ref message);
                }
                else
                {
                    dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "'  order by CreationDate desc", ref message);
                }
                if (dt.Rows.Count > 0)
                {
                    getDataForTrace();
                    tracing();
                    CreateExcelFile(dt);
                }
                else
                {
                    //CreateExcelFile(dy)
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }


        }
        catch (Exception ex)
        {
            getDataForTrace();
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'Excel Not Downloded Showing Error:'" + error + "'')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    public void CreateExcelFile(DataTable Excel)
    {

        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=WithdrawalList.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {
            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {
                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";
            }

            Response.Write("\n");


        }
        Response.End();
    }


    protected void btnPdf_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtTo.Text)))
            {
                dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "' and CreationDate BETWEEN '" + txtFrom.Text + "' and '" + txtTo.Text + "'  order by CreationDate desc", ref message);
            }
            else
            {
                dt = objDAL.Gettable("Select ID,UserID,TransactionType,CR,DR,Descriptions,TransferBy,CONVERT(nvarchar,CreationDate,105)As CreationDate From Ledger_Wallet Where UserID='" + UserID + "'  order by CreationDate desc", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                getDataForTrace();
                tracingPdf();
                CreatePdfFile(dt);
            }

        }
        catch (Exception ex)
        {
            getDataForTrace();
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'PDF Not Downloded Showing Error:'" + error + "'')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }
        }
    }
    void CreatePdfFile(DataTable PDF)
    {
        string filename = "Ledger.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);

        Document doc = new Document(PageSize.A4, 10, 10, 40, 10);

        Paragraph p = new Paragraph("");
        p.Alignment = Element.ALIGN_CENTER;

        try
        {

            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(7);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("Ledger Report", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----      
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("../Company/images/Probuzimg.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------


            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "Ledger/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch (Exception ex)
        {

        }
    }

    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void getDataForTrace()
    {

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("select UserID, Password from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Password = dt.Rows[0]["Password"].ToString();
                UserID = dt.Rows[0]["UserID"].ToString();

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void tracing()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'Excel File downloded Successfully for Ledger..!!')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void tracingPdf()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into MemberLoginDteail(UserID,Password,loginIP,Date,Status) values('" + UserID + "','" + Password + "','" + LoginIP + "',GETDATE(),'PDF File downloded Successfully for Ledger..!!')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }
}