﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_logindetails : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {


        //if (!IsPostBack)
        //{
      //  string userid = Request.QueryString["userid"];

      

        if (!IsPostBack)
        {
            if (Request.QueryString["userid"] != null && Request.QueryString["password"] != string.Empty && Request.QueryString["name"]!=null)
                Label1.Text = Request.QueryString["userid"];
                Label2.Text = Request.QueryString["password"];
                Label3.Text = Request.QueryString["name"];
                Showdatalogo();
        }




        //}
    }

    public void showname()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
           sb.AppendFormat("select UserID,Password from MLM_Registration where UserID='{0}'", userid);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
             //  Label1.Text = dt.Rows[0]["UserID"].ToString();
             //   Label2.Text = dt.Rows[0]["Password"].ToString();
             
            }
            else
            {
               // Label1.Text = "No Associate";
            }
        }
        catch (Exception ex)
        {
            /// ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {

                lblCompanyname.Text = dt.Rows[0]["CompanyName"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    // imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    imgLogo1.ImageUrl = "data:image/png;base64," + base64String;
                }
                showname();
            }
            else
            {
            }
        }
        catch (Exception ex)
        {


        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-login.aspx");
    }
}