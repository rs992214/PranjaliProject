﻿using DataAccessLayer;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_add_contacts : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();
    HiddenField hf_Basic = new HiddenField();
    HiddenField hf_Bank_Account = new HiddenField();

    //string key = "304143904755886";
    //string mode = "0";
    //string service = "7972947432";
    //string Name = "Probuz";
    //string Address = "Nagpur";
    //string Email= "probuzcare@gmail.com";

    public string key = "";
    public string mode = "";
    public string service = "";
    public string Name = "";
    public string Address = "";
    public string Email = "";
    public string AccountNo = "";
    public string IFSCcode = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        GetApiCredential();

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                btnSave.Enabled = false;
                txtuserid_TextChanged(sender, e);
                GetAllContacts();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    protected void txtuserid_TextChanged(object sender, EventArgs e)
    {
        DataTable dtuserid = dal.Gettable("select UserID,Name from MLM_Registration where UserID ='" + Session["UserID"].ToString() + "' and JoinType='Paid'", ref message);
        if (dtuserid.Rows.Count > 0)
        {
            DataTable dtdata = dal.Gettable("select mm.UserID,mm.Name,mm.Mobile,mm.Email,ml.Address from MLM_Registration mm inner join MLM_UserDetail ml on mm.UserID=ml.UserID where mm.UserID='" + Session["UserID"].ToString() + "' and mm.JoinType='Paid'", ref message);
            if (dtdata.Rows.Count > 0)
            {
                txtuserid.Text = Session["UserID"].ToString();
                txtBeneficiaryName.Text = dtdata.Rows[0]["Name"].ToString();
                txtmobile.Text = dtdata.Rows[0]["Mobile"].ToString();
                txtemail.Text = dtdata.Rows[0]["Email"].ToString();
                txtaddress.Text = "Customer";

                lbluserid.Visible = true;
                lbluserid.Text = dtuserid.Rows[0]["Name"].ToString();
                lblInvalidID.Visible = false;
                btnSave.Enabled = true;
            }
            else
            {
                clear();
            }
        }
        else
        {
            clear();
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        //JoloGetAPIKEY();
        Getdata();
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.RawUrl);
    }

    protected void Getdata()
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        var client = new RestClient("https://api.razorpay.com/v1/contacts");
        client.Timeout = -1;
        var request = new RestRequest(Method.POST);
        request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
        //request.AddHeader("Authorization", "Basic cnpwX3Rlc3RfUDQ2S3c1VjBCTmV2aFc6cXZhN3lRZGhJOTNwOVdnd0dKZ2g3UzJk");
        request.AddHeader("Content-Type", "application/json");
        request.AddParameter("application/json", "{\r\n\"name\" : \"" + txtBeneficiaryName.Text + "\",\r\n\"email\" : \"" + txtemail.Text + "\",\r\n\"contact\" : \"" + txtmobile.Text + "\",\r\n\"type\" : \"customer\",\r\n\"reference_id\" : \"" + txtuserid.Text + "\",\r\n\"notes\" : {\r\n    \t\"notes_key_1\":\"Add New Customer\"\r\n    }\r\n\r\n}", ParameterType.RequestBody);

        IRestResponse response = client.Execute(request);
        //Response.Write(response.Content);
        //Response.End();

        string status = response.StatusCode.ToString();

        if (status == "Created" || status == "OK")
        {
            Items data = JsonConvert.DeserializeObject<Items>(response.Content);
            txtReId.Text = data.id;
            txtReEntity.Text = data.entity;
            txtReName.Text = data.name;
            txtReContact.Text = data.contact;
            txtReEmail.Text = data.email;
            txtReType.Text = data.type;
            txtReRefrence.Text = data.reference_id;
            string status1 = data.active.ToString();
            rdStatus.Items.FindByValue(status1).Selected = true;

            DataTable dt = dal.Gettable("SELECT * FROM Razor_Contacts WHERE ContactID = '" + txtReId.Text + "' AND UserID = '" + txtReRefrence.Text + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                Response.Write("<script>alert('Contact Already Created');</script>");
            }
            else
            {
                int index = dal.Executequery("INSERT INTO Razor_Contacts(UserID, ContactID, CreationDate) VALUES ('" + txtReRefrence.Text + "', '" + txtReId.Text + "', GETDATE())", ref message);
                Response.Write("<script>alert('Contact Created Successfully');</script>");
            }
            GetAllContacts();
        }
    }

    public void GetAllContacts()
    {
        DataTable dt = dal.Gettable("SELECT ContactID FROM Razor_Contacts WHERE UserID = '" + Session["UserID"].ToString() + "'", ref message);
        DataTable dtContact = new DataTable();

        if (dt.Rows.Count > 0)
        {
            dtContact.Columns.Add("Cont_UserID", typeof(string));
            dtContact.Columns.Add("Cont_Id", typeof(string));
            dtContact.Columns.Add("Cont_Name", typeof(string));
            dtContact.Columns.Add("Cont_Number", typeof(string));
            dtContact.Columns.Add("Cont_Email", typeof(string));
            dtContact.Columns.Add("Cont_Type", typeof(string));
            dtContact.Columns.Add("Cont_Status", typeof(bool));
            DataRow dtrow = null;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string id = dt.Rows[i]["ContactID"].ToString();
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                var client = new RestClient("https://api.razorpay.com/v1/contacts/" + id);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
                IRestResponse response = client.Execute(request);

                string status = response.StatusCode.ToString();
                //Response.Write(response.Content);
                if (status == "Created" || status == "OK")
                {
                    Items data = JsonConvert.DeserializeObject<Items>(response.Content);
                    dtrow = dtContact.NewRow();
                    dtrow["Cont_UserID"] = data.reference_id;
                    dtrow["Cont_Id"] = data.id;
                    dtrow["Cont_Name"] = data.name;
                    dtrow["Cont_Number"] = data.contact;
                    dtrow["Cont_Email"] = data.email;
                    dtrow["Cont_Type"] = data.type;
                    dtrow["Cont_Status"] = data.active;

                    dtContact.Rows.Add(dtrow);
                }
            }
        }

        GV_Contacts.DataSource = dtContact;
        GV_Contacts.DataBind();
    }

    protected void btnSelect_Command(object sender, CommandEventArgs e)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        string id = e.CommandArgument.ToString();
        var client = new RestClient("https://api.razorpay.com/v1/contacts/" + id);
        client.Timeout = -1;
        var request = new RestRequest(Method.GET);
        request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
        IRestResponse response = client.Execute(request);
        //Console.WriteLine(response.Content);
        Items data = JsonConvert.DeserializeObject<Items>(response.Content);
        txtReId.Text = data.id;
        txtReEntity.Text = data.entity;
        txtReName.Text = data.name;
        txtReContact.Text = data.contact;
        txtReEmail.Text = data.email;
        txtReType.Text = data.type;
        txtReRefrence.Text = data.reference_id;
        string status = data.active.ToString();
        rdStatus.Items.FindByValue(status).Selected = true;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        var client = new RestClient("https://api.razorpay.com/v1/contacts/" + txtReId.Text);
        client.Timeout = -1;
        var request = new RestRequest(Method.PATCH);
        request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
        request.AddHeader("Content-Type", "application/json");
        request.AddParameter("application/json", "{\r\n\"name\" : \"" + txtReName.Text + "\",\r\n\"email\" : \"" + txtReEmail.Text + "\",\r\n\"contact\" : \"" + txtReContact.Text + "\",\r\n\"type\" : \"customer\",\r\n\"reference_id\" : \"" + txtuserid.Text + "\",\r\n\"notes\" : {\r\n    \t\"notes_key_1\":\"Tea, Earl Grey, Hot\"\r\n    }\r\n\r\n}", ParameterType.RequestBody);
        IRestResponse response = client.Execute(request);
        //Console.WriteLine(response.Content);
        string status = response.StatusCode.ToString();
        //Response.Write(response.Content);
        if (status == "Created" || status == "OK")
        {
            ChangeStatus();
            Response.Write("<script>alert('Contact Udated Successfully');window.location='../customer/auth-add-contacts.aspx';</script>");
            GetAllContacts();
        }
    }
    public void ChangeStatus()
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        var client = new RestClient("https://api.razorpay.com/v1/contacts/" + txtReId.Text);
        client.Timeout = -1;
        var request = new RestRequest(Method.PATCH);
        request.AddHeader("Authorization", "Basic " + hf_Basic.Value.ToString());
        request.AddHeader("Content-Type", "application/json");
        request.AddParameter("application/json", "{\r\n\"active\": " + rdStatus.SelectedValue.ToLower().ToString() + "\r\n}", ParameterType.RequestBody);
        IRestResponse response = client.Execute(request);
    }
    protected void clear()
    {
        txtBeneficiaryName.Text = "";
        txtmobile.Text = "";
        txtemail.Text = "";
        txtaddress.Text = "";

        txtuserid.Text = "";
        lbluserid.Visible = false;
        lblInvalidID.Visible = true;
        lblInvalidID.Text = "Invalid UserID";
        btnSave.Enabled = false;
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("assets/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }
    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void btnFund_Command(object sender, CommandEventArgs e)
    {
        string cont_id = e.CommandArgument.ToString();
        Response.Redirect("auth-add-fund-account.aspx?cont_id=" + cont_id);
    }

    public void GetApiCredential()
    {
        DataTable dt = dal.Gettable("SELECT * FROM Razor_Credential_Master", ref message);
        string status = dt.Rows[0]["Razor_Status"].ToString();
        if (status == "Test")
        {
            string test_key = dt.Rows[0]["Razor_Test_Key"].ToString();
            string test_secrete = dt.Rows[0]["Razor_Test_Secrete"].ToString();
            string test_account = dt.Rows[0]["Razor_Test_Account"].ToString();

            //var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("rzp_test_Kpbhv00EJjZLkA:Lm7mdp3gHZpu3Ot80LeF3RqP");
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(test_key + ":" + test_secrete);
            string val = System.Convert.ToBase64String(plainTextBytes);
            hf_Basic.Value = val;
            hf_Bank_Account.Value = test_account;
        }
        else if (status == "Live")
        {
            string live_key = dt.Rows[0]["Razor_Live_Key"].ToString();
            string live_secrete = dt.Rows[0]["Razor_Live_Secrete"].ToString();
            string live_account = dt.Rows[0]["Razor_Live_Account"].ToString();

            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(live_key + ":" + live_secrete);
            string val = System.Convert.ToBase64String(plainTextBytes);
            hf_Basic.Value = val;
            hf_Bank_Account.Value = live_account;
        }
        else
        {
            hf_Basic.Value = "";
            hf_Bank_Account.Value = "";
        }
    }
}