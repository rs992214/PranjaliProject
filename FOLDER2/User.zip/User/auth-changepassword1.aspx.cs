﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Data;
using System.Text;

public partial class customer_auth_changepassword : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                //showname();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select UserID,Password from MLM_Registration where UserID='{0}' and Password='{1}'", Session["UserID"].ToString(), txtoldpassword.Text);
                DataTable dt = dal.Gettable(sb.ToString(), ref message);
                if (dt.Rows.Count > 0)
                {
                    StringBuilder sba = new StringBuilder();
                    sba.AppendFormat("Update MLM_Registration set Password='{0}' where UserID='{1}'", txtnewpassword.Text, Session["UserID"].ToString());
                    int rowaffected = dal.Executequery(sba.ToString(), ref message);
                    if (rowaffected > 0)
                    {
                        ShowPopupMessage("Password Change Successfully", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message.ToString(), PopupMessageType.Error);
                    }
                }
                else
                {
                    ShowPopupMessage("Incorrect Password.Please Try Again..", PopupMessageType.Error);
                }
            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
            finally
            {
                txtconfirmpassword.Text = null;
                txtnewpassword.Text = null;
                txtoldpassword.Text = null;
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }




    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("../Company/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here





}