﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_packagerecipt : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string jointype = string.Empty;
    string userid = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                GetDetails();
                GetCompanyDetails();
                if (jointype == "Paid")
                {
                    lblUserid.Text = userid;
                    GetPackageDetails();
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void GetDetails()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from MLM_Registration where UserID='" + Session["UserID"].ToString() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                lblName.Text = dt.Rows[0]["Name"].ToString();
                userid = dt.Rows[0]["UserID"].ToString();
                string doj = dt.Rows[0]["JoinDate"].ToString();
                lbljoindate.Text = Convert.ToDateTime(doj).ToString("dd-MM-yyyy");
                jointype = dt.Rows[0]["JoinType"].ToString();
            }
            else
            {
                lblName.Text = string.Empty;
                lblUserid.Text = string.Empty;
                lbljoindate.Text = string.Empty;
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message.ToString() + "')", true);
        }
    }

    public void GetPackageDetails()
    {
        try
        {
            DataTable dt = dal.Gettable("select pp.PackageName,pp.Amount from PackageInfo pp INNER JOIN MLM_Registration mm On mm.Package=pp.PackageName where UserID='" + Session["UserID"].ToString() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                lblKit.Text = dt.Rows[0]["PackageName"].ToString();
                txtAmount.Text = dt.Rows[0]["Amount"].ToString() + " (Inclusive of All Taxes)";
            }
            else
            {
                lblKit.Text = string.Empty;
                txtAmount.Text = string.Empty;
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message.ToString() + "')", true);
        }
    }
    public void GetCompanyDetails()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from CompanyInfo", ref message);
            if (dt.Rows.Count > 0)
            {
                lbladdress.Text = dt.Rows[0]["Address"].ToString();
                lblemail.Text = dt.Rows[0]["Email"].ToString();
                lblmobno.Text = dt.Rows[0]["PhoneNo"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    imglogo.ImageUrl = "data:image/png;base64," + base64String;
                }
                else
                {
                    imglogo.ImageUrl = "~/pages/images/logo.png";
                }
            }
            else
            {
                lbladdress.Text = string.Empty;
                lblemail.Text = string.Empty;
                lblmobno.Text = string.Empty;
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message.ToString() + "')", true);
        }
    }
}