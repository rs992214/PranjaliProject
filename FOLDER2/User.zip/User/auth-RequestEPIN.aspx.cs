﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_RequestEPIN : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DAL objDAL = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Getdata();
            //  GetPackage();
        }
        lbl_BTC();
        lbl_Tron();
        lbl_Eth();
    }


    private void lbl_Tron()
    {
        DAL objDAL = new DAL();
        //  sb.AppendFormat("select Recipt from RequestEPinGenertae where Userid='{0}'", Session["UserID"].ToString());
        DataTable dt = objDAL.Gettable("select Dollar from Tron_Master", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["Dollar"] != DBNull.Value)
            {
               lbltrn.Text = dt.Rows[0]["Dollar"].ToString();
            }
        }
    }
    private void lbl_BTC()
    {
        DAL objDAL = new DAL();
        //  sb.AppendFormat("select Recipt from RequestEPinGenertae where Userid='{0}'", Session["UserID"].ToString());
        DataTable dt = objDAL.Gettable("select Dollar from BTC_Master", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["Dollar"] != DBNull.Value)
            {
                lblbtc.Text = dt.Rows[0]["Dollar"].ToString();
            }
        }
    }
     private void lbl_Eth()
    {
        DAL objDAL = new DAL();
        //  sb.AppendFormat("select Recipt from RequestEPinGenertae where Userid='{0}'", Session["UserID"].ToString());
        DataTable dt = objDAL.Gettable("select Dollar from Ethereum_Master", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["Dollar"] != DBNull.Value)
            {
                lbleth.Text = dt.Rows[0]["Dollar"].ToString();
            }
        }
    }


    public static string GetUniqueKeyOriginal_BIASED(int size)
    {
        char[] chars = "0123456789".ToCharArray();
        byte[] data = new byte[size];
        using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
        {
            crypto.GetBytes(data);
        }
        StringBuilder result = new StringBuilder(size);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }

    private void TronCoin(string tron)
    {
        DAL objDAL = new DAL();
        //  sb.AppendFormat("select Recipt from RequestEPinGenertae where Userid='{0}'", Session["UserID"].ToString());
        DataTable dt = objDAL.Gettable("select Dollar from Tron_Master", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["Dollar"] != DBNull.Value)
            {
                decimal amount = Convert.ToDecimal(txtQty.Text) / Convert.ToDecimal(dt.Rows[0]["Dollar"].ToString());
                txtamount.Text = String.Format("{0:0.##}", amount);
            }
        }
    }
    private void BTCCoin(string Btc)
    {
        DAL objDAL = new DAL();
        //  sb.AppendFormat("select Recipt from RequestEPinGenertae where Userid='{0}'", Session["UserID"].ToString());
        DataTable dt = objDAL.Gettable("select Dollar from BTC_Master", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["Dollar"] != DBNull.Value)
            {
                decimal amount = Convert.ToDecimal(txtQty.Text) / Convert.ToDecimal(dt.Rows[0]["Dollar"].ToString());
                txtamount.Text = String.Format("{0:0.##}", amount);
            }
        }
    }
    private void EthereumCoin(string Ethereum)
    {
        DAL objDAL = new DAL();
        //  sb.AppendFormat("select Recipt from RequestEPinGenertae where Userid='{0}'", Session["UserID"].ToString());
        DataTable dt = objDAL.Gettable("select Dollar from Ethereum_Master", ref message);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["Dollar"] != DBNull.Value)
            {
                decimal amount = Convert.ToDecimal(txtQty.Text) / Convert.ToDecimal(dt.Rows[0]["Dollar"].ToString());
                txtamount.Text = String.Format("{0:0.##}", amount);
            }
            else
            {
            }
        }
    }
    public void Getdata()
    {
        try
        {
            DAL objDAL = new DAL();
            //  sb.AppendFormat("select Recipt from RequestEPinGenertae where Userid='{0}'", Session["UserID"].ToString());
            DataTable dt = objDAL.Gettable("select Userid,TransactionID,User_TransactionID,PakageName,Qty,Amount,Date,Recipt,Status from RequestEPinGenertae where UserID='" + Session["UserID"].ToString() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                GV_PackageList.DataSource = dt;
                GV_PackageList.DataBind();
            }
            else
            {
                GV_PackageList.DataSource = null;
                GV_PackageList.DataBind();
            }
        }
        catch (Exception ex)
        {
            //ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    public void Clear()
    {
        txtamount.Text = "";
        txtQty.Text = "";
    }

    string status = null;
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            #region Unused      

            //DAL dal = new DAL();
            //DataTable dtkyc = dal.Gettable("Select KYC from MLM_UserDetail where UserID='" + Session["UserID"].ToString() + "'", ref message);
            //if (dtkyc.Rows.Count > 0)
            //{
            //    status = dtkyc.Rows[0]["KYC"].ToString();
            //    if (status == "Yes")
            //    {
            //    }
            //    else
            //    {
            //        status = "Kyc Pending !";
            //        ShowPopupMessage(status, PopupMessageType.Warning);
            //    }
            //}
            //else
            //{
            //    status = "Kyc Pending !";
            //    ShowPopupMessage(status, PopupMessageType.Warning);
            //}
            #endregion
            if (txtTransactionID.Text!=string.Empty && txtamount.Text!=string.Empty && txtQty.Text!=string.Empty)
            {
            decimal temp_amount = Convert.ToDecimal(txtQty.Text);
                    if (temp_amount > 0)
                    {
                        if (Session["UserID"] != null)
                        {
                            if (FileUpload1.HasFile)
                            {
                                string ext = Path.GetExtension(FileUpload1.FileName);
                                if (ext == ".jpg" || ext == ".png" || ext == ".jpeg" || ext == ".JPG" || ext == ".PNG")
                                {
                                    string photo = null;
                                    string UserID = Session["UserID"].ToString();
                                    con = new SqlConnection(connstring);
                                    con.Open();
                                    cmd = new SqlCommand("Sp_RequestEPinGenertae", con);
                                    if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.ContentLength <= 800000)
                                    {
                                        string FileName = string.Concat(Path.GetFileNameWithoutExtension(FileUpload1.FileName),
                                        DateTime.Now.ToString("yyyyMMddHHssfff"),
                                        Path.GetExtension(FileUpload1.FileName));
                                        //if (FileName == ".JPG")
                                        FileUpload1.SaveAs(Server.MapPath("../customer/receipts/" + FileName));
                                        photo = "../customer/receipts/" + FileName;
                                        //Stream fs = FileUpload1.PostedFile.InputStream;
                                        //BinaryReader br = new BinaryReader(fs);
                                        //Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                                        //photo = bytes;

                                        cmd.CommandType = CommandType.StoredProcedure;
                                        //withdrawal request tbl
                                        cmd.Parameters.AddWithValue("@UserID", UserID);
                                        cmd.Parameters.AddWithValue("@PakageName", DDLPackage.SelectedItem.Text);
                                        cmd.Parameters.AddWithValue("@Qty", txtQty.Text);
                                        cmd.Parameters.AddWithValue("@Amount", txtamount.Text);
                                        cmd.Parameters.AddWithValue("@Recipt", photo);
                                        cmd.Parameters.AddWithValue("@TransactionID", "T"+GetUniqueKeyOriginal_BIASED(12));
                                        cmd.Parameters.AddWithValue("@User_TransactionID", txtTransactionID.Text);
                                        cmd.Parameters.AddWithValue("@Mode", "InsertCustomerRequest");
                                        int flag = cmd.ExecuteNonQuery();
                                        if (flag > 0)
                                        {
                                            ReciptUpload();
                                            //   btnSave.Enabled = true;
                                            //ShowPopupMessage("Your Request has been send to Admin.", PopupMessageType.Success);
                                            Response.Redirect("success.aspx?Link=auth-RequestEPIN.aspx");
                                            Clear();
                                            Getdata();

                                        }
                                        else
                                        {
                                            ReciptUpload();
                                            //   ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                                            // ShowPopupMessage("Your Request has been send to Admin.", PopupMessageType.Success);
                                            Response.Redirect("success.aspx?Link=auth-RequestEPIN.aspx");
                                            Clear();
                                            Getdata();
                                        }


                                    }
                                    else
                                    {
                                        ShowPopupMessage("Receipt size Should be Less Than or equal to 800kb.", PopupMessageType.Warning);
                                    }
                                }
                                else
                                {
                                    ShowPopupMessage("Selected file format must be .jpg and .png", PopupMessageType.Warning);
                                }
                            }
                            else
                            {
                                ShowPopupMessage("Please Upload File.", PopupMessageType.Message);
                            }
                        }
                    }
            }
        }

        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("auth-RequestEPIN.aspx");
    }

    protected void txtQty_TextChanged(object sender, EventArgs e)
    {
        decimal temp_amount = Convert.ToDecimal(txtQty.Text);


        if (DDLPackage.SelectedIndex > 0)
        {
            //if (txtQty.Text != string.Empty)
            //{
            //}
            if (Convert.ToDecimal(txtQty.Text) > 0 && txtQty.Text != string.Empty)
            {


                if (DDLPackage.SelectedItem.Text == "TRON")
                {
                    TronCoin(DDLPackage.SelectedItem.Text);
                }
                if (DDLPackage.SelectedItem.Text == "BTC")
                {
                    BTCCoin(DDLPackage.SelectedItem.Text);
                }
                if (DDLPackage.SelectedItem.Text == "ETHEREUM")
                {
                    EthereumCoin(DDLPackage.SelectedItem.Text);
                }

            }
            else
            {
                txtQty.Text = string.Empty;
                txtamount.Text = string.Empty;
                ShowPopupMessage("Please Enter Positive value...", PopupMessageType.Warning);
            }
        }
        else
        {
            txtQty.Text = string.Empty;
            ShowPopupMessage("Please Select Currency", PopupMessageType.Warning);
        }

    }

    private void GetPackage()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,PackageName From PackageInfo order by ID Asc", ref message);
            if (dt.Rows.Count > 0)
            {
                DDLPackage.DataSource = dt;
                DDLPackage.DataTextField = "PackageName";
                DDLPackage.DataValueField = "ID";
                DDLPackage.DataBind();
                DDLPackage.Items.Insert(0, new ListItem("--Please Select Package--", "0"));
            }
            else
            {
                DDLPackage.DataSource = dt;
                DDLPackage.DataBind();
                DDLPackage.Items.Insert(0, new ListItem("--Please Select Package--", "0"));
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    public void saveAddressProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/receipts/");
            if (FileUpload1.HasFile)
            {



                int ContentLength = FileUpload1.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload1.PostedFile.FileName;
                    FileUpload1.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/receipts/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                //    sba.AppendFormat("update MLM_UserDetail set AddressProof='{0}',AddressProofvalue='{1}',AddressProofUrl='{2}',AddressProofvalidate='{3}' where UserID='{4}'", drpaddress.SelectedItem.Text, txtadressproofvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    Response.Redirect("success.aspx?Link=auth-RequestEPIN.aspx");
                    //ShowPopupMessage("Aadhar Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    public void ReciptUpload()
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select Recipt from RequestEPinGenertae where Userid='{0}'", Session["UserID"].ToString());
                object addressproofobject = dal.Getscalar(sb.ToString(), ref message);

                if (addressproofobject is DBNull)
                {
                    saveAddressProof();
                }
                else
                {
                    //  ImageDeleteFromFolder(addressproofobject.ToString());
                    saveAddressProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }


    protected void btnbtnimage_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string filePath = (sender as ImageButton).CommandArgument;
            Response.ContentType = "application/octet-stream"; //ContentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
            Response.WriteFile(filePath);
            Response.End();
        }
        catch (Exception ex)
        {

            ShowPopupMessage(ex.Message, PopupMessageType.Error);

        }


    }

    protected void GV_PackageList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_PackageList.PageIndex = e.NewPageIndex;
        Getdata();
    }
}