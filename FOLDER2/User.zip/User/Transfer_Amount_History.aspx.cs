﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;


public partial class customer_Transfer_Amount_History : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            if (!IsPostBack)
            {

                GetData();
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    private void GetData()
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            if (!(string.IsNullOrEmpty(txtFrom.Text) && string.IsNullOrEmpty(txtFrom.Text)))
            {
                //dt = objDAL.Gettable("select UserID,PinNo,PackageName,ActivationDate from PinGenerateNew p1 inner join PackageInfo p2 On p1.PackageID=p2.ID Where UserID='" + UserID + "' and ActivationDate BETWEEN '" + txtFrom.Text + "' and '" + txtTo.Text + "' order by ActivationDate desc", ref message);
                dt = objDAL.Gettable("select UserID,Amount,TransferBy,TransferTo,TransactionDate from Transfer_Money where UserID='"+UserID+ "' and TransactionDate BETWEEN '" + txtFrom.Text + "' and '" + txtTo.Text + "' order by TransactionDate desc", ref message);
            }
            else
            {
                // dt = objDAL.Gettable("select UserID,PinNo,PackageName,ActivationDate from PinGenerateNew p1 inner join PackageInfo p2 On p1.PackageID=p2.ID where transferto='" + UserID + "' and UserID is not null order by ActivationDate Desc", ref message);
                dt = objDAL.Gettable("select UserID,Amount,TransferBy,TransferTo,TransactionDate from Transfer_Money where UserID='" + UserID+"' and UserID is not null order by TransactionDate Desc", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        GetData();
    }

}