﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_kyc : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                ShowProfile();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/assets/images/Red_cross_tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/assets/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/assets/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/assets/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/assets/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    public void saveAdharProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/kyc/");
            if (FileUpload1.HasFile)
            {
                int ContentLength = FileUpload1.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload1.PostedFile.FileName;
                    FileUpload1.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/kyc/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                sba.AppendFormat("update MLM_UserDetail set Address2value='{0}',Address2ProofUrl='{1}' where UserID='{2}'", TextBox1.Text, SaveFilename, Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowProfile();
                    ShowPopupMessage("Adhar Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }
    protected void btnadhar_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select Address2ProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object Address1ProofObject = dal.Getscalar(sb.ToString(), ref message);

                if (Address1ProofObject is DBNull)
                {
                    saveAdharProof();
                    ShowPopupMessage("Adhar Proof Updated Successfully", PopupMessageType.Success);
                }
                else if (Address1ProofObject != null)
                {
                    //ImageDeleteFromFolder(Address1ProofObject.ToString());
                    saveAdharProof();
                    ShowPopupMessage("Adhar Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    saveAdharProof();
                    ShowPopupMessage("Adhar Proof Updated Successfully", PopupMessageType.Success);

                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    public void saveAddressProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/kyc/");
            if (FileUpload6.HasFile)
            {
                int ContentLength = FileUpload6.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload6.PostedFile.FileName;
                    FileUpload6.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/kyc/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                sba.AppendFormat("update MLM_UserDetail set AddressProofvalue='{0}',AddressProofUrl='{1}' where UserID='{2}'", TextBox2.Text, SaveFilename, Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowProfile();
                    ShowPopupMessage("Address Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }
    protected void btnaddress1_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select AddressProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object Address1ProofObject = dal.Getscalar(sb.ToString(), ref message);

                if (Address1ProofObject is DBNull)
                {
                    saveAddressProof();
                }
                else if (Address1ProofObject != null)
                {
                    //ImageDeleteFromFolder(Address1ProofObject.ToString());
                    saveAddressProof();
                }
                else
                {
                    saveAddressProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    public void saveBankProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/kyc/");
            if (FileUpload3.HasFile)
            {
                int ContentLength = FileUpload3.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload3.PostedFile.FileName;
                    FileUpload3.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/kyc/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                //sba.AppendFormat("update MLM_UserDetail set BankProof='{0}',BankProofvalue='{1}',BankProofUrl='{2}',BankProofvalidate='{3}' where UserID='{4}'", drpbankproof.SelectedItem.Text, txtbankproofvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                sba.AppendFormat("update MLM_UserDetail set BankProofvalue='{0}',BankProofUrl='{1}' where UserID='{2}'", TextBox4.Text, SaveFilename, Session["UserID"].ToString());

                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowProfile();
                    ShowPopupMessage("Bank Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }
    protected void btnbankproofupdate1_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select BankProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object Bankproofobject = dal.Getscalar(sb.ToString(), ref message);

                if (Bankproofobject is DBNull)
                {
                    saveBankProof();
                }
                else
                {
                    // ImageDeleteFromFolder(Bankproofobject.ToString());
                    saveBankProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }

    protected void btnapplication_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select ApplicationUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object ApplicationProofObject = dal.Getscalar(sb.ToString(), ref message);

                if (ApplicationProofObject is DBNull)
                {
                    saveApplicationProof();
                }
                else
                {
                    //ImageDeleteFromFolder(ApplicationProofObject.ToString());
                    saveApplicationProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }


    }
    public void saveApplicationProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/kyc/");
            if (FileUpload5.HasFile)
            {
                int ContentLength = FileUpload5.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload5.PostedFile.FileName;
                    FileUpload5.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/kyc/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                //sba.AppendFormat("update MLM_UserDetail set Application='{0}',Applicationvalue='{1}',ApplicationUrl='{2}',Applicationvalidate='{3}' where UserID='{4}'", drpapplication.SelectedItem.Text, txtapplicationvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                sba.AppendFormat("update MLM_UserDetail set Applicationvalue='{0}',ApplicationUrl='{1}' where UserID='{2}'", TextBox5.Text, SaveFilename, Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowProfile();
                    ShowPopupMessage("Application Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }

    protected void btngstprrofupdate_Click(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            try
            {
                DAL dal = new DAL();
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select GSTProofUrl from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
                object GstProofObject = dal.Getscalar(sb.ToString(), ref message);

                if (GstProofObject is DBNull)
                {
                    saveGSTProof();
                }
                else
                {
                    // ImageDeleteFromFolder(GstProofObject.ToString());
                    saveGSTProof();
                }
            }
            catch (Exception ex)
            {

                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            Response.Redirect("Logout.aspx");
        }
    }
    public void saveGSTProof()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            string FileName = null;
            string SaveFilename = null;
            string folderPath = Server.MapPath("~/customer/kyc/");
            if (FileUpload4.HasFile)
            {
                int ContentLength = FileUpload4.PostedFile.ContentLength;
                if (ContentLength <= 1000000)
                {
                    FileName = Session["UserID"].ToString() + FileUpload4.PostedFile.FileName;
                    FileUpload4.SaveAs(folderPath + FileName);
                    SaveFilename = "~/customer/kyc/" + FileName;
                }
                else
                {
                    ShowPopupMessage("Document size Should be Less Than or equal to 1 MB.", PopupMessageType.Warning);
                    return;
                }
                //sba.AppendFormat("update MLM_UserDetail set GST='{0}',GSTProofvalue='{1}',GSTProofUrl='{2}',GSTProofvalidate='{3}' where UserID='{4}'", drpgstproof.SelectedItem.Text, txtgstproofvalue.Text, SaveFilename, "0", Session["UserID"].ToString());
                sba.AppendFormat("update MLM_UserDetail set GSTProofvalue='{0}',GSTProofUrl='{1}' where UserID='{2}'", TextBox4.Text, SaveFilename, Session["UserID"].ToString());
                int rowaffected = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ShowProfile();
                    ShowPopupMessage("GST Proof Updated Successfully", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Warning);
                }
            }
            else
            {
                ShowPopupMessage("Please Upload Document.", PopupMessageType.Warning);
                return;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }



    public void ShowProfile()
    {
        try
        {
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = Session["UserID"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            if (dt.Rows.Count > 0)
            {

                string Adharproof = dt.Rows[0]["AddressProof"].ToString();
                if (!string.IsNullOrEmpty(Adharproof))
                {
                    //txtadressproofvalue.Text = dt.Rows[0]["AddressProofvalue"].ToString();
                    TextBox1.Text = dt.Rows[0]["Address2value"].ToString();
                    string validate = dt.Rows[0]["AddressProofvalidate"].ToString();
                    if (validate == "1")
                    {
                        spanadress.Visible = true;
                        //btnaddressupdate.Enabled = false;
                        Image1.ImageUrl = dt.Rows[0]["Address2ProofUrl"].ToString();
                    }
                    else
                    {
                        spanadress.Visible = false;
                        //btnaddressupdate.Enabled = true;
                        Image1.ImageUrl = dt.Rows[0]["Address2ProofUrl"].ToString();
                    }
                }
                else
                {
                    spanadress.Visible = false;
                    // btnaddressupdate.Enabled = true;
                }


                string Addressproof = dt.Rows[0]["AddressProof"].ToString();
                if (!string.IsNullOrEmpty(Addressproof))
                {
                    //txtadressproofvalue.Text = dt.Rows[0]["AddressProofvalue"].ToString();
                    TextBox2.Text = dt.Rows[0]["AddressProofvalue"].ToString();
                    string validate = dt.Rows[0]["AddressProofvalidate"].ToString();
                    if (validate == "1")
                    {
                        spanadress.Visible = true;
                        //btnaddressupdate.Enabled = false;
                        Image2.ImageUrl = dt.Rows[0]["AddressProofUrl"].ToString();
                    }
                    else
                    {
                        spanadress.Visible = false;
                        //btnaddressupdate.Enabled = true;
                        Image2.ImageUrl = dt.Rows[0]["AddressProofUrl"].ToString();
                    }
                }
                else
                {
                    spanadress.Visible = false;
                    // btnaddressupdate.Enabled = true;
                }



                string Bankproof = dt.Rows[0]["AddressProof"].ToString();
                if (!string.IsNullOrEmpty(Bankproof))
                {
                    //txtadressproofvalue.Text = dt.Rows[0]["AddressProofvalue"].ToString();
                    TextBox4.Text = dt.Rows[0]["BankProofvalue"].ToString();
                    string validate = dt.Rows[0]["AddressProofvalidate"].ToString();
                    if (validate == "1")
                    {
                        spanadress.Visible = true;
                        //btnaddressupdate.Enabled = false;
                        Image4.ImageUrl = dt.Rows[0]["BankProofUrl"].ToString();
                    }
                    else
                    {
                        spanadress.Visible = false;
                        //btnaddressupdate.Enabled = true;
                        Image4.ImageUrl = dt.Rows[0]["BankProofUrl"].ToString();
                    }
                }
                else
                {
                    spanadress.Visible = false;
                    // btnaddressupdate.Enabled = true;
                }



                string Applicationproof = dt.Rows[0]["AddressProof"].ToString();
                if (!string.IsNullOrEmpty(Applicationproof))
                {
                    //txtadressproofvalue.Text = dt.Rows[0]["AddressProofvalue"].ToString();
                    TextBox5.Text = dt.Rows[0]["Applicationvalue"].ToString();
                    string validate = dt.Rows[0]["AddressProofvalidate"].ToString();
                    if (validate == "1")
                    {
                        spanadress.Visible = true;
                        //btnaddressupdate.Enabled = false;
                        Image5.ImageUrl = dt.Rows[0]["ApplicationUrl"].ToString();
                    }
                    else
                    {
                        spanadress.Visible = false;
                        //btnaddressupdate.Enabled = true;
                        Image5.ImageUrl = dt.Rows[0]["ApplicationUrl"].ToString();
                    }
                }
                else
                {
                    spanadress.Visible = false;
                    // btnaddressupdate.Enabled = true;
                }


                string GSTproof = dt.Rows[0]["AddressProof"].ToString();
                if (!string.IsNullOrEmpty(GSTproof))
                {
                    //txtadressproofvalue.Text = dt.Rows[0]["AddressProofvalue"].ToString();
                    TextBox6.Text = dt.Rows[0]["GSTProofvalue"].ToString();
                    string validate = dt.Rows[0]["AddressProofvalidate"].ToString();
                    if (validate == "1")
                    {
                        spanadress.Visible = true;
                        //btnaddressupdate.Enabled = false;
                        Image6.ImageUrl = dt.Rows[0]["GSTProofUrl"].ToString();
                    }
                    else
                    {
                        spanadress.Visible = false;
                        //btnaddressupdate.Enabled = true;
                        Image6.ImageUrl = dt.Rows[0]["GSTProofUrl"].ToString();
                    }
                }
                else
                {
                    spanadress.Visible = false;
                    // btnaddressupdate.Enabled = true;
                }



                //string Identityproof = dt.Rows[0]["IdentityProof"].ToString();
                //if (!string.IsNullOrEmpty(Identityproof))
                //{
                //    drpidentityproof.ClearSelection();
                //    drpidentityproof.Items.FindByText(dt.Rows[0]["IdentityProof"].ToString()).Selected = true;
                //    txtidentityvalue.Text = dt.Rows[0]["IdentityProofvalue"].ToString();
                //    string validate = dt.Rows[0]["IdentityProofvalidate"].ToString();
                //    if (validate == "1")
                //    {
                //        spanidentity.Visible = true;
                //        btnidentityupdate.Enabled = false;
                //    }
                //    else
                //    {
                //        spanidentity.Visible = false;
                //        btnidentityupdate.Enabled = true;
                //    }
                //}
                //else
                //{
                //    spanidentity.Visible = false;
                //    btnidentityupdate.Enabled = true;
                //}
                //string BankProof = dt.Rows[0]["BankProof"].ToString();
                //if (!string.IsNullOrEmpty(BankProof))
                //{
                //    drpbankproof.ClearSelection();
                //    drpbankproof.Items.FindByText(dt.Rows[0]["BankProof"].ToString()).Selected = true;
                //    txtbankproofvalue.Text = dt.Rows[0]["BankProofvalue"].ToString();
                //    string validate = dt.Rows[0]["BankProofvalidate"].ToString();
                //    if (validate == "1")
                //    {
                //        spanbank.Visible = true;
                //        btnbankproofupdate.Enabled = false;
                //    }
                //    else
                //    {
                //        spanbank.Visible = false;
                //        btnbankproofupdate.Enabled = true;
                //    }
                //}
                //else
                //{
                //    spanbank.Visible = false;
                //    btnbankproofupdate.Enabled = true;
                //}
                //string ApplicationProof = dt.Rows[0]["Application"].ToString();
                //if (!string.IsNullOrEmpty(ApplicationProof))
                //{
                //    drpapplication.ClearSelection();
                //    drpapplication.Items.FindByText(dt.Rows[0]["Application"].ToString()).Selected = true;
                //    txtapplicationvalue.Text = dt.Rows[0]["Applicationvalue"].ToString();
                //    string validate = dt.Rows[0]["Applicationvalidate"].ToString();
                //    if (validate == "1")
                //    {
                //        spanapplication.Visible = true;
                //        btnapplication.Enabled = false;
                //    }
                //    else
                //    {
                //        spanapplication.Visible = false;
                //        btnapplication.Enabled = true;
                //    }
                //}
                //else
                //{
                //    spanapplication.Visible = false;
                //    btnapplication.Enabled = true;
                //}
                //string GSTProof = dt.Rows[0]["GST"].ToString();
                //if (!string.IsNullOrEmpty(GSTProof))
                //{
                //    drpgstproof.ClearSelection();
                //    drpgstproof.Items.FindByText(dt.Rows[0]["GST"].ToString()).Selected = true;
                //    txtgstproofvalue.Text = dt.Rows[0]["GSTProofvalue"].ToString();
                //    string validate = dt.Rows[0]["GSTProofvalidate"].ToString();
                //    if (validate == "1")
                //    {
                //        spangst.Visible = true;
                //        btngstprrofupdate.Enabled = false;
                //    }
                //    else
                //    {
                //        spangst.Visible = false;
                //        btngstprrofupdate.Enabled = true;
                //    }
                //}
                //else
                //{
                //    spangst.Visible = false;
                //    btngstprrofupdate.Enabled = true;
                //}
                //string Address2 = dt.Rows[0]["Address2"].ToString();
                //if (!string.IsNullOrEmpty(Address2))
                //{
                //    //drpaddress1.ClearSelection();
                //    //drpaddress1.Items.FindByText(dt.Rows[0]["Address2"].ToString()).Selected = true;
                //    txtaddress1value.Text = dt.Rows[0]["Address2value"].ToString();
                //    string validate = dt.Rows[0]["Address2validate"].ToString();
                //    if (validate == "1")
                //    {
                //        spanaddress1.Visible = true;
                //        btnaddress1.Enabled = false;
                //    }
                //    else
                //    {
                //        spanaddress1.Visible = false;
                //        btnaddress1.Enabled = true;
                //    }
                //}
                //else
                //{
                //    spanaddress1.Visible = false;
                //    btnaddress1.Enabled = true;
                //}
                //ShowSponsorName();
                //string PhotoPath = dt.Rows[0]["PhotoPath"].ToString();
                //if (PhotoPath != string.Empty)
                //{
                //    Image1.ImageUrl = dt.Rows[0]["PhotoPath"].ToString();
                //}
                //else if (PhotoPath == string.Empty)
                //{
                //    Image1.ImageUrl = "~/Member/images/dummyprofilepic.png";
                //}
            }

            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
}