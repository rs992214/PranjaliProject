﻿using DataAccessLayer;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class customer_auth_forgot : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string Mobile = string.Empty;
    string Name = string.Empty;
    string Password = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        Showdatalogo();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        DataTable dt = dal.Gettable("select UserID,Password,Mobile,Email,Name from MLM_Registration where UserID='"+txtuser.Text+"'", ref message);
        if(dt.Rows.Count > 0)
        {
            Mobile = dt.Rows[0]["Mobile"].ToString();
            Name = dt.Rows[0]["Name"].ToString();
            Password = dt.Rows[0]["Password"].ToString();
            SendMsg();
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Login Credential Sent To Your Number')", true);
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Invalid UserId...')", true);
        }
    }

    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                Session["Company"] = dt.Rows[0]["CompanyName"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    // imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    imgLogo.ImageUrl = "data:image/png;base64," + base64String;
                }
            }
            else
            {
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void SendMsg()
    {
        DAL dal = new DAL();

        string url = "";
        string username = "";
        string key = "";
        string request = "";
        string sender = "";
        string route = "";
        int sms = 0;
        string status = "";
        string message = string.Empty;
        //DataTable dt2 = dal.Gettable("Select RegistrationSMS,RegistrationEmail from SMS_Email_Notification", ref message);
        //smsstatus = dt2.Rows[0]["RegistrationSMS"].ToString();
       // emailstatus = dt2.Rows[0]["RegistrationEmail"].ToString();
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            url = dt.Rows[0]["APIurl"].ToString();
            username = dt.Rows[0]["Username"].ToString();
            key = dt.Rows[0]["APIkey"].ToString();
            request = dt.Rows[0]["APIrequest"].ToString();
            sender = dt.Rows[0]["Sender"].ToString();
            route = dt.Rows[0]["Route"].ToString();
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());

            if (sms != 0)
            {

                string text = "Dear Member, Your User ID: " + txtuser.Text + " and password:" + Password + ". Thank You. ";
                try
                {
                    string jsonValue = "";
                    string sURL;
                    StreamReader objReader;
                    // sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + username + "&password=" + password + "&sender=" + senderId + "&to=" + txtmobileNo.Text + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + routeId + "";
                    // sURL = "http://sms.probuztech.com/sms-panel/api/http/index.php?username=WYSE&apikey=FC144-3DD84&apirequest=Text&sender=PROBUZ&mobile=8055002299&message=TEST&route=TRANS&format=JSON";
                    sURL = "" + url + "?username=" + username + "&apikey=" + key + "&apirequest=" + request + "&sender=" + sender + "&mobile=" + Mobile + "&message=" + text + "&route=" + route + "&format=JSON";
                    WebRequest wrGETURL;
                    wrGETURL = WebRequest.Create(sURL);
                    try
                    {
                        Stream objStream;
                        objStream = wrGETURL.GetResponse().GetResponseStream();
                        objReader = new StreamReader(objStream);
                        jsonValue = objReader.ReadToEnd();
                        var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                        string status1 = myDetails.status;
                        if (status1 == "error")
                        {
                            SMSHistory(txtuser.Text, Name, Mobile, text, "Not Send");
                        }
                        else
                        {
                            SMSdebit();
                            SMSHistory(txtuser.Text, Name, Mobile, text, "Send");
                        }

                        objReader.Close();
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
    }

    protected void SMSdebit()
    {
        int sms = 0;
        int smsAvailable = 0;
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());
            smsAvailable = sms - 2;

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update SmsmasterNew set CreditSMS='{0}'", smsAvailable);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('SMS Send Successfully...')", true);
                }
                else
                {
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {

            }

        }


    }
    protected void SMSHistory(string userid, string name, string mobile, string msg, string sts)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sba = new StringBuilder();
        sba.AppendLine("insert into SMSHistory(UserID,Name,Mobileno,Message,Status)");
        sba.AppendFormat("values('{0}','{1}','{2}','{3}','{4}')", userid, name, mobile, msg, sts);
        int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
        if (rowaffected1 > 0)
        {

        }

    }
    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
    }
}