﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;

public partial class customer_auth_mybinarytree : System.Web.UI.Page
{
    string L = null, R = null;
    ArrayList UserIDList = new ArrayList();
    ArrayList UserIDRightList = new ArrayList();
    string websitename = "";
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                CLEAR();

                detail(Session["UserID"].ToString());
                btnback.Visible = false;
                CountLeft_Right_Carry_Count();

                // ShowleftrightBV(Session["UserID"].ToString());
                //ShowSaleValuesofteam();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

            //TimeSpan ts = DateTime.Now.TimeOfDay;
            
        }


    }

    private void CountLeft_Right_Carry_Count()
    {
      //  string Lleg;
        SqlConnection con = new SqlConnection(connstring);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "GENOLOGY_COUNT";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@user_id", Session["UserID"].ToString());
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            //Lleg = dt.Rows[0]["LLeg"].ToString();

            lblGid.Text = dt.Rows[0]["l_paid"].ToString();
            lblACarryFwd.Text= dt.Rows[0]["l_carry"].ToString();
            lblBGid.Text= dt.Rows[0]["r_paid"].ToString();
            lblBCarryFwd.Text= dt.Rows[0]["r_carry"].ToString();
            lblARid.Text= dt.Rows[0]["l_free"].ToString();
            lblBRid.Text= dt.Rows[0]["r_free"].ToString();
        }

    }
    private void CountLeft_Right_Carry_Count(string value)
    {
        //  string Lleg;
        SqlConnection con = new SqlConnection(connstring);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "GENOLOGY_COUNT";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@user_id", value);
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            //Lleg = dt.Rows[0]["LLeg"].ToString();

            lblGid.Text = dt.Rows[0]["l_paid"].ToString();
            lblACarryFwd.Text = dt.Rows[0]["l_carry"].ToString();
            lblBGid.Text = dt.Rows[0]["r_paid"].ToString();
            lblBCarryFwd.Text = dt.Rows[0]["r_carry"].ToString();
            lblARid.Text = dt.Rows[0]["l_free"].ToString();
            lblBRid.Text = dt.Rows[0]["r_free"].ToString();
        }

    }
    public void find(string UserID, out string Left, out string Right)
    {
        Left = null;
        Right = null;
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            Left = dt.Rows[0]["LLeg"].ToString();
            Right = dt.Rows[0]["RLeg"].ToString();
        }
    }

    public void ShowleftrightBV(string UserID)
    {
        string USERIDBV = UserID;
        SqlConnection con = new SqlConnection(connstring);
        SqlCommand mcmd1 = new SqlCommand("auth_total_bv_tree", con);
        mcmd1.CommandType = CommandType.StoredProcedure;
        mcmd1.Parameters.AddWithValue("@SessionID", USERIDBV); 
         SqlDataAdapter sda = new SqlDataAdapter(mcmd1);
        DataTable dtd = new DataTable();
        sda.Fill(dtd);
        if (dtd.Rows.Count > 0)
        {
            lblteamAsvp.Text = dtd.Rows[0]["LEFTBV"].ToString();
            lblteamBsvp.Text = dtd.Rows[0]["RIGHTBV"].ToString();
            lblljoin.Text = dtd.Rows[0]["LEFTA"].ToString();
            lblrjoin.Text = dtd.Rows[0]["RIGHTA"].ToString();
        }
    }

    public DataTable fillUserDetail(string UserID)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            //sb.AppendFormat("select (Select top(1)Name from MLM_Registration WHERE UserID =(Select SponsorID from MLM_Registration WHERE UserID ='" + UserID + "' )) as SponsorName,Name,JoinType,LLeg,CONVERT(nvarchar,JoinDate,105) as JoinDate ,RLeg,isnull(LJoining,0)as LJoining,isnull(Rjoining,0)as Rjoining,CONVERT(nvarchar,PackageDate,105) as PackageDate,Package  from MLM_Registration where  UserID='{0}'", UserID);
            //sb.AppendFormat("select (Select top(1)Name from MLM_Registration WHERE UserID =(Select SponsorID from MLM_Registration WHERE UserID ='" + UserID + "' ))as SponsorName,Name,SponsorID,JoinType,LLeg,CONVERT(nvarchar,JoinDate,105) as JoinDate ,RLeg,isnull(LJoining,0)as LJoining,isnull(Rjoining,0)as Rjoining,CONVERT(nvarchar,PackageDate,105) as PackageDate,Package,pp.DonationAmount as damount from MLM_Registration mm right join PackageInfo pp ON mm.Package=pp.PackageName  where  UserID='" + UserID + "'", UserID);
            sb.AppendFormat("select Name,JoinType,LLeg,CONVERT(nvarchar,JoinDate,105) as JoinDate,Package,SponsorID ,RLeg,isnull(LJoining,0)as LJoining,isnull(Rjoining,0)as Rjoining,CONVERT(nvarchar,PackageDate,105) as PackageDate  from MLM_Registration where  UserID='{0}'", UserID);
            //     sb.AppendFormat("select Name,JoinType,LLeg,RLeg,isnull(LJoining,0)as LJoining,isnull(Rjoining,0)as Rjoining,JoinDate from MLM_Registration where  UserID='{0}'", UserID);

            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            return dt;
        }
        catch (Exception ex)
        {

            throw;
        }

    }
    public void ClearLeftRight()
    {
        L = null;
        R = null;
    }
    public void detail(string UserID)
    {
        CLEAR();
        DAL dal = new DAL();
        string message = string.Empty;
        DataTable UserDetail = new DataTable();
        UserDetail = fillUserDetail(UserID);
        if (UserDetail.Rows.Count > 0)
        {
            Lb1.Text = UserID;

            //ToolTip

            Lb1.Text = UserID;
            lblname.Text = UserDetail.Rows[0]["Name"].ToString();
            i1.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
            i1.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
            i1.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
            i1.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
            i1.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
            //i1.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
            i1.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
            //i1.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";


            //End
            //BUSINESS VALUME COUNT FUNCTION USING SP START
            //ShowleftrightBV(UserID);
            //BUSINESS VALUME COUNT FUNCTION USING SP END
            lblname.Text = UserDetail.Rows[0]["Name"].ToString();
            //lblljoin.Text = UserDetail.Rows[0]["LJoining"].ToString();
            //lblrjoin.Text = UserDetail.Rows[0]["Rjoining"].ToString();
            string jointype = UserDetail.Rows[0]["JoinType"].ToString();
            if (jointype == "Paid")
            {
                //i1.Src = "images/G.png";
                i1.ImageUrl = "assets/images/G.png";
            }
            else
            {
                //i1.Src = "images/R.png";
                i1.ImageUrl = "assets/images/R.png";
            }
        }
        check();
        ClearLeftRight();
        find(Lb1.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb2L.Visible = true;
            Lb2L.Text = L;

            UserDetail = fillUserDetail(L);
            if (UserDetail.Rows.Count > 0)
            {
                Lb2L.Text = L;

                //ToolTip

                Lb2L.Text = L;
                lbllb2L.Text = UserDetail.Rows[0]["Name"].ToString();
                i2.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i2.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i2.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i2.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i2.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i2.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i2.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i2.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", L);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                //i2.Src = "images/R.png";
                i2.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    //i2.Src = "images/G.png";
                    i2.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i2.Src = "images/R.png";
                    i2.ImageUrl = "assets/images/R.png";
                }
            }
        }

        if (!string.IsNullOrEmpty(R))
        {
            Lb3R.Visible = true;
            Lb3R.Text = R;


            UserDetail = fillUserDetail(R);
            if (UserDetail.Rows.Count > 0)
            {
                Lb3R.Text = R;

                //ToolTip

                Lb3R.Text = R;
                lblLB3R.Text = UserDetail.Rows[0]["Name"].ToString();
                i3.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i3.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i3.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i3.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i3.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i3.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i3.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i3.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", R);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                //i3.Src = "images/R.png";
                i3.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    // i3.Src = "images/G.png";
                    i3.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    i3.ImageUrl = "assets/images/R.png";
                    // i3.Src = "images/R.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb2L.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb4L.Visible = true;
            Lb4L.Text = L;

            UserDetail = fillUserDetail(L);
            if (UserDetail.Rows.Count > 0)
            {
                Lb4L.Text = L;

                //ToolTip

                Lb4L.Text = L;
                lblLb4L.Text = UserDetail.Rows[0]["Name"].ToString();
                i4.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i4.ToolTip += "Join Date : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i4.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i4.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i4.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i4.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i4.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i4.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }


            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", L);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                // i4.Src = "images/R.png";
                i4.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    // i4.Src = "images/G.png";
                    i4.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i4.Src = "images/R.png";
                    i4.ImageUrl = "assets/images/R.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb5R.Visible = true;
            Lb5R.Text = R;

            UserDetail = fillUserDetail(R);
            if (UserDetail.Rows.Count > 0)
            {
                Lb5R.Text = R;

                //ToolTip

                Lb5R.Text = R;
                lblLb5R.Text = UserDetail.Rows[0]["Name"].ToString();
                i5.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i5.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i5.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i5.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i5.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i5.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i5.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i5.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", R);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                //i5.Src = "images/R.png";
                i5.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    i5.ImageUrl = "assets/images/G.png";
                    //i5.Src = "images/G.png";
                }
                else
                {
                    //i5.Src = "images/R.png";
                    i5.ImageUrl = "assets/images/R.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb4L.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb8L.Visible = true;
            Lb8L.Text = L;

            UserDetail = fillUserDetail(L);
            if (UserDetail.Rows.Count > 0)
            {
                Lb8L.Text = L;

                //ToolTip

                Lb8L.Text = L;
                lblLb8L.Text = UserDetail.Rows[0]["Name"].ToString();
                i8.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i8.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i8.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i8.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i8.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i8.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i8.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i8.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", L);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                //i8.Src = "images/R.png";
                i8.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    //i8.Src = "images/G.png";
                    i8.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    // i8.Src = "images/R.png";
                    i8.ImageUrl = "assets/images/R.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb9R.Visible = true;
            Lb9R.Text = R;

            UserDetail = fillUserDetail(R);
            if (UserDetail.Rows.Count > 0)
            {
                Lb9R.Text = R;

                //ToolTip

                Lb9R.Text = R;
                lblLb9R.Text = UserDetail.Rows[0]["Name"].ToString();
                i9.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i9.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i9.ToolTip += "Activation Date: " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i9.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i9.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i9.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i9.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i9.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", R);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                // i9.Src = "images/R.png";
                i9.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    //i9.Src = "images/G.png";
                    i9.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i9.Src = "images/R.png";
                    i9.ImageUrl = "assets/images/R.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb5R.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb10L.Visible = true;
            Lb10L.Text = L;

            UserDetail = fillUserDetail(L);
            if (UserDetail.Rows.Count > 0)
            {
                Lb10L.Text = L;

                //ToolTip

                Lb10L.Text = L;
                lblLb10L.Text = UserDetail.Rows[0]["Name"].ToString();
                i10.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i10.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i10.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i10.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i10.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i10.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i10.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i10.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }



            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", L);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                //i10.Src = "images/R.png";
                i10.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    //i10.Src = "images/G.png";
                    i10.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    // i10.Src = "images/R.png";
                    i10.ImageUrl = "assets/images/R.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb11R.Visible = true;
            Lb11R.Text = R;

            UserDetail = fillUserDetail(R);
            if (UserDetail.Rows.Count > 0)
            {
                Lb11R.Text = R;

                //ToolTip

                Lb11R.Text = R;
                lblLb11R.Text = UserDetail.Rows[0]["Name"].ToString();
                i11.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i11.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i11.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i11.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i11.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i11.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i11.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i11.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", R);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                // i11.Src = "images/R.png";
                i11.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    // i11.Src = "images/G.png";
                    i11.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    // i11.Src = "images/R.png";
                    i11.ImageUrl = "assets/images/R.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb3R.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb6L.Visible = true;
            Lb6L.Text = L;


            UserDetail = fillUserDetail(L);
            if (UserDetail.Rows.Count > 0)
            {
                Lb6L.Text = L;

                //ToolTip

                Lb6L.Text = L;
                lblLb6L.Text = UserDetail.Rows[0]["Name"].ToString();
                i6.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i6.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i6.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i6.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i6.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i6.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i6.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i6.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }


            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", L);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                // i6.Src = "images/R.png";
                i6.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    // i6.Src = "images/G.png";
                    i6.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i6.Src = "images/R.png";
                    i6.ImageUrl = "assets/images/R.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb7R.Visible = true;
            Lb7R.Text = R;

            UserDetail = fillUserDetail(R);
            if (UserDetail.Rows.Count > 0)
            {
                Lb7R.Text = R;

                //ToolTip

                Lb7R.Text = R;
                lblLb7R.Text = UserDetail.Rows[0]["Name"].ToString();
                i7.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i7.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i7.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i7.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i7.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i7.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i7.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i7.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }


            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", R);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                // i7.Src = "images/R.png";
                i7.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    // i7.Src = "images/G.png";
                    i7.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i7.Src = "images/R.png";
                    i7.ImageUrl = "assets/images/R.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb6L.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb12L.Visible = true;
            Lb12L.Text = L;

            UserDetail = fillUserDetail(L);
            if (UserDetail.Rows.Count > 0)
            {
                Lb12L.Text = L;

                //ToolTip

                Lb12L.Text = L;
                lblLb12L.Text = UserDetail.Rows[0]["Name"].ToString();
                i12.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i12.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i12.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i12.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i12.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i12.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i12.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i12.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", L);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                //i12.Src = "images/R.png";
                i12.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    // i12.Src = "images/G.Png";
                    i12.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i12.Src = "images/R.png";
                    i12.ImageUrl = "assets/images/R.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb13R.Visible = true;
            Lb13R.Text = R;

            UserDetail = fillUserDetail(R);
            if (UserDetail.Rows.Count > 0)
            {
                Lb13R.Text = R;

                //ToolTip

                Lb13R.Text = R;
                lblLb13R.Text = UserDetail.Rows[0]["Name"].ToString();
                i13.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i13.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i13.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i13.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i13.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i13.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i13.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i13.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", R);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                //i13.Src = "images/R.png";
                i13.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    //i13.Src = "images/G.png";
                    i13.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i13.Src = "images/R.png";
                    i13.ImageUrl = "assets/images/R.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb7R.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb14L.Visible = true;
            Lb14L.Text = L;


            UserDetail = fillUserDetail(L);
            if (UserDetail.Rows.Count > 0)
            {
                Lb14L.Text = L;

                //ToolTip

                Lb14L.Text = L;
                lblLb14L.Text = UserDetail.Rows[0]["Name"].ToString();
                i14.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i14.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i14.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i14.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i14.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i14.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i14.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i14.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", L);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                //i14.Src = "images/R.png";
                i14.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    //i14.Src = "images/G.png";
                    i14.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i14.Src = "images/R.png";
                    i14.ImageUrl = "assets/images/R.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb15R.Visible = true;
            Lb15R.Text = R;

            UserDetail = fillUserDetail(R);
            if (UserDetail.Rows.Count > 0)
            {
                Lb15R.Text = R;

                //ToolTip

                Lb15R.Text = R;
                lblLb15R.Text = UserDetail.Rows[0]["Name"].ToString();
                i15.ToolTip = "Name: " + UserDetail.Rows[0]["Name"].ToString() + "\n";
                i15.ToolTip += "Join Date. : " + UserDetail.Rows[0]["JoinDate"].ToString() + "\n";
                i15.ToolTip += "Activation Date : " + UserDetail.Rows[0]["PackageDate"].ToString() + "\n";
                i15.ToolTip += "Join Type : " + UserDetail.Rows[0]["Jointype"].ToString() + "\n";
                i15.ToolTip += "Sponsor ID : " + UserDetail.Rows[0]["SponsorID"].ToString() + "\n";
                //i15.ToolTip += "SponsorName : " + UserDetail.Rows[0]["SponsorName"].ToString() + "\n";
                i15.ToolTip += "Package : " + UserDetail.Rows[0]["Package"].ToString() + "\n";
                //i15.ToolTip += "Donation Amount : " + UserDetail.Rows[0]["damount"].ToString() + "\n";

                //End
            }

            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType from MLM_Registration where UserID='{0}'", R);
            object JoinType = dal.Getscalar(JT.ToString(), ref message);
            if (JoinType is DBNull)
            {
                // i15.Src = "images/R.png";
                i15.ImageUrl = "assets/images/R.png";
            }
            else if (JoinType != null)
            {
                string UserJointype = JoinType.ToString();
                if (UserJointype == "Paid")
                {
                    //i15.Src = "images/G.png";
                    i15.ImageUrl = "assets/images/G.png";
                }
                else
                {
                    //i15.Src = "images/R.png";
                    i15.ImageUrl = "assets/images/R.png";
                }
            }
        }

    }

    public void check()
    {
        Lb2L.Text = "Join Now";
        Lb3R.Text = "Join Now";
        Lb4L.Text = "Join Now";
        Lb5R.Text = "Join Now";
        Lb6L.Text = "Join Now";
        Lb7R.Text = "Join Now";
        Lb8L.Text = "Join Now";
        Lb9R.Text = "Join Now";
        Lb10L.Text = "Join Now";
        Lb11R.Text = "Join Now";
        Lb12L.Text = "Join Now";
        Lb13R.Text = "Join Now";
        Lb14L.Text = "Join Now";
        Lb15R.Text = "Join Now";
        i2.ImageUrl = "assets/images/B.png";
        i3.ImageUrl = "assets/images/B.png";
        i4.ImageUrl = "assets/images/B.png";
        i5.ImageUrl = "assets/images/B.png";
        i6.ImageUrl = "assets/images/B.png";
        i7.ImageUrl = "assets/images/B.png";
        i8.ImageUrl = "assets/images/B.png";
        i9.ImageUrl = "assets/images/B.png";
        i10.ImageUrl = "assets/images/B.png";
        i11.ImageUrl = "assets/images/B.png";
        i12.ImageUrl = "assets/images/B.png";
        i13.ImageUrl = "assets/images/B.png";
        i14.ImageUrl = "assets/images/B.png";
        i15.ImageUrl = "assets/images/B.png";
        // i2.Src = "images/B.png";
        // i3.Src = "images/B.png";
        //i4.Src = "images/B.png";
        // i5.Src = "images/B.png";
        // i6.Src = "images/B.png";
        // i7.Src = "images/B.png";
        //i8.Src = "images/B.png";
        //i9.Src = "images/B.png";
        //i10.Src = "images/B.png";
        //i11.Src = "images/B.png";
        //i12.Src = "images/B.png";
        //i13.Src = "images/B.png";
        //i14.Src = "images/B.png";
        //i15.Src = "images/B.png";
        i1.ToolTip = "";
        i2.ToolTip = "";
        i3.ToolTip = "";
        i4.ToolTip = "";
        i5.ToolTip = "";
        i6.ToolTip = "";
        i7.ToolTip = "";
        i8.ToolTip = "";
        i9.ToolTip = "";
        i10.ToolTip = "";
        i11.ToolTip = "";
        i12.ToolTip = "";
        i13.ToolTip = "";
        i14.ToolTip = "";
        i15.ToolTip = "";
    }
    protected void Lb2L_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        CountLeft_Right_Carry_Count(Lb2L.Text);
        if (Lb2L.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb1.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb1.Text + "&Position=" + "LLeg" + "&Placeunder=" + Lb1.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + Lb1.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + Session["UserID"].ToString());
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb2L.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb2L.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb2L.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb3R_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb3R.Text);
        txtSearch.Text = string.Empty;
        if (Lb3R.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb1.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb1.Text + "&Position=" + "RLeg" + "&Placeunder=" + Lb1.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + Lb1.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + Session["UserID"].ToString());
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb3R.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb3R.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb3R.Text);
            btnback.Visible = true;
        }
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        try
        {
            txtSearch.Text = string.Empty;
            UserIDList = ((ArrayList)Session["temp"]);
            int count = UserIDList.Count - 1;
            if (count > 0)
            {
                string last = UserIDList[count - 1].ToString();
                UserIDList.Remove(last);
                Session["temp"] = UserIDList;
                detail(last);
                CountLeft_Right_Carry_Count(last);


            }
            else if (count == 0)
            {
                detail(Session["UserID"].ToString());
               CountLeft_Right_Carry_Count(Session["UserID"].ToString());

                Session["temp"] = null;
                btnback.Visible = false;
            }
        }
        catch(Exception ex)
        {
            Response.Redirect("auth-mybinarytree.aspx");
            //throw;
        }
    }
    protected void Lb4L_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb4L.Text);

        txtSearch.Text = string.Empty;
        if (Lb4L.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb2L.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb2L.Text + "&Position=" + "LLeg" + "&Placeunder=" + Lb2L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + Lb2L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + lbllb2L.Text);
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb4L.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb4L.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb4L.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb5R_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb5R.Text);

        txtSearch.Text = string.Empty;
        if (Lb5R.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb2L.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb2L.Text + "&Position=" + "RLeg" + "&Placeunder=" + Lb2L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + Lb2L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + lbllb2L.Text);
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb5R.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb5R.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb5R.Text);
            btnback.Visible = true;
        }

    }
    protected void Lb6L_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb6L.Text);

        txtSearch.Text = string.Empty;
        if (Lb6L.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb3R.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb3R.Text + "&Position=" + "LLeg" + "&Placeunder=" + Lb3R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + Lb3R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg");
            }
            else
            {
                return;
            }

        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb6L.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb6L.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb6L.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb7R_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb7R.Text);

        txtSearch.Text = string.Empty;
        if (Lb7R.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }


            if (Lb3R.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb3R.Text + "&Position=" + "RLeg" + "&Placeunder=" + Lb3R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + Lb3R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb7R.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb7R.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb7R.Text);
            btnback.Visible = true;
        }

    }
    protected void Lb8L_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb8L.Text);

        txtSearch.Text = string.Empty;
        if (Lb8L.Text == "Join Now")
        {
            if (Lb4L.Text != "Join Now")
            {
                string msg = "";
                DAL dal = new DAL();
                DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
                if (dt.Rows.Count > 0)
                {
                    websitename = dt.Rows[0]["Website"].ToString();
                }
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb4L.Text + "&Position=" + "LLeg" + "&Placeunder=" + Lb4L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + Lb4L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb8L.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb8L.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb8L.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb9R_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb9R.Text);

        txtSearch.Text = string.Empty;
        if (Lb9R.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb4L.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb4L.Text + "&Position=" + "RLeg" + "&Placeunder=" + Lb4L.Text);
               // Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + Lb4L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb9R.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb9R.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb9R.Text);
            btnback.Visible = true;
        }

    }
    protected void Lb10L_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb10L.Text);

        txtSearch.Text = string.Empty;
        if (Lb10L.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb5R.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb5R.Text + "&Position=" + "LLeg" + "&Placeunder=" + Lb5R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + Lb5R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb10L.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb10L.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb10L.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb11R_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb11R.Text);

        txtSearch.Text = string.Empty;
        if (Lb11R.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb5R.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb5R.Text + "&Position=" + "RLeg" + "&Placeunder=" + Lb5R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + Lb5R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb11R.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb11R.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb11R.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb12L_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb12L.Text);

        txtSearch.Text = string.Empty;
        if (Lb12L.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb6L.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb6L.Text + "&Position=" + "LLeg" + "&Placeunder=" + Lb6L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + Lb6L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb12L.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb12L.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb12L.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb13R_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb13R.Text);

        txtSearch.Text = string.Empty;
        if (Lb13R.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb6L.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb6L.Text + "&Position=" + "RLeg" + "&Placeunder=" + Lb6L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + Lb6L.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb13R.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb13R.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb13R.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb14L_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb14L.Text);

        txtSearch.Text = string.Empty;
        if (Lb14L.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb7R.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb7R.Text + "&Position=" + "LLeg" + "&Placeunder=" + Lb7R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg" + "&Placeunder=" + Lb7R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb14L.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb14L.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb14L.Text);
            btnback.Visible = true;
        }
    }
    protected void Lb15R_Click(object sender, EventArgs e)
    {
        CountLeft_Right_Carry_Count(Lb15R.Text);

        txtSearch.Text = string.Empty;
        if (Lb15R.Text == "Join Now")
        {
            string msg = "";
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
            if (dt.Rows.Count > 0)
            {
                websitename = dt.Rows[0]["Website"].ToString();
            }

            if (Lb7R.Text != "Join Now")
            {
                Response.Redirect("/customer/auth-binaryregister.aspx?Refferalid=" + Lb7R.Text + "&Position=" + "RLeg" + "&Placeunder=" + Lb7R.Text);
               // Response.Redirect("" + websitename + "/customer/auth-binaryregister.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "RLeg" + "&Placeunder=" + Lb7R.Text);
                //Response.Redirect("" + websitename + "/customer/auth-register-binary.aspx?Refferalid=" + Session["UserID"].ToString() + "&Position=" + "LLeg");
            }
            else
            {
                return;
            }
        }
        else
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(Lb15R.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb15R.Text);
                Session["temp"] = UserIDList;
            }
            detail(Lb15R.Text);
            btnback.Visible = true;
        }
    }

    //---------------------- Sales values Code Goes here-------------------------
    public void ShowSaleValuesofteam()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            string LeftUser = null;
            string RightUser = null;
            int OwnSV = 0;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg,isnull(SV,0)as SV from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();
                OwnSV = Convert.ToInt32(dt.Rows[0]["SV"]);
                if (LeftUser != null)
                {
                    ShowSalesValuesofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowSalesValuesofteamB(RightUser);
                }
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    public void ShowSalesValuesofteamA(string Leftuserid)
    {
        try
        {
            string L = null;
            string R = null;
            int TeamASV = 0;
            string UserID = Leftuserid;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg,isnull(SV,0)as SV from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    TeamASV += Convert.ToInt32(UserDetail.Rows[0]["SV"]);
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
            lblteamAsvp.Text = TeamASV.ToString();
        }
        catch (Exception)
        {

            throw;
        }
    }
    public void ShowSalesValuesofteamB(string Rightuserid)
    {
        try
        {
            string L = null;
            string R = null;
            int TeamBSV = 0;
            string UserID = Rightuserid;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg,isnull(SV,0)as SV from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    TeamBSV += Convert.ToInt32(UserDetail.Rows[0]["SV"]);
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
            lblteamBsvp.Text = TeamBSV.ToString();
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        DAL dal = new DAL();
        string message = string.Empty;

        DataTable dtLoginUser = dal.Gettable("Select DID From MLM_Registration Where UserID='" + Session["UserID"].ToString() + "'", ref message);
        DataTable dtSearchUser = dal.Gettable("Select DID From MLM_Registration Where UserID='" + txtSearch.Text + "'", ref message);
        int LoginDID = Convert.ToInt32(dtLoginUser.Rows[0]["DID"]);
        int SearchDID = 0;
        if (dtSearchUser.Rows.Count > 0)
        {
            SearchDID = Convert.ToInt32(dtSearchUser.Rows[0]["DID"]);
        }
        else
        {
            SearchDID = 0;
        }

        if (SearchDID > LoginDID)
        {
            if (Session["temp"] != null)
            {
                UserIDList = ((ArrayList)Session["temp"]);
                UserIDList.Add(txtSearch.Text);
                Session["temp"] = UserIDList;
            }
            else
            {
                UserIDList.Add(txtSearch.Text);
                Session["temp"] = UserIDList;
            }
            detail(txtSearch.Text);
            btnback.Visible = true;
        }
        else
        {
            txtSearch.Text = string.Empty;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You can not search upline/crossline UserID.')", true);
            Label lblalert = new Label();
            //  lblalert.Text = "Invalid ID";

        }

    }

    public void CLEAR()
    {
        lbllb2L.Text = string.Empty;
        lblLB3R.Text = string.Empty;
        lblLb4L.Text = string.Empty;
        lblLb5R.Text = string.Empty;
        lblLb6L.Text = string.Empty;
        lblLb7R.Text = string.Empty;
        lblLb8L.Text = string.Empty;
        lblLb9R.Text = string.Empty;
        lblLb10L.Text = string.Empty;
        lblLb11R.Text = string.Empty;
        lblLb12L.Text = string.Empty;
        lblLb13R.Text = string.Empty;
        lblLb14L.Text = string.Empty;
        lblLb15R.Text = string.Empty;


    }

}