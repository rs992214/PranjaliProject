﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Text;

public partial class customer_auth_TransferE_Pin : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            int pin = Convert.ToInt32(Request.QueryString["Pin"]);
            if(pin > 0)
            {
                
                 ShowPopupMessage("Pin has been Transfered To Member.", PopupMessageType.Success);
            }
            showname();
            GetData();
        }
    }
    public void showname()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select Name from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            object Name = dal.Getscalar(sb.ToString(), ref message);
            if (Name is DBNull)
            {
                lblname.Text = "Demo";
            }
            else
            {
                if (Name != null)
                {
                    lblname.Text = Name.ToString();
                }
                else
                {
                    lblname.Text = "Demo";
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void GetData()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("select Pg.ID,pg.PinNo,pack.PackageName,Pg.Status,pg.TransferBy,pg.TransferTo,pg.UpdationDate from PinGenerateNew Pg inner join PackageInfo pack on Pg.PackageID=pack.ID where TransferTo = '"+UserID+"' And Status='Unused'", ref message);
            if (dt.Rows.Count > 0)
            {
                GV_PinNoList.DataSource = dt;
                GV_PinNoList.DataBind();
            }
            else
            {
                GV_PinNoList.DataSource = dt;
                GV_PinNoList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnTransfer_Click(object sender, EventArgs e)
    {
        //try
        //{
        //    if (Session["UserID"] != null)
        //    {
        //        string UserID = Session["UserID"].ToString();
        //        LinkButton btn = (LinkButton)(sender);
        //        lblID.Text = btn.CommandArgument;
        //        DAL objDAL = new DAL();
        //        DataTable dt = objDAL.Gettable("Select PG.ID,PG.UserID,PG.PinNo,P.Amount From PinGenerateNew PG Inner Join PackageInfo P On P.ID=PG.PackageID Where PG.UserID='" + UserID + "' and PG.ID='" + lblID.Text + "'", ref message);
        //        if (dt.Rows.Count > 0)
        //        {
        //            txtPinNo.Text = dt.Rows[0]["PinNo"].ToString();
        //            lblPackageAmount.Text = dt.Rows[0]["Amount"].ToString();
        //            ClientScript.RegisterStartupScript(this.GetType(), "Pop", "openModal();", true);
        //        }
        //    }
        //    else
        //    {
        //        Response.Redirect("Logout.aspx");
        //    }
        //}
        //catch (Exception ex)
        //{
        //    ShowPopupMessage(ex.Message, PopupMessageType.Error);
        //}
    }

    [System.Web.Services.WebMethod]
    public static string CheckIsValidMemberID(string MemberID)
    {
        string _ValidMemberID = string.Empty;
        string message = string.Empty;
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID From MLM_Registration Where UserID='" + MemberID + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            _ValidMemberID = dt.Rows[0]["UserID"].ToString();
            MemberID = _ValidMemberID;
        }
        else
        {
            MemberID = string.Empty;
        }

        return MemberID;
    }
    protected void txtMemberID_TextChanged(object sender, EventArgs e)
    {
        //DAL objDAL = new DAL();
        //DataTable dt = objDAL.Gettable("Select UserID From MLM_Registration Where UserID='" + txtMemberID.Text + "' and UserID!='" + Session["UserID"].ToString() + "'", ref message);
        //if (dt.Rows.Count > 0)
        //{
        //    txtMemberID.Text = dt.Rows[0]["UserID"].ToString();
        //    _Valid.Visible = true;
        //    lblMSG.Visible = false;
        //}
        //else
        //{
        //    txtMemberID.Text = string.Empty;
        //    _Valid.Visible = false;
        //    lblMSG.Visible = true;
        //}
    }

    //private void InsertWalletLedger_DR()
    //{
    //    decimal CR = 0;
    //    decimal DR = Convert.ToDecimal(lblPackageAmount.Text);
    //    string Description = "Pin Purchased.";
    //    con = new SqlConnection(connstring);
    //    con.Open();
    //    cmd = new SqlCommand("Ledger_Wallet_ALL", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.AddWithValue("@UserID", txtMemberID.Text);
    //    cmd.Parameters.AddWithValue("@TransactionType", "DR");
    //    cmd.Parameters.AddWithValue("@CR", CR);
    //    cmd.Parameters.AddWithValue("@DR", DR);
    //    cmd.Parameters.AddWithValue("Descriptions", Description);
    //    cmd.Parameters.AddWithValue("@Mode", "IN");
    //    int flag = cmd.ExecuteNonQuery();
    //    con.Close();

    //}
    private void LedgerCredit()
    {
        //decimal CR = Convert.ToDecimal(lblPackageAmount.Text);
        //decimal DR = 0;
        //string Description = "Pin Purchased.";
        //string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        //SqlConnection con = new SqlConnection(connstring);
        //con.Open();
        //SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        //cmd.CommandType = CommandType.StoredProcedure;
        //cmd.Parameters.AddWithValue("@UserID", txtMemberID.Text);
        //cmd.Parameters.AddWithValue("@TransactionType", "CR");
        //cmd.Parameters.AddWithValue("@CR", CR);
        //cmd.Parameters.AddWithValue("@DR", DR);
        //cmd.Parameters.AddWithValue("@Descriptions", Description);
        //cmd.Parameters.AddWithValue("@Mode", "IN");
        //int flag = cmd.ExecuteNonQuery();
    }
    private void LedgerDebit()
    {
        //decimal CR = 0;
        //decimal DR = Convert.ToDecimal(lblPackageAmount.Text);
        //string Description = "Pin Purchased.";
        //string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        //SqlConnection con = new SqlConnection(connstring);
        //con.Open();
        //SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        //cmd.CommandType = CommandType.StoredProcedure;
        //cmd.Parameters.AddWithValue("@UserID", txtMemberID.Text);
        //cmd.Parameters.AddWithValue("@TransactionType", "DR");
        //cmd.Parameters.AddWithValue("@CR", CR);
        //cmd.Parameters.AddWithValue("@DR", DR);
        //cmd.Parameters.AddWithValue("@Descriptions", Description);
        //cmd.Parameters.AddWithValue("@Mode", "IN");
        //int flag = cmd.ExecuteNonQuery();
    }

    protected void btnProceed_Click(object sender, EventArgs e)
    {
        //try
        //{
        //    if (Session["UserID"] != null)
        //    {
        //        string UserID = Session["UserID"].ToString();
        //        con = new SqlConnection(connstring);
        //        con.Open();
        //        //cmd = new SqlCommand("PinGenerate_ALL", con);
        //        cmd = new SqlCommand("PinGenerateNew_ALL", con);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@UserID", UserID);
        //        cmd.Parameters.AddWithValue("@TransferBy", txtMemberID.Text);
        //        cmd.Parameters.AddWithValue("@ID", lblID.Text);
        //        cmd.Parameters.AddWithValue("@Mode", "TRANSFER_IN");
        //        int flag = cmd.ExecuteNonQuery();
        //        con.Close();
        //        if (flag > 0)
        //        {
        //            LedgerCredit();
        //            LedgerDebit();
        //            GetData();
        //            ShowPopupMessage("Pin has been Transfered To Member.", PopupMessageType.Success);

        //        }
        //        else
        //        {
        //            ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
        //        }

        //    }
        //    else
        //    {
        //        Response.Redirect("Logout.aspx");
        //    }
        //}
        //catch (Exception ex)
        //{
        //    ShowPopupMessage(ex.Message, PopupMessageType.Error);
        //}
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/Company/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    /// </summary>
    /// </summary>
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void btnTransfer_Command(object sender, CommandEventArgs e)
    {
        string id = e.CommandArgument.ToString();
        Response.Redirect("auth-transferEPIN.aspx?id=" + id);
    }
}