﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net;
using System.Web.Script.Serialization;
using System.Text;
using DataAccessLayer;

public partial class frmComposeSMS : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
              
            if (!IsPostBack)
            {
                if (Session["UserName"] != null)
                {
                    showinfo();
                    showtemplates();
                }
                else
                {
                    Response.Redirect("Logout.aspx");
                }
            }
       
    }
    static  string userid = string.Empty;
    static  string password = string.Empty;
    static  string senderid = string.Empty;
    static  string route = string.Empty;
    static string Status = string.Empty;
    public void showinfo()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from Smsmaster", ref message);
            if (dt.Rows.Count > 0)
            {
                userid = dt.Rows[0]["Userid"].ToString();
                password = dt.Rows[0]["Password"].ToString();
                senderid = dt.Rows[0]["Senderid"].ToString();
                route = dt.Rows[0]["Routeid"].ToString();
                Status = dt.Rows[0]["Status"].ToString();
                if (Status == "Inactive")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('SMS is In inactive Mode.Change the Status From SMS Matser')", true);
                    btnSend.Enabled = false;
                }
                else
                {
                    btnSend.Enabled = true;
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Configure SMS Setting First.')", true);
                btnSend.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
   

    public void reset()
    {
        txtMobileNumber.Text = "";
        txtMessage.Text = "";
    }
    public void insert()
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Insert into SMSHistory(MobileNo,Message)");
            sb.AppendFormat("Values('{0}','{1}')",txtMobileNumber.Text,txtMessage.Text);
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected>0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Message Send Successfully')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + message + "')", true);
            }

        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);
        }
      
    }


   
    protected void btnSend_Click(object sender, EventArgs e)
    {
        if(txtMessage.Text!=string.Empty && txtMobileNumber.Text!=string.Empty)
        {
            // string senderusername = "probuztech";
            string sURL;
            StreamReader objReader;
            //FOR ECONOMY (PROMOTIONL) ROUT 12 FOR TRANSACTIONAL ROUTE 7

            sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userid + "&password=" + password + "&sender=" + senderid + "" + "&to=" + txtMobileNumber.Text + "&message=" + txtMessage.Text + " &reqid=1&format={json|text}&route_id=" + route + "";

            WebRequest wrGETURL;
            wrGETURL = WebRequest.Create(sURL);

            try
            {
                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                objReader.Close();
                insert();
                reset();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Mobile No And Massage')", true);
        }
        
           
    }
        
    
    protected void OnSelectedIndexChanged(object sender, EventArgs e)
    {
        txtMessage.Text = GridView1.SelectedRow.Cells[1].Text;

    }
    
    public void showtemplates()
    {

        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select Template from Template order by TemplateID desc");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
           GridView1.DataBind();
        }
        else
        {
           GridView1.DataSource = null;
           GridView1.DataBind();
        }
 
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtMessage.Text = GridView1.SelectedRow.Cells[1].Text;
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        showtemplates();
    }
}