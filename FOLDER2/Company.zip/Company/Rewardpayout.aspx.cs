﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;
using System.Web.Script.Serialization;
using System.Drawing;
using System.IO;

public partial class Company_Rewardpayout : System.Web.UI.Page
{

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                ShowPayout();
                btnexcel.Visible = false;
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void ShowPayout()
    {
        try
        {
            drppayout.DataTextField = "PayoutBetween";
            drppayout.DataValueField = "PayoutBetween";
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select DISTINCT PayoutBetween,max(Date) from MemberPayment where Descriptions in ('Direct Income Weekly','Pair 7','Pair 15','Pair 25','Pair 50','Pair 100','Pair 250','Pair 500','Pair 750','Pair 1000') group by PayoutBetween order by max(Date)");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                drppayout.DataSource = dt;
                drppayout.DataBind();
                drppayout.Items.Insert(0, new ListItem("Select Payout Date", "0"));
            }
            else
            {
                drppayout.DataSource = null;
                drppayout.DataBind();
                drppayout.Items.Insert(0, new ListItem("Select Payout Date", "0"));
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    public void ShowPayoutSheet()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select MR.UserID, MR.Name, BP.PaymentID, BP.Reward, BP.PayoutPair, BP.PayoutAmount, BP.AdminCharge, BP.TDS, BP.NetAmount, BP.Descriptions, BP.PaymentStatus, BP.PaymentMode, BP.ReferenceNo, convert(nvarchar(10), BP.PaymentGenrateDate, 103) as PaymentGenrateDate, convert(nvarchar(10), BP.PaymentReleaseDate, 103) as PaymentDate, MLU.PayeeName, MLU.BankName, MLU.AccountNo, MLU.IFSCCode, MLU.PANNO, MLU.Paytm from MemberPayment as BP inner join MLM_Registration as MR on BP.UserID = MR.UserID Left join MLM_UserDetail as MLU on MR.UserID = MLU.UserID where   bp.NetAmount!=0  and Bp.PayoutBetween = '{0}'", drppayout.SelectedValue);

            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                GridView1.AllowPaging = false;
                GridView1.PageSize = dt.Rows.Count;
                btnexcel.Visible = true;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnexcel.Visible = false;

            }

        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ShowPayoutSheet();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowPayoutSheet();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        ShowPayoutSheet();

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            string paymentID = GridView1.DataKeys[e.RowIndex].Values["PaymentID"].ToString();
            string paymentstatus = ((DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList1")).SelectedItem.Text;
            string paymentmode = ((DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList2")).SelectedItem.Text;
            string refernceno = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtrefernceno")).Text;
            string paymentDate = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox3")).Text;
            string[] dte = paymentDate.Split('/');
            string finaldate = dte[2] + "/" + dte[1] + "/" + dte[0];
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("update MemberPayment set PaymentStatus='{0}',PaymentMode='{1}',ReferenceNo='{2}',PaymentReleaseDate='{3}' where PaymentID='{4}'", paymentstatus, paymentmode, refernceno, finaldate, paymentID);
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Payment Info Updated')", true);

            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }

        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            GridView1.EditIndex = -1;
            ShowPayoutSheet();
        }

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        ShowPayoutSheet();
    }
    protected void btnexcel_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string filename = drppayout.SelectedItem.Text;
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename='" + filename + "'.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridView1.AllowPaging = false;
                this.ShowPayoutSheet();
                GridView1.HeaderRow.Cells[1].Visible = false;
                GridView1.HeaderRow.Cells[2].Visible = false;
                GridView1.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridView1.HeaderRow.Cells)
                {
                    cell.BackColor = GridView1.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridView1.Rows)
                {
                    row.Cells[1].Visible = false;
                    row.Cells[2].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridView1.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridView1.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridView1.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (Exception)
        {

            throw;
        }

    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DAL dal = new DAL();
            string userID = e.Row.Cells[7].Text;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", userID);
            DataTable jointype = dal.Gettable(sb.ToString(), ref message);


            if (jointype.Rows[0]["JoinType"].ToString() == "Free")
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/orange.svg";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Not Procced";
                e.Row.Cells[2].Enabled = false;
            }
            else if (jointype.Rows[0]["Status"].ToString() == "Inactive")
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/red.png";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Not Procced";
                e.Row.Cells[2].Enabled = false;
            }
            else
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/green.png";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Procced";
                e.Row.Cells[2].Enabled = true;
            }

        }
    }
}