﻿using DataAccessLayer;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Reneval : System.Web.UI.Page
{
    string RenewalList = string.Empty;
    string message = string.Empty;
    int i;
    DAL dal = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetDate();
           // ShowData();
        }
        //string result = DateOfJoin.AddDays(Convert.ToInt32(335)).ToString("dd-MM-yyyy");
    }
    StringBuilder sba = new StringBuilder();
    // StringBuilder sb = new StringBuilder();
    void GetDate()
    {

        sba.AppendFormat("SELECT UserID,Name,JoinDate,(JoinDate + 364) as RenewalDate FROM MLM_Registration Order By DID");
        DataTable dt = dal.Gettable(sba.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        //List<MLMUserDetailProperty> detail = new List<MLMUserDetailProperty>();
        //do
        //{
        //    string message = string.Empty;
        //    StringBuilder sb = new StringBuilder();
        //    sb.AppendFormat("SELECT UserID FROM MLM_Registration");
        //    DataTable dt1 = dal.Gettable(sb.ToString(), ref message);
        //    if (dt1.Rows.Count > 0)
        //    {
        //        for (int i = 0; i <= dt1.Rows.Count; i++)
        //        {
        //            string userid = "";
        //            userid = dt1.Rows[i]["UserID"].ToString();
        //            List lst = new List();
        //            lst.Add(userid);
        //            sb.Clear();
        //            DataTable dtUser1 = new DataTable();
        //            dtUser1 = dal.Gettable("SELECT UserID,Name,JoinDate FROM MLM_Registration where UserID='" + userid + "'", ref message);
        //            if (dtUser1.Rows.Count > 0)
        //            {
        //                DateTime JoinDate = new DateTime();
        //                JoinDate = Convert.ToDateTime(dtUser1.Rows[i]["JoinDate"]);
        //                RenewalList = Convert.ToString(JoinDate.AddDays(335));

        //                detail.Add(new MLMUserDetailProperty
        //                {
        //                    UserID = dtUser1.Rows[0]["UserID"].ToString(),
        //                    Name = dtUser1.Rows[0]["Name"].ToString(),
        //                    JoinDate = dtUser1.Rows[0]["JoinDate"].ToString(),
        //                    RenewalDate = dtUser1.Rows.Add(RenewalList, true).ToString()
        //                });

        //            }
        //        }
        //    }
        //} while (User != null);
        //    GridView1.DataSource = detail.ToList();
        //    GridView1.DataBind();

    }

    //sba.AppendFormat("SELECT UserID FROM MLM_Registration");
    //DataTable dt1 = dal.Gettable(sba.ToString(), ref message);
    //if (dt1.Rows.Count > 0)
    //{
    //    for (int i = 0; i <= dt1.Rows.Count; i++)
    //    {
    //        string userid = "";
    //        userid = dt1.Rows[i]["UserID"].ToString();
    //        List lst = new List();
    //        lst.Add(userid);
    //        sb.Clear();
    //        sb.AppendFormat("SELECT JoinDate FROM MLM_Registration where UserID='"+ userid + "'");
    //        DataTable dt = dal.Gettable(sb.ToString(), ref message);
    //        if (dt.Rows.Count > 0)
    //        {
    //            for (int j = 0; j <= dt.Rows.Count; j++)
    //            {
    //                DateTime JoinDate = new DateTime();
    //                  JoinDate = Convert.ToDateTime(dt.Rows[i]["JoinDate"]);
    //                RenewalDate = Convert.ToString(JoinDate.AddDays(335));
    //                List list = new List();
    //                list.Add(RenewalDate);

    //                DataTable table = ConvertListToDataTable(list);
    //                GridView1.DataSource = table;

    //            }





    //static DataTable ConvertListToDataTable(List<string[]> list)
    //{
    //    // New table.
    //    DataTable table = new DataTable();

    //    // Get max columns.
    //    int columns = 0;
    //    foreach (var array in list)
    //    {
    //        if (array.Length > columns)
    //        {
    //            columns = array.Length;
    //        }
    //    }

    //    // Add columns.
    //    for (int i = 0; i < columns; i++)
    //    {
    //        table.Columns.Add();
    //    }

    //    // Add rows.
    //    foreach (var array in list)
    //    {
    //        table.Rows.Add(array);
    //    }

    //    return table;
    //}
    //sb.AppendFormat("SELECT JoinDate FROM MLM_Registration");
    //DataTable dt = dal.Gettable(sba.ToString(), ref message);
    //if (dt.Rows.Count > 0)
    //{
    //        for (int i=1;i<= Convert.ToInt32(dt);i++)
    //{
    //    {
    //        DataRow dr;

    //       string[]  DateOfJoin = ["JoinDate"];

    //        result = Convert.ToBase64String(DateOfJoin) + 335;

    //        //string[,] row1 = { { result.ToString() } };
    //        //DataTable table = new DataTable();
    //        //table.Columns.Add("Renewal Date", typeof(string));
    //        //for (int i = 0; i <= row1.GetUpperBound(0); i++)
    //        //{
    //        //    table.Rows.Add();
    //        //    table.Rows[i]["Renewal Date"] = row1[i, 335];
    //        //}
    //    }

    //    GridView2.DataSource = dt;
    //    GridView2.DataBind();
    //}
    //GridView2.DataSource = dt;
    //GridView2.DataBind();
    //    }

    //    DataTable dt3 = dt1.Copy();
    //    for (int column = 0; column < dt.Columns.Count; column++)
    //    {
    //        dt3.Columns.Add(dt.Columns[column].ColumnName);
    //    }
    //    for (int row = 0; row < dt3.Rows.Count; row++)
    //    {
    //        for (int column = 0; column < dt.Columns.Count; column++)
    //        {
    //            dt3.Rows[row][dt1.Columns[column].ColumnName] = dt.Rows[row][column];
    //        }
    //    }
    //    GridView1.DataSource = dt3;
    //    GridView1.DataBind();
    //    // string result = DateOfJoin.AddDays(335).ToString();
    //}
    //void ShowData()
    //{
    //    string[,] row1 = { { result.ToString() } };
    //    DataTable table = new DataTable();
    //    table.Columns.Add("Renew Date", typeof(string));
    //    for (int i = 0; i <= row1.GetUpperBound(0); i++)
    //    {
    //        table.Rows.Add();
    //        table.Rows[i]["Renew Date"] = row1[i, 0];
    //    }

    //    GridView1.DataSource = table;
    //    GridView1.DataBind();
    //}

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        for(int i=GridView1.Rows.Count;i<GridView1.Rows.Count; i--)
       {
          string userid = GridView1.SelectedRow.Cells[0].Text;
          string RenewalDate = GridView1.SelectedRow.Cells[3].Text;
          sba.AppendFormat("update MLM_Registration set RenewalDate='" + Convert.ToDateTime(RenewalDate).ToString("yyyy-MM-dd") + "' where UserID='" + userid + "'" );
          int rowaffected = dal.Executequery(sba.ToString(), ref message);
            if(rowaffected > 0)
            {
                GridView1.Rows[i].BackColor = Color.Green;
            }
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int count = GridView1.Rows.Count;
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {
                //Label userid = (Label)row.FindControl("lblUserID");
                if(e.CommandName == "Renewal" && e.CommandArgument.ToString() != string.Empty)
                {
                    Label renewaldate = (Label)row.FindControl("lblrenewaldate");
                    sba.AppendFormat("update MLM_Registration set RenewalDate='" + Convert.ToDateTime(renewaldate.Text).ToString("yyyy-MM-dd") + "' where UserID='" + e.CommandArgument + "'");
                    int rowaffected = dal.Executequery(sba.ToString(), ref message);
                    if (rowaffected > 0)
                    {
                        GridView1.Rows[i].BackColor = Color.Green;
                        GetDate();
                    }
                }
            }
        }
    }


    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = new DataTable();
            if (txtfromdate.Text != null && txtfromdate.Text != "" && txttodate.Text != null && txttodate.Text != "")
            {
                dt = dal.Gettable("select UserID,SponsorID,JoinType,Name,JoinDate,(JoinDate + 364) as RenewalDate from MLM_Registration where JoinDate between '" + txtfromdate.Text + "' and '" + txttodate.Text + "' Order By DID", ref message);
            }
            else if (txtUserID.Text != null && txtUserID.Text != "")
            {
                dt = dal.Gettable("select UserID,SponsorID,JoinType,Name,JoinDate,(JoinDate + 364) as RenewalDate from MLM_Registration where UserID='" + txtUserID.Text + "' Order By DID", ref message);
            }
            else
            {
                dt = dal.Gettable("select UserID,SponsorID,JoinType,Name,JoinDate,(JoinDate + 364) as RenewalDate from MLM_Registration Order By DID", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            // ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnrefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("Reneval.aspx");
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowState == DataControlRowState.Alternate)
        {
            string UserID = e.Row.Cells[0].Text.ToString();
            DataTable dt = dal.Gettable("Select RenewalDate from MLM_Registration where UserID='"+UserID+"'",ref message);
            if(dt.Rows.Count > 0)
            {
                string date = dt.Rows[0]["RenewalDate"].ToString();
                if(date != "")
                {
                    e.Row.BackColor = Color.GreenYellow;
                }
            }
        }
        //Response.Redirect(Request.Url.AbsoluteUri);
    }


    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        int count = GridView1.Rows.Count;
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {
               Label userid = (Label)row.FindControl("lblUserID");
                DataTable dt = dal.Gettable("Select RenewalDate from MLM_Registration where UserID='" + userid.Text + "'", ref message);
                if (dt.Rows.Count > 0)
                {
                    string date = dt.Rows[0]["RenewalDate"].ToString();
                    if (date != "")
                    {
                        row.BackColor = Color.GreenYellow;
                    }
                }
                
            }
            
        }
    }
}