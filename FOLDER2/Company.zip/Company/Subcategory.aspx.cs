﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Subcategory : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                ShowCategory();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void ShowCategory()
    {
        drpcategory.DataTextField = "CategoryName";
        drpcategory.DataValueField = "ID";
        try
        {
            CategoryMaster CM = new CategoryMaster();
            DataTable dt=  CM.FetchCategory(ref message);
            if (dt.Rows.Count>0)
            {
                drpcategory.DataSource = dt;
                drpcategory.DataBind();
                drpcategory.Items.Insert(0, new ListItem("Select Category", "0"));
            }
            else
            {
                drpcategory.DataSource = null;
                drpcategory.DataBind();
                drpcategory.Items.Insert(0, new ListItem("Select Category", "0"));
            }
        }
        catch (Exception ex)
        {

            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            SubcategoryProperty SP = new SubcategoryProperty { SubCategoryName = txtsubcategory.Text, CategoryName = drpcategory.SelectedItem.Text };
            SubcategoryMaster SM = new SubcategoryMaster();
            int rowaffected = SM.SaveSubCategory(SP, ref message);
            if (rowaffected > 0)
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", "Sub Category Save Successfully");
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);

            }
            else
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", message);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);

            }
        }
        catch (Exception ex)
        {

            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
        }

    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        drpcategory.SelectedIndex = 0;
        txtsubcategory.Text = null;
    }
}