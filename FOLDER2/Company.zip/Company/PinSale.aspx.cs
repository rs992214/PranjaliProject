﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using Newtonsoft.Json;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;

public partial class Company_PinSale : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DAL dal = new DAL();
    string message = string.Empty;
    string loginip = GetLocalIPAddress();
    string UserName = "";
    string password1 = "";
   

    protected void Page_Load(object sender, EventArgs e)
    {
        GetLocalIPAddress();
        AdminLoginInfo();

        if (!IsPostBack)
        {
            GetPackage();
            GetData("Unused");
        }
    }
    private void GetPackage()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,PackageName From PackageInfo", ref message);
            if (dt.Rows.Count > 0)
            {
                DDLPackage.DataSource = dt;
                DDLPackage.DataTextField = "PackageName";
                DDLPackage.DataValueField = "ID";
                DDLPackage.DataBind();
                DDLPackage.Items.Insert(0, new ListItem("--Please Select Package--", "0"));
            }
            else
            {
                DDLPackage.DataSource = dt;
                DDLPackage.DataBind();
                DDLPackage.Items.Insert(0, new ListItem("--Please Select Package--", "0"));
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void GetData(string Status)
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt;
            if (Status== "Used")
            {
                dt = objDAL.Gettable("Select PG.ID,PG.UserID,PG.PackageID,P.PackageName,P.Amount,PG.PinNo,PG.Status,PG.TransferBy,PG.TransferTo From PinGenerateNew PG Inner Join PackageInfo P On P.ID=PG.PackageID Where PG.Status='" + Status + "' and PG.TransferBy='Admin'", ref message);
            }
            else
            {
                dt = objDAL.Gettable("Select PG.ID,PG.UserID,PG.PackageID,P.PackageName,P.Amount,PG.PinNo,PG.Status,PG.TransferBy,PG.TransferTo From PinGenerateNew PG Inner Join PackageInfo P On P.ID=PG.PackageID Where PG.Status='" + Status + "' and PG.TransferBy='Admin' OR TransferTo IS NOT NULL", ref message);
            }
            
            if (dt.Rows.Count > 0)
            {
                GV_PackageList.DataSource = dt;
                GV_PackageList.DataBind();
            }
            else
            {
                GV_PackageList.DataSource = null;
                GV_PackageList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }
    private void GetPinNo()
    {
        int flag = 1;
        con = new SqlConnection(connstring);
        con.Open();
        while (flag == 1)
        {
            string PinNo = GetUniqueKey(6);
            cmd = new SqlCommand("PinGenerateNew_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PinNo", PinNo);
            cmd.Parameters.AddWithValue("@Mode", "CHECK_PIN_NO");
            flag = (int)cmd.ExecuteScalar();
            lblPinNo.Text = PinNo;
        }
        con.Close();
    }
    private void ClearData()
    {
        txtUserID.Text = string.Empty;
        lblName.Text = string.Empty;
        DDLPackage.SelectedIndex = 0;
        txtQty.Text = string.Empty;
        GetData("Unused");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string value = @"[0-9]{1,5}";
        if(Regex.IsMatch(txtQty.Text,value) == true)
        {
            if (txtUserID.Text != "" && txtQty.Text != "")
            {
                PinAvailable();

            }
            else
            {
                ShowPopupMessage("Fill All Data.", PopupMessageType.Warning);
            }
        }
        else
        {
            ShowPopupMessage("Please Enter Proper data.", PopupMessageType.Warning);
        }
       
        //try
        //{
        //    int PinQty = Convert.ToInt32(txtQty.Text);
        //    if (PinQty > 0)
        //    {
        //        int _Count = 0;
        //        for (int i = 0; i < PinQty; i++)
        //        {
        //            GetPinNo();
        //            con = new SqlConnection(connstring);
        //            con.Open();
        //            cmd = new SqlCommand("PinGenerateNew_ALL", con);
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);

        //            cmd.Parameters.AddWithValue("@PackageID", DDLPackage.SelectedValue);
        //            cmd.Parameters.AddWithValue("@PinNo", lblPinNo.Text);
        //            cmd.Parameters.AddWithValue("@Mode", "IN2");
        //            int flag = cmd.ExecuteNonQuery();
        //            con.Close();
        //            if (flag > 0)
        //            {
        //                _Count = _Count + flag;
        //            }
        //            else
        //            {
        //                _Count = _Count + flag;
        //            }
        //        }

        //        if (_Count == PinQty)
        //        {
        //            ClearData();
        //            ShowPopupMessage("Pin has been Sale successfully.", PopupMessageType.Success);
        //        }
        //    }
        //    else
        //    {
        //        ShowPopupMessage("Invalid Pin Qty.", PopupMessageType.Error);
        //    }

        //}
        //catch (Exception ex)
        //{
        //    ShowPopupMessage(ex.Message, PopupMessageType.Error);
        //}
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        Response.Redirect("PinSale.aspx");
    }
    protected void GV_PackageList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_PackageList.PageIndex = e.NewPageIndex;
        string Status = string.Empty;
        if (rdActive.Checked == true)
        {
            Status = "Used";
        }
        else
        {
            Status = "Unused";
        }
        GetData(Status);
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("PinGenerateNew_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Parameters.AddWithValue("@Mode", "DEL");
            int flag = cmd.ExecuteNonQuery();
            con.Close();
            if (flag > 0)
            {
                ClearData();
                Response.Redirect("SuccessView.aspx?Link=PinSale.aspx");
                //ShowPopupMessage("Pin has been Deleted successfully.", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage("This Pin in used.", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void rdActive_CheckedChanged(object sender, EventArgs e)
    {
        GetData("Used");
    }

    protected void rdInactive_CheckedChanged(object sender, EventArgs e)
    {
        GetData("Unused");
    }
    protected void txtUserID_TextChanged(object sender, EventArgs e)
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Name From MLM_Registration Where UserID='" + txtUserID.Text + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                txtUserID.Text = dt.Rows[0]["UserID"].ToString();
                lblName.Text = dt.Rows[0]["Name"].ToString();
            }
            else
            {
                txtUserID.Text = string.Empty;
                lblName.Text = string.Empty;
                ShowPopupMessage("Incorrect User ID.", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void PinAvailable()
    {
        DAL dal = new DAL();

        string val = DDLPackage.SelectedValue;
        DataTable dt = dal.Gettable("Select PG.UserID,PG.TransferBy,PG.TransferTo, PG.ID,PG.PackageID,P.PackageName,P.Amount,PG.PinNo,PG.Status From PinGenerateNew PG Inner Join PackageInfo P On P.ID=PG.PackageID Where PG.Status='Unused' and PG.UserID IS NULL and PG.TransferTo IS NULL and PG.TransferBy='Admin' and PG.PackageID='"+val+"' order by PG.ID desc", ref message);
        if (dt.Rows.Count >= Convert.ToInt32(txtQty.Text))
        {
            SalePin();
            //ShowPopupMessage("Done Pin.", PopupMessageType.Success);
        }
        else
        {
            txtQty.Text = "";
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Warning:Insufficient Pin Entered By Admin')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                con.Close();
            }
            ShowPopupMessage("Insufficient Pin.", PopupMessageType.Warning);
        }
    }

    string company = string.Empty;
    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                company = dt.Rows[0]["CompanyName"].ToString();
            }
            else
            {
            }
        }
        catch (Exception ex)
        {

        }
    }

    string Mobile = string.Empty;
    string Password = string.Empty;
    string Name = string.Empty;

    void GetData1()
    {
        DAL dal = new DAL();
        string message1 = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from MLM_Registration where UserID='" + txtUserID.Text + "'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message1);
        if (dt.Rows.Count > 0)
        {
            Mobile = dt.Rows[0]["Mobile"].ToString();
            Password = dt.Rows[0]["Password"].ToString();
            Name = dt.Rows[0]["Name"].ToString();
        }
    }

    protected void SalePin()
    {
        try
        {
           int PinQty = Convert.ToInt32(txtQty.Text);
            //ViewState["PinQty"] = PinQty;
            //ViewState["UserID"] = txtUserID;
            //ViewState["PackageName"] = DDLPackage.SelectedItem;
            if (PinQty > 0)
            {
                int _Count = 0;
                for (int i = 0; i < PinQty; i++)
                {
                    //GetPinNo();
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("PinGenerateNew_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);

                    cmd.Parameters.AddWithValue("@PackageID", DDLPackage.SelectedValue);
                    //cmd.Parameters.AddWithValue("@PinNo", lblPinNo.Text);

                    cmd.Parameters.AddWithValue("@Mode", "IN2");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    if (flag > 0)
                    {
                        _Count = _Count + flag;
                    }
                    else
                    {
                        _Count = _Count + flag;
                    }
                }

                if (_Count == PinQty)
                {
                    SendMsg();
                    PinGenrationDetail();
                    ClearData();
                    Response.Redirect("SuccessView.aspx?Link=PinSale.aspx");
                   // ShowPopupMessage("Pin has been Sale successfully.", PopupMessageType.Success);
                }
            }
            else
            {
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Error:Invalid Pin Qty Entered By Admin ')", con);
                    cmd.CommandType = CommandType.Text;

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {

                    }
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    con.Close();
                }

                ShowPopupMessage("Invalid Pin Qty.", PopupMessageType.Error);
            }

        }
        catch (Exception ex)
        {
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Error: "+error+" ')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void GV_PackageList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblStatus = e.Row.FindControl("lblStatus") as Label;
            LinkButton btnApproved = e.Row.FindControl("btnDelete") as LinkButton;
            if (lblStatus.Text == "Unused")
            {
                btnApproved.Enabled = true;
                btnApproved.CssClass = "btn btn-sm btn-danger";
            }
            else
            {
                btnApproved.Enabled = false;
                btnApproved.CssClass = "btn btn-sm btn-danger disabled";
            }
        }
    }

    string smsstatus = string.Empty;
    string emailstatus = string.Empty;
    public void SendMsg()
    {
        DAL dal = new DAL();

        string url = "";
        string username = "";
        string key = "";
        string request = "";
        string sender = "";
        string route = "";
        int sms = 0;
        string status = "";
        string message = string.Empty;

        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='"+smsstatus+"'", ref message);
        if (dt.Rows.Count > 0)
        {
            url = dt.Rows[0]["APIurl"].ToString();
            username = dt.Rows[0]["Username"].ToString();
            key = dt.Rows[0]["APIkey"].ToString();
            request = dt.Rows[0]["APIrequest"].ToString();
            sender = dt.Rows[0]["Sender"].ToString();
            route = dt.Rows[0]["Route"].ToString();
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());

            if (sms != 0)
            {
                Showdatalogo();
                GetData1();
                string text = "Dear User("+txtUserID.Text+") pin has been sale successfully. please check in your Panel...";
                try
                {
                    string jsonValue = "";
                    string sURL;
                    StreamReader objReader;
                    // sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + username + "&password=" + password + "&sender=" + senderId + "&to=" + txtmobileNo.Text + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + routeId + "";
                    // sURL = "http://sms.probuztech.com/sms-panel/api/http/index.php?username=WYSE&apikey=FC144-3DD84&apirequest=Text&sender=PROBUZ&mobile=8055002299&message=TEST&route=TRANS&format=JSON";
                    sURL = "" + url + "?username=" + username + "&apikey=" + key + "&apirequest=" + request + "&sender=" + sender + "&mobile=" + Mobile + "&message=" + text + "&route=" + route + "&format=JSON";
                    WebRequest wrGETURL;
                    wrGETURL = WebRequest.Create(sURL);
                    try
                    {
                        Stream objStream;
                        objStream = wrGETURL.GetResponse().GetResponseStream();
                        objReader = new StreamReader(objStream);
                        jsonValue = objReader.ReadToEnd();
                        var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                        string status1 = myDetails.status;
                        if (status1 == "error")
                        {
                            SMSHistory(txtUserID.Text, Name, Mobile, text, "Not Send");
                        }
                        else
                        {
                            SMSdebit();
                            SMSHistory(txtUserID.Text, Name, Mobile, text, "Send");
                        }

                        objReader.Close();
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                    }
                }
                catch (Exception)
                {
                    throw;
                }

            }
        }
    }

    public void SendMail(string mailID, string Username1, string userPassword)
    {

        string email = "";
        string password = "";
        string smtp = "";
        int port = 0;
        Boolean ssl = false;
        string logolink = "";
        string loginlink = "";


        DAL dal = new DAL();
        string message1 = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select EmailID,Password,SMTP,PortNo,EnableSSl,Logolink,Loginlink from EmailConfig where Status='" + emailstatus + "'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message1);
        if (dt.Rows.Count > 0)
        {
            email = dt.Rows[0]["EmailID"].ToString();
            password = dt.Rows[0]["Password"].ToString();
            smtp = dt.Rows[0]["SMTP"].ToString();
            port = Convert.ToInt32(dt.Rows[0]["PortNo"].ToString());
            ssl = Convert.ToBoolean(dt.Rows[0]["EnableSSl"].ToString());
            logolink = dt.Rows[0]["Logolink"].ToString();
            loginlink = dt.Rows[0]["Loginlink"].ToString();

            //gather email from form textbox
            string remail = mailID;

            //MailAddress from = new MailAddress("info@paxpluewealth.com");
            MailAddress from = new MailAddress(email);

            MailAddress to = new MailAddress(remail);
            MailMessage message = new MailMessage(from, to);

            message.Subject = company + " Registration Success";

            //string note = "<div>Hello! <b>'" + txtname.Text + "'</b> </div>";
            //note += "<div><br><p>Your Registerd Username IS : <b>'" + Username1 + "'</b> AND Password IS : <b>'" + userPassword + "'</b>. Keep it secured.<br>Thank You.</p></div>";
            //note += "<div><br>Regards<br><a href='http://www.paxpluewealth.com/Member/login.aspx'>http://www.paxpluewealth.com</a></div>";

            //string note = MailBody(Username1, userPassword, TransactionPassword);

            string note = "<!DOCTYPE html>";
            note += "<html><body>";
            note += "<h1><img src='" + logolink + "' height=100px width=100px></h1>";
            note += "<p>Hello <b>'" + Name + "'</b>,</p>";
            note += "<p>Welcome to <b>" + company + "</b>, You have Registered successfully with us. We provide you your login Credentials. Please Keep it secure.</p>";
            note += "<p>Following are the log-in Credential.</p>";
            note += "<p><blink><a href='" + loginlink + "' target='_blank'>Click Here</a></blink></p>";
            note += "<p>Username : <b>'" + Username1 + "'</b></p>";
            note += "<p>Password : <b>'" + userPassword + "'</b></p>";
            note += "<br><br><br>";
            note += "<p>Regards</p>";
            note += "<p><a href='" + loginlink + "' target='_blank'>" + company + "</a><p>";
            note += "</body></html>";

            message.Body = note;
            message.BodyEncoding = System.Text.Encoding.UTF8;
            message.IsBodyHtml = true;

            //SmtpClient client = new SmtpClient("smtp.paxpluewealth.com", 587);
            SmtpClient client = new SmtpClient(smtp, port);
            client.UseDefaultCredentials = false;
            client.EnableSsl = ssl;
            //client.Credentials = new NetworkCredential("info@paxpluewealth.com", "aXGU(nT0");
            client.Credentials = new NetworkCredential(email, password);

            try
            {
                client.Send(message);
            }
            catch (Exception ex)
            {
                //error message?
            }
            finally
            {

            }

        }

    }

    protected void SMSdebit()
    {
        int sms = 0;
        int smsAvailable = 0;
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());
            smsAvailable = sms - 2;

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update SmsmasterNew set CreditSMS='{0}'", smsAvailable);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {

                }
                else
                {
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {

            }
        }
    }

protected void SMSHistory(string userid, string name, string mobile, string msg, string sts)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sba = new StringBuilder();
        sba.AppendLine("insert into SMSHistory(UserID,Name,Mobileno,Message,Status)");
        sba.AppendFormat("values('{0}','{1}','{2}','{3}','{4}')", userid, name, mobile, msg, sts);
        int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
        if (rowaffected1 > 0)
        {

        }

    }

    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
    }
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }
        throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName = dt.Rows[0]["UserName"].ToString();
                password1 = dt.Rows[0]["password"].ToString();

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

    public void PinGenrationDetail()

    {
        
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Status:Pin Generated  SuccessFully for UserID=" + txtUserID.Text + ", with Package Name=" + DDLPackage.SelectedItem.Text + ",for " + txtQty.Text + " Qty ')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
}