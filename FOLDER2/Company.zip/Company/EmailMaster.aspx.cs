﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;

public partial class Company_EmailMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                showemailconfig();
                if (GridView1.Rows.Count > 0)
                {
                    btnsave.Enabled = false;
                }
                btnupdate.Visible = false;
            }
            else
            {
               
                Response.Redirect("Logout.aspx");
            }
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();

        string status = string.Empty;
        if (RadioButton2.Checked == true)
        {
            status = RadioButton2.Text;
        }
        else
        {
            status = RadioButton1.Text;
        }

        sb.AppendLine("insert into EmailConfig(EmailID,Password,SMTP,PortNo,EnableSSl,Logolink,Loginlink,Status)");
        sb.AppendFormat("values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", txtemailid.Text, txtpassword.Text, txtsmtphost.Text, txtmailport.Text, drpssl.SelectedItem.Text, txtlogo.Text, txtlogin.Text, status);
        try
        {
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                showemailconfig();
                Response.Redirect("SuccessView.aspx?Link=EmailMaster.aspx");
                //  ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Email Configuration Save Successfully')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + message + "')", true);
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
        }
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtemailid.Text = string.Empty;
        txtmailport.Text = string.Empty;
        txtpassword.Text= string.Empty;
        txtsmtphost.Text= string.Empty;
        btnsave.Visible = true;
        btnupdate.Visible = false;
        txtemailid.ReadOnly = false;

        txtlogo.Text = string.Empty;
        txtlogin.Text = string.Empty;
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtemailid.Text = GridView1.SelectedRow.Cells[0].Text;
        txtemailid.ReadOnly = true;
        txtpassword.Text = GridView1.SelectedRow.Cells[1].Text;
        txtsmtphost.Text = GridView1.SelectedRow.Cells[2].Text;
        txtmailport.Text= GridView1.SelectedRow.Cells[3].Text;
        drpssl.ClearSelection();
        drpssl.Items.FindByText(GridView1.SelectedRow.Cells[4].Text).Selected=true;

        txtlogo.Text = GridView1.SelectedRow.Cells[5].Text;
        txtlogin.Text = GridView1.SelectedRow.Cells[6].Text;

        string status = GridView1.SelectedRow.Cells[7].Text;
        if (status == "Active")
        {
            RadioButton1.Checked = true;
            RadioButton2.Checked = false;
        }
        else if (status == "InActive")
        {
            RadioButton2.Checked = true;
            RadioButton1.Checked = false;
        }


        btnupdate.Visible = true;
        btnsave.Visible = false;
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string emailid = GridView1.DataKeys[e.RowIndex].Values["EmailID"].ToString();
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("delete from EmailConfig where EmailID='{0}'", emailid);
        try
        {
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                showemailconfig();
                Response.Redirect("SuccessView.aspx?Link=EmailMaster.aspx");
               // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Email Setting Deleted Successfully')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + message + "')", true);
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            showemailconfig();
        }

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        showemailconfig();
    }
    public void showemailconfig()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from EmailConfig");
        try
        {
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();

        string status = string.Empty;
        if (RadioButton2.Checked == true)
        {
            status = RadioButton2.Text;
        }
        else
        {
            status = RadioButton1.Text;
        }

        sb.AppendFormat("update EmailConfig set Password='{0}',SMTP='{1}',PortNo='{2}',EnableSSl='{3}',Logolink='{5}',Loginlink='{6}',Status='{7}'  where EmailID='{4}'", txtpassword.Text, txtsmtphost.Text, txtmailport.Text, drpssl.SelectedItem.Text,txtemailid.Text, txtlogo.Text, txtlogin.Text, status);
        try
        {
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                showemailconfig();
                Response.Redirect("SuccessView.aspx?Link=EmailMaster.aspx");
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Email Setting Updated Successfully')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + message + "')", true);
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            btnsave.Visible = true;
            btnupdate.Visible = false;
            btncancel_Click(sender, new EventArgs());
            showemailconfig();
        }
    }
}