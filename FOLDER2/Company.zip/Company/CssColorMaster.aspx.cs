﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_CssColorMaster : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Getdata();
        }
    }

    public void Getdata()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from color_master");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            txtcolour1.Text = dt.Rows[0]["colorname"].ToString();
            txtcolor2.Text = dt.Rows[1]["colorname"].ToString();
            txtcolour3.Text = dt.Rows[2]["colorname"].ToString();
            txtcolor4.Text = dt.Rows[4]["colorname"].ToString();
            txtYellow.Text = dt.Rows[5]["colorname"].ToString();
            txtdefault.Text = dt.Rows[3]["colorname"].ToString();
            color1 = dt.Rows[0]["Status"].ToString();
            color2 = dt.Rows[1]["Status"].ToString();
            color3 = dt.Rows[2]["Status"].ToString();
            color4 = dt.Rows[4]["Status"].ToString();
            color5 = dt.Rows[5]["Status"].ToString();
            default1 = dt.Rows[3]["Status"].ToString();
            ValidData();
        }
    }

    string color1 = string.Empty;
    string color2 = string.Empty;
    string color3 = string.Empty;
    string color4 = string.Empty;
    string color5 = string.Empty;
    string default1 = string.Empty;
    
    public void ValidData()
    {
        if(color1 == "Active")
        {
            rdoredorange.Checked = true;
        }
        else if(color2 == "Active")
        {
            rdoyellow.Checked = true;
        }
        else if(color3=="Active")
        {
            rdoblue.Checked = true;
        }
        else if(color3 == "Active")
        {
            rdocolor4.Checked = true;
        }
        else if (color5 == "Active")
        {
            rbYellow.Checked = true;
        }
        else
        {
            rdodefault.Checked = true;
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        string colorname = string.Empty;

        if(rdoblue.Checked == true)
        {
            colorname = txtcolour3.Text;
        }
        else if(rdoredorange.Checked==true)
        {
            colorname = txtcolour1.Text;
        }
        else if(rdoyellow.Checked == true)
        {
            colorname = txtcolor2.Text;
        }
        else if(rdocolor4.Checked == true)
        {
            colorname = txtcolor4.Text;
        }
        else if (rbYellow.Checked == true)
        {
            colorname = txtYellow.Text;
        }
        else
        {
            colorname = txtdefault.Text;
        }

        StringBuilder sb1 = new StringBuilder();
        sb1.AppendLine("Update color_master ");
        sb1.AppendFormat("set Status = CASE WHEN colorname = '"+colorname+"' THEN 'Active'  ELSE 'InActive'  END ");
        int rowaffected = dal.Executequery(sb1.ToString(), ref message);
        if (rowaffected > 0)
        {
            Response.Redirect("SuccessView.aspx?Link=CssColorMaster.aspx");
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Data Save Successfully')", true);
        }
    }

    protected void btnreset_Click(object sender, EventArgs e)
    {
        //Response.Redirect("CssColorMaster.aspx");
        Response.Redirect("SuccessView.aspx?Link=CssColorMaster.aspx");

    }
}