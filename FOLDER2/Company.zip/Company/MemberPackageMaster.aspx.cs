﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Net;

public partial class Company_MemberPackageMaster : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    string loginip = GetLocalIPAddress();
    string UserName = "";
    string password = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            AdminLoginInfo();
            if (!IsPostBack)
            {
                IfExist();
                GetData();
                btnsave.Text = "Save";
            }
        }
    }

    void IfExist()
    {
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select ID,PackageName,Amount,DirectIncome,BinaryIncome,MonthlyCapping,DailyCapping,PairRatio,CONVERT(nvarchar,CreationDate,105)As CreationDate From PackageInfo Order By ID ASC", ref message);
        if (dt.Rows.Count > 0)
        {
            string rdo = dt.Rows[0]["PairRatio"].ToString();
            if(rdo == "2:1")
            {
                rdo1.Checked = true;
                //rdo2.Enabled = false;
            }
            else
            {
                rdo2.Checked = true;
                //rdo1.Enabled = false;
            }

            string daily = dt.Rows[0]["DailyCapping"].ToString();
            string Monthly = dt.Rows[0]["MonthlyCapping"].ToString();
            if(daily != "0.00")
            {
                txtCapping.Text = daily;
                //txtCapping.Enabled = false;
                //ddlcapping.Visible = false;
            }
            else
            {
                txtCapping.Text = Monthly;
                //txtCapping.Enabled = false;
                //ddlcapping.Visible = false;
            }

            //br.Visible = false;
        }
        else
        {

        }
    }

    private void GetData()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,PackageName,Amount,DirectIncome,BinaryIncome,MonthlyCapping,DailyCapping,PairRatio,CONVERT(nvarchar,CreationDate,105)As CreationDate From PackageInfo Order By ID ASC", ref message);
            if (dt.Rows.Count > 0)
            {
                GV_PackageList.DataSource = dt;
                GV_PackageList.DataBind();
            }
            else
            {
                GV_PackageList.DataSource = null;
                GV_PackageList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void Clear()
    {
        txtpackagename.Text = string.Empty;
        txtpackagename.Text = string.Empty;
        txtPackageAmount.Text = string.Empty;
        txtdirectincome.Text = string.Empty;
        txtpaireincome.Text = string.Empty;
        txtpackagename.ReadOnly = false;
        GetData();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtpackagename.Text != string.Empty && txtPackageAmount.Text != string.Empty && txtdirectincome.Text != string.Empty && txtpaireincome.Text != string.Empty)
            {

                Calculation();
                if (btnsave.Text == "Save")
                {
                    if (txtPackageAmount.Text != "" && txtpackagename.Text != "")
                    {
                        con = new SqlConnection(connstring);
                        con.Open();
                        cmd = new SqlCommand("PackageInfo_ALL", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@PackageName", txtpackagename.Text);
                        cmd.Parameters.AddWithValue("@Amount", txtPackageAmount.Text);
                        cmd.Parameters.AddWithValue("@DirectIncome", DirectAmount);
                        cmd.Parameters.AddWithValue("@BinaryIncome", PairAmount);

                        double dailycapping = 0;
                        double monthlycapping = 0;
                       
                            dailycapping = Convert.ToDouble(txtCapping.Text);
                            monthlycapping = Convert.ToDouble(txtCapping.Text) * 30;

                        if (rdo1.Checked == true)
                        {
                            Pairs = "2:1";
                        }
                        else
                        {
                            Pairs = "1:1";
                        }
                        cmd.Parameters.AddWithValue("@Paires", Pairs);
                        cmd.Parameters.AddWithValue("@DailyCapping", dailycapping);
                        cmd.Parameters.AddWithValue("@MonthlyCapping", monthlycapping);
                        cmd.Parameters.AddWithValue("@Mode", "IN");
                        int flag = cmd.ExecuteNonQuery();
                        con.Close();
                        if (flag > 0)
                        {
                            IfExist();
                            GetPackageTrace();
                            ShowPopupMessage("Package has been Added Successfully.", PopupMessageType.Success);
                        }
                        else
                        {
                            ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                        }
                    }
                    else
                    {
                        ShowPopupMessage("Please Enter Data", PopupMessageType.Warning);
                    }
                }
                else if (ViewState["PackageID"] != null && txtpackagename.Text != null)
                {
                    double dailycapping = 0;
                    double monthlycapping = 0;
                   
                        dailycapping = Convert.ToDouble(txtCapping.Text);
                        monthlycapping = Convert.ToDouble(txtCapping.Text) * 30;

                    if (rdo1.Checked == true)
                    {
                        Pairs = "2:1";
                    }
                    else
                    {
                        Pairs = "1:1";
                    }
                    string ID = ViewState["PackageID"].ToString();
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("PackageInfo_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.Parameters.AddWithValue("@PackageName", txtpackagename.Text);
                    cmd.Parameters.AddWithValue("@Amount", txtPackageAmount.Text);
                    cmd.Parameters.AddWithValue("@DirectIncome", txtdirectincome.Text);
                    cmd.Parameters.AddWithValue("@BinaryIncome", txtpaireincome.Text);
                    cmd.Parameters.AddWithValue("@Paires", Pairs);
                    cmd.Parameters.AddWithValue("@DailyCapping", dailycapping);
                    cmd.Parameters.AddWithValue("@MonthlyCapping", monthlycapping);
                    cmd.Parameters.AddWithValue("@Mode", "UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    if (flag > 0)
                    {
                        IfExist();
                        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                        SqlConnection con = new SqlConnection(connstring);

                        con.Open();
                        SqlCommand cmd1 = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Success:Package has been Updated Successfully With " + Pairs + " Macthing Pair income...!!')", con);
                        cmd1.CommandType = CommandType.Text;

                        SqlDataAdapter sda = new SqlDataAdapter(cmd1);
                        int a = cmd1.ExecuteNonQuery();
                        if (a > 0)
                        {

                        }
                    
                    ShowPopupMessage("Package has been Updated Successfully.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                    }
                }
            }
            else
            {
                ShowPopupMessage("Please Update All Data.", PopupMessageType.Warning);
            }
        }
        catch (Exception ex)
        {
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd1 = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Error: " + error + "')", con);
                cmd1.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd1);
                int a = cmd1.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        finally
        {
            Clear();
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Clear();
        Response.Redirect("MemberPackageMaster.aspx");
    }

    double DirectAmount = 0;
    double PairAmount = 0;
    string Pairs = string.Empty;
    private void Calculation()
    {
        double PackageAmount = 0;

        if (txtPackageAmount.Text != string.Empty)
        {
            PackageAmount = Convert.ToDouble(txtPackageAmount.Text);
        }
        else
        {
            txtPackageAmount.Text = "0";
        }

        if(ddlDirect.SelectedItem.Text == "Percentage")
        {
            DirectAmount = PackageAmount * Convert.ToDouble(txtdirectincome.Text) / 100;
        }
        else
        {
            DirectAmount = Convert.ToDouble(txtdirectincome.Text);
        }

        if (ddlPair.SelectedItem.Text == "Percentage")
        {
            PairAmount = PackageAmount * Convert.ToDouble(txtpaireincome.Text) / 100;
        }
        else
        {
            PairAmount = Convert.ToDouble(txtpaireincome.Text);
        }
    }
    protected void GV_PackageList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_PackageList.PageIndex = e.NewPageIndex;
        GetData();
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,PackageName,Amount,DirectIncome,BinaryIncome,MonthlyCapping,DailyCapping,CONVERT(nvarchar,CreationDate,105)As CreationDate From PackageInfo Where ID='" + ID + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                ViewState["PackageID"] = dt.Rows[0]["ID"].ToString();
                txtpackagename.Text = dt.Rows[0]["PackageName"].ToString();
                txtpackagename.ReadOnly = true;
                txtPackageAmount.Text = dt.Rows[0]["Amount"].ToString();
                txtdirectincome.Text = dt.Rows[0]["DirectIncome"].ToString();
                txtpaireincome.Text = dt.Rows[0]["BinaryIncome"].ToString();
                double dailycapping = Convert.ToDouble(dt.Rows[0]["DailyCapping"]);
                double monthlycapping = Convert.ToDouble(dt.Rows[0]["MonthlyCapping"]);
                if(dailycapping != 0.00)
                {
                    txtCapping.Text = dailycapping.ToString();
                }
                else
                {
                    txtCapping.Text = monthlycapping.ToString();
                }
                // ddlcapping.Visible = false;
                // txtCapping.Enabled = false;
                //br.Visible = true;
                btnsave.Text = "Update";
            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {
                con.Open();
                SqlCommand cmd1 = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Error: " + error + "')", con);
                cmd1.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd1);
                int a = cmd1.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("PackageInfo_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Parameters.AddWithValue("@Mode", "DEL");
            int flag = cmd.ExecuteNonQuery();
            con.Close();
            if (flag > 0)
            {
                Clear();
                ShowPopupMessage("Member Package has been Deleted.", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage("Deletion Failed.", PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }
        }

        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName = dt.Rows[0]["UserName"].ToString();
                password = dt.Rows[0]["password"].ToString();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

    public void GetPackageTrace()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Success:Package has been Added Successfully With " + Pairs + " Macthing Pair income...!!')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
}