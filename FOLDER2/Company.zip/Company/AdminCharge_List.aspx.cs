﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_AdminCharge_List : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                ShowPayout();
                btnexcel.Visible = false;
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void ShowPayout()
    {
        try
        {
            drppayout.DataTextField = "PayoutBetween";
            drppayout.DataValueField = "PayoutBetween";
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select DISTINCT PayoutBetween,max(Date) from MemberPayment group by PayoutBetween order by max(Date)");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                drppayout.DataSource = dt;
                drppayout.DataBind();
                drppayout.Items.Insert(0, new ListItem("Select Payout Date", "0"));
            }
            else
            {
                drppayout.DataSource = null;
                drppayout.DataBind();
                drppayout.Items.Insert(0, new ListItem("Select Payout Date", "0"));
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }

    public void ShowPayoutSheet()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select MR.UserID, MR.Name, BP.PayoutAmount as [Payout Amount],BP.AdminCharge as [AdminCharge(5%)], convert(nvarchar(10), BP.PaymentGenrateDate, 103) as [Date] from MemberPayment as BP inner join MLM_Registration as MR on BP.UserID = MR.UserID Left join MLM_UserDetail as MLU on MR.UserID = MLU.UserID where Bp.PayoutBetween = '{0}'", drppayout.SelectedValue);

            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                GridView1.AllowPaging = false;
                GridView1.PageSize = dt.Rows.Count;
                btnexcel.Visible = true;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnexcel.Visible = false;

            }

        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ShowPayoutSheet();
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowPayoutSheet();
    }
    protected void btnexcel_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string filename = "AdminCharge_" + drppayout.SelectedItem.Text;
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename='" + filename + "'.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridView1.AllowPaging = false;
                this.ShowPayoutSheet();
                GridView1.HeaderRow.Cells[1].Visible = false;
                GridView1.HeaderRow.Cells[2].Visible = false;
                GridView1.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridView1.HeaderRow.Cells)
                {
                    cell.BackColor = GridView1.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridView1.Rows)
                {
                    row.Cells[1].Visible = false;
                    row.Cells[2].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridView1.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridView1.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridView1.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (Exception)
        {

            throw;
        }

    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
}