﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.IO;
using System.Net;

public partial class Company_Ledger : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    string message = string.Empty;
    DAL objDAL;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnSave.Enabled = false;
        }
    }
    private void Clear()
    {
        Right.Visible = false;
        DDLTransferType.SelectedIndex = 0;
        txtUserID.Text = string.Empty;
        txtAmount.Text = string.Empty;
        txtDescription.Text = string.Empty;
    }
    protected void txtUserID_TextChanged(object sender, EventArgs e)
    {
        try
        {
            objDAL = new DAL();
            if (txtUserID.Text!=string.Empty)
            {
                DataTable dt = objDAL.Gettable("Select UserID,Mobile From MLM_Registration Where UserID='" + txtUserID.Text + "'", ref message);
                if (dt.Rows.Count > 0)
                {
                    Right.Visible = true;
                    btnSave.Enabled = true;
                    txtUserID.Text = dt.Rows[0]["UserID"].ToString();
                    lblMobile.Text = dt.Rows[0]["Mobile"].ToString();
                }
                else
                {
                    Right.Visible = false;
                    txtUserID.Text = string.Empty;
                    lblMobile.Text = string.Empty;
                    btnSave.Enabled = false;
                    ShowPopupMessage("Incorrect User ID.", PopupMessageType.Message);
                }
            }
            else
            {
                ShowPopupMessage("Please Enter User ID.", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void SendSMS()
    {
        string UserName = string.Empty;
        string Password = string.Empty;
        string SenderID = string.Empty;
        string MobileNo = string.Empty;
        string TextMessage = string.Empty;
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select * From Smsmaster", ref message);
        if (dt.Rows.Count > 0)
        {
            UserName = dt.Rows[0]["Userid"].ToString();
            Password = dt.Rows[0]["Password"].ToString();
            SenderID = dt.Rows[0]["Senderid"].ToString();

            MobileNo = lblMobile.Text;
        }
        string sURL = string.Empty;
        StreamReader objReader;

        if (DDLTransferType.SelectedItem.Text == "CR")
        {
            TextMessage = "Congratulations, Dear User You have Credited Rs.  " + txtAmount.Text + ", Thank You. Regards ";
        }
        else if (DDLTransferType.SelectedItem.Text == "DR")
        {
            TextMessage = "Congratulations, Dear User You have Debited Rs.  " + txtAmount.Text + ", Thank You. Regards";
        }
        
        sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + UserName + "&password=" + Password + "&sender=" + SenderID + "&to=" + MobileNo + "&message=" + TextMessage + " &reqid=1&format={json|text}&route_id=7";

        WebRequest wrGETURL;
        wrGETURL = WebRequest.Create(sURL);

        Stream objStream;
        objStream = wrGETURL.GetResponse().GetResponseStream();
        objReader = new StreamReader(objStream);
        objReader.Close();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if(txtAmount.Text!=string.Empty && DDLTransferType.SelectedValue!="0")
        {
            try
            {
                decimal CR = 0;
                decimal DR = 0;
                if (DDLTransferType.SelectedItem.Text == "CR")
                {
                    CR = Convert.ToDecimal(txtAmount.Text);
                }
                else if (DDLTransferType.SelectedItem.Text == "DR")
                {
                    DR = Convert.ToDecimal(txtAmount.Text);
                }

                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
                cmd.Parameters.AddWithValue("@TransactionType", DDLTransferType.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@CR", CR);
                cmd.Parameters.AddWithValue("@DR", DR);
                //cmd.Parameters.AddWithValue("@Descriptions", txtDescription.Text);
                cmd.Parameters.AddWithValue("@Descriptions", "Green Wallet");

                cmd.Parameters.AddWithValue("@Mode", "IN");
                int flag = cmd.ExecuteNonQuery();
                con.Close();
                if (flag > 0)
                {
                    //SendSMS();
                    Clear();
                    ShowPopupMessage("Transaction Processed Successfully.", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                }

            }
            catch (Exception ex)
            {
                ShowPopupMessage(ex.Message, PopupMessageType.Error);
            }
        }
        else
        {
            ShowPopupMessage("Fill Proper Information", PopupMessageType.Error);
        }

                    
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Ledger_Wallet.aspx");
    }
    



    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here




    
}