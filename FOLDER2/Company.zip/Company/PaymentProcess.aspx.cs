﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Text;
using System.Data;
using System.Web.Script.Serialization;

public partial class Company_PaymentProcess : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["StockistID"]) && !string.IsNullOrEmpty(Request.QueryString["InvoiceNo"]))
                {
                    ViewState["StockistID"] = Request.QueryString["StockistID"].ToString();
                    ViewState["InvoiceNo"] = Request.QueryString["InvoiceNo"].ToString();
                    ShowInfo();
                }
                else
                {
                    Response.Redirect("");
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    private void ShowInfo()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            if (ViewState["StockistID"].ToString()=="4")
            {
                sb.AppendFormat("select MR.Name,OC.InvoiceNo,OC.Amount,OC.Status from OrderCancel as OC inner join MLM_Registration as MR on OC.orderby = MR.UserID where OC.Stockisttype = '{0}' and OC.InvoiceNo = '{1}'", ViewState["StockistID"].ToString(), ViewState["InvoiceNo"].ToString());
            }
            else
            {
                sb.AppendFormat("select SD.Name,OC.InvoiceNo,OC.Amount,OC.Status from OrderCancel as OC inner join StockistDetail as SD on Oc.orderby = SD.UserID where OC.Stockisttype ='{0}' and OC.InvoiceNo = '{1}'", ViewState["StockistID"].ToString(), ViewState["InvoiceNo"].ToString());
            }
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                lblcustomername.Text = dt.Rows[0]["Name"].ToString();
                lblamount.Text= dt.Rows[0]["Amount"].ToString();
                lblstatus.Text= dt.Rows[0]["Status"].ToString();
                if (lblstatus.Text=="Transfer")
                {
                    btntransfer.Enabled = false;
                }
                lblinvoiceno.Text= dt.Rows[0]["InvoiceNo"].ToString();
            }
            
            
        }
        catch (Exception)
        {

            throw;
        }
    }

    protected void btntransfer_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("update OrderCancel set PaymentMode='{0}',Refernce='{1}',Status='{2}' where InvoiceNo='{3}' and Stockisttype='{4}'", drppaymentmode.SelectedItem.Text, txtrefernceno.Text, "Transfer", ViewState["InvoiceNo"].ToString(), ViewState["StockistID"].ToString());
            int rowaffected= dal.Executequery(sb.ToString(), ref message);
            if (rowaffected>0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Payment Transfer Successfully')", true);
                ShowInfo();
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
}