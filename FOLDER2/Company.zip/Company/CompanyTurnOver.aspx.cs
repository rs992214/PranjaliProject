﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;

public partial class Company_TurnOver : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    MLMUserDetailProperty MD = new MLMUserDetailProperty();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
        }
    }
    private void GetData()
    {
        try
        {
            //if (txtUserID.Text != string.Empty)
            //{
            //    MD.UserID = txtUserID.Text;
            //}
            //if (txtFrom.Text != string.Empty)
            //{
            //    MD.FromDate = txtFrom.Text;
            //}
            //if (txtTo.Text != string.Empty)
            //{
            //    MD.ToDate = txtTo.Text;
            //}
            con = new SqlConnection(connstring);
            con.Open();
            string str = "SELECT mm.UserID,mm.Name,mm.Package,pp.Amount,mm.JoinType from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where JoinType='paid'";
            SqlCommand cmd = new SqlCommand(str,con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GV_RewardList.DataSource = dt;
                GV_RewardList.DataBind();

                GV_RewardList.FooterRow.Cells[3].Text += "Total ";
                GV_RewardList.FooterRow.Cells[3].HorizontalAlign = HorizontalAlign.Right;
                string Credit = dt.Compute("Sum(Amount)", "").ToString();
                GV_RewardList.FooterRow.Cells[4].Text = Credit.ToString();
            }
            else
            {
                GV_RewardList.DataSource = dt;
                GV_RewardList.DataBind();
            }
           
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
       // GetData();
    }
    protected void GV_RewardList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        //GV_RewardList.PageIndex = e.NewPageIndex;
        //GetData();
    }
    protected void GV_RewardList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    Label lblID = e.Row.FindControl("lblID") as Label;
        //    string Status = string.Empty;
        //    DAL objDAL = new DAL();
        //    DataTable dt = objDAL.Gettable("Select ID,Status From RewardTransaction Where ID='" + lblID.Text + "'", ref message);
        //    if (dt.Rows.Count > 0)
        //    {
        //        Status = dt.Rows[0]["Status"].ToString();
        //        if (Status == "Achieved")
        //        {
        //            e.Row.Cells[7].Text = "<i class='fa fa-check-circle-o fa-2x' style='color:green;'></i>";
        //        }
        //        else if (Status == "Not Achieved")
        //        {
        //            e.Row.Cells[7].Text = "<i class='fa fa-times-circle-o fa-2x' style='color:red;'></i>";
        //        }
        //    }

        //}
    }



    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here




}