﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Gallery : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                //txtID.Text = GetUniqueKey(6).ToString();
                //GetPinNo();
                //txtID.ReadOnly = true;
             
                ShowData();
            }
            else
            {
               
                Response.Redirect("Logout.aspx");
            }

        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        GalleryProperty GP = new GalleryProperty();
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);


        if (FileUpload1.HasFile)
        {
            string FileName = FileUpload1.PostedFile.FileName;
            string FileSize = FileName.Length.ToString() + " Bytes";
            //strFileName = DateTime.Now.ToString("yyyyMMddHHmmss") + FileUpload1.FileName;  
            FileUpload1.PostedFile.SaveAs(Server.MapPath(@"../Document/" + FileName.Trim()));
            string FilePath = @"../Document/" + FileName.Trim().ToString();
            //GP.ID = txtID.Text;
            GP.Name = txtName.Text;
            GP.Status = drpstatus.SelectedItem.Text;
            GP.FileUpload = FilePath;
            GP.Videolink = txtlink.Text;

            //try
            //    {
            //        GalleryLogic GL = new GalleryLogic();
            //        int rowaffected = GL.Insert(GP, ref message);
            //        if (rowaffected > 0)
            //        {
            //            int index = dal.Executequery("Update Gallery set Name=@Name", ref message);
            //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Information Saved Successfully')", true);
            //        }
            //        else
            //        {
            //            string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
            //            var script = string.Format("alert({0});", errormessage);
            //            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Please try again...!", script, true);
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            //        var script = string.Format("alert({0});", errormessage);
            //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            //    }
            //    finally
            //    {
            //        ShowData();
            //        //GetPinNo();
            //        Reset();
            //    }
            try
            {
               
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Gallery(Name,Videos,Images,Status,Date) values('" + txtName.Text + "','"+txtlink.Text+"','" + FilePath + "','" + drpstatus.SelectedItem.Text + "',GETDATE())", con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                //sda.Fill(dt);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    Response.Redirect("SuccessView.aspx?Link=Gallery.aspx");
                    //Response.Write("<script>alert('Data Inserted Sucessfully...!!')</script>");

                }
                else
                {
                    Response.Write("<script>alert('Data Not Inserted ...!!')</script>");
                }


            }
            catch (Exception ex)
            {

            }
            finally
            {
                Reset();
                ShowData();
            }


        }
        else
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Gallery(Name,Videos,Images,Status,Date) values('" + txtName.Text + "','"+txtlink.Text+"','Not Available','" + drpstatus.SelectedItem.Text + "',GETDATE())", con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    Response.Redirect("SuccessView.aspx?Link=Gallery.aspx");
                    // Response.Write("<script>alert('Data Inserted Sucessfully...!!')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Data Not Inserted ...!!')</script>");
                }
            }
            catch(Exception ex)
            {

            }
            finally
            {
                Reset();
                ShowData();
            }

        }
    }
    void ShowData()
    {
        StringBuilder sba = new StringBuilder();
        sba.AppendFormat("Select ID,Name,Images,Status,Date,Videos from Gallery");
        DataTable dt = dal.Gettable(sba.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }

    
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            string FileName = FileUpload1.PostedFile.FileName;
            string FileSize = FileName.Length.ToString() + " Bytes";
            //strFileName = DateTime.Now.ToString("yyyyMMddHHmmss") + FileUpload1.FileName;  
            FileUpload1.PostedFile.SaveAs(Server.MapPath(@"../Document/" + FileName.Trim()));
            string FilePath = @"../Document/" + FileName.Trim().ToString();
            //GP.ID = txtID.Text;


            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update Gallery set Name='" + txtName.Text + "',Videos='" + txtlink.Text + "',Images='" + FilePath + "',Status='" + drpstatus.SelectedItem.Text + "' where ID='" + ViewState["ID"].ToString() + "' ", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();

                if (a > 0)
                {
                    Response.Redirect("SuccessView.aspx?Link=Gallery.aspx");
                    // Response.Write("<script>alert('Record Updated Sucessfully...!!')</script>");
                    ShowData();
                }
                else
                {
                    Response.Write("<script>alert('Record Not Updated Sucessfully...!!')</script>");
                }


            }
            catch (Exception ex)
            {

            }

            finally
            {
                con.Close();
                clear();
            }
        }
        else
        {
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update Gallery set Name='" + txtName.Text + "',Videos='" + txtlink.Text + "',Status='" + drpstatus.SelectedItem.Text + "' where ID='" + ViewState["ID"].ToString() + "' ", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();

                if (a > 0)
                {
                    Response.Redirect("SuccessView.aspx?Link=Gallery.aspx");
                    // Response.Write("<script>alert('Record Updated Sucessfully...!!')</script>");
                    ShowData();
                }
                else
                {
                    Response.Write("<script>alert('Record Not Updated Sucessfully...!!')</script>");
                }


            }
            catch (Exception ex)
            {

            }

            finally
            {
                con.Close();
                clear();



            }

        }
        
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Reset();
    }

    void Reset()
    {
        txtName.Text = string.Empty;
        txtlink.Text = string.Empty;
        drpstatus.SelectedIndex = -1;
        //GetPinNo();
    }

    //protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName == "Download")
    //    {
    //        Response.Clear();
    //        Response.ContentType = "application/octect-stream";
    //        Response.AppendHeader("content-disposition", "filename=" + e.CommandArgument);
    //        Response.TransmitFile(Server.MapPath(@"~/Document/") + e.CommandArgument);
    //        Response.End();
    //    }
    //}

    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }

    //private void GetPinNo()
    //{
    //    int flag = 1;
    //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
    //    con.Open();
    //    while (flag == 1)
    //    {
    //        string ID = GetUniqueKey(6);
    //        SqlCommand cmd = new SqlCommand("PinGenerateGallery", con);
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.Parameters.AddWithValue("@ID", ID);
    //        cmd.Parameters.AddWithValue("@Mode", "CHECK_PIN_NO");
    //        flag = (int)cmd.ExecuteScalar();
    //        txtID.Text = ID;
    //    }
    //    con.Close();
    //}


    public void ActiveInactiveStatus()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select Status from Gallery", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            string status = dt.Rows[0]["Status"].ToString();
            if (status == "Active")
            {
               
            }

        }
        catch (Exception ex)
        {


        }
    }


    protected void btnEdit_Command(object sender, CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        ViewState["ID"] = id;
        

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Gallery where ID='" + id + "'", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                btnAdd.Visible = false;
                btncancel.Visible = false;
                btnupdate.Visible = true;
                txtName.Text = dt.Rows[0]["Name"].ToString();
                //txtlink.Text = dt.Rows[0]["Videos"].ToString();
                drpstatus.SelectedItem.Text =  dt.Rows[0]["Status"].ToString();
                imgUpdate.ImageUrl = dt.Rows[0]["Images"].ToString();

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

    public void clear()
    {
       // txtlink.Text = "";
        txtName.Text = "";
        drpstatus.SelectedItem.Text = "Select Status";
        imgUpdate.ImageUrl = "~/Company/images/dummy.jpg";

    }

}