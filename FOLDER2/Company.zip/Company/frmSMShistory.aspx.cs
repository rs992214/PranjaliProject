﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Data;
using System.Text;

public partial class Company_frmSMShistory : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {

                ShowSendMessage();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
       string Sendid = GridView1.DataKeys[e.RowIndex].Values["SendID"].ToString();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("delete from SMSHistory where SendID='{0}'", Sendid);
        try
        {
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Message Deleted Successfully')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Oops! Some Error Occur.try After Some Time.')", true);
            }
        }
        catch (Exception)
        {

            throw;
        }
        finally
        {
            ShowSendMessage();
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowSendMessage();
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ShowSendMessage();
    }
    public void ShowSendMessage()
    {
        StringBuilder sb = new StringBuilder();
        if (txtdate.Text!="" && txtdate1.Text != "")
        {
            //string[] date = txtdate.Text.Split('/');
            //string[] date1 = txtdate1.Text.Split('/');
            //string joinstring = "/";
            //string fromdate = date[2] + joinstring + date[1] + joinstring + date[0];
            //string todate = date1[2] + joinstring + date1[1] + joinstring + date1[0];
            sb.AppendFormat("select * from SMSHistory where DATEADD(DAY, DATEDIFF(DAY, '19000101', Date), '19000101') between '{0}' and '{1}'", txtdate.Text, txtdate1.Text);
        }
        else
        {
            sb.AppendFormat("select * from SMSHistory order by SendID desc");
        }

        try
        {
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
}