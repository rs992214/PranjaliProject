﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;
using iTextSharp.text;
using iTextSharp.text.pdf;

public partial class Member_ReceiveReport : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string package = string.Empty;
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                GetReceiveList();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void GetReceiveList()
    {
        try
        {
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Donation_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Mode", "GET_RECEIVE_ALL");
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rdr);
            con.Close();
            if (dt.Rows.Count > 0)
            {
                GV_Receive_List.DataSource = dt;
                GV_Receive_List.DataBind();
                btnexportexcel.Visible = true;
                btnexportPdf.Visible = true;
            }
            else
            {
                GV_Receive_List.DataSource = null;
                GV_Receive_List.DataBind();
                btnexportexcel.Visible = false;
                btnexportPdf.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void GV_Receive_List_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_Receive_List.PageIndex = e.NewPageIndex;
    }
    protected void lnkAccept_Click(object sender, EventArgs e)
    {
        try
        {
            
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void lnkUpload_Command(object sender, CommandEventArgs e)
    {
        try
        {
            GridViewRow grdrow = (GridViewRow)((LinkButton)sender).NamingContainer as GridViewRow;
            Label lblamount = (Label)grdrow.FindControl("lblAmount");
            FileUpload file = (FileUpload)grdrow.FindControl("fupUpload");
            string extension = Path.GetExtension(file.PostedFile.FileName);
            string fileName = "Receipt_" + Session["UserID"].ToString() + "_" + lblamount.Text + "_" + DateTime.Today.ToString("dd-MM-yyyy") + extension;
            file.PostedFile.SaveAs(Server.MapPath("~/Receipt/" + fileName));
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Donation_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Status", "Approved");
            cmd.Parameters.AddWithValue("@Photo", "~/Receipt/" + fileName);
            cmd.Parameters.AddWithValue("@ID", e.CommandArgument.ToString());
            cmd.Parameters.AddWithValue("@Mode", "UPD");
            int flag = cmd.ExecuteNonQuery();
            if (flag > 0)
            {
                ShowPopupMessage("Receipt Uploaded Successfully!", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage(message, PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        finally
        {
            con.Close();
        }
    }
    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=ReceiveReport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GV_Receive_List.AllowPaging = false;
                GetReceiveList();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GV_Receive_List.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GV_Receive_List.HeaderRow.Cells)
                {
                    cell.BackColor = GV_Receive_List.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GV_Receive_List.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GV_Receive_List.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GV_Receive_List.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GV_Receive_List.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void imgPdf_Command(object sender, CommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Download")
            {
                if (e.CommandArgument.ToString() != "images/gallery.png")
                {
                    Response.Clear();
                    Response.ContentType = "application/octet-stream";
                    Response.AppendHeader("Content-Disposition", "filename=" + e.CommandArgument);
                    Response.TransmitFile(e.CommandArgument.ToString());
                }
                else
                {
                    ShowPopupMessage("Receipt not generated yet!", PopupMessageType.Warning);
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
    protected void GV_Receive_List_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string id = GV_Receive_List.DataKeys[e.RowIndex].Values["ID"].ToString();
        try
        {
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Donation_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", id);
            cmd.Parameters.AddWithValue("@Mode", "DEL");
            int flag = cmd.ExecuteNonQuery();
            if (flag > 0)
            {
                ShowPopupMessage("Data Deleted Successfully!", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage(message, PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "'" + ex.Message + "'", true);
        }
        finally
        {
            con.Close();
            GetReceiveList();
        }
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }

    protected void btnexportPdf_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(connstring);
        con.Open();
        cmd = new SqlCommand("Donation_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Mode", "GET_RECEIVE_ALL");
        SqlDataReader rdr = cmd.ExecuteReader();
        DataTable dt = new DataTable();
        dt.Load(rdr);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            CreatePdfFile(dt);
        }
    }

    void CreatePdfFile(DataTable PDF)
    {
        string filename = "GSTReport.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);


        Document doc = new Document(PageSize.A4, 10, 10, 40, 10);

        Paragraph p = new Paragraph("GST Report");
        p.Alignment = Element.ALIGN_CENTER;

        try
        {
            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(11);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("GST Report", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("images/Probuzimg.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------

            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "application/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch
        {

        }
    }
    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }
}