﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Security.Cryptography;

public partial class Company_PinGenerate : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetPackage();
            GetData("Unused");
        }
    }
    private void GetPackage()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,PackageName From PackageInfo order by ID asc", ref message);
            if (dt.Rows.Count > 0)
            {
                DDLPackage.DataSource = dt;
                DDLPackage.DataTextField = "PackageName";
                DDLPackage.DataValueField = "ID";
                DDLPackage.DataBind();
                DDLPackage.Items.Insert(0, new ListItem("--Please Select Package--", "0"));
            }
            else
            {
                DDLPackage.DataSource = dt;
                DDLPackage.DataBind();
                DDLPackage.Items.Insert(0, new ListItem("--Please Select Package--", "0"));
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void GetData(string Status)
    {
        if(Status== "Used")
        {

        }
        try
        {
            DAL objDAL = new DAL();
            DataTable dt;
            if (Status == "Used")
            {
                 dt = objDAL.Gettable("Select PG.UserID,PG.ID,PG.PackageID,P.PackageName,P.Amount,PG.PinNo,PG.Status From PinGenerateNew PG Inner Join PackageInfo P On P.ID=PG.PackageID Where PG.Status='" + Status + "' and PG.TransferBy='Admin' order by ID desc", ref message);
            }
            else
            {
                 dt = objDAL.Gettable("Select PG.UserID,PG.ID,PG.PackageID,P.PackageName,P.Amount,PG.PinNo,PG.Status From PinGenerateNew PG Inner Join PackageInfo P On P.ID=PG.PackageID Where PG.Status='" + Status + "' and PG.UserID IS NULL and PG.TransferTo IS NULL order by ID desc", ref message);
            }

            if (dt.Rows.Count > 0)
            {
                GV_PackageList.DataSource = dt;
                GV_PackageList.DataBind();
            }
            else
            {
                GV_PackageList.DataSource = null;
                GV_PackageList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }
    private void GetPinNo()
    {
        int flag = 1;
        con = new SqlConnection(connstring);
        con.Open();
        while (flag == 1)
        {
            string PinNo = GetUniqueKey(6);
            cmd = new SqlCommand("PinGenerateNew_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@PinNo", PinNo);
            cmd.Parameters.AddWithValue("@Mode", "CHECK_PIN_NO");
            flag = (int)cmd.ExecuteScalar();
            lblPinNo.Text = PinNo;
        }
        con.Close();
    }
    private void ClearData()
    {
        DDLPackage.SelectedIndex = 0;
        txtQty.Text = string.Empty;
        GetData("Unused");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

        // <-- 22/10/2019 Pin genearte start go code -->

        try
        { 
            if(txtQty.Text != string.Empty && DDLPackage.SelectedValue != "0")
            {
                int PinQty = Convert.ToInt32(txtQty.Text);
                if (PinQty > 0)
                {
                    int _Count = 0;
                    for (int i = 0; i < PinQty; i++)
                    {
                        GetPinNo();
                        con = new SqlConnection(connstring);
                        con.Open();
                        cmd = new SqlCommand("PinGenerateNew_ALL", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@PackageID", DDLPackage.SelectedValue);
                        cmd.Parameters.AddWithValue("@PinNo", lblPinNo.Text);
                        cmd.Parameters.AddWithValue("@Mode", "IN");
                        int flag = cmd.ExecuteNonQuery();
                        con.Close();
                        if (flag > 0)
                        {
                            _Count = _Count + flag;
                        }
                        else
                        {
                            _Count = _Count + flag;
                        }
                    }
                    if (_Count == PinQty)
                    {
                        ClearData();
                        Response.Redirect("SuccessView.aspx?Link=PinGenerate.aspx");
                        //ShowPopupMessage("Pin has been Generated SuccessFully.", PopupMessageType.Success);
                    }
                }
                else
                {
                    ShowPopupMessage("Invalid Pin Qty.", PopupMessageType.Error);
                }
            }
        }
        catch(Exception ex)
        {
            ShowPopupMessage(ex.Message,PopupMessageType.Error);
        }   
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        Response.Redirect("PinGenerate.aspx");
    }
    protected void GV_PackageList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_PackageList.PageIndex = e.NewPageIndex;
        string Status = string.Empty;
        if (rdActive.Checked == true)
        {
            Status = "Used";
        }
        else
        {
            Status = "Unused";
        }
        GetData(Status);
    }
    
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("PinGenerateNew_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Parameters.AddWithValue("@Mode", "DEL");
            int flag = cmd.ExecuteNonQuery();
            con.Close();
            if (flag > 0)
            {
                ClearData();
                Response.Redirect("SuccessView.aspx?Link=PinGenerate.aspx");
               // ShowPopupMessage("Pin has been Deleted successfully.", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage("This Pin in used.", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void rdActive_CheckedChanged(object sender, EventArgs e)
    {
        GetData("Used");
    }

    protected void rdInactive_CheckedChanged(object sender, EventArgs e)
    {
        GetData("Unused");
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here    
}