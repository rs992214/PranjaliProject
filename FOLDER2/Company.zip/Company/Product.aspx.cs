﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Product : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                showcategoryList();
                drpsubcategory.Items.Insert(0, new ListItem("Select SubCategory", "0"));
                if (string.IsNullOrEmpty(Request.QueryString["ProductCode"]))
                {
                    btnupdate.Visible = false;
                }
                else
                {
                    Helper hlp = new Helper();
                    ViewState["ProductCode"] = HttpUtility.UrlDecode(hlp.Decrypt(Request.QueryString["ProductCode"].ToString()));
                    ShowProductDetail();
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void showcategoryList()
    {
        drpcategory.DataTextField = "CategoryName";
        drpcategory.DataValueField = "ID";
        try
        {
            CategoryMaster CM = new CategoryMaster();
            DataTable dt = CM.FetchCategory(ref message);
            if (dt.Rows.Count > 0)
            {
                drpcategory.DataSource = dt;
                drpcategory.DataBind();
                drpcategory.Items.Insert(0, new ListItem("Select Category", "0"));
            }
            else
            {
                drpcategory.DataSource = null;
                drpcategory.DataBind();
                drpcategory.Items.Insert(0, new ListItem("Select Category", "0"));
            }
        }
        catch (Exception ex)
        {
            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    public void showSubCategoryList()
    {
        drpsubcategory.DataTextField = "SubCategoryName";
        drpsubcategory.DataValueField = "ID";
        try
        {
            SubcategoryProperty SP = new SubcategoryProperty { CategoryName = drpcategory.SelectedItem.Text };
            SubcategoryMaster SM = new SubcategoryMaster();
            DataTable dt = SM.FetchSubCategory(SP, ref message);
            if (dt.Rows.Count > 0)
            {
                drpsubcategory.DataSource = dt;
                drpsubcategory.DataBind();
                drpsubcategory.Items.Insert(0, new ListItem("Select SubCategory", "0"));
            }
            else
            {
                drpsubcategory.DataSource = null;
                drpsubcategory.DataBind();
                drpsubcategory.Items.Insert(0, new ListItem("Select SubCategory", "0"));
            }
        }
        catch (Exception ex)
        {
            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
        }
    }
    protected void drpcategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpsubcategory.Items.Clear();
        showSubCategoryList();
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            ProductProperty PP = new ProductProperty
            {
                ID = Convert.ToInt32(drpsubcategory.SelectedValue),
                ProductName = txtproductname.Text,
                HSNCode = txthsncode.Text,
                Description = txtdescription.Text,
                CostPrice = Convert.ToDecimal(txtpurchaserate.Text),
                SellingPrice = Convert.ToDecimal(txtsalesrate.Text),
                MRP = (!string.IsNullOrEmpty(txtmrp.Text)) ? Convert.ToDecimal(txtmrp.Text) : 0,
                SV = (!string.IsNullOrEmpty(txtsv.Text)) ? Convert.ToInt32(txtsv.Text) : 0,
                ReorderPoint = (!string.IsNullOrEmpty(txtreorderpoint.Text)) ? Convert.ToInt32(txtreorderpoint.Text) : 0,
                OpeningStock = (!string.IsNullOrEmpty(txtopeningstock.Text)) ? Convert.ToInt32(txtopeningstock.Text) : 0,
                GST = (!string.IsNullOrEmpty(txtgst.Text)) ? Convert.ToDecimal(txtgst.Text) : 0,
                BBOPrice = Convert.ToDecimal(txtbboprice.Text),
                Status = drpstatus.SelectedItem.Text,
                ShippingPrice = Convert.ToDecimal(txtshipping.Text)
            };
            ProductLogic PL = new ProductLogic();
            int rowaffected = PL.Saveproduct(PP, ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Product Added Successfully')", true);
            }
            else
            {
                var errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }
        catch (Exception ex)
        {
            var ErrorMessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", ErrorMessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        try
        {
            ProductProperty PP = new ProductProperty
            {
                ProductCode = ViewState["ProductCode"].ToString(),
                ID = Convert.ToInt32(drpsubcategory.SelectedValue),
                ProductName = txtproductname.Text,
                HSNCode = txthsncode.Text,
                Description = txtdescription.Text,
                CostPrice = Convert.ToDecimal(txtpurchaserate.Text),
                SellingPrice = Convert.ToDecimal(txtsalesrate.Text),
                MRP = (!string.IsNullOrEmpty(txtmrp.Text)) ? Convert.ToDecimal(txtmrp.Text) : 0,
                SV = (!string.IsNullOrEmpty(txtsv.Text)) ? Convert.ToInt32(txtsv.Text) : 0,
                ReorderPoint = (!string.IsNullOrEmpty(txtreorderpoint.Text)) ? Convert.ToInt32(txtreorderpoint.Text) : 0,
                OpeningStock = (!string.IsNullOrEmpty(txtopeningstock.Text)) ? Convert.ToInt32(txtopeningstock.Text) : 0,
                GST = (!string.IsNullOrEmpty(txtgst.Text)) ? Convert.ToDecimal(txtgst.Text) : 0,
                BBOPrice = Convert.ToDecimal(txtbboprice.Text),
                Status = drpstatus.SelectedItem.Text,
                ShippingPrice = Convert.ToDecimal(txtshipping.Text)
            };
            ProductLogic PL = new ProductLogic();
            int rowaffected = PL.Updateproduct(PP, ref message);
            if (rowaffected > 0)
            {
                Session["Message"] = rowaffected;
                Response.Redirect("ProductDetails.aspx", false);
            }
            else
            {
                var errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }
        catch (Exception ex)
        {
            var ErrorMessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", ErrorMessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        drpcategory.SelectedIndex = 0;
        drpsubcategory.SelectedIndex = 0;
        txtproductname.Text = null;
        txthsncode.Text = null;
        txtdescription.Text = null;
        txtpurchaserate.Text = null;
        txtsalesrate.Text = null;
        txtmrp.Text = null;
        txtsv.Text = null;
        txtreorderpoint.Text = "0";
        txtopeningstock.Text = "0";
        txtgst.Text = "0.0";
        btnsave.Visible = true;
        btnupdate.Visible = false;
        txtbboprice.Text = null;
        drpstatus.SelectedIndex = 0;
        txtshipping.Text = null;
        if (ViewState["ProductCode"] != null)
        {
            ViewState["ProductCode"] = null;
        }
    }

    public void ShowProductDetail()
    {
        try
        {
            ProductProperty PP = new ProductProperty { ProductCode = ViewState["ProductCode"].ToString() };
            ProductLogic PL = new ProductLogic();
            DataTable dt = PL.SearchProductCode(PP, ref message);
            if (dt.Rows.Count > 0)
            {
                drpcategory.ClearSelection();
                drpcategory.Items.FindByText(dt.Rows[0]["Category"].ToString()).Selected = true;
                drpsubcategory.Items.Clear();
                showSubCategoryList();
                drpsubcategory.ClearSelection();
                drpsubcategory.Items.FindByText(dt.Rows[0]["SubCategoryName"].ToString()).Selected = true;
                txtproductname.Text = dt.Rows[0]["ProductName"].ToString();
                txthsncode.Text = dt.Rows[0]["HSNCode"].ToString();
                txtdescription.Text = dt.Rows[0]["Description"].ToString();
                txtpurchaserate.Text = dt.Rows[0]["CostPrice"].ToString();
                txtsalesrate.Text = dt.Rows[0]["SellingPrice"].ToString();
                txtmrp.Text = dt.Rows[0]["MRP"].ToString();
                txtreorderpoint.Text = dt.Rows[0]["ReorderPoint"].ToString();
                txtopeningstock.Text = dt.Rows[0]["OpeningStock"].ToString();
                txtopeningstock.Enabled = false;
                txtgst.Text = dt.Rows[0]["GST"].ToString();
                txtsv.Text = dt.Rows[0]["SV"].ToString();
                txtbboprice.Text = dt.Rows[0]["BBOPrice"].ToString();
                drpstatus.Items.FindByText(dt.Rows[0]["Status"].ToString()).Selected = true;
                txtshipping.Text = dt.Rows[0]["Shipping Charge(%)"].ToString();
                btnsave.Visible = false;
                btnupdate.Visible = true;
            }
        }
        catch (Exception ex)
        {

            var ErrorMessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", ErrorMessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
}