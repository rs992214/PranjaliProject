﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_AddStock : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            txtproductcode.Focus();
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try { 
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
        string SQL = "Update Product set OpeningStock=OpeningStock + '" + txtquantity.Text + "' , UpdateDate=GetDate() where ProductCode='"+ txtproductcode.Text +"' OR ProductName='" +  txtproductname.Text + "'" ;
        SqlCommand cmd = new SqlCommand(SQL, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Stock Updated Successfully')", true);
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            txtproductcode.Text = "";
            txtproductname.Text = "";
            txtquantity.Text = "";
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtproductcode.Text = "";
        txtproductname.Text = "";
        txtquantity.Text = "";
    }
}