﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Text;
using System.Data;

public partial class Company_GeneralLedger : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(Request.QueryString["Date1"]) && !string.IsNullOrEmpty(Request.QueryString["Date2"]))
        {
            
            ViewState["Date1"] = Request.QueryString["Date1"].ToString();
            ViewState["Date2"] = Request.QueryString["Date2"].ToString();
            Showgeneralledger();
        }
        else
        {
            Response.Redirect("Reports.aspx");
        }

    }

    private void Showgeneralledger()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select S.Name,GL.InvoiceNo as [Voucher/InvoiceNo],GL.Description,GL.Debit,GL.Credit,convert(nvarchar(10),GL.Date,103) as Date from GeneralLedger as GL inner join Supplier as S on GL.SupplierID = S.SupplierID where GL.Date Between '{0}' and '{1}'", ViewState["Date1"].ToString(), ViewState["Date2"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Showgeneralledger();
    }

    decimal credit = 0;
    decimal debit = 0;
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            decimal tempcredit = 0;
            debit += Convert.ToDecimal(e.Row.Cells[4].Text);
            decimal.TryParse(e.Row.Cells[5].Text,out tempcredit);
            credit += tempcredit;
            lbldebit.Text = debit.ToString();
            lblcredit.Text = credit.ToString();

            lblclosingbal.Text= (debit - credit).ToString();
        }
    }
}