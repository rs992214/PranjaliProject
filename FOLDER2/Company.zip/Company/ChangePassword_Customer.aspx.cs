﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Net;

public partial class Company_ChangePassword_Customer : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    string loginip = GetLocalIPAddress();
    string UserName = "";
    string password1 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        GetLocalIPAddress();
        AdminLoginInfo();
        if (!IsPostBack)
        {

        }
    }
    private void Clear()
    {
        txtUserID.Text = string.Empty;
        txtPassword.Text = string.Empty;
        txtConfirm.Text = string.Empty;
        _Valid.Visible = false;
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtUserID.Text != string.Empty && txtPassword.Text != string.Empty)
            {
                if(txtPassword.Text == txtConfirm.Text)
                {

               

            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("MLM_Registration_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
            cmd.Parameters.AddWithValue("@Mode", "CHANGE_PASSWORD");
            int flag = cmd.ExecuteNonQuery();
            if (flag > 0)
            {
                ChangeUserPassword();
                Clear();
                    Response.Redirect("SuccessView.aspx?Link=ChangePassword_Customer.aspx");
                   // ShowPopupMessage("Password has been changed.", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage("Some Error Occurred.", PopupMessageType.Error);
            }
                }
                else
                {
                    ShowPopupMessage("Password Not Matched.", PopupMessageType.Warning);
                }

            }
            else
            {
                ShowPopupMessage(" Please Update All Data...", PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {


                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Error: "+error+" ... ')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChangePassword_Customer.aspx");
    }
    protected void txtUserID_TextChanged(object sender, EventArgs e)
    {
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID From MLM_Registration Where UserID='" + txtUserID.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtUserID.Text = dt.Rows[0]["UserID"].ToString();
            _Valid.Visible = true;
        }
        else
        {
            txtUserID.Text = string.Empty;
            _Valid.Visible = false;
            ShowPopupMessage("Incorrect User ID.", PopupMessageType.Error);
        }
    }





    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName = dt.Rows[0]["UserName"].ToString();
                password1 = dt.Rows[0]["password"].ToString();

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    public void ChangeUserPassword()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {


            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Success:Password Changed Successfully For User Id="+ txtUserID.Text+ " and New Password is "+ txtPassword.Text+ " ')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }


}