﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
using System.Text;
using System.IO;
using System.Net;
using System.Web.Script.Serialization;
using DataAccessLayer;

public partial class Backoffice_Login : System.Web.UI.Page
{
    
    DAL dal = new DAL();
    string message = string.Empty;
    string loginip = GetLocalIPAddress();
    string Error = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        GetLocalIPAddress();
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select UserName,Password from Adminlogin where UserName='{0}' and Password='{1}'", txtusername.Value, txtpassword.Value);
        try
        {
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                Session["UserName"] = dt.Rows[0]["UserName"].ToString();
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" +txtusername.Value + "','" + txtpassword.Value + "','" + loginip + "',GETDATE(),'Login SucessFully..!!')", con);
                    cmd.CommandType = CommandType.Text;

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {

                    }
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    con.Close();
                }

                Response.Redirect("Dashboard.aspx", false);
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username Or Password')</script>");
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + txtusername.Value + "','" + txtpassword.Value + "','" + loginip + "',GETDATE(),'Login Faild:Invalid Account Or Password.!!')", con);
                    cmd.CommandType = CommandType.Text;

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {

                    }
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    con.Close();
                }
                return;
                

            }
        }
        catch (Exception ex)
        {
     
            Error = ex.ToString();
            forcatchTrace();

        }
    }
    string senderusername, userid, password, routeid;
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select * from Adminlogin where Mobile='{0}'", txtMobileNo.Text);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                StringBuilder sb1 = new StringBuilder();
                sb1.AppendFormat("select * from Smsmaster");
                DataTable dt1 = dal.Gettable(sb1.ToString(), ref message);
                if (dt1.Rows.Count > 0)
                {
                    senderusername = dt1.Rows[0]["Senderid"].ToString();
                    userid = dt1.Rows[0]["Userid"].ToString();
                    password = dt1.Rows[0]["Password"].ToString();
                    routeid = dt1.Rows[0]["Routeid"].ToString();
                    string text = "Hello," + "\n" + "You have Requested For Login Credential. Your Credential Information Are Given Below:\n" + "UserID:" + dt.Rows[0]["UserName"].ToString() + ", Password:" + dt.Rows[0]["Password"].ToString() + "\nThank You.";
                    string sURL;
                    StreamReader objReader;
                    sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userid + "&password=" + password + "&sender=" + senderusername + "&to=" + txtMobileNo.Text + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + routeid;
                    WebRequest wrGETURL;
                    wrGETURL = WebRequest.Create(sURL);
                    try
                    {
                        Stream objStream;
                        objStream = wrGETURL.GetResponse().GetResponseStream();
                        objReader = new StreamReader(objStream);
                        objReader.Close();
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Credential Information Sent on Your Mobile No Successfully.')", true);
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                    }
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Sorry,Your Mobile Number Is Not Present In Our DataBase.')", true);
                return;
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            txtMobileNo.Text = null;
        }
    }
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    public void forcatchTrace()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + txtusername.Value + "','" + txtpassword.Value + "','" + loginip + "',GETDATE(),'Error:'" + Error + "'')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }


    }
}