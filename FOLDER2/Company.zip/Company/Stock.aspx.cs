﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Stock : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["ProductCode"]))
                {
                    ViewState["ProductCode"] = Request.QueryString["ProductCode"].ToString();
                    Showinward();
                    Showoutward();
                }
                else
                {
                    Response.Redirect("ProductDetails.aspx");
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    private void Showinward()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select P.ProductName,S.InvoiceNo,SP.Qty,S.Date from Stock_Product  as SP inner join Stock as S on SP.InvoiceNo=S.InvoiceNo inner join Product as P on Sp.ProductCode=P.ProductCode  where SP.ProductCode='{0}' order by s.Date desc", ViewState["ProductCode"].ToString());
            DataTable inward = dal.Gettable(sb.ToString(), ref message);
            if (inward.Rows.Count > 0)
            {
                grdinward.DataSource = inward;
                grdinward.DataBind();
            }
            else
            {
                grdinward.DataSource = null;
                grdinward.DataBind();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    private void Showoutward()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select P.ProductName,InvoiceNo,QTY,convert(nvarchar(10),Datetime,103) as Date from OutWardProduct as OP inner join Product as p on OP.ProductCode=P.ProductCode where OP.ProductCode='{0}' order by OP.Datetime desc", ViewState["ProductCode"].ToString());
            DataTable outward = dal.Gettable(sb.ToString(), ref message);
            if (outward.Rows.Count > 0)
            {
                grdoutward.DataSource = outward;
                grdoutward.DataBind();
            }
            else
            {
                grdoutward.DataSource = null;
                grdoutward.DataBind();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected void grdinward_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdinward.PageIndex = e.NewPageIndex;
        Showinward();
    }

    protected void grdinward_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string invoiceno = grdinward.SelectedRow.Cells[2].Text;
        //Response.Redirect("PurchaseEntry_Detail.aspx?InvoiceNo=" + invoiceno, false);
    }

    protected void grdoutward_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdoutward.PageIndex = e.NewPageIndex;
        Showoutward();
    }

    protected void grdoutward_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string invoiceno = grdoutward.SelectedRow.Cells[2].Text;
        //Response.Redirect("Order_Detail.aspx?invoiceNo=" + invoiceno, false);
    }
}