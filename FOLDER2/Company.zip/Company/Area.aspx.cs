﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Area : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ShowStateName();
            ShowCityName();
            ShowAreaName();
            btnupdate.Visible = false;
        }
    }
    public void ShowStateName()
    {
        drpstate.DataTextField = "StateName";
        drpstate.DataValueField = "StateID";
        drpstate1.DataTextField = "StateName";
        drpstate1.DataValueField = "StateID";
        State St = new State();
        DataTable dt = St.GetData(ref message);
        if (dt.Rows.Count > 0)
        {
            drpstate.DataSource = dt;
            drpstate.DataBind();
            drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));
            drpstate1.DataSource = dt;
            drpstate1.DataBind();
            drpstate1.Items.Insert(0, new ListItem("Select State Name", "0"));
        }
        else
        {
            drpstate.DataSource = null;
            drpstate.DataBind();
            drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));
            drpstate1.DataSource = null;
            drpstate1.DataBind();
            drpstate1.Items.Insert(0, new ListItem("Select State Name", "0"));
        }
    }

    public void ShowCityName()
    {

        if (drpstate.SelectedIndex > 0)
        {
            drpcity.DataTextField = "CityName";
            drpcity.DataValueField = "CityID";

            CityProperty Cp = new CityProperty();
            Cp.StateID = Convert.ToInt32(drpstate.SelectedValue);
            City cty = new City();
            DataTable dt = cty.GetData(Cp, ref message);
            if (dt.Rows.Count > 0)
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select City Name", "0"));
            }
            else
            {
                drpcity.DataSource = null;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select City Name", "0"));
            }
        }
        else if (drpstate1.SelectedIndex > 0)
        {

            drpcity1.DataTextField = "CityName";
            drpcity1.DataValueField = "CityID";

            CityProperty Cp = new CityProperty();
            Cp.StateID = Convert.ToInt32(drpstate1.SelectedValue);
            City cty = new City();
            DataTable dt = cty.GetData(Cp, ref message);
            if (dt.Rows.Count > 0)
            {
                drpcity1.DataSource = dt;
                drpcity1.DataBind();
                drpcity1.Items.Insert(0, new ListItem("Select City Name", "0"));
            }
            else
            {
                drpcity1.DataSource = null;
                drpcity1.DataBind();
                drpcity1.Items.Insert(0, new ListItem("Select City Name", "0"));
            }
        }
        else
        {
            drpcity.DataSource = null;
            drpcity.DataBind();
            drpcity.Items.Insert(0, new ListItem("Select City Name", "0"));
            drpcity1.DataSource = null;
            drpcity1.DataBind();
            drpcity1.Items.Insert(0, new ListItem("Select City Name", "0"));
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        AreaProperty Ap = new AreaProperty();
        Ap.StateID= Convert.ToInt32(drpstate.SelectedValue);
        Ap.CityID=Convert.ToInt32(drpcity.SelectedValue);
        Ap.AreaName = txtarea.Text;
        Area Aa = new Area();
        try
        {
            int rowaffected = Aa.SaveArea(Ap, ref message);
            if (rowaffected>0)
            {

                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "Area Save Successfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text =message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {

            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowAreaName();
        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        AreaProperty Ap = new AreaProperty();
        Ap.StateID = Convert.ToInt32(drpstate.SelectedValue);
        Ap.CityID = Convert.ToInt32(drpcity.SelectedValue);
        Ap.AreaName = txtarea.Text;
        Ap.AreaID = Convert.ToInt32(ViewState["AreaID"]);
        Area Aa = new Area();
        try
        {
            int rowaffected = Aa.UpdateArea(Ap, ref message);
            if (rowaffected>0)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "Area Updated Successfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowAreaName();
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        drpstate.SelectedIndex = 0;
        drpcity.SelectedIndex = 0;
        txtarea.Text = string.Empty;
        btnupdate.Visible = false;
        btnsave.Visible = true;
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        AreaProperty Ap = new AreaProperty();
        Ap.AreaName = txtsearch.Text;
        Area Aa = new Area();
        try
        {
            DataTable dt = Aa.SearchData(Ap, ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                drpstate1.SelectedValue = dt.Rows[0]["StateID"].ToString();
                ShowCityName();
                drpcity1.SelectedValue= dt.Rows[0]["CityID"].ToString();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
        }
    }

    protected void drpcity1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowAreaName();
    }

    protected void drpstate1_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpcity1.Items.Clear();
        ShowCityName();
    }

    protected void drpstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpcity.Items.Clear();
        ShowCityName();
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowAreaName();

    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        AreaProperty Ap = new AreaProperty();
        Ap.AreaID = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values["AreaID"].ToString());
        Area Aa = new Area();
        try
        {
            int rowaffetced = Aa.DeleteArea(Ap, ref message);
            if (rowaffetced > 0)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "Area Deleted Sucessfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowAreaName();
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpstate.SelectedValue= drpstate1.SelectedValue;
        ShowCityName();
        drpcity.SelectedValue = drpcity1.SelectedValue;
        ViewState["AreaID"] = GridView1.SelectedRow.Cells[0].Text;
        txtarea.Text= GridView1.SelectedRow.Cells[1].Text;
        btnupdate.Visible = true;
        btnsave.Visible = false;

    }

    public void ShowAreaName()
    {
        if (drpcity1.SelectedIndex > 0)
        {
            AreaProperty Ap = new AreaProperty();
            Ap.CityID = Convert.ToInt32(drpcity1.SelectedValue);
            Area Aa = new Area();
            try
            {
                DataTable dt = Aa.GetData(Ap, ref message);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {
                    GridView1.DataSource = null;
                    GridView1.DataBind();
                }
            }
            catch (Exception ex)
            {

                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = ex.Message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }
    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> getAreaname(string prefixText)
    {
        List<string> name = new List<string>();
        DAL dal = new DAL();
        string message = string.Empty;
        try
        {
            StringBuilder sbb = new StringBuilder();
            sbb.AppendFormat("select AreaName from Area where AreaName like'{0}%'", prefixText);

            DataTable dt = dal.Gettable(sbb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    name.Add(dt.Rows[i][0].ToString());
                }

            }
        }

        catch (Exception)
        {
            throw;
        }
        return name;
    }
}