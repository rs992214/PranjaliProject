﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Globalization;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.IO;

public partial class Company_gst : System.Web.UI.Page
{
    

    string message = string.Empty;
    DAL objDAL = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           DATABIND();
        }
    }
    private void DATABIND()
    {
        try
        {
          
            DataTable dt = new DataTable();
          
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
            con.Open();
            //string query = "select * from  ##tbl_gst4";
            SqlCommand cmd = new SqlCommand("sp_gstreport", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GV_GST.DataSource = dt;
                GV_GST.DataBind();
            }
            else
            {
                GV_GST.DataSource = null;
                GV_GST.DataBind();
            }
        }
        catch(Exception ex)
        {

        }
    }

    //private void search()
    // {

    //    try
    //    {
    //        if (ddlmonth.SelectedIndex == 1)
    //        {
    //            DataTable dt = new DataTable();

    //            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
    //            con.Open();
    //            //string query = "select * from  ##tbl_gst5  where packagedate between CAST ( DATEADD(month, DATEDIFF(month, -1, getdate()) - 2, 0)AS date) AND  CAST  (DATEADD(ss, -1, DATEADD(month, DATEDIFF(month, 0, getdate()), 0))AS date) ";

    //            SqlCommand cmd = new SqlCommand("sp_gstreportmonth", con);
    //            cmd.CommandType = CommandType.StoredProcedure; ;
    //            SqlDataAdapter da = new SqlDataAdapter(cmd);
    //            da.Fill(dt);
    //            GV_GST.DataSource = dt;
    //            GV_GST.DataBind();
    //            con.Close();
    //        }
    //        else if (ddlmonth.SelectedIndex == 2)
    //        {
    //            DataTable dt = new DataTable();



    //            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
    //            con.Open();
    //            //string query = "select * from ##tbl_gst5  where (DatePart(Month, packagedate) BETWEEN DatePart(Month,DATEADD(m,-3,getdate())) AND  DatePart(Month,DATEADD(m,-1,getdate())) )AND(DatePart(Year, packagedate) BETWEEN DatePart(Year, DATEADD(m, -3, getdate())) AND DatePart(Year, DATEADD(m, -1, getdate())))";

    //            SqlCommand cmd = new SqlCommand("[sp_quarter]", con);
    //            cmd.CommandType = CommandType.StoredProcedure;
    //            SqlDataAdapter da = new SqlDataAdapter(cmd);
    //            da.Fill(dt);
    //            GV_GST.DataSource = dt;
    //            GV_GST.DataBind();
    //            con.Close();
    //        }
    //        else
    //        {
    //            DATABIND();

    //        }
    //    }
    //    catch(Exception ex)
    //    {


    //    }
        

        


    // }
    //private void searchquarter()
    //{
    //    DataTable dt = new DataTable();



    //    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
    //    con.Open();
    //    //string query = "select * from ##tbl_gst5  where (DatePart(Month, packagedate) BETWEEN DatePart(Month,DATEADD(m,-3,getdate())) AND  DatePart(Month,DATEADD(m,-1,getdate())) )AND(DatePart(Year, packagedate) BETWEEN DatePart(Year, DATEADD(m, -3, getdate())) AND DatePart(Year, DATEADD(m, -1, getdate())))";
   
    //    SqlCommand cmd = new SqlCommand("[sp_quarter]", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    SqlDataAdapter da = new SqlDataAdapter(cmd);
    //    da.Fill(dt);
    //    GV_GST.DataSource = dt;
    //    GV_GST.DataBind();
    //    con.Close();

        

    //}


    //private void total()
    //{
    //    DATABIND();
    //}

    
    //protected void btnSearch_Click(object sender, EventArgs e)
    //{
    //    if (ddlmonth.SelectedIndex==0)
    //    {
    //        search();
    //    }
    //    else if (ddlmonth.SelectedIndex==1)
    //    {
    //        searchquarter();
    //    }
    //    else
    //    {
    //        total();
    //    }

    //}
   



    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {

            //if (txtfromdate.Text != string.Empty && txttodate.Text != string.Empty && txtuserid.Text != string.Empty)
            if (txtfromdate.Text != string.Empty && txttodate.Text != string.Empty)

            {

                DataTable dt = new DataTable();
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
                con.Open();


                SqlCommand cmd = new SqlCommand("sp_date", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@fromdate", txtfromdate.Text);
                cmd.Parameters.AddWithValue("@todate", txttodate.Text);
                //cmd.Parameters.AddWithValue("@UserId", txtuserid.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                GV_GST.DataSource = dt;
                GV_GST.DataBind();
                con.Close();
            }
            else if  (txtuserid.Text != string.Empty)
            {
                DataTable dt = new DataTable();
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
                con.Open();
                

                SqlCommand cmd = new SqlCommand("sp_GSTUSER", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@fromdate", txtfromdate.Text);
                //cmd.Parameters.AddWithValue("@todate", txttodate.Text);
                cmd.Parameters.AddWithValue("@UserId", txtuserid.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                GV_GST.DataSource = dt;
                GV_GST.DataBind();
                con.Close();
            }
        }
        catch(Exception ex)
        {

        }

    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("gst.aspx");
    }



    protected void ddlmonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlmonth.SelectedIndex == 1)
            {
                DataTable dt = new DataTable();

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
                con.Open();
                //string query = "select * from  ##tbl_gst5  where packagedate between CAST ( DATEADD(month, DATEDIFF(month, -1, getdate()) - 2, 0)AS date) AND  CAST  (DATEADD(ss, -1, DATEADD(month, DATEDIFF(month, 0, getdate()), 0))AS date) ";

                SqlCommand cmd = new SqlCommand("sp_gstreportmonth", con);
                cmd.CommandType = CommandType.StoredProcedure; ;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                GV_GST.DataSource = dt;
                GV_GST.DataBind();
                con.Close();
            }
            else if (ddlmonth.SelectedIndex == 2)
            {
                DataTable dt = new DataTable();



                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
                con.Open();
                //string query = "select * from ##tbl_gst5  where (DatePart(Month, packagedate) BETWEEN DatePart(Month,DATEADD(m,-3,getdate())) AND  DatePart(Month,DATEADD(m,-1,getdate())) )AND(DatePart(Year, packagedate) BETWEEN DatePart(Year, DATEADD(m, -3, getdate())) AND DatePart(Year, DATEADD(m, -1, getdate())))";

                SqlCommand cmd = new SqlCommand("[sp_quarter]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                GV_GST.DataSource = dt;
                GV_GST.DataBind();
                con.Close();
            }
            else
            {
                DATABIND();

            }
        }
        catch (Exception ex)
        {


        }
    }

    protected void GV_GST_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_GST.PageIndex = e.NewPageIndex;
        DATABIND();
    }
}

            












    