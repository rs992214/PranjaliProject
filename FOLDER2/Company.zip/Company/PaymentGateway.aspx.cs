﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Text;
using System.Data;
using System.Web.Script.Serialization;
using System.Web.Configuration;
using System.Web;

public partial class Company_PaymentGateway : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                Showdata();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    protected void btnPay_Click(object sender, EventArgs e)
    {
        PaymentGatewayProperty ISPP = new PaymentGatewayProperty();
        ISPP.MerchantKey = txtmerchantkey.Text;
        ISPP.Salt = txtsalt.Text;
        ISPP.MobileNo = txtmobile.Text;
        if (rdoMode.SelectedIndex > -1)
        {
            ISPP.Mode = rdoMode.SelectedItem.Text;
       
        // ISPP.Date = txtdate.Text;

        try
        {
            PaymentGatewayLogic CI = new PaymentGatewayLogic();
            int rowaffected = CI.Insert(ISPP, ref message);
            if (rowaffected > 0)
            {
                int index = dal.Executequery("Update PaymentGateway set MobileNo=@MobileNo", ref message);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Merchant Information Saved Successfully')", true);
                PostData();
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Please try again...!", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            Showdata();
            reset();
            Response.Redirect("PaymentGateway.aspx");
        }
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Select Mode')", true);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        reset();
    }

    void reset()
    {
        txtmerchantkey.Text = string.Empty;
        //txtmerchantkey.ReadOnly = false;
        txtsalt.Text = string.Empty;
        txtmobile.Text = string.Empty;
        rdoMode.ClearSelection();
    }

    void Showdata()
    {
        StringBuilder sba = new StringBuilder();
        sba.AppendFormat("select * from PaymentGateway");
        DataTable dt = dal.Gettable(sba.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            btnPay.Enabled = false;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        int rowaffected = 0;
        try
        {
            PaymentGatewayProperty ISPP = new PaymentGatewayProperty();

            ISPP.MerchantKey = txtmerchantkey.Text;
            ISPP.Salt = txtsalt.Text;
            ISPP.MobileNo = txtmobile.Text;
            ISPP.Mode = rdoMode.SelectedItem.Text;

            PaymentGatewayLogic CI = new PaymentGatewayLogic();
            rowaffected = CI.Update(ISPP, ref message);

            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Merchant Information update Successfully')", true);
                PostData();
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Please try again...!", script, true);
            }

        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);

        }
        finally
        {
            Showdata();
            reset();
            Response.Redirect("PaymentGateway.aspx");
        }
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtmerchantkey.Text = GridView1.SelectedRow.Cells[0].Text;
        //txtmerchantkey.ReadOnly = true;
        txtsalt.Text = GridView1.SelectedRow.Cells[1].Text;
        txtmobile.Text = GridView1.SelectedRow.Cells[2].Text;
       // rdoMode.SelectedItem.Text = GridView1.SelectedRow.Cells[3].Text;
        btnUpdate.Visible = true;
        btnPay.Visible = false;
    }


    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string ID = GridView1.DataKeys[e.RowIndex].Values["MerchantKey"].ToString();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Delete from PaymentGateway where MerchantKey='" + ID + "'");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                Showdata();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Payment Gateway Information Deleted Successfully')", true);
                reset();
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
        finally
        {
            Response.Redirect("PaymentGateway.aspx");
        }
    }

    void PostData()
    {
        Configuration webconfig = WebConfigurationManager.OpenWebConfiguration(HttpContext.Current.Request.ApplicationPath);
        webconfig.AppSettings.Settings.Remove("MerchantKey");
        webconfig.AppSettings.Settings.Add("MerchantKey", txtmerchantkey.Text);
        webconfig.Save();

        webconfig.AppSettings.Settings.Remove("Salt");
        webconfig.AppSettings.Settings.Add("Salt", txtsalt.Text);
        webconfig.Save();
    }
    
    //void GetData()
    //{
    //    string Merchantkey = ConfigurationManager.AppSettings["MerchantKey"];
    //    txtmerchantkey.Text = Merchantkey;
    //    string SaltName = ConfigurationManager.AppSettings["Salt"];
    //    txtsalt.Text = SaltName;

    //}
}