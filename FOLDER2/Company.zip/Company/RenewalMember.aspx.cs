﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_RenewalMember : System.Web.UI.Page
{
    string message = string.Empty;
    DAL objDAL = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        Getdata();
    }

    void Getdata()
    {
        try
        {
            DataTable dt = new DataTable();
            if (txtfromdate.Text != null && txtfromdate.Text != "" && txttodate.Text != null && txttodate.Text != "")
            {
                dt = objDAL.Gettable("select M.UserID,M.SponsorID,U.PhotoPath,M.JoinType,M.Name,M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID = U.UserID where M.JoinDate between '" + txtfromdate.Text + "' and '" + txttodate.Text + "' Order By DID", ref message);
            }
            else if (txtUserID.Text != null && txtUserID.Text != "")
            {
                dt = objDAL.Gettable("select M.UserID,M.SponsorID,U.PhotoPath,M.JoinType,M.Name,M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID = U.UserID where M.UserID='" + txtUserID.Text + "' Order By DID", ref message);
            }
            else
            {
                dt = objDAL.Gettable("select M.UserID,M.SponsorID,U.PhotoPath,M.JoinType,M.Name,M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID = U.UserID  Order By DID", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = null;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
            // ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {

    }
}