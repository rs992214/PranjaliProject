﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;
using System.Text;

public partial class Company_StateMaster : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ShowData();
            btnupdate.Visible = false;
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowData();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        StateProperty Sp = new StateProperty();
        Sp.StateID = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values["StateID"].ToString());
        try
        {
            State ST = new State();
            int rowaffected = ST.DeleteState(Sp, ref message);
            if (rowaffected > 0)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "State Deleted Successfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
            else
            {
                if (message.Contains("REFERENCE constraint"))
                {
                    lblmsg.Visible = true;
                    lblmsg.BackColor = System.Drawing.Color.White;
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    lblmsg.Text = "State Allready is in use.You Can't Delete";
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.BackColor = System.Drawing.Color.White;
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    lblmsg.Text = message;
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                }
            }
        }
        catch (SqlException ex)
        {
            if (ex.Number==547)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text ="State Allready is in use.You Can't Delete";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Green;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowData();
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ViewState["Stateid"] = GridView1.SelectedRow.Cells[0].Text;
        txtstatename.Text = GridView1.SelectedRow.Cells[1].Text;
        btnupdate.Visible = true;
        btnsave.Visible = false;
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        StateProperty Sp = new StateProperty();
        Sp.StateName = txtstatename.Text;
        try
        {
            State ST = new State();
            int rowaffected = ST.SaveState(Sp, ref message);
            if (rowaffected > 0)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "State Save Successfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Green;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowData();
        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        StateProperty Sp = new StateProperty();
        Sp.StateID = Convert.ToInt32(ViewState["Stateid"]);
        Sp.StateName = txtstatename.Text;
        try
        {
            State St = new State();
            int rowaffected = St.UpdateState(Sp, ref message);
            if (rowaffected > 0)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "State Updated Successfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
            else
            {

                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Green;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowData();
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtstatename.Text = string.Empty;
        btnsave.Visible = true;
        btnupdate.Visible = false;
    }
    public void ShowData()
    {
        try
        {
            State ST = new State();
            DataTable dt= ST.GetData(ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }

        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Green;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
        }
    }
    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> getstatename(string prefixText)
    {
        List<string> name = new List<string>();
        DAL dal = new DAL();
        string message = string.Empty;
        try
        {
            StringBuilder sbb = new StringBuilder();
            sbb.AppendFormat("select StateName from State where StateName like'{0}%'", prefixText);

            DataTable dt = dal.Gettable(sbb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    name.Add(dt.Rows[i][0].ToString());
                }

            }
        }

        catch (Exception)
        {
            throw;
        }
        return name;
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        StateProperty Sp = new StateProperty();
        Sp.StateName = txtsearch.Text;
        try
        {
            State St = new State();
           DataTable dt= St.SearchData(Sp, ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Green;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

        }
    }
}