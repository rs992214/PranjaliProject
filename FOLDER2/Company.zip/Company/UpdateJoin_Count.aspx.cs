﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;

public partial class Company_UpdateJoin_Count : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void txtUserID_TextChanged(object sender, EventArgs e)
    {
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select DID,UserID,ISNULL(LJoining,0)As LJoining,ISNULL(PreviousLJoin,0)As PreviousLJoin,ISNULL(TotalLJoin,0)As TotalLJoin,ISNULL(Rjoining,0)As Rjoining,ISNULL(PreviousRJoin,0)As PreviousRJoin,ISNULL(TotalRJoin,0)As TotalRJoin From MLM_Registration Where UserID='" + txtUserID.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            txtUserID.Text = dt.Rows[0]["UserID"].ToString();
            lblLeftCount.Text = dt.Rows[0]["LJoining"].ToString();
            lblPreviousLeft.Text = dt.Rows[0]["PreviousLJoin"].ToString();

            lblRightCount.Text = dt.Rows[0]["Rjoining"].ToString();
            lblPreviousRight.Text = dt.Rows[0]["PreviousRJoin"].ToString();
            _Valid.Visible = true;
            btnSave.Enabled = true;
        }
        else
        {
            Clear();
            ShowPopupMessage("Incorrect User ID.", PopupMessageType.Error);
        }
    }
    private void Clear()
    {
        txtUserID.Text = string.Empty;
        lblLeftCount.Text = "0";
        lblPreviousLeft.Text = "0";
        lblRightCount.Text = "0";
        lblPreviousRight.Text = "0";
        DDLPosition.SelectedIndex = 0;
        txtJoin.Text = "0";
        _Valid.Visible = false;
        btnSave.Enabled = false;
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (DDLPosition.SelectedIndex > 0)
            {
                int _CurrentLJoin = Convert.ToInt32(lblLeftCount.Text);
                int _PreviousLJoin = Convert.ToInt32(lblPreviousLeft.Text);
                int _TotalLJoin = 0;

                int _CurrentRJoin = Convert.ToInt32(lblRightCount.Text);
                int _PreviousRJoin = Convert.ToInt32(lblPreviousRight.Text);
                int _TotalRJoin = 0;

                if (DDLPosition.SelectedItem.Text == "Left")
                {
                    int _CountLeft = Convert.ToInt32(txtJoin.Text);
                    _CurrentLJoin = _CurrentLJoin + _CountLeft;
                    _TotalLJoin = _PreviousLJoin + _CurrentLJoin;
                }
                else
                {
                    int _CountLeft = 0;
                    _CurrentLJoin = _CurrentLJoin + _CountLeft;
                    _TotalLJoin = _PreviousLJoin + _CurrentLJoin;
                }

                if (DDLPosition.SelectedItem.Text == "Right")
                {
                    int _CountRight = Convert.ToInt32(txtJoin.Text);
                    _CurrentRJoin = _CurrentRJoin + _CountRight;
                    _TotalRJoin = _PreviousRJoin + _CurrentRJoin;
                }
                else
                {
                    int _CountRight = 0;
                    _CurrentRJoin = _CurrentRJoin + _CountRight;
                    _TotalRJoin = _PreviousRJoin + _CurrentRJoin;
                }
                
                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("MLM_Registration_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
                cmd.Parameters.AddWithValue("@LJoining", _CurrentLJoin);
                cmd.Parameters.AddWithValue("@TotalLJoin", _TotalLJoin);
                cmd.Parameters.AddWithValue("@Rjoining", _CurrentRJoin);
                cmd.Parameters.AddWithValue("@TotalRJoin", _TotalRJoin);
                cmd.Parameters.AddWithValue("@Mode", "UPD_JOIN_COUNT_BY_ADMIN");
                int flag = cmd.ExecuteNonQuery();
                if (flag > 0)
                {
                    Clear();
                    ShowPopupMessage("Record has been updated.", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                }
            }
            else
            {
                ShowPopupMessage("Please Select Position.", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateJoin_Count.aspx");
    }



    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here




    
}