﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;

public partial class Company_MemberBlock : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    string message = string.Empty;
    public string UserID { get; set; }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
        }
    }
    private void GetData()
    {
        try
        {
            if (txtSearch.Text != string.Empty)
            {
                UserID = txtSearch.Text;
            }

            con = new SqlConnection(connstring);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("MLM_Registration_ALL", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@UserID", UserID);
            da.SelectCommand.Parameters.AddWithValue("@Mode", "GET_UNBLOCK_DATA");
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GV_MemberList.DataSource = dt;
                GV_MemberList.DataBind();
            }
            else
            {
                GV_MemberList.DataSource = null;
                GV_MemberList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void GV_MemberList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblStatus = e.Row.FindControl("lblStatus") as Label;
            LinkButton btnBlock = e.Row.FindControl("btnBlock") as LinkButton;
            if (lblStatus.Text == "Yes")
            {
                btnBlock.Enabled = false;
                btnBlock.CssClass = "btn btn-sm btn-danger disabled";
            }
            else if (lblStatus.Text == "No")
            {
                btnBlock.Enabled = true;
                btnBlock.CssClass = "btn btn-sm btn-danger";
            }
        }
    }
    protected void GV_MemberList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_MemberList.PageIndex = e.NewPageIndex;
        GetData();
    }
    protected void btnBlock_Click(object sender, EventArgs e)
    {
        try
        {
            int rowIndex = Convert.ToInt32(((sender as LinkButton).NamingContainer as GridViewRow).RowIndex);
            GridViewRow row = GV_MemberList.Rows[rowIndex];

            LinkButton btn = (LinkButton)(sender);
            txtUserID.Text = btn.CommandArgument;
            Label lblName = row.FindControl("lblName") as Label;
            txtName.Text = lblName.Text;

            ClientScript.RegisterStartupScript(this.GetType(), "Pop", "openModal();", true);
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnProceed_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("MLM_Registration_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
            cmd.Parameters.AddWithValue("@IsBlock", "Yes");
            cmd.Parameters.AddWithValue("@Mode", "UPD_BLOCK_STATUS");
            int flag = cmd.ExecuteNonQuery();
            if (flag > 0)
            {
                GetData();
                ShowPopupMessage("User has been Blocked.", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage("Some error occuring while trying to block user.", PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        GetData();
    }




    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here






    protected void btnreset_Click(object sender, EventArgs e)
    {
        Response.Redirect("MemberBlock.aspx");
    }
}