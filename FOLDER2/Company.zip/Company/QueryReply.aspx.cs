﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_QueryReply : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    int id;
    string query;
    string loginip = GetLocalIPAddress();
    string UserName1 = "";
    string password1 = "";
    string UserID = "";
    

    public string UserName { get; private set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        GetLocalIPAddress();
        getid();
        AdminLoginInfo();
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                 id = Convert.ToInt32(Request.QueryString["ID"]);
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
            SetDefaultButton(txtQuery, btnSave);
        }
    }

    private void SetDefaultButton(TextBox txt, Button defaultButton)
    {
        txtQuery.Attributes.Add("onkeypress", "funfordefautenterkey1(" + btnSave.ClientID + ",event)");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtQuery.Text.Trim() != string.Empty)
            {

                //query = Request.QueryString["ID"].ToString();
                //getid();
                query = Request.QueryString["ID"].ToString();
                int id = Convert.ToInt32(query);
                getid();
                string Name = Session["UserName"].ToString();
                int flag = dal.Executequery(" Update Helpdesk set Response='" + txtQuery.Text + "' where ID='" + id + "' ", ref message);
                if (flag > 0)
                {
                    QueryReplyTrace();
                    txtQuery.Text = "";
                    ShowPopupMessage("Response has been sent successfully.", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage(message, PopupMessageType.Error);
                }
            }
            else
            {
                ShowPopupMessage("Please Enter Response...", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName1 + "','" + password1 + "','" + loginip + "',GETDATE(),'Error:"+error+"  ')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    void getid()
    {
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select * from Helpdesk where ID='"+query+"'", ref message);
        if (dt.Rows.Count > 0)
        {
            id = Convert.ToInt32(dt.Rows[0]["ID"]);
            UserID = dt.Rows[0]["UserID"].ToString();
        }
    }


    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/Red_Cross_Tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("QueryList.aspx");
    }

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName1 = dt.Rows[0]["UserName"].ToString();
                password1 = dt.Rows[0]["password"].ToString();

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void QueryReplyTrace()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            getid();
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName1 + "','" + password1 + "','" + loginip + "',GETDATE(),'Sucess:Response : " + txtQuery.Text+"  has been sent  to "+ UserID + "  ')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
}