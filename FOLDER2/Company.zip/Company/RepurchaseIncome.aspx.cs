﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_RepurchaseIncome : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
        }
    }
    void GetData()
    {
        con = new SqlConnection(connstring);
        cmd = new SqlCommand("Select * from RepurchaseMaster", con);
        SqlDataAdapter ads = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        ads.Fill(dt);
        if(dt.Rows.Count > 0)
        {
            GV_PackageList.DataSource = dt;
            GV_PackageList.DataBind();
        }
        else
        {
            GV_PackageList.DataSource = null;
            GV_PackageList.DataBind();
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (btnsave.Text == "Save")
            {
                if (txtbusiness.Text != "" && txtcapping.Text != "")
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("PackageInfo_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@BusinessVolume", txtbusiness.Text);
                    cmd.Parameters.AddWithValue("@Capping", txtcapping.Text);
                    cmd.Parameters.AddWithValue("@DirectIncome", txtdirect.Text);
                    cmd.Parameters.AddWithValue("@BVRate", txtbvrate.Text);
                    cmd.Parameters.AddWithValue("@Mode", "RepurchaseInsert");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    if (flag > 0)
                    {
                         Clear();
                        GetData();
                        Response.Redirect("SuccessView.aspx?Link=RepurchaseIncome.aspx");
                        // ShowPopupMessage("Data has been Added Successfully.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                    }
                }
                else
                {
                   ShowPopupMessage("Please Enter Data", PopupMessageType.Warning);
                }
            }
            else
            {
                if (txtbusiness.Text != "" && txtcapping.Text != "")
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("PackageInfo_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", ViewState["PackageID"]);
                    cmd.Parameters.AddWithValue("@BusinessVolume", txtbusiness.Text);
                    cmd.Parameters.AddWithValue("@Capping", txtcapping.Text);
                    cmd.Parameters.AddWithValue("@DirectIncome", txtdirect.Text);
                    cmd.Parameters.AddWithValue("@BVRate", txtbvrate.Text);
                    cmd.Parameters.AddWithValue("@Mode", "RepurchaseUpdate");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    if (flag > 0)
                    {
                        Clear();
                        GetData();
                        Response.Redirect("SuccessView.aspx?Link=RepurchaseIncome.aspx");
                        // ShowPopupMessage("Data has been Added Successfully.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                    }
                }
            }
           
        }
        catch (Exception ex)
        {

        }
        finally
        {
            Clear();
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("RepurchaseIncome.aspx");
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,BusinessVolume,Capping,DirectIncome,BVRate from RepurchaseMaster Where ID='" + ID + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                ViewState["PackageID"] = dt.Rows[0]["ID"].ToString();
                txtbusiness.Text = dt.Rows[0]["BusinessVolume"].ToString();
                txtcapping.Text = dt.Rows[0]["Capping"].ToString();
                txtdirect.Text = dt.Rows[0]["DirectIncome"].ToString();
                txtbvrate.Text = dt.Rows[0]["BVRate"].ToString();
                btnsave.Text = "Update";
            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    void Clear()
    {
        txtbusiness.Text = string.Empty;
        txtbvrate.Text = string.Empty;
        txtcapping.Text = string.Empty;
        txtdirect.Text = string.Empty;
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here
}