﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Label : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            txtuserid.Focus();
        }
    }

    protected void btncreate_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "insert into LabelInfo(UserID,InvoiceNo) values(" + "'" +txtuserid.Text +"',"+"'"+ txtinvoiceno.Text +"')";
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        con.Close();
        ShowdataCompany();
        ShowCompanyName();
        ShowDataUser();
        show();
        pnlview.Visible = true;
    }
    public void ShowdataCompany()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
              lblcomapnyname.Text  = dt.Rows[0]["CompanyName"].ToString();
               lblcompanyaddress.Text = dt.Rows[0]["Address"].ToString();
                lblphone.Text = dt.Rows[0]["PhoneNo"].ToString();
                lblemail.Text = dt.Rows[0]["Email"].ToString();
               lblgstno.Text = dt.Rows[0]["GSTNo"].ToString();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    Image1.ImageUrl = "data:image/png;base64," + base64String;
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
    void ShowDataUser()
    {
        MLMUserDetailProperty Mp = new MLMUserDetailProperty();
        MLMUserDetailLogic MlL = new MLMUserDetailLogic();
        DataTable dt = dal.Gettable("Select * from MLM_UserDetail where UserID='" + txtuserid.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            lblbboaddress.Text = dt.Rows[0]["Address"].ToString();
            lblbbophone.Text = dt.Rows[0]["AlternateMobile"].ToString();
            lblbbogst.Text = "GST No. :" + dt.Rows[0]["GSTProofvalue"].ToString();
            lblinvoice.Text = txtuserid.Text + "/" + txtinvoiceno.Text;
            lblpaymentmode.Text = "CASH";
        }
    }

    void show()
    {
        MLMUserDetailProperty Mp = new MLMUserDetailProperty();
        MLMUserDetailLogic MlL = new MLMUserDetailLogic();
        DataTable dt = dal.Gettable("Select * from MLM_Registration where UserID='" + txtuserid.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            lblbboname.Text = dt.Rows[0]["Name"].ToString();
            lblShippingaddress.Text = dt.Rows[0]["ProductDeliveryStatus"].ToString();
            lblbboemail.Text = dt.Rows[0]["Email"].ToString();
            lblorderdate.Text = dt.Rows[0]["PackageDate"].ToString();
        }
    }
    protected void ShowCompanyName()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select CI.CompanyName,CI.Address,CT.CityName,ST.StateName,CI.PhoneNo,CI.GstNo,CI.Email from CompanyInfo as CI inner join State as ST on CI.StateID = ST.StateID inner join City as CT on CI.CityID = CT.CityID");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                Label3.Text = dt.Rows[0]["CompanyName"].ToString();
                Label4.Text = dt.Rows[0]["Address"].ToString() + "\n" + dt.Rows[0]["CityName"].ToString() + "," + dt.Rows[0]["StateName"].ToString();
                Label5.Text = "Phone No: " + dt.Rows[0]["PhoneNo"].ToString();
                Label6.Text = "Email ID: " + dt.Rows[0]["Email"].ToString();
                Label7.Text = "GSTIN: " + dt.Rows[0]["GstNo"].ToString();
            }
            else
            {
                Label1.Text = null; ;
                Label2.Text = null;
                Label3.Text = "Phone No: ";
                Label4.Text = "Email ID: ";
                Label5.Text = "GSTIN: ";
            }
        }
        catch (Exception)
        {

            throw;
        }
    }

}