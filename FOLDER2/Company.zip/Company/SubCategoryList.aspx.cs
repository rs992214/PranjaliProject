﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_SubCategoryList : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                ShowCategory();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void ShowCategory()
    {
        drpcategory.DataTextField = "CategoryName";
        drpcategory.DataValueField = "ID";
        try
        {
            CategoryMaster CM = new CategoryMaster();
            DataTable dt= CM.FetchCategory(ref message);
            if (dt.Rows.Count>0)
            {
                drpcategory.DataSource = dt;
                drpcategory.DataBind();
                drpcategory.Items.Insert(0, new ListItem("Select Category", "0"));
            }
            else
            {
                drpcategory.DataSource = null;
                drpcategory.DataBind();
                drpcategory.Items.Insert(0, new ListItem("Select Category", "0"));

            }
        }
        catch (Exception)
        {

            throw;
        }
        
    }
    public void ShowSUbCategoryList()
    {
        SubcategoryProperty SP = new SubcategoryProperty { CategoryName = drpcategory.SelectedItem.Text };
        SubcategoryMaster SCM = new SubcategoryMaster();
        DataTable dt = SCM.FetchSubCategory(SP,ref message);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowSUbCategoryList();
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        ShowSUbCategoryList();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            SubcategoryProperty CMP = new SubcategoryProperty { ID = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values["ID"].ToString()) };
            SubcategoryMaster SM = new SubcategoryMaster();
            int rowaffected = SM.DeleteSubCategory(CMP, ref message);
            if (rowaffected > 0)
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", "SubCategory Deleted Successfully.");
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
                ShowSUbCategoryList();
            }
            else
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", message);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
            }
        }
        catch (Exception ex)
        {

            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
        }

    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        ShowSUbCategoryList();
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            SubcategoryProperty CMP = new SubcategoryProperty { ID = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[0].Text), SubCategoryName = ((TextBox)(GridView1.Rows[e.RowIndex].FindControl("TextBox1"))).Text };
            SubcategoryMaster CM = new SubcategoryMaster();
            int rowaffected = CM.UpdateSubCategory(CMP, ref message);
            GridView1.EditIndex = -1;
            if (rowaffected > 0)
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", "SubCategory Updated Successfully.");
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
                ShowSUbCategoryList();
            }
            else
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", message);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
            }
        }
        catch (Exception ex)
        {

            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
        }
        

    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ShowSUbCategoryList();
    }
}