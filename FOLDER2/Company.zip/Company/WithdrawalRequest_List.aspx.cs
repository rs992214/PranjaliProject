﻿using DataAccessLayer;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_WithdrawalRequest_List : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL dal = new DAL();
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
        }
    }
    private void GetData()
    {

        try
        {
            MLMUserDetailProperty MDP = new MLMUserDetailProperty();
            if (txtFrom.Text != string.Empty)
            {
                MDP.FromDate = txtFrom.Text;
            }
            if (txtTo.Text != string.Empty)
            {
                MDP.ToDate = txtTo.Text;
            }

            if (txtSearch.Text != string.Empty)
            {
                MDP.UserID = txtSearch.Text;
            }

            con = new SqlConnection(connstring);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@UserID", MDP.UserID);
            da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
            da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
            da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA_1");
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GV_WithdrawalRequest_List.DataSource = dt;
                GV_WithdrawalRequest_List.DataBind();
                btnExport.Visible = true;
            }
            else
            {
                GV_WithdrawalRequest_List.DataSource = dt;
                GV_WithdrawalRequest_List.DataBind();
                btnExport.Visible = true;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void GV_WithdrawalRequest_List_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_WithdrawalRequest_List.PageIndex = e.NewPageIndex;
        GetData();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        GetData();
    }
    protected void GV_WithdrawalRequest_List_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblStatus = e.Row.FindControl("lblStatus") as Label;
            //Label lblmode = e.Row.FindControl("lblmode") as Label;
            

            LinkButton btnApproved = e.Row.FindControl("btnApproved") as LinkButton;
            LinkButton btnAccept = e.Row.FindControl("btnAccept") as LinkButton;
           
            if (lblStatus.Text == "REQUEST")
            {
                btnApproved.Enabled = true;
                btnApproved.CssClass = "btn btn-sm btn-blue";
            }
            else
            {
                btnApproved.Enabled = false;
                btnApproved.CssClass = "btn btn-sm btn-blue disabled";

                //if (lblmode.Text == "")
                //{

                //}
                //else
                //{
                //    btnAccept.Enabled = false;
                //    btnAccept.CssClass = "btn btn-sm btn-success disabled";
                //}

            }
        }
    }
    protected void btnApproved_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;

            DAL objDAL = new DAL();
            //DataTable dt = objDAL.Gettable("Select ID,UserID,Amount,Description From WithdrawalRequest Where ID='" + ID + "'", ref message);
            DataTable dt = objDAL.Gettable("select PaymentID,UserID,PayoutAmount,NetAmount,Status,Currency from  MemberPayment Where PaymentID='" + ID + "'  order by Date", ref message);
            if (dt.Rows.Count > 0)
            {
                ID = dt.Rows[0]["PaymentID"].ToString();
                string UserID = dt.Rows[0]["UserID"].ToString();
                string currency = dt.Rows[0]["Currency"].ToString();
                decimal DR = Convert.ToDecimal(dt.Rows[0]["PayoutAmount"]);
                //string Description = dt.Rows[0]["Description"].ToString();
                decimal CR = 0;

                if (currency == "Dollar")
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    cmd.Parameters.AddWithValue("@TransactionType", "DR");
                    cmd.Parameters.AddWithValue("@CR", CR);
                    cmd.Parameters.AddWithValue("@DR", DR);
                    cmd.Parameters.AddWithValue("@Descriptions", "Withdrawal Request");
                    cmd.Parameters.AddWithValue("@Mode", "UPD_WITHDRAWAL_STATUS_Main_1");
                    int flag = cmd.ExecuteNonQuery();
                    // int flag = 1;
                    con.Close();
                    if (flag > 0)
                    {
                        GetData();
                        Response.Redirect("SuccessView.aspx?Link=WithdrawalRequest_List.aspx");
                        //ShowPopupMessage("Withdrawal request has been approved.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                    }
                }
                else if(currency == "Pluto")
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    cmd.Parameters.AddWithValue("@TransactionType", "DR");
                    cmd.Parameters.AddWithValue("@CR", CR);
                    cmd.Parameters.AddWithValue("@DR", DR);
                    cmd.Parameters.AddWithValue("@Descriptions", "Withdrawal Request Pluto");
                    cmd.Parameters.AddWithValue("@Mode", "UPD_WITHDRAWAL_STATUS_Main_1");
                    int flag = cmd.ExecuteNonQuery();
                    // int flag = 1;
                    con.Close();
                    if (flag > 0)
                    {
                        GetData();
                        Response.Redirect("SuccessView.aspx?Link=WithdrawalRequest_List.aspx");
                        //ShowPopupMessage("Withdrawal request has been approved.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                    }
                }
                else if(currency=="ROI")
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", ID);
                    cmd.Parameters.AddWithValue("@UserID", UserID);
                    cmd.Parameters.AddWithValue("@TransactionType", "DR");
                    cmd.Parameters.AddWithValue("@CR", CR);
                    cmd.Parameters.AddWithValue("@DR", DR);
                    cmd.Parameters.AddWithValue("@Descriptions", "Withdrawal Request ROI");
                    cmd.Parameters.AddWithValue("@Mode", "UPD_WITHDRAWAL_STATUS_Main_1");
                    int flag = cmd.ExecuteNonQuery();
                    // int flag = 1;
                    con.Close();
                    if (flag > 0)
                    {
                        GetData();
                        Response.Redirect("SuccessView.aspx?Link=WithdrawalRequest_List.aspx");
                        //ShowPopupMessage("Withdrawal request has been approved.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("WithdrawalRequest_List.aspx");
    }
    public void CreateExcelFile(DataTable Excel)
    {

        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=WithdrawalList.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {
            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {
                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";
            }

            Response.Write("\n");
        }
        Response.End();
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            MLMUserDetailProperty MDP = new MLMUserDetailProperty();
            if (txtFrom.Text != string.Empty)
            {
                MDP.FromDate = txtFrom.Text;
            }
            if (txtTo.Text != string.Empty)
            {
                MDP.ToDate = txtTo.Text;
            }

            if (txtSearch.Text != string.Empty)
            {
                MDP.UserID = txtSearch.Text;
            }

            con = new SqlConnection(connstring);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@UserID", MDP.UserID);
            da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
            da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
            da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA_1");
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                CreateExcelFile(dt);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void btnPDF_Click(object sender, EventArgs e)
    {
        MLMUserDetailProperty MDP = new MLMUserDetailProperty();
        if (txtFrom.Text != string.Empty)
        {
            MDP.FromDate = txtFrom.Text;
        }
        if (txtTo.Text != string.Empty)
        {
            MDP.ToDate = txtTo.Text;
        }

        if (txtSearch.Text != string.Empty)
        {
            MDP.UserID = txtSearch.Text;
        }

        con = new SqlConnection(connstring);
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        da.SelectCommand.Parameters.AddWithValue("@UserID", MDP.UserID);
        da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
        da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
        da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA_1");
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            CreatePdfFile(dt);
        }

        string[] columnNames = (from dc in dt.Columns.Cast<DataColumn>()
                                select dc.ColumnName).ToArray();
        
    }

    void CreatePdfFile(DataTable PDF)
    {
        string filename = "WithdrawalList.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);


        Document doc = new Document(PageSize.A4, 10, 10, 10, 10);

        Paragraph p = new Paragraph();
        p.Alignment = Element.ALIGN_CENTER;

        try
        {
            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(11);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("Withdrawal List", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("../Company/images/plutologo.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------

           
            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }
           
            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "application/pdf";
            context.Response.AppendHeader("content-disposition","attachment; filename=" + filename);
            context.Response.End();
        }
        catch
        {

        }
    }
    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }


    protected void btnAccept_Click(object sender, EventArgs e)
    {
        try
        {
            Showdatalogo();
            GetData1();
            int rowIndex = Convert.ToInt32(((sender as LinkButton).NamingContainer as GridViewRow).RowIndex);
            GridViewRow row = GV_WithdrawalRequest_List.Rows[rowIndex];

            LinkButton btn = (LinkButton)(sender);
            txtpid.Text = btn.CommandArgument;

            Label lblName = row.FindControl("lblName") as Label;
            txtName.Text = lblName.Text;

            Label lbluserid = row.FindControl("lbluserid") as Label;
            txtUserID.Text = lbluserid.Text;

            Label lblamount = row.FindControl("lblamount") as Label;
            txtamount.Text = lblamount.Text;

            ClientScript.RegisterStartupScript(this.GetType(), "Pop", "openModal();", true);
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnProceed_Click(object sender, EventArgs e)
    {
        if (ddlpaymentmode.SelectedIndex != 0)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update WithdrawalRequest set Status='APPROVED', paymentmode='{0}',paymentdate=Getdate(),ReadNotification='0' where ID='{1}'", ddlpaymentmode.SelectedItem.Text, txtpid.Text);
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
                StringBuilder sb1 = new StringBuilder();
                sb1.AppendFormat("Insert Into Ledger_Wallet(UserID,TransactionType,DR,Descriptions,CreationDate) values('{0}','{1}','{2}','{3}',GetDate())",txtUserID.Text,"DR",txtamount.Text,"Withdrawal Amount");
                int rowaffected1 = dal.Executequery(sb1.ToString(), ref message);
            if (rowaffected > 0 && rowaffected1 > 0)
            {
                GetData();
                GetData1();
                SendMail(Email ,txtName.Text,pass);
                SendMsg();
                Response.Redirect("SuccessView.aspx?Link=WithdrawalRequest_List.aspx");
                // ShowPopupMessage("Payment Updated Successfully.", PopupMessageType.Success);
            }
            else
            {
                GetData();
                ShowPopupMessage("Error Occurs.", PopupMessageType.Error);
            }
        }
        else
        {
            GetData();
            ShowPopupMessage("Please Select Payment Mode.", PopupMessageType.Error);
        }
    }
    string company = string.Empty;
    public void Showdatalogo()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                company = dt.Rows[0]["CompanyName"].ToString();
            }
            else
            {
            }
        }
        catch (Exception ex)
        {

        }
    }

    string Mobile = string.Empty;
    string pass = string.Empty;
    string UserID = string.Empty;
    string Email = string.Empty;
    void GetData1()
    {
        DAL dal = new DAL();
        string message1 = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from MLM_Registration where UserID='"+txtUserID.Text+"'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message1);
        if (dt.Rows.Count > 0)
        {
            Mobile = dt.Rows[0]["Mobile"].ToString();
            pass = dt.Rows[0]["Password"].ToString();
            UserID = dt.Rows[0]["UserID"].ToString();
            Email = dt.Rows[0]["Email"].ToString();

        }
    }

    public void SendMail(string mailID, string Username1, string userPassword)
    {

        string email = "";
        string password = "";
        string smtp = "";
        int port = 0;
        Boolean ssl = false;
        string logolink = "";
        string loginlink = "";
        Showdatalogo();

        DAL dal = new DAL();
        string message1 = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select EmailID,Password,SMTP,PortNo,EnableSSl,Logolink,Loginlink from EmailConfig where Status='" + emailstatus + "'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message1);
        if (dt.Rows.Count > 0)
        {
            email = dt.Rows[0]["EmailID"].ToString();
            password = dt.Rows[0]["Password"].ToString();
            smtp = dt.Rows[0]["SMTP"].ToString();
            port = Convert.ToInt32(dt.Rows[0]["PortNo"].ToString());
            ssl = Convert.ToBoolean(dt.Rows[0]["EnableSSl"].ToString());
            logolink = dt.Rows[0]["Logolink"].ToString();
            loginlink = dt.Rows[0]["Loginlink"].ToString();

            //gather email from form textbox
            string remail = mailID;

            //MailAddress from = new MailAddress("info@paxpluewealth.com");
            MailAddress from = new MailAddress(email);

            MailAddress to = new MailAddress(remail);
            MailMessage message = new MailMessage(from, to);

            message.Subject = company;

            //string note = "<div>Hello! <b>'" + txtname.Text + "'</b> </div>";
            //note += "<div><br><p>Your Registerd Username IS : <b>'" + Username1 + "'</b> AND Password IS : <b>'" + userPassword + "'</b>. Keep it secured.<br>Thank You.</p></div>";
            //note += "<div><br>Regards<br><a href='http://www.paxpluewealth.com/Member/login.aspx'>http://www.paxpluewealth.com</a></div>";

            //string note = MailBody(Username1, userPassword, TransactionPassword);

            string note = "<!DOCTYPE html>";
            note += "<html><body>";
            note += "<h1><img src='" + logolink + "' height=100px width=100px></h1>";
            note += "<p>Hello <b>'" + txtName.Text + "'</b>,</p>";
            note += "<p>Welcome to <b>" + company + "</b>, Dear Customer Your withdrawal request for " + txtamount.Text + " INR was successfully processed by Cash on Date " + DateTime.Now.ToLongDateString() + ".You will receive the amount in your bank account.</p>";
            note += "<p>Following are the log-in Credential.</p>";
            note += "<p><blink><a href='" + loginlink + "' target='_blank'>Click Here</a></blink></p>";
            note += "<p>Username : <b>'" + Username1 + "'</b></p>";
            note += "<p>Password : <b>'" + userPassword + "'</b></p>";
            note += "<br><br><br>";
            note += "<p>Regards</p>";
            note += "<p><a href='" + loginlink + "' target='_blank'>" + company + "</a><p>";
            note += "</body></html>";

            message.Body = note;
            message.BodyEncoding = System.Text.Encoding.UTF8;
            message.IsBodyHtml = true;

            //SmtpClient client = new SmtpClient("smtp.paxpluewealth.com", 587);
            SmtpClient client = new SmtpClient(smtp, port);
            client.UseDefaultCredentials = false;
            client.EnableSsl = ssl;
            //client.Credentials = new NetworkCredential("info@paxpluewealth.com", "aXGU(nT0");
            client.Credentials = new NetworkCredential(email, password);

            try
            {
                client.Send(message);
            }
            catch (Exception ex)
            {
                //error message?
            }
            finally
            {

            }
        }
    }

    protected void SMSdebit()
    {
        int sms = 0;
        int smsAvailable = 0;
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='Active'", ref message);
        if (dt.Rows.Count > 0)
        {
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());
            smsAvailable = sms - 2;

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update SmsmasterNew set CreditSMS='{0}'", smsAvailable);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {

                }
                else
                {
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {

            }
        }
    }
    protected void SMSHistory(string userid, string name, string mobile, string msg, string sts)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sba = new StringBuilder();
        sba.AppendLine("insert into SMSHistory(UserID,Name,Mobileno,Message,Status)");
        sba.AppendFormat("values('{0}','{1}','{2}','{3}','{4}')", userid, name, mobile, msg, sts);
        int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
        if (rowaffected1 > 0)
        {

        }
    }
    public class MyDetail
    {
        public string status
        {
            get;
            set;
        }
    }

    string smsstatus = string.Empty;
    string emailstatus = string.Empty;
    public void SendMsg()
    {
        DAL dal = new DAL();

        string url = "";
        string username = "";
        string key = "";
        string request = "";
        string sender = "";
        string route = "";
        int sms = 0;
        string status = "";
        string message = string.Empty;
        DataTable dt2 = dal.Gettable("Select RegistrationSMS,RegistrationEmail,Withdrawal_SystemEmail,Withdrawal_SystemSMS,E_PinSMS,E_PinEmail from SMS_Email_Notification", ref message);
        smsstatus = dt2.Rows[0]["Withdrawal_SystemSMS"].ToString();
        emailstatus = dt2.Rows[0]["Withdrawal_SystemEmail"].ToString();
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew where Status='" + smsstatus + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            url = dt.Rows[0]["APIurl"].ToString();
            username = dt.Rows[0]["Username"].ToString();
            key = dt.Rows[0]["APIkey"].ToString();
            request = dt.Rows[0]["APIrequest"].ToString();
            sender = dt.Rows[0]["Sender"].ToString();
            route = dt.Rows[0]["Route"].ToString();
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());

            if (sms != 0)
            {

                string text = "Dear Customer Your withdrawal request for "+txtamount.Text+" INR was successfully processed by Cash on Date "+DateTime.Now+".You will receive the amount in your bank account.";
                try
                {
                    string jsonValue = "";
                    string sURL;
                    StreamReader objReader;
                    // sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + username + "&password=" + password + "&sender=" + senderId + "&to=" + txtmobileNo.Text + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + routeId + "";
                    // sURL = "http://sms.probuztech.com/sms-panel/api/http/index.php?username=WYSE&apikey=FC144-3DD84&apirequest=Text&sender=PROBUZ&mobile=8055002299&message=TEST&route=TRANS&format=JSON";
                    sURL = "" + url +""; //"?username=" + username + "&apikey=" + key + "&apirequest=" + request + "&sender=" + sender + "&mobile=" + txtmobileNo.Text + "&message=" + text + "&route=" + route + "&format=JSON";
                    WebRequest wrGETURL;
                    wrGETURL = WebRequest.Create(sURL);
                    try
                    {
                        Stream objStream;
                        objStream = wrGETURL.GetResponse().GetResponseStream();
                        objReader = new StreamReader(objStream);
                        jsonValue = objReader.ReadToEnd();
                        var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonValue);
                        string status1 = myDetails.status;
                        if (status1 == "error")
                        {
                            SMSHistory(txtUserID.Text, txtName.Text, Mobile, text, "Not Send");
                        }
                        else
                        {
                            SMSdebit();
                            SMSHistory(txtUserID.Text, txtName.Text, Mobile, text, "Send");
                        }

                        objReader.Close();
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
    }
}
















//    DataRow dr = GetData("SELECT * FROM WithdrawalRequest");
//    Document document = new Document(PageSize.A4, 88f, 88f, 10f, 10f);
//    Font NormalFont = FontFactory.GetFont("Arial", 12, Font.NORMAL, BaseColor.BLACK);
//    using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream())
//    {
//        PdfWriter writer = PdfWriter.GetInstance(document, memoryStream);
//        Phrase phrase = null;
//        PdfPCell cell = null;
//        PdfPTable table = null;
//        Color color = new Color();

//        document.Open();

//        phrase = new Phrase();
//        phrase.Add(new Chunk(dr["ID"].ToString(), FontFactory.GetFont("Arial", 10, Font.BOLD, iTextSharp.text.BaseColor.BLACK)));
//        cell = PhraseCell(phrase, PdfPCell.ALIGN_LEFT);
//        cell.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
//        table.AddCell(cell);
//        document.Add(table);

//        table = new PdfPTable(2);
//        table.HorizontalAlignment = Element.ALIGN_LEFT;
//        table.SetWidths(new float[] { 0.3f, 1f });
//        table.SpacingBefore = 20f;


//        cell = PhraseCell(new Phrase(dr["UserID"].ToString(), FontFactory.GetFont("Arial", 12, Font.UNDERLINE, iTextSharp.text.BaseColor.BLACK)), PdfPCell.ALIGN_CENTER);
//        cell.Colspan = 2;
//        table.AddCell(cell);
//        cell = PhraseCell(new Phrase(), PdfPCell.ALIGN_CENTER);
//        cell.Colspan = 2;
//        cell.PaddingBottom = 30f;
//        table.AddCell(cell);


//        phrase = new Phrase();
//        phrase.Add(new Chunk(dr["Amount"].ToString(), FontFactory.GetFont("Arial", 10, Font.BOLD, iTextSharp.text.BaseColor.BLACK)));
//        cell = PhraseCell(phrase, PdfPCell.ALIGN_LEFT);
//        cell.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
//        table.AddCell(cell);
//        document.Add(table);



//        table = new PdfPTable(2);
//        table.SetWidths(new float[] { 0.5f, 2f });
//        table.TotalWidth = 340f;
//        table.LockedWidth = true;
//        table.SpacingBefore = 20f;
//        table.HorizontalAlignment = Element.ALIGN_RIGHT;


//        phrase = new Phrase();
//        phrase.Add(new Chunk(dr["Description"].ToString(), FontFactory.GetFont("Arial", 10, Font.BOLD, iTextSharp.text.BaseColor.BLACK)));
//        cell = PhraseCell(phrase, PdfPCell.ALIGN_LEFT);
//        cell.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
//        table.AddCell(cell);
//        document.Add(table);



//        phrase = new Phrase();
//        phrase.Add(new Chunk(dr["Status"].ToString(), FontFactory.GetFont("Arial", 10, Font.BOLD, iTextSharp.text.BaseColor.BLACK)));
//        cell = PhraseCell(phrase, PdfPCell.ALIGN_LEFT);
//        cell.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
//        table.AddCell(cell);
//        document.Add(table);


//        phrase = new Phrase();
//        phrase.Add(new Chunk(dr["CreationDate"].ToString(), FontFactory.GetFont("Arial", 10, Font.BOLD, iTextSharp.text.BaseColor.BLACK)));
//        cell = PhraseCell(phrase, PdfPCell.ALIGN_LEFT);
//        cell.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
//        table.AddCell(cell);
//        document.Add(table);


//        phrase = new Phrase();
//        phrase.Add(new Chunk(dr["UpdationDate"].ToString(), FontFactory.GetFont("Arial", 10, Font.BOLD, iTextSharp.text.BaseColor.BLACK)));
//        cell = PhraseCell(phrase, PdfPCell.ALIGN_LEFT);
//        cell.VerticalAlignment = PdfPCell.ALIGN_MIDDLE;
//        table.AddCell(cell);
//        document.Add(table);
//        DrawLine(writer, 160f, 80f, 160f, 690f, BaseColor.BLACK);
//        DrawLine(writer, 115f, document.Top - 200f, document.PageSize.Width - 100f, document.Top - 200f, iTextSharp.text.BaseColor.BLACK);

//        document.Close();
//        byte[] bytes = memoryStream.ToArray();
//        memoryStream.Close();
//        Response.Clear();
//        Response.ContentType = "application/pdf";
//        Response.AddHeader("Content-Disposition", "attachment; filename=WithdrawalList.pdf");
//        Response.ContentType = "application/pdf";
//        Response.Buffer = true;
//        Response.Cache.SetCacheability(HttpCacheability.NoCache);
//        Response.BinaryWrite(bytes);
//        Response.End();
//        Response.Close();
//    }
//}

//private static void DrawLine(PdfWriter writer, float x1, float y1, float x2, float y2, iTextSharp.text.BaseColor color)
//{
//    PdfContentByte contentByte = writer.DirectContent;
//    contentByte.SetColorStroke(color);
//    contentByte.MoveTo(x1, y1);
//    contentByte.LineTo(x2, y2);
//    contentByte.Stroke();
//}
//private static PdfPCell PhraseCell(Phrase phrase, int align)
//{
//    PdfPCell cell = new PdfPCell(phrase);
//    cell.BorderColor = iTextSharp.text.BaseColor.WHITE;
//    cell.VerticalAlignment = PdfPCell.ALIGN_TOP;
//    cell.HorizontalAlignment = align;
//    cell.PaddingBottom = 2f;
//    cell.PaddingTop = 0f;
//    return cell;
//}
//private static PdfPCell ImageCell(string path, float scale, int align)
//{
//    iTextSharp.text.Image image = iTextSharp.text.Image.GetInstance(HttpContext.Current.Server.MapPath(path));
//    image.ScalePercent(scale);
//    PdfPCell cell = new PdfPCell(image);
//    cell.BorderColor = iTextSharp.text.BaseColor.WHITE;
//    cell.VerticalAlignment = PdfPCell.ALIGN_TOP;
//    cell.HorizontalAlignment = align;
//    cell.PaddingBottom = 0f;
//    cell.PaddingTop = 0f;
//    return cell;
//}

//private DataTable GetData(string query)
//{
//    string conString = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
//    SqlCommand cmd = new SqlCommand(query);
//    using (SqlConnection con = new SqlConnection(conString))
//    {
//        using (SqlDataAdapter sda = new SqlDataAdapter())
//        {
//            cmd.Connection = con;

//            sda.SelectCommand = cmd;
//            using (DataTable dt = new DataTable())
//            {
//                sda.Fill(dt);
//                return dt;
//            }
//        }
//    }
//}

