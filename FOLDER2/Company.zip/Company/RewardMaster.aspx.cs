﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;

public partial class Company_RewardMaster : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
            txtAchieveTime.Text = "0";
        }
    }
    private void GetData()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,RewardName,LeftPair,RightPair,AchieveTime,Gift,CONVERT(nvarchar,CreationDate,105)As CreationDate From Reward", ref message);
            if (dt.Rows.Count > 0)
            {
                GV_RewardList.DataSource = dt;
                GV_RewardList.DataBind();
            }
            else
            {
                GV_RewardList.DataSource = null;
                GV_RewardList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void Clear()
    {
        txtDesignation.Text = string.Empty;
        txtLeftPair.Text = string.Empty;
        txtRightPair.Text = string.Empty;
        txtAchieveTime.Text = string.Empty;
        txtGift.Text = string.Empty;
        ViewState["RewardID"] = null;

        GetData();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["RewardID"] == null)
            {
                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("Reward_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RewardName", txtDesignation.Text);
                cmd.Parameters.AddWithValue("@LeftPair", txtLeftPair.Text);
                cmd.Parameters.AddWithValue("@RightPair", txtRightPair.Text);
                cmd.Parameters.AddWithValue("@AchieveTime", txtAchieveTime.Text);
                cmd.Parameters.AddWithValue("@Gift", txtGift.Text);
                cmd.Parameters.AddWithValue("@Mode", "IN");
                int flag = cmd.ExecuteNonQuery();
                con.Close();
                if (flag > 0)
                {
                    Clear();
                    ShowPopupMessage("Reward has been Added Successfully.", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                }
            }
            else if (ViewState["RewardID"] != null)
            {
                string ID = ViewState["RewardID"].ToString();
                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("Reward_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", ID);
                cmd.Parameters.AddWithValue("@RewardName", txtDesignation.Text);
                cmd.Parameters.AddWithValue("@LeftPair", txtLeftPair.Text);
                cmd.Parameters.AddWithValue("@RightPair", txtRightPair.Text);
                cmd.Parameters.AddWithValue("@AchieveTime", txtAchieveTime.Text);
                cmd.Parameters.AddWithValue("@Gift", txtGift.Text);
                cmd.Parameters.AddWithValue("@Mode", "UPD");
                int flag = cmd.ExecuteNonQuery();
                con.Close();
                if (flag > 0)
                {
                    Clear();
                    ShowPopupMessage("Reward has been Updated Successfully.", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("RewardMaster.aspx");
    }
    protected void GV_RewardList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_RewardList.PageIndex = e.NewPageIndex;
        GetData();
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;

            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,RewardName,LeftPair,RightPair,AchieveTime,Gift,CONVERT(nvarchar,CreationDate,105)As CreationDate From Reward Where ID='" + ID + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                ViewState["RewardID"] = dt.Rows[0]["ID"].ToString();
                txtDesignation.Text = dt.Rows[0]["RewardName"].ToString();
                txtLeftPair.Text = dt.Rows[0]["LeftPair"].ToString();
                txtRightPair.Text = dt.Rows[0]["RightPair"].ToString();
                txtAchieveTime.Text = dt.Rows[0]["AchieveTime"].ToString();
                txtGift.Text = dt.Rows[0]["Gift"].ToString();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Reward_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Parameters.AddWithValue("@Mode", "DEL");
            int flag = cmd.ExecuteNonQuery();
            con.Close();
            if (flag > 0)
            {
                Clear();
                ShowPopupMessage("Reward has been Deleted.", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage("Deletion Failed.", PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }



    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here



    
}