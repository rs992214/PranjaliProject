﻿using System;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Web.Configuration;
using DataAccessLayer;
using Newtonsoft.Json;

public partial class Company : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        smsleft();
        //smsNew();
        if(!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                cominfo();
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
      
    }
    public void cominfo()
    {
        string connectionString = ConfigurationManager.ConnectionStrings["CN"].ToString();
        SqlConnection con = new SqlConnection(connectionString);
        string sql = "select CompanyName as clientname from CompanyInfo";
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                lblCompname.Text = dr["clientname"].ToString();
                lblCname.Text = dr["clientname"].ToString();
            }
            dr.Close();
            con.Close();
        }
        catch (Exception ex)
        {

        }
    }
    /* public void profileimage()
   {
       if(Session["userid"]!=null)
       {
           _id=Session["userid"].ToString();
       }
       DAL dal = new DAL();
       string message = string.Empty;
       try
       {
           object image = dal.Getscalar("select proimage from Registration where id='" + _id + "'", ref message);
           if (image != null)
           {
               Image1.ImageUrl = image.ToString();
           }
       }
       catch (Exception ex)
       {
           ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);
       }
   }*/
    public void smsleft()
    {
        string userid = string.Empty;
        string apirequest = string.Empty;
        string senderid = string.Empty;
        string route = string.Empty;
        string key = string.Empty;

        DAL dal = new DAL();
        string message = string.Empty;
        try
        {
            DataTable dt = dal.Gettable("select * from SmsMasterNew", ref message);
            if (dt.Rows.Count > 0)
            {
                userid = dt.Rows[0]["Username"].ToString();
                apirequest = dt.Rows[0]["APIrequest"].ToString();
                //senderid = dt.Rows[0]["Senderid"].ToString();
                route = dt.Rows[0]["Route"].ToString();
                key = dt.Rows[0]["APIkey"].ToString();
                //key = "";
                string sURL;
                StreamReader objReader;
                //sURL= "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?method=request_routeid&username=valivest&password=valivest123&route_id=7&format={json|text}";
                sURL = "http://sms.probuztech.com/sms-panel/api/http/index.php?username=" + userid + "&apikey="+key+"&apirequest=CreditCheck&route=" + route + "&format=Json";
                WebRequest wrGETURL;
                wrGETURL = WebRequest.Create(sURL);

                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                string jsonValue = "";
                objReader = new StreamReader(objStream);
                jsonValue = objReader.ReadToEnd();
                var myDetails = JsonConvert.DeserializeObject<CheckCount>(jsonValue);
                string Status1 = myDetails.Status;
                if (Status1 != "error")
                {
                    lblmsg.Text = "SMS Left :" + " " + myDetails.balance;
                }
                else
                {
                    lblmsg.Text = "SMS Left : 0";
                    ScriptManager.RegisterStartupScript(this,GetType(),"alert","alert('"+ myDetails.Message + "')",true);
                }
            }
            else
            {
                lblmsg.Text = "SMS Left : 0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public class CheckCount
    {
        public string Status
        {
            get;
            set;
        }
        public string balance
        {
            get;
            set;
        }
        public string Message
        {
            get;
            set;
        }
    }
    public void smsNew()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        int sms = 0;
        int smsAvailable = 0;
        DataTable dt = dal.Gettable("select APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew", ref message);
        if (dt.Rows.Count > 0)
        {
            sms = Convert.ToInt32(dt.Rows[0]["CreditSMS"].ToString());
            lblmsg.Text = "SMS Left:" + " " + sms.ToString();
        }
    }

}
