﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Net;
using System.Web.UI.WebControls;

public partial class Company_BBOList : System.Web.UI.Page
{

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                btncancell.Visible = true;
                ShowBBOinformation();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void ShowBBOinformation()
    {
        try
        {
            if (DropDownList1.SelectedIndex > 0)
            {
                MLMUserDetailProperty Mp = new MLMUserDetailProperty();
                DataTable dt = new DataTable();
                if (DropDownList1.SelectedValue == "InActive")
                {
                    Mp.Status = DropDownList1.SelectedValue;
                    MLMUserDetailLogic MlL = new MLMUserDetailLogic();
                    dt = MlL.UserdetailList1(Mp, ref message);
                }
                else
                {
                    Mp.Jointype = DropDownList1.SelectedValue;
                    MLMUserDetailLogic MlL = new MLMUserDetailLogic();
                    dt = MlL.UserdetailList(Mp, ref message);
                }

                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                MLMUserDetailLogic MlL = new MLMUserDetailLogic();
                DataTable dt = MlL.UserdetailList(ref message);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
    }


    public void ShowBBOinformationByName()
    {
        try
        {
            MLMUserDetailProperty Mp = new MLMUserDetailProperty { Userid = TextBox1.Text };
            MLMUserDetailLogic MlL = new MLMUserDetailLogic();
            DataTable dt = MlL.UserdetailListbyName(Mp, ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowBBOinformation();
    }
    string userid = string.Empty;
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string userid = GridView1.SelectedRow.Cells[1].Text;
        Response.Redirect("UserDetail.aspx?AccountNo=" + userid);

    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowBBOinformation();
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ShowBBOinformationByName();
        btncancell.Visible = true;

    }
    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> getName(string prefixText)
    {
        List<string> name = new List<string>();
        DAL dal = new DAL();
        string message = string.Empty;
        try
        {
            StringBuilder sbb = new StringBuilder();
            sbb.AppendFormat("select Name from MLM_Registration where Name like'{0}%'", prefixText);

            DataTable dt = dal.Gettable(sbb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    name.Add(dt.Rows[i][0].ToString());
                }

            }
        }

        catch (Exception)
        {
            throw;
        }
        return name;
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string jointype = ((Label)e.Row.Cells[0].FindControl("Label1")).Text;
            if (jointype == "Free")
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/free.png";
            }
            else if (jointype == "Paid")
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/green.png";
            }
            else
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/red.png";
            }
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Login")
        {
            Response.Redirect("/Member/Login.aspx?UserID=" + e.CommandArgument.ToString());
        }
        else
        {
            return;
        }
    }

    protected void btncancell_Click(object sender, EventArgs e)
    {
        Response.Redirect("BBOList.aspx");
    }


    public void CreateExcelFile(DataTable Excel)
    {

        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=CustomerList.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {
            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {
                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";
            }

            Response.Write("\n");


        }
        Response.End();
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {

            MLMUserDetailLogic MlL = new MLMUserDetailLogic();
            DataTable dt = MlL.UserdetailList(ref message);

            if (dt.Rows.Count > 0)
            {

                CreateExcelFile(dt);
            }
            else
            {
                Response.Redirect(Request.RawUrl);
            }

        }
        catch (Exception ex)
        {
        }
    }

    void CreatePdfFile(DataTable PDF)
    {
        string filename = "CustomerList.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);

        Document doc = new Document(PageSize.A4, 10, 10, 40, 10);

        Paragraph p = new Paragraph("");
        p.Alignment = Element.ALIGN_CENTER;

        try
        {

            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(7);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("Ledger Report", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----      
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("../Company/images/PlutoLogo1.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------


            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "Ledger/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch (Exception ex)
        {

        }
    }

    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }


    protected void btnPdf_Click(object sender, EventArgs e)
    {
        try
        {

            MLMUserDetailLogic MlL = new MLMUserDetailLogic();
            DataTable dt = MlL.UserdetailList(ref message);
            if (dt.Rows.Count > 0)
            {
                // getDataForTrace();
                //tracingPdf();
                CreatePdfFile(dt);
            }
            else
            {
                Response.Redirect(Request.RawUrl);
            }

        }
        catch (Exception ex)
        {

        }
    }

}