﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.IO;
using System.Net;


public partial class Company_otherincomes : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlCommand cmd1;

    string message = string.Empty;
    DAL objDAL;
    protected void Page_Load(object sender, EventArgs e)
    {
        // Modal PopUp Code Goes here
    } 
    private void ShowPopupMessage(string message, PopupMessageType messageType)
        {
            switch (messageType)
            {
                case PopupMessageType.Error:
                    lblMessagePopupHeading.Text = "Error";
                    //Render image in literal control
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                    break;
                case PopupMessageType.Message:
                    lblMessagePopupHeading.Text = "Information";
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                    break;
                case PopupMessageType.Warning:
                    lblMessagePopupHeading.Text = "Warning";
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                    break;
                case PopupMessageType.Success:
                    lblMessagePopupHeading.Text = "Success";
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                    break;
                default:
                    lblMessagePopupHeading.Text = "Information";
                    ltrMessagePopupImage.Text = "<img src='" +
                      Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                    break;
            }

            lblMessagePopupText.Text = message;
            mpeMessagePopup.Show();
        }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here    
   
    public void growthdirectincome()
    {
        con = new SqlConnection(connstring);
        con.Open();
           cmd = new SqlCommand("DailyGrowth", con);
        cmd1 = new SqlCommand("Direct_income", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd1.CommandType = CommandType.StoredProcedure;

        // cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
        int flag1 = cmd1.ExecuteNonQuery();
        con.Close();



        if (flag > 0)
        {

            ShowPopupMessage("Growth and Direct Income Processed.", PopupMessageType.Success);
        }
        else
        {
            ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
        }
    }

    protected void btnDirect_Click(object sender, EventArgs e)
    {
        growthdirectincome();
    }
}