﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Company_CategoryList : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                ShowCategoryList();
            }
            else
            {
                Response.Redirect("Logout.aspx");

            }
        }
    }
    public void ShowCategoryList()
    {
        CategoryMaster CM = new CategoryMaster();
        DataTable dt= CM.FetchCategory(ref message);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowCategoryList();
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        ShowCategoryList();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            CategoryMatserProperty CMP = new CategoryMatserProperty { CategoryName = GridView1.DataKeys[e.RowIndex].Values["CategoryName"].ToString() };
            CategoryMaster CM = new CategoryMaster();
            int rowaffected = CM.DeleteCategory(CMP, ref message);
            if (rowaffected > 0)
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", "Category Deleted Successfully.");
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
                ShowCategoryList();
            }
            else
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", message);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
            }
        }
        catch (Exception ex)
        {

            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
        }
       
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        ShowCategoryList();
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            CategoryMatserProperty CMP = new CategoryMatserProperty { ID = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[0].Text), CategoryName = ((TextBox)(GridView1.Rows[e.RowIndex].FindControl("TextBox1"))).Text };
            CategoryMaster CM = new CategoryMaster();
            int rowaffected = CM.UpdateCategory(CMP, ref message);
            GridView1.EditIndex = -1;
            if (rowaffected > 0)
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", "Category Updated Successfully.");
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
                ShowCategoryList();
            }
            else
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", message);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
            }
        }
        catch (Exception ex)
        {

            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
        }
        
    }
}