﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Net;
using System.Configuration;
using System.Data.SqlClient;

public partial class Company_CompanyInfo : System.Web.UI.Page
{
    string loginip = GetLocalIPAddress();
    string UserName = "";
    string password = "";
    string message = string.Empty;
    DAL dal = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        AdminLoginInfo();
        if (!IsPostBack)
        {
            
            if (Session["UserName"] != null)
            {
                
                ShowState();
                drpcity.Items.Insert(0, new ListItem("Select City", "0"));
                Showdata();
                if (GridView1.Rows.Count > 0)
                {
                    btnsave.Enabled = false;
                }
                btnupdate.Visible = false;
            }
            else
            {
                Response.Redirect("Logout.aspx");

            }

        }
    }
    public void ShowState()
    {
        drpstate.DataTextField = "StateName";
        drpstate.DataValueField = "StateID";
        try
        {
            State st = new State();
            DataTable dt = st.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                drpstate.DataSource = dt;
                drpstate.DataBind();
                drpstate.Items.Insert(0, new ListItem("Select State", "0"));
            }
            else
            {
                drpstate.DataSource = null;
                drpstate.DataBind();
                drpstate.Items.Insert(0, new ListItem("Select State", "0"));
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.Text = ex.Message;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.BackColor = System.Drawing.Color.White;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
        }
    }
    public void ShowCity()
    {
        drpcity.DataTextField = "CityName";
        drpcity.DataValueField = "CityID";
        try
        {

            CityProperty CP = new CityProperty
            {
                StateID = Convert.ToInt32(drpstate.SelectedValue)
            };
            City ct = new City();
            DataTable dt = ct.GetData(CP, ref message);
            if (dt.Rows.Count > 0)
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select City", "0"));
            }
            else
            {
                drpcity.DataSource = null;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select City", "0"));
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.Text = ex.Message;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.BackColor = System.Drawing.Color.White;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
        }

    }
    public void Showdata()
    {
        try
        {
            CompanyInfo CI = new CompanyInfo();
            DataTable dt = CI.GetData(ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                string Logo = dt.Rows[0]["Logo"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    byte[] bytes = (byte[])dt.Rows[0]["Logo"];
                    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    Image1.ImageUrl = "data:image/png;base64," + base64String;
                }
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnsave.Enabled = true;
            }
        }
        catch (Exception ex)
        {

            lblmsg.Visible = true;
            lblmsg.Text = ex.Message;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.BackColor = System.Drawing.Color.White;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true); 
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        CompanyInfoProperty CIP = new CompanyInfoProperty();

        if (FileUpload1.HasFile)
        {
            Stream fs = FileUpload1.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);
            CIP.Logo = bytes;
        }
        else
        {
            CIP.Logo = null;
        }

        CIP.CompanyName = txtcompanyname.Text;
        CIP.StateID = Convert.ToInt32(drpstate.SelectedValue);
        CIP.CityID = Convert.ToInt32(drpcity.SelectedValue);
        CIP.Address = txtaddress.Text;
        CIP.CINNo = txtcinno.Text;
        CIP.PhoneNo = txtphoneno.Text;
        CIP.Emailid = txtEmail.Text;
        CIP.GstNo = txtgstno.Text;
        CIP.Website = txtwebsite.Text;

        try
        {
            CompanyInfo CI = new CompanyInfo();
            int rowaffected = CI.SaveCompInfo(CIP, ref message);
            if (rowaffected > 0)
            {
                int index = dal.Executequery("Update CompanyInfo set PhoneNo=@Phoneno", ref message);
                lblmsg.Visible = true;
               // lblmsg.Text = "Company profile Save Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.BackColor = System.Drawing.Color.White;
                //  ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
                ShowPopupMessage("Company Profile Published Successfully", PopupMessageType.Message);
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Success:Company Profile Published Successfully..!!')", con);
                    cmd.CommandType = CommandType.Text;

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {

                    }
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    con.Close();
                }

            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = message;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.BackColor = System.Drawing.Color.White;
                ShowPopupMessage("Please Update Profile Carefully", PopupMessageType.Message);
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Warning:Please Update Profile Carefully..!!')", con);
                    cmd.CommandType = CommandType.Text;

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {

                    }
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    con.Close();
                }

            }
        }
        catch (Exception ex)
        {
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Error:'"+error+"'')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

            lblmsg.Visible = true;
            lblmsg.Text = ex.Message;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.BackColor = System.Drawing.Color.White;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
        }
        finally
        {
            Showdata();
        }

    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        

        int rowaffected = 0;
        try
        {
            CompanyInfoProperty CIP = new CompanyInfoProperty();
            if (FileUpload1.HasFile)
            {
                Stream fs = FileUpload1.PostedFile.InputStream;

                BinaryReader br = new BinaryReader(fs);

                Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                CIP.Logo = bytes;
                
                CIP.CompanyName = txtcompanyname.Text;
                CIP.StateID = Convert.ToInt32(drpstate.SelectedValue);
                CIP.CityID = Convert.ToInt32(drpcity.SelectedValue);
                CIP.Address = txtaddress.Text;
                CIP.PhoneNo = txtphoneno.Text;
                CIP.CINNo = txtcinno.Text;
                CIP.GstNo = txtgstno.Text;
                CIP.Emailid = txtEmail.Text;
                CIP.Website = txtwebsite.Text;

                CompanyInfo CI = new CompanyInfo();
                rowaffected = CI.UpdateCompinfo(CIP, ref message);
           

            }
            else
            {
                CIP.CompanyName = txtcompanyname.Text;
                CIP.StateID = Convert.ToInt32(drpstate.SelectedValue);
                CIP.CityID = Convert.ToInt32(drpcity.SelectedValue);
                CIP.Address = txtaddress.Text;
                CIP.PhoneNo = txtphoneno.Text;
                CIP.CINNo = txtcinno.Text;
                CIP.GstNo = txtgstno.Text;
                CIP.Emailid = txtEmail.Text;
                CIP.Website = txtwebsite.Text;
                CompanyInfo CI = new CompanyInfo();
                rowaffected = CI.UpdateCompinfowithoutlogo(CIP, ref message);
                
            }
            if (rowaffected > 0)
            {
                int index = dal.Executequery("Update Adminlogin set Mobile='" + txtphoneno.Text + "'", ref message);
                lblmsg.Visible = true;
               // lblmsg.Text = "Company profile Updated Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.BackColor = System.Drawing.Color.White;
                //  ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
                ShowPopupMessage("Company Profile Updated Successfully", PopupMessageType.Success);
                if (FileUpload1.HasFile)
                {

                    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                    SqlConnection con = new SqlConnection(connstring);
                    try
                    {

                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Success:Company Profile Updated Successfully And Company Logo Has Changed..!!')", con);
                        cmd.CommandType = CommandType.Text;

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {

                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        con.Close();
                    }


                }
                else
                {
                    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                    SqlConnection con = new SqlConnection(connstring);
                    try
                    {

                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Success:Company Profile Updated Successfully..!!')", con);
                        cmd.CommandType = CommandType.Text;

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {

                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        con.Close();
                    }


                }
            }
            else
            {

                lblmsg.Visible = true;
                lblmsg.Text = message;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.BackColor = System.Drawing.Color.White;
                //  ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
                ShowPopupMessage("Please Update Profile Carefully", PopupMessageType.Error);
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Warning:Please Update Profile Carefully')", con);
                    cmd.CommandType = CommandType.Text;

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {

                    }
                }
                catch (Exception ex)
                {

                }
                finally
                {
                    con.Close();
                }
            }

        }
        catch (Exception ex)
        {
            string Error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password + "','" + loginip + "',GETDATE(),'Error:'"+Error+"'')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }


            lblmsg.Visible = true;
            lblmsg.Text = ex.Message;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.BackColor = System.Drawing.Color.White;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);

        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            Showdata();
        }
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtcompanyname.Text = string.Empty;
        drpstate.SelectedIndex = 0;
        drpcity.SelectedIndex = 0;
        txtcinno.Text = string.Empty;
        txtaddress.Text = string.Empty;
        txtphoneno.Text = string.Empty;
        txtEmail.Text = string.Empty;
        txtgstno.Text = string.Empty;
        txtwebsite.Text = string.Empty;
        txtcompanyname.ReadOnly = true;
        btnsave.Visible = true;
        btnupdate.Visible = false;

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtcompanyname.Text = GridView1.SelectedRow.Cells[0].Text;
        txtcompanyname.ReadOnly = false;
        drpstate.ClearSelection();
        drpstate.Items.FindByText(GridView1.SelectedRow.Cells[1].Text).Selected = true;
        CityProperty CP = new CityProperty { StateID = Convert.ToInt32(drpstate.SelectedValue) };
        ShowCity();
        drpcity.ClearSelection();
        drpcity.Items.FindByText(GridView1.SelectedRow.Cells[2].Text).Selected = true;
        txtaddress.Text = GridView1.SelectedRow.Cells[3].Text;
        txtphoneno.Text = GridView1.SelectedRow.Cells[4].Text;
        txtEmail.Text = GridView1.SelectedRow.Cells[5].Text;
        txtcinno.Text = GridView1.SelectedRow.Cells[6].Text;
        txtgstno.Text = GridView1.SelectedRow.Cells[7].Text;
        txtwebsite.Text = GridView1.SelectedRow.Cells[8].Text;
        btnupdate.Visible = true;
        btnsave.Visible = false;
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        CompanyInfoProperty CIP = new CompanyInfoProperty();
        CIP.CompanyName = GridView1.DataKeys[e.RowIndex].Values["CompanyName"].ToString();
        try
        {
            CompanyInfo CI = new CompanyInfo();
            int rowaffected = CI.DeleteInfo(CIP, ref message);
            if (rowaffected > 0)
            {
                lblmsg.Visible = true;
               // lblmsg.Text = "Company profile Deleted Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.BackColor = System.Drawing.Color.White;
                //   ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
                ShowPopupMessage("Company Profile Deleted Successfully.", PopupMessageType.Success);
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = message;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.BackColor = System.Drawing.Color.White;
                ShowPopupMessage("Incomplete Profile Details.", PopupMessageType.Warning);
            }
        }
        catch (Exception ex)
        {

            lblmsg.Visible = true;
            lblmsg.Text = ex.Message;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.BackColor = System.Drawing.Color.White;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Show Modal Pop Up", "showmodalpopup();", true);
        }
        finally
        {
            Showdata();
        }
    }

    protected void drpstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowCity();
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here  
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName = dt.Rows[0]["UserName"].ToString();
                password = dt.Rows[0]["password"].ToString();
                
            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
   

}