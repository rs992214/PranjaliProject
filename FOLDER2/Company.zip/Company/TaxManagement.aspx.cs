﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_TaxManagement : System.Web.UI.Page
{
    DAL objdal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
            GetRecords();
        }
    }

    void GetRecords()
    {
        DAL dal = new DAL();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select T.ID,P.PackageName,T.Taxable_Amount,T.SGST,T.CGST,T.IGST from PackageInfo P inner join Tax_Master T On P.ID = T.PackageID");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            gvgst.DataSource = dt;
            gvgst.DataBind();
        }
        else
        {
            gvgst.DataSource = null;
            gvgst.DataBind();
        }
    }

    void GetData()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select PackageName,ID from PackageInfo");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                ddlpackage.DataSource = dt;
                ddlpackage.DataBind();
                ddlpackage.DataTextField = "PackageName";
                ddlpackage.DataValueField = "ID";
                ddlpackage.DataBind();
            }
            else
            {
                ddlpackage.DataSource = null;
                ddlpackage.DataBind();
                ddlpackage.DataTextField = "PackageName";
                ddlpackage.DataValueField = "ID";
                ddlpackage.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    double amount = 0;
    void Calculation()
    {
        DAL dal = new DAL();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select Amount from PackageInfo where ID=" + ddlpackage.SelectedValue);
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            double value = Convert.ToDouble(dt.Rows[0]["Amount"]);
            amount = value / (Convert.ToDouble(txtsgst.Text) + Convert.ToDouble(txtcgst.Text) + 100)* 100;
            amount = Math.Round(amount,2);
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            decimal igst = Convert.ToDecimal(txtigst.Text);
            decimal sgst = Convert.ToDecimal(txtsgst.Text);
            decimal cgst = Convert.ToDecimal(txtcgst.Text);
            if (igst >= 0 || sgst >=0 ||  cgst >= 0)
            {
                Calculation();
                DAL dal = new DAL();
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("insert into Tax_Master(PackageID,SGST,CGST,IGST,Taxable_Amount,PackageName)");
                sb.AppendFormat("values('{0}','{1}','{2}','{3}','{4}','{5}')", ddlpackage.SelectedValue, txtsgst.Text, txtcgst.Text, txtigst.Text, amount, ddlpackage.SelectedItem.Text);
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {
                    Response.Redirect("SuccessView.aspx?Link=TaxManagement.aspx");
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('GST Plan Save Successfully')", true);
                }
                else
                {
                    string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                    var script = string.Format("alert('{0}');", errormessage);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
                }
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
        Clear();
        GetRecords();
    }

    protected void btnreset_Click(object sender, EventArgs e)
    {
        Response.Redirect("TaxManagement.aspx");
    }

    void Clear()
    {
        ddlpackage.SelectedIndex = -1;
        txtigst.Text = string.Empty;
        txtcgst.Text = string.Empty;
        txtsgst.Text = string.Empty;
    }

    protected void btndelete_Command(object sender, CommandEventArgs e)
    {
        int flag = objdal.Executequery("Delete from tax_master where ID="+e.CommandArgument,ref message);
        if(flag > 0)
        {
            GetRecords();
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('GST Plan deleted Successfully')", true);
        }
    }
}