﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web; 
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;
using System.Web.Script.Serialization;

public partial class AdminCharge : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                //GridView1.DataBind();
                data();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }    

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        StringBuilder sba = new StringBuilder();
        sba.AppendFormat("select * from AdminMaster");
        DataTable dt = dal.Gettable(sba.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Admin Charge Allready Prresent')", true);
            return;
        }
        else
        {
           
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("insert into AdminMaster(Admin)");
            sb.AppendFormat("values('{0}')", txtuserid.Text);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {
                    Response.Redirect("SuccessView.aspx?Link=AdminCharge.aspx");
                    // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Save Successfully')", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Oops!Some Error Occur.Try After Some Time.')", true);
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                txtuserid.Text = string.Empty;
                data();
                //GridView1.DataBind();
            }

        }
        
    }
    

    protected void data()
    {
        StringBuilder sba = new StringBuilder();
        sba.AppendFormat("select * from AdminMaster");
        DataTable dt = dal.Gettable(sba.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string ID = GridView1.DataKeys[e.RowIndex].Values["ID"].ToString();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Delete from AdminMaster where ID='" + ID + "'");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                data();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Admin Charge Information Deleted Successfully')", true);
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }

    }
}