﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Email_SMSNotification : System.Web.UI.Page
{
    string message = string.Empty;
    string loginip = GetLocalIPAddress();
    string UserName = "";
    string password1 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        AdminLoginInfo();
        if (!IsPostBack)
        {
            GetData();
        }
    }
    int Id;
    void GetData()
    {
        DAL dal = new DAL();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select * from SMS_Email_Notification");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            smsepin = dt.Rows[0]["E_PinSMS"].ToString();
            smspayout = dt.Rows[0]["PayoutsSMS"].ToString();
            smswithdrawal = dt.Rows[0]["Withdrawal_SystemSMS"].ToString();
            smsregistartion = dt.Rows[0]["RegistrationSMS"].ToString();
            emailepin = dt.Rows[0]["E_PinEmail"].ToString();
            emailpayout = dt.Rows[0]["PayoutsEmail"].ToString();
            emailwithdrawal = dt.Rows[0]["Withdrawal_SystemEmail"].ToString();
            emailregistration = dt.Rows[0]["RegistrationEmail"].ToString();
            ValidData();
        }
    }

    void ValidData()
    {
        if (smsepin == "Active")
        {
            chksmsepin.Checked = true;
        }
        else
        {
            chksmsepin.Checked = false;
        }

        if (smspayout == "Active")
        {
            chksmspayout.Checked = true;
        }
        else
        {
            chksmspayout.Checked = false;
        }

        if (smswithdrawal == "Active")
        {
            chksmswithdrawal.Checked = true;
        }
        else
        {
            chksmswithdrawal.Checked = false;
        }

        if (smsregistartion == "Active")
        {
            chksmsregistration.Checked = true;
        }
        else
        {
            chksmsregistration.Checked = false;
        }

        if (emailepin == "Active")
        {
            chkemailepin.Checked = true;
        }
        else
        {
            chkemailepin.Checked = false;
        }

        if (emailpayout == "Active")
        {
            chkemailpayout.Checked = true;
        }
        else
        {
            chkemailpayout.Checked = false;
        }

        if (emailwithdrawal == "Active")
        {
            chkemailwithdrawal.Checked = true;
        }
        else
        {
            chkemailwithdrawal.Checked = false;
        }

        if (emailregistration == "Active")
        {
            chkemailregistration.Checked = true;
        }
        else
        {
            chkemailregistration.Checked = false;
        }

    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        SMS();
        Email();
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select * from SMS_Email_Notification");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                Id = Convert.ToInt32(dt.Rows[0]["ID"]);
                StringBuilder sb1 = new StringBuilder();
                sb1.AppendLine("Update SMS_Email_Notification ");
                sb1.AppendFormat("set E_PinSMS ='{0}',PayoutsSMS='{1}',Withdrawal_SystemSMS='{2}',RegistrationSMS='{3}',E_PinEmail='{4}',PayoutsEmail='{5}',Withdrawal_SystemEmail='{6}',RegistrationEmail='{7}' where ID="+Id+"", smsepin, smspayout, smswithdrawal, smsregistartion, emailepin, emailpayout, emailwithdrawal, emailregistration);
                int rowaffected = dal.Executequery(sb1.ToString(), ref message);
                if (rowaffected > 0)
                {
                    EmailSmsStatus();
                    Response.Redirect("SuccessView.aspx?Link=Email_SMSNotification.aspx");
                  //  ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Notification Save Successfully')", true);
                }
                else
                {

                    string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                    var script = string.Format("alert('{0}');", errormessage);
                    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                    SqlConnection con = new SqlConnection(connstring);
                    try
                    {


                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Error:  "+errormessage+" ')", con);
                        cmd.CommandType = CommandType.Text;

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {

                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        con.Close();
                    }

                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
                }
            }
            else
            {
                StringBuilder sb1 = new StringBuilder();
                sb1.AppendLine("insert into SMS_Email_Notification(E_PinSMS,PayoutsSMS,Withdrawal_SystemSMS,RegistrationSMS,E_PinEmail,PayoutsEmail,Withdrawal_SystemEmail,RegistrationEmail)");
                sb1.AppendFormat("values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", smsepin, smspayout, smswithdrawal, smsregistartion, emailepin, emailpayout, emailwithdrawal,emailregistration);
                int rowaffected = dal.Executequery(sb1.ToString(), ref message);
                if (rowaffected > 0)
                {
                    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                    SqlConnection con = new SqlConnection(connstring);
                    try
                    {


                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Status:Notification For E_PinSMS=" + smsepin + ",PayoutsSMS=" + smspayout + ",Withdrawal_SystemSMS=" + smswithdrawal + ",RegistrationSMS=" + smsregistartion + ",E_PinEmail=" + emailepin + ",PayoutsEmail=" + emailpayout + ",Withdrawal_SystemEmail=" + emailwithdrawal + ",RegistrationEmail=" + emailregistration + " saved Successfully..!! ')", con);
                        cmd.CommandType = CommandType.Text;

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {

                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        con.Close();
                    }

                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Notification Save Successfully')", true);
                }
                else
                {
                    string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                    var script = string.Format("alert('{0}');", errormessage);
                    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                    SqlConnection con = new SqlConnection(connstring);
                    try
                    {


                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Status:Notification For Email And Messege are Not Updated showing Some " + errormessage + " ')", con);
                        cmd.CommandType = CommandType.Text;

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {

                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        con.Close();
                    }


                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
                }
            }
        }
        catch (Exception ex)
        {
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {


                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Error: " + error + " ')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

        }
    }

    protected void btnreset_Click(object sender, EventArgs e)
    {
        //Response.Redirect("Email_SMSNotification.aspx");
        Response.Redirect("SuccessView.aspx?Link=Email_SMSNotification.aspx");
    }

    string smsepin = string.Empty;
    string smspayout = string.Empty;
    string smswithdrawal = string.Empty;
    string smsregistartion = string.Empty;
    string emailepin = string.Empty;
    string emailpayout = string.Empty;
    string emailwithdrawal = string.Empty;
    string emailregistration = string.Empty;
    
    void SMS()
    {
        if (chksmsepin.Checked == true)
        {
            smsepin = "Active";
        }
        else
        {
            smsepin = "DeActive";
        } 

        if (chksmspayout.Checked == true)
        {
            smspayout = "Active";
        }
        else
        {
            smspayout = "DeActive";
        }

        if(chksmswithdrawal.Checked == true)
        {
            smswithdrawal = "Active";
        }
        else
        {
            smswithdrawal = "DeActive";
        }

        if(chksmsregistration.Checked == true)
        {
            smsregistartion = "Active";
        }
        else
        {
            smsregistartion = "DeActive";
        }
    }

    void Email()
    {
        if(chkemailepin.Checked == true)
        {
            emailepin = "Active";
        }
        else
        {
            emailepin = "DeActive";
        }

        if(chkemailpayout.Checked == true)
        {
            emailpayout = "Active";
        }
        else
        {
            emailpayout = "DeActive";
        }

        if(chkemailwithdrawal.Checked == true)
        {
            emailwithdrawal = "Active";
        }
        else
        {
            emailwithdrawal = "DeActive";
        }

        if(chkemailregistration.Checked == true)
        {
            emailregistration = "Active";
        }
        else
        {
            emailregistration = "DeActive";
        }
    }
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName = dt.Rows[0]["UserName"].ToString();
                password1 = dt.Rows[0]["password"].ToString();

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void EmailSmsStatus()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Status:Notification For E_PinSMS="+ smsepin + ",PayoutsSMS="+ smspayout + ",Withdrawal_SystemSMS="+ smswithdrawal + ",RegistrationSMS="+ smsregistartion + ",E_PinEmail="+ emailepin + ",PayoutsEmail="+ emailpayout + ",Withdrawal_SystemEmail="+ emailwithdrawal + ",RegistrationEmail="+ emailregistration + " saved Successfully..!! ')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }

}