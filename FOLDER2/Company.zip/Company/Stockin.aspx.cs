﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Stockin : System.Web.UI.Page
{
    string message = string.Empty;
    string Type;
    string date1;
    string date2;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Showproductreport();
        }
    }
    private void Showproductreport()
    {
        try
        {
            
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select ProductCode as [Product Code], ProductName as [Product Name],OpeningStock as Quantity from Product");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        Showproductreport();
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            int quantity = int.Parse(e.Row.Cells[3].Text);
            if (quantity >= 10)
            {
                e.Row.BackColor = Color.Green;
            }
            if (quantity < 10)
            {
                e.Row.BackColor = Color.Yellow;
            }
            if (quantity <= 5)
            {
                e.Row.BackColor = Color.Red;
            }
        }
    }
    public void ShowBBOinformationByName()
    {
        try
        {
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("Select ProductCode as [Product Code], ProductName as [Product Name],OpeningStock as Quantity from Product where ProductName='" + txtproductname.Text + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }
        catch (Exception)
        {

            throw;
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ShowBBOinformationByName();
    }
}