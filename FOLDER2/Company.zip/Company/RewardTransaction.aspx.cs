﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Collections;
using System.Text;

public partial class Company_RewardTransaction : System.Web.UI.Page
{
    public int countA = 0;
    public int countB = 0;
    ArrayList UserIDRightList = new ArrayList();
    ArrayList UserIDRightList1 = new ArrayList();

    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    DAL objDAL;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
        }
    }
    private void GetData()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,RewardName,LeftPair,RightPair,AchieveTime,dbo.Get_OnlyNumeric(AchieveTime)As Days,Gift,CONVERT(nvarchar,CreationDate,105)As CreationDate From Reward", ref message);
            if (dt.Rows.Count > 0)
            {
                GV_RewardList.DataSource = dt;
                GV_RewardList.DataBind();
            }
            else
            {
                GV_RewardList.DataSource = null;
                GV_RewardList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void InsertReward(string UserID, string RewardID, string Status)
    {
        con = new SqlConnection(connstring);
        con.Open();
        cmd = new SqlCommand("RewardTransaction_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", UserID);
        cmd.Parameters.AddWithValue("@RewardID", RewardID);
        cmd.Parameters.AddWithValue("@Status", Status);
        cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
        int flag = cmd.ExecuteNonQuery();
        con.Close();
    }
    protected void btnProceed_Click(object sender, EventArgs e)
    {
        //try
        //{
        //    objDAL = new DAL();
        //    DataTable dtUserList = objDAL.Gettable("Select DID,UserID From MLM_Registration Where Userid='C19258' Order By DID ASC", ref message);
        //    if (dtUserList.Rows.Count > 0)
        //    {
        //        for (int i = 0; i < dtUserList.Rows.Count; i++)
        //        {
        //            string UserID = dtUserList.Rows[i]["UserID"].ToString();
        //            string Status = string.Empty;
        //            foreach (GridViewRow row in GV_RewardList.Rows)
        //            {
        //                Label lblRewardID = row.FindControl("lblRewardID") as Label;
        //                Label lblLeftPair = row.FindControl("lblLeftPair") as Label;
        //                Label lblRightPair = row.FindControl("lblRightPair") as Label;
        //                Label lblAchieveTime = row.FindControl("lblAchieveTime") as Label;

        //                int _LeftPairRequired = Convert.ToInt32(lblLeftPair.Text);
        //                int _RightPairRequired = Convert.ToInt32(lblRightPair.Text);
        //                int No_of_Days = Convert.ToInt32(lblAchieveTime.Text);

        //                DataTable dt = objDAL.Gettable("Select UserID,CONVERT(nvarchar,JoinDate,105)As JoinDate From MLM_Registration Where UserID='" + UserID + "'", ref message);
        //                if (dt.Rows.Count > 0)
        //                {
        //                    string[] _JoinDate = dt.Rows[0]["JoinDate"].ToString().Split('-'); // User Joining Date
        //                    DateTime _NewDate = new DateTime(Convert.ToInt32(_JoinDate[2]), Convert.ToInt32(_JoinDate[1]), Convert.ToInt32(_JoinDate[0]));
        //                    DateTime _TragetTime = _NewDate.AddDays(No_of_Days);
        //                    string FinalDate = _TragetTime.ToString("yyyy-MM-dd"); // From Date

        //                    DataTable dtCount = objDAL.Gettable("Select SponsorID,ISNULL(SUM(LJoining),0) As LeftCount,ISNULL(SUM(Rjoining),0) As RightCount From MLM_Registration Where SponsorID='" + UserID + "' and JoinDate Between JoinDate and '" + FinalDate + "' Group By SponsorID", ref message);
        //                    if (dtCount.Rows.Count > 0)
        //                    {
        //                        int _LeftCount = Convert.ToInt32(dtCount.Rows[0]["LeftCount"]);
        //                        int _RightCount = Convert.ToInt32(dtCount.Rows[0]["RightCount"]);
        //                        if (_LeftCount >= _LeftPairRequired && _RightCount >= _RightPairRequired)
        //                        {
        //                            Status = "Achieved";
        //                        }
        //                        else
        //                        {
        //                            Status = "Not Achieved";
        //                        }
        //                    }
        //                    else
        //                    {
        //                        Status = "Not Achieved";
        //                    }
        //                    InsertReward(UserID, lblRewardID.Text, Status);

        //                }
        //                else
        //                {
        //                    Status = "Not Achieved";
        //                    InsertReward(UserID, lblRewardID.Text, Status);
        //                }

        //            }
        //        }
        //    }
        //}
        //catch (Exception ex)
        //{
        //    ShowPopupMessage(ex.Message, PopupMessageType.Error);
        //}


          GenerateRewards();
    }



    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    private void GenerateRewards()
    {
        DAL dal = new DAL();
        StringBuilder sb1 = new StringBuilder();
      //  sb1.AppendFormat("select LLeg,RLeg,UserID from MLM_Registration Where UserID='C19258'");

        sb1.AppendFormat("select LLeg,RLeg,UserID from MLM_Registration ORDER BY DID");

        DataTable dt = dal.Gettable(sb1.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string userid = dt.Rows[i]["UserID"].ToString();
                string Leftuserid = dt.Rows[i]["LLeg"].ToString();
                string Rightuserid = dt.Rows[i]["RLeg"].ToString();
                countA = 0;
                countB = 0;
                try
                {
                    string L = null;
                    string R = null;
                    int TeamASV = 0;
                    string UserID = Leftuserid;
                    do
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                        DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                        if (UserDetail.Rows.Count > 0)
                        {
                            L = UserDetail.Rows[0]["LLeg"].ToString();
                            R = UserDetail.Rows[0]["RLeg"].ToString();

                            StringBuilder sbgold = new StringBuilder();
                            //sbgold.AppendFormat("select * from MLM_Registration where UserID='{0}' and JoinType='Paid' and cast(JoinDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);
                            sbgold.AppendFormat("select * from MLM_Registration where UserID='{0}' and JoinType='Paid'", UserID);
                            DataTable dtpaid = dal.Gettable(sbgold.ToString(), ref message);
                            // TeamASV = Convert.ToInt32(UserDetail.Rows[0]["SV"]);
                            if (dtpaid.Rows.Count > 0)
                            {
                                 countA++;
                                //countA = 24;

                            }
                        }
                        if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                            UserIDRightList.Add(R);
                        }
                        if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                        }
                        else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserIDRightList.Add(R);
                            int count = UserIDRightList.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList[count - 1].ToString();
                                UserIDRightList.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }

                        }
                        else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            int count = UserIDRightList.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList[count - 1].ToString();
                                UserIDRightList.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }

                        }
                    } while (UserID != null);
                    //Response.Write(countA);
                    //Response.End();
                }
                catch (Exception)
                {

                    throw;
                }

                //Right Count
                try
                {
                    string L = null;
                    string R = null;
                    int TeamASV = 0;
                    string UserID = Rightuserid;
                    do
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                        DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                        if (UserDetail.Rows.Count > 0)
                        {
                            L = UserDetail.Rows[0]["LLeg"].ToString();
                            R = UserDetail.Rows[0]["RLeg"].ToString();
                            StringBuilder sbgold = new StringBuilder();
                            //sbgold.AppendFormat("select * from MLM_Registration where UserID='{0}' and JoinType='Paid' and cast(JoinDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "'", UserID);
                             sbgold.AppendFormat("select * from MLM_Registration where UserID='{0}' and JoinType='Paid'", UserID);
                            DataTable dtpaid = dal.Gettable(sbgold.ToString(), ref message);
                            //TeamASV = Convert.ToInt32(UserDetail.Rows[0]["SV"]);
                            if (dtpaid.Rows.Count > 0)
                            {
                                countB++;
                               // countB = 24;

                            }
                        }
                        if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                            UserIDRightList1.Add(R);
                        }
                        if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                        }
                        else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserIDRightList1.Add(R);
                            int count = UserIDRightList1.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList1[count - 1].ToString();
                                UserIDRightList1.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }

                        }
                        else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            int count = UserIDRightList1.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList1[count - 1].ToString();
                                UserIDRightList1.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }

                        }
                    } while (UserID != null);
                    //Response.Write(countB++);
                    //Response.End();
                }
                catch (Exception)
                {

                    throw;
                }
                //Response.Write(countA + "/" + countB);
                //Response.End();
                if(countA>=1 && countA<=10 && countB >= 1 && countB <= 10)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 1);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Watch')", true);
                }
                else if (countA >= 25 && countA < 50 && countB >= 25 && countB < 50)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 2);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Ceiling Fan')", true);
                }
                else if (countA >= 50 && countA < 100 && countB >= 50 && countB < 100)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 3);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Smart Phone')", true);
                }
                else if (countA >= 100 && countA < 300 && countB >= 100 && countB < 300)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 4);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Home Theater')", true);
                }
                else if (countA >= 300 && countA < 500 && countB >= 300 && countB < 500)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 5);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Laptop')", true);
                }
                else if (countA >= 500 && countA < 1000 && countB >= 500 && countB < 1000)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 6);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Bike')", true);
                }
                else if (countA >= 1000 && countA < 2500 && countB >= 1000 && countB < 2500)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 7);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Bullet 150 C.C.')", true);
                }
                else if (countA >= 2500 && countA < 5000 && countB >= 2500 && countB < 5000)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 8);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Alto 800 ( Maruti )')", true);
                }
                else if (countA >= 5000 && countA < 10000000 && countB >= 5000 && countB < 10000000)
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("RewardTransaction_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserID", userid);
                    cmd.Parameters.AddWithValue("@RewardID", 9);
                    cmd.Parameters.AddWithValue("@Status", "Achieved");
                    cmd.Parameters.AddWithValue("@Mode", "IN_UPD");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('I-20 Active (Hyundai)')", true);
                }
               

            }

        }

    }

  



}