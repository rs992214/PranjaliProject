﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using DataAccessLayer;
using System.IO;
using System.Drawing;
using iTextSharp.text;
using iTextSharp.text.pdf;

public partial class Company_CollectionReport : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnexportexcel.Visible = false;
            btnexportPDF.Visible = false;

        }
    }
    public void GetData()
    {
        string[] dte = txtfromdate.Text.Split('/');
        string[] dte1 = txttodate.Text.Split('/');
        string joinstring = "/";
        DateTime date1 = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
        DateTime date2 = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);
        DAL dal = new DAL();
        StringBuilder sb = new StringBuilder();
        //  sb.AppendFormat("select MR.UserID,MR.Name,PAck.PackageName,CAST((Amount-(Amount*18/100)) as decimal(18,2)) as [Amount],CAST((Amount*18/100) as decimal(18,2)) as [GST(18%)],ISNULL(PAck.Amount,0) as [Total Amount],convert(nvarchar(10),MR.PackageDate,103)as [Date] from MLM_Registration as MR inner join PackageInfo as PAck on MR.Package = PAck.PackageName where MR.packageDate between '{0}' and '{1}'", date1, date2);
        // sb.AppendFormat("Select UserID,Name,packageDate from MLM_Registration between '{0}' and '{1}'", txtfromdate.Text, txttodate.Text);
        sb.AppendFormat("Select UserID,Name,packageDate,JoinType from MLM_Registration");

        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            GridView1.PageSize = dt.Rows.Count;
            GridView1.DataSource = dt;
            GridView1.DataBind();
            btnexportexcel.Visible = true;
            btnexportPDF.Visible = true;
        }
        else
        {
            btnexportPDF.Visible = true;
            btnexportexcel.Visible = false;
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        if(txtfromdate.Text!=string.Empty && txttodate.Text!=string.Empty)
        { 
              try
              {
                  GetData();
              }
              catch (Exception ex)
              {

                  throw;
              }
        }
        else
        {

        }
    }
    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=CollectionReport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridView1.AllowPaging = false;
                GetData();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GridView1.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridView1.HeaderRow.Cells)
                {
                    cell.BackColor = GridView1.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridView1.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridView1.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridView1.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridView1.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    protected void btnexportPDF_Click(object sender, EventArgs e)
    {
        string[] dte = txtfromdate.Text.Split('/');
        string[] dte1 = txttodate.Text.Split('/');
        string joinstring = "/";
        DateTime date1 = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
        DateTime date2 = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);
        DAL dal = new DAL();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select MR.UserID,MR.Name,PAck.PackageName,CAST((Amount-(Amount*18/100)) as decimal(18,2)) as [Amount],CAST((Amount*18/100) as decimal(18,2)) as [GST(18%)],ISNULL(PAck.Amount,0) as [Total Amount],convert(nvarchar(10),MR.PackageDate,103)as [Date] from MLM_Registration as MR inner join PackageInfo as PAck on MR.Package = PAck.PackageName where MR.packageDate between '{0}' and '{1}'", date1, date2);
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            CreatePdfFile(dt);
        }
    }

    void CreatePdfFile(DataTable PDF)
    {
        string filename = "CollectionReport.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);


        Document doc = new Document(PageSize.A4, 10, 10, 10, 10);

        Paragraph p = new Paragraph();
        p.Alignment = Element.ALIGN_CENTER;

        try
        {
            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(11);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("Collection Report", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("images/Probuzimg.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------


            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "application/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch
        {

        }
    }
    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }
}