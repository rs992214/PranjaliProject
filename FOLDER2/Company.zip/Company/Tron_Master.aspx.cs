﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;

public partial class Company_Tron_Master : System.Web.UI.Page
{
    DAL dal;
    string message = string.Empty;
    SqlConnection con;
    SqlCommand cmd;
    string connstr = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(connstr);
        cmd = new SqlCommand();
        cmd.Connection = con;
        if (!IsPostBack)
        {
            LoadData();
        }
    }

    private void LoadData()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("Select ID,TronCoin,Dollar,Date from Tron_Master", ref message);
        if (dt.Rows.Count > 0)
        {
            btnsave.Enabled = false;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            btnsave.Enabled = true;
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            cmd.CommandText = "Insert into Tron_Master(TronCoin, Dollar, Date)values(" + Convert.ToInt16(txtPlutocoin.Text) + "," + Convert.ToDecimal(txtDollar.Text) + " , GETDATE())";
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                LoadData();
                ScriptManager.RegisterStartupScript(this, GetType(), "", "alert('Data Updated Successfully.')", true);
            }
        }
        catch (Exception ex)
        {

        }
        finally { con.Close(); }

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DAL dal = new DAL();
        //string ID = GridView1.DataKeys[e.RowIndex].Values["ID"].ToString();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Delete from Tron_Master");
        int rowaffected = dal.Executequery(sb.ToString(), ref message);
        if (rowaffected > 0)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Deleted Successfully');window.location='Tron_Master.aspx'", true);
            LoadData();
        }
    }

}