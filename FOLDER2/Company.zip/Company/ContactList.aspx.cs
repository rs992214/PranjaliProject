﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_ContactList : System.Web.UI.Page
{
    string message = string.Empty;
    DAL objDAL = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        Getdata();
    }

    void Getdata()
    {
        try
        {
            DataTable dt = new DataTable();
            if (txtfromdate.Text != null && txtfromdate.Text != "" && txttodate.Text != null && txttodate.Text != "")
            {
                dt = objDAL.Gettable("select * from ContactUs where Cast(Date as date) between '" + txtfromdate.Text + "' and '" + txttodate.Text + "' Order By ID", ref message);
            }
            else if (txtUserID.Text != null && txtUserID.Text != "")
            {
                dt = objDAL.Gettable("select * from ContactUs where Name='" + txtUserID.Text + "' Order By ID", ref message);
            }
            else
            {
                dt = objDAL.Gettable("select * from ContactUs Order By ID", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = null;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
            // ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        Getdata();
    }

    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        Getdata();
    }
}