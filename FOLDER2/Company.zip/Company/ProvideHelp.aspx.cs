﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_ProvideHelp : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                GetReceiveList();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void GetReceiveList()
    {
        try
        {
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Donation_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Mode", "GET_RECEIVE_ALL");
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rdr);
            con.Close();
            if (dt.Rows.Count > 0)
            {
                GV_Receive_List.DataSource = dt;
                GV_Receive_List.DataBind();
            }
            else
            {
                GV_Receive_List.DataSource = null;
                GV_Receive_List.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void GV_Receive_List_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_Receive_List.PageIndex = e.NewPageIndex;
        GetReceiveList();
    }
    protected void GV_Receive_List_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblStatus = e.Row.FindControl("lblStatus") as Label;
            Label lblGetAmount = e.Row.FindControl("lblGetAmount") as Label;
            string status = lblStatus.Text;
            if (status == "Completed")
            {
                e.Row.Cells[4].Text = lblGetAmount.Text;
            }
            else
            {
                e.Row.Cells[4].Text = "0";
            }
        }
    }
    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GetHelp.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GV_Receive_List.AllowPaging = false;
                GetReceiveList();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GV_Receive_List.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GV_Receive_List.HeaderRow.Cells)
                {
                    cell.BackColor = GV_Receive_List.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GV_Receive_List.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GV_Receive_List.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GV_Receive_List.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GV_Receive_List.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    protected override void InitializeCulture()
    {
        CultureInfo ci = new CultureInfo("en-IN");
        ci.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = ci;
        base.InitializeCulture();
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }

}