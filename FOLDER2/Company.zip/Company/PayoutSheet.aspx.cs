﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;
using System.Web.Script.Serialization;
using System.Drawing;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;


public partial class Company_PayoutSheet : System.Web.UI.Page
{

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                ShowPayout();
                btnexcel.Visible = false;
                btnpdf.Visible = false;
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void ShowPayout()
    {
        try
        {
            drppayout.DataTextField = "PayoutBetween";
            drppayout.DataValueField = "PayoutBetween";
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select DISTINCT PayoutBetween,max(Date) from MemberPayment group by PayoutBetween order by max(Date)");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                drppayout.DataSource = dt;
                drppayout.DataBind();
                drppayout.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select Payout Date", "0"));
            }
            else
            {
                drppayout.DataSource = null;
                drppayout.DataBind();
                drppayout.Items.Insert(0, new System.Web.UI.WebControls.ListItem("Select Payout Date", "0"));
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    public void ShowPayoutSheet()
    {
        try
        {
           DAL dal = new DAL();
           StringBuilder sb = new StringBuilder();
           sb.AppendFormat("select MR.UserID, MR.Name, BP.PaymentID, BP.Reward, BP.PayoutPair, BP.PayoutAmount, BP.AdminCharge, BP.TDS, BP.NetAmount,BP.Descriptions, BP.PaymentStatus, BP.PaymentMode, BP.ReferenceNo, convert(nvarchar(10), BP.PaymentGenrateDate, 103) as PaymentGenrateDate, convert(nvarchar(10), BP.PaymentReleaseDate, 103) as PaymentDate, MLU.PayeeName, MLU.BankName, MLU.AccountNo, MLU.IFSCCode, MLU.PANNO, MLU.Paytm from MemberPayment as BP inner join MLM_Registration as MR on BP.UserID = MR.UserID Left join MLM_UserDetail as MLU on MR.UserID = MLU.UserID where   bp.NetAmount!=0  and Bp.PayoutBetween = '{0}'", drppayout.SelectedValue);
           
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                GridView1.AllowPaging = false;
                GridView1.PageSize = dt.Rows.Count;
                btnexcel.Visible = true;
                btnpdf.Visible = true;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnexcel.Visible = false;
                btnpdf.Visible = false;

            }

        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ShowPayoutSheet();
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowPayoutSheet();
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
            GridView1.EditIndex = e.NewEditIndex;
            ShowPayoutSheet();
        
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            string paymentID = GridView1.DataKeys[e.RowIndex].Values["PaymentID"].ToString();
            string paymentstatus = ((DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList1")).SelectedItem.Text;
            string paymentmode = ((DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList2")).SelectedItem.Text;
            string refernceno = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtrefernceno")).Text;
            string paymentDate = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox3")).Text;
            string[] dte = paymentDate.Split('/');
            string finaldate = dte[2] + "/" + dte[1] + "/" + dte[0];
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("update MemberPayment set PaymentStatus='{0}',PaymentMode='{1}',ReferenceNo='{2}',PaymentReleaseDate='{3}' where PaymentID='{4}'", paymentstatus, paymentmode, refernceno, finaldate, paymentID);
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Payment Info Updated')", true);

            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }

        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            GridView1.EditIndex = -1;
            ShowPayoutSheet();
        }

    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex =-1;
        ShowPayoutSheet();
    }

    protected void btnexcel_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
         //   string filename = drppayout.SelectedItem.Text;
            string filename = "PayoutSheet";
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename='"+ filename+"'.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridView1.AllowPaging = false;
                this.ShowPayoutSheet();
                GridView1.HeaderRow.Cells[1].Visible = false;
                GridView1.HeaderRow.Cells[2].Visible = false;
                GridView1.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridView1.HeaderRow.Cells)
                {
                    cell.BackColor = GridView1.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridView1.Rows)
                {
                    row.Cells[1].Visible = false;
                    row.Cells[2].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridView1.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridView1.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridView1.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (Exception)
        {

            throw;
        }
        
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DAL dal = new DAL();
            string userID = e.Row.Cells[7].Text;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", userID);
            DataTable jointype = dal.Gettable(sb.ToString(), ref message);
            

            if (jointype.Rows[0]["JoinType"].ToString() == "Free")
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/orange.svg";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Not Procced";
                e.Row.Cells[2].Enabled = false;
            }
            else if (jointype.Rows[0]["Status"].ToString() == "Inactive")
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/red.png";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Not Procced";
                e.Row.Cells[2].Enabled = false;
            }
            else
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/green.png";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Procced";
                e.Row.Cells[2].Enabled = true;
            }

        }
    }


    //void CreatePdfFile(DataTable PDF)
    //{
    //    string filename = Guid.NewGuid() + ".pdf";
    //    string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);


    //    Document doc = new Document(PageSize.A4, 10, 10, 30, 10);

    //    Paragraph p = new Paragraph("Payout List");
    //    p.Alignment = Element.ALIGN_CENTER;

    //    try
    //    {
    //        PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
    //        PdfPTable pdfPtable = new PdfPTable(11);

    //        pdfPtable.HorizontalAlignment = 1;
    //        pdfPtable.SpacingBefore = 20f;
    //        pdfPtable.SpacingAfter = 20f;

    //        doc.Open();
    //        DataTable dt = PDF;
    //        if (dt != null)
    //        {
    //            //---- Add Result of DataTable to PDF file With Header -----
    //            PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
    //            pdfTable.DefaultCell.Padding = 3;
    //            pdfTable.WidthPercentage = 100; // percentage
    //            pdfTable.DefaultCell.BorderWidth = 2;
    //            pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

    //            foreach (DataColumn column in dt.Columns)
    //            {
    //                pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
    //            }
    //            pdfTable.HeaderRows = 1; // this is the end of the table header
    //            pdfTable.DefaultCell.BorderWidth = 1;

    //            foreach (DataRow row in dt.Rows)
    //            {
    //                foreach (object cell in row.ItemArray)
    //                {
    //                    //assume toString produces valid output
    //                    pdfTable.AddCell(FormatPhrase(cell.ToString()));
    //                }
    //            }
    //            doc.Add(pdfTable);
    //        }

    //        doc.Close();
    //        byte[] content = File.ReadAllBytes(filepath);

    //        HttpContext context = HttpContext.Current;

    //        context.Response.BinaryWrite(content);
    //        context.Response.ContentType = "application/pdf";
    //        context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
    //        context.Response.End();
    //    }
    //    catch (Exception ex)
    //    {

    //    }
    //}
    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }

    protected void btnPdf_Click(object sender, EventArgs e)
    {

        try
        {
            if (Session["UserName"] != null)
            {
                DAL dal = new DAL();
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("select MR.UserID, MR.Name, BP.PaymentID, BP.Reward, BP.PayoutPair, BP.PayoutAmount, BP.AdminCharge, BP.TDS, BP.NetAmount,BP.Descriptions, BP.PaymentStatus, BP.PaymentMode, BP.ReferenceNo, convert(nvarchar(10), BP.PaymentGenrateDate, 103) as PaymentGenrateDate, convert(nvarchar(10), BP.PaymentReleaseDate, 103) as PaymentDate, MLU.PayeeName, MLU.BankName, MLU.AccountNo, MLU.IFSCCode, MLU.PANNO, MLU.Paytm from MemberPayment as BP inner join MLM_Registration as MR on BP.UserID = MR.UserID Left join MLM_UserDetail as MLU on MR.UserID = MLU.UserID where   bp.NetAmount!=0  and Bp.PayoutBetween = '{0}'", drppayout.SelectedValue);
                DataTable dt = dal.Gettable(sb.ToString(), ref message);
                if (dt.Rows.Count > 0)
                {
                    CreatePdfFile(dt);
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }


        }
        catch (Exception ex)
        {
            //ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    void CreatePdfFile(DataTable PDF)
    {
        string filename = "PayoutSheet.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);

        Document doc = new Document(PageSize.A4, 10, 10, 40, 10);

        Paragraph p = new Paragraph("");
        p.Alignment = Element.ALIGN_CENTER;

        try
        {

            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(7);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("Payout Report", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----      
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("../Company/images/Probuzimg.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------


            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "Payout Sheet/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch (Exception ex)
        {

        }
    }

}