﻿using DataAccessLayer;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_ProductDetails : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                if (Session["Message"] != null)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Product Updated Successfully')", true);
                    Session["Message"] = null;
                }
                ProductList();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void ProductList()
    {
        try
        {
            ProductLogic PL = new ProductLogic();
            if (string.IsNullOrEmpty(txtproductname.Text))
            {
                DataTable dt = PL.FetchProduct(ref message);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                   // btnexport.Visible = true;
                }
                else
                {
                    GridView1.DataSource = null;
                    GridView1.DataBind();
                    btnexport.Visible = false;
                }
            }
            else
            {
                ProductProperty PP = new ProductProperty { ProductName = txtproductname.Text };
                DataTable dt = PL.SearchProduct(PP, ref message);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    btnexport.Visible = true;
                }
                else
                {
                    GridView1.DataSource = null;
                    GridView1.DataBind();
                    btnexport.Visible = false;
                }
            }

        }
        catch (Exception ex)
        {

            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ProductList();
    }
    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> getproductname(string prefixText)
    {
        List<string> name = new List<string>();
        DAL dal = new DAL();
        string message = string.Empty;
        try
        {
            StringBuilder sbb = new StringBuilder();
            sbb.AppendFormat("select ProductName from Product where ProductName like'{0}%'", prefixText);

            DataTable dt = dal.Gettable(sbb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    name.Add(dt.Rows[i][0].ToString());
                }

            }
        }

        catch (Exception)
        {
            throw;
        }
        return name;
    }
    protected void btnexport_Click(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=ProductList.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        StringWriter sw = new StringWriter();
        
            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            //GridView1.AllowPaging = false;
            //this.ProductList();
            //GridView1.HeaderRow.Cells[0].Visible = false;
            //GridView1.HeaderRow.Cells[1].Visible = false;
            //GridView1.HeaderRow.BackColor = Color.White;
            //foreach (TableCell cell in GridView1.HeaderRow.Cells)
            //{
            //    cell.BackColor = GridView1.HeaderStyle.BackColor;
            //}
            //foreach (GridViewRow row in GridView1.Rows)
            //{
            //    row.Cells[0].Visible = false;
            //    row.Cells[1].Visible = false;
            //    row.BackColor = Color.White;
            //    foreach (TableCell cell in row.Cells)
            //    {
            //        if (row.RowIndex % 2 == 0)
            //        {
            //            cell.BackColor = GridView1.AlternatingRowStyle.BackColor;
            //        }
            //        else
            //        {
            //            cell.BackColor = GridView1.RowStyle.BackColor;
            //        }
            //        cell.CssClass = "textmode";
            //    }
            //}

            GridView1.RenderControl(hw);
        Response.Write(sw.ToString());

            ////style to format numbers to string
            //string style = @"<style> .textmode { } </style>";
            //Response.Write(style);
            //Response.Output.Write(sw.ToString());
            //Response.Flush();
            Response.End();
        
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ProductList();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            ProductProperty PP = new ProductProperty { ProductCode = GridView1.DataKeys[e.RowIndex].Values["ProductCode"].ToString() };
            ProductLogic PL = new ProductLogic();
            int rowaffected = PL.Deleteproduct(PP, ref message);
            if (rowaffected > 0)
            {
                ProductList();
                var errormessage = new JavaScriptSerializer().Serialize("Product Deleted Successfully.");
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
            else
            {
                var errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }
        catch (Exception ex)
        {

            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string productcode = GridView1.SelectedRow.Cells[3].Text;
        Helper hlp = new Helper();
        Response.Redirect("Product.aspx?ProductCode=" + HttpUtility.UrlEncode(hlp.Encrypt(productcode)));
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "viewdetail")
        {
            string productcode = e.CommandArgument.ToString();
            Response.Redirect("Stock.aspx?ProductCode=" + productcode, false);
        }
        else
        {
            return;
        }
    }

    protected void btnexportPDF_Click(object sender, EventArgs e)
    { 
        ProductLogic PL = new ProductLogic();
            DataTable dt = PL.FetchProduct(ref message);
            if (dt.Rows.Count > 0)
            {
            CreatePdfFile(dt);
                // btnexport.Visible = true;
            }
        }

    void CreatePdfFile(DataTable PDF)
    {
        string filename = "ProductList.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);


        Document doc = new Document(PageSize.A4, 10, 10, 10, 10);

        Paragraph p = new Paragraph("");
        p.Alignment = Element.ALIGN_CENTER;

        try
        {
            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(11);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("Product List", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("images/Probuzimg.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------

            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "application/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch
        {

        }
    }
    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }
}