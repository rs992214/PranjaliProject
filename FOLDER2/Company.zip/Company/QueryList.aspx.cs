﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_QueryList : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string loginip = GetLocalIPAddress();
    string UserName = "";
    string password1 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        GetLocalIPAddress();
        AdminLoginInfo();
        if (!IsPostBack)
        {
            GetData();
        }
    }
    private void GetData()
    {
        try
        {
            DataTable dt = dal.Gettable("Select ID,hd.UserID,Query,hd.Status,hd.Response,CONVERT(nvarchar,Date,105)As Date,mr.Name From Helpdesk hd left join MLM_Registration mr on mr.UserID=hd.UserID order by ID desc", ref message);
            if (dt.Rows.Count > 0)
            {
                gdvQuery.DataSource = dt;
                gdvQuery.DataBind();
            }
            else
            {
                gdvQuery.DataSource = dt;
                gdvQuery.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void gdvQuery_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvQuery.PageIndex = e.NewPageIndex;
    GetData();
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            int flag = dal.Executequery("delete from Helpdesk where ID='" + ID + "'", ref message);
            if (flag > 0)
            {
                GetData();
                ShowPopupMessage("Record has been Deleted Successfully.", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage(message, PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void rdoStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        RadioButtonList btnButton = sender as RadioButtonList;
        GridViewRow gvRow = (GridViewRow)btnButton.NamingContainer;
        Label lbl = (Label)gvRow.FindControl("lblid");
        string id = lbl.Text;
        RadioButtonList rbl = (RadioButtonList)sender;
        string status = rbl.SelectedItem.Text;
        try
        {
            int flag = dal.Executequery("UPDATE Helpdesk SET Status='" + status + "' WHERE ID='" + id + "'", ref message);
            if (flag > 0)
            {
                ShowPopupMessage("Request has been " + status + ".", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage(message, PopupMessageType.Error);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void gdvQuery_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string gdr = DataBinder.Eval(e.Row.DataItem, "Status").ToString();
            RadioButtonList rb11 = (RadioButtonList)e.Row.FindControl("rdoStatus");
            rb11.Items.FindByText(gdr).Selected = true;
        }
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/Red_Cross_Tick.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void btnreply_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)(sender);
        string id = btn.CommandArgument;
        try
        {
            Response.Redirect("QueryReply.aspx?ID=" + id);
        }
        catch (Exception ex)
        {
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            string error = ex.ToString();
            try
            {


                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Error: "+error+" ')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

        }
    }
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName = dt.Rows[0]["UserName"].ToString();
                password1 = dt.Rows[0]["password"].ToString();

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
}