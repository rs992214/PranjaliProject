﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;

public partial class Company_sms_master_s : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
   
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserName"] != null)
                {
                   // Getdata();
                  
                    SMSMATER();

                }
                else
                {
                    Response.Redirect("Logout.aspx");
                }
            }

        }

    protected void Button1_Click(object sender, EventArgs e)
    {
       
            string status = string.Empty;
            if (RadioButton2.Checked == true)
            {
                status = RadioButton2.Text;
            }
            else
            {
                status = RadioButton1.Text;
            }

            StringBuilder sb = new StringBuilder();
              sb.AppendLine("insert into Smsmaster(Status,api_key,url,sender)");
               sb.AppendFormat("values('{0}','{1}','{2}','{3}')", status, txtApikeys.Text, txtApiurl.Text, txtSender.Text);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('SMS Configured Successfully')", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Oops!Some Error Occur.Try After Some Time.')", true);
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {

            GridView1.DataBind();

            SMSMATER();

        }

        }



        protected void SMSMATER()
        {
            DataTable dt = dal.Gettable("select SrNo,Status,api_key,url,sender from Smsmaster", ref message);
            if (dt.Rows.Count > 0)
            {
              txtApiurl.Text = dt.Rows[0]["url"].ToString();
               txtApikeys.Text = dt.Rows[0]["api_key"].ToString();
             txtSender.Text = dt.Rows[0]["sender"].ToString();
            string status = dt.Rows[0]["Status"].ToString();
             

            }
        }


        protected void Getdata()
        {
            DataTable dt = dal.Gettable("select Srno,Status,api_key,url,sender from Smsmaster", ref message);
            if (dt.Rows.Count > 0)
            {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        }
    }