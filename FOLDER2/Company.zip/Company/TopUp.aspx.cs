﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;
using System.Web.Script.Serialization;

public partial class Company_TopUp : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if(!string.IsNullOrEmpty(Request.QueryString["ID"]))
            {
                Showpackageinfo();
                ViewState["ID"] = Request.QueryString["ID"].ToString();
                ShowMemberInfo();
            }
            else
            {
                Response.Redirect("BBOList.aspx");
            }
            
        }
    }

    private void Showpackageinfo()
    {
        try
        {
            DDLPlan.DataTextField = "PackageInfo";
            DDLPlan.DataValueField = "PackageName";
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat(" select ID,CONCAT(PackageName,'-',Amount) as PackageInfo,PackageName,Amount from PackageInfo order by PackageName");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                DDLPlan.DataSource = dt;
                DDLPlan.DataBind();
                DDLPlan.Items.Insert(0, new ListItem("Select Plan", "0"));

            }
            else
            {
                DDLPlan.DataSource = null;
                DDLPlan.DataBind();
                DDLPlan.Items.Insert(0, new ListItem("Select Plan", "0"));
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    private void ShowMemberInfo()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select MR.UserID,MR.Name,Pack.PackageName from MLM_Registration as MR left join PackageInfo as Pack on MR.Package = Pack.PackageName where MR.UserID = '{0}'", ViewState["ID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                txtmemberaccount.Text = dt.Rows[0]["UserID"].ToString();
                txtmembername.Text= dt.Rows[0]["Name"].ToString();
                if (!string.IsNullOrEmpty(dt.Rows[0]["PackageName"].ToString()))
                {
                    DDLPlan.ClearSelection();
                    DDLPlan.Items.FindByValue(dt.Rows[0]["PackageName"].ToString()).Selected=true;
                    DDLPlan.Enabled = false;
                    btnupdatepackage.Enabled = false;
                }
                else
                {
                    DDLPlan.Enabled = true;
                    btnupdatepackage.Enabled = true;
                }
                
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnupdatepackage_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("update MLM_Registration set JoinType='Paid',Package='{0}',PackageDate='{1}' where UserID='{2}'", DDLPlan.SelectedValue,System.DateTime.Now.ToString("yyyy-MM-dd"), ViewState["ID"].ToString());
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Package Updated Successfully')", true);
                ShowMemberInfo();
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
           
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
}