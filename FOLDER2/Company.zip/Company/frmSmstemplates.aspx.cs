﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Script.Serialization;
using DataAccessLayer;
using System.Text;

public partial class frmSmstemplates : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if(Session["UserName"]!=null)
            {

            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void addsmstemp()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Insert into Template(Template)");
            sb.AppendFormat("Values('{0}')", txtMsg.Text);
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected>0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Template Add Successfully')", true);
            }
        }
        catch (Exception ex)
        {
            var message = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", message);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }

        finally
        {
            txtMsg.Text = null;
            GridView1.DataBind();
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        addsmstemp();
    }
}