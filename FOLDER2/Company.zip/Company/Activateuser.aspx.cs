﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;

public partial class Company_Activateuser : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            clear();
            lbltimer.Text = DateTime.Now.ToString("hh:mm:ss tt");
            timer();
        }
    }

    protected void GetTime(object sender, EventArgs e)
    {
        lbltimer.Text = DateTime.Now.ToString("hh:mm:ss tt");
    }

    private void timer()
    {

        DateTime timer = Convert.ToDateTime(lbltimer.Text);
        System.DateTime moment = timer;
        int hour = moment.Hour;
        if (hour == 23)
        {
            btnsave.Visible = false;
            //btnCancel.Visible = false;
            txtuserid.ReadOnly = true;
            drplpackage.Enabled = true;
            spnote.Visible = true;
            lblmassage.Visible = true;
            lblmassage.Text = "System Is in Calculation Mode Hence Do Not Activate ID 11:00 PM - 12:10 AM";
            
        }


    }

    public void clear()
    {
        btnsave.Enabled = false;
        txtuserid.Text = string.Empty;
        drplpackage.SelectedValue = "0";
        lblname.Text = string.Empty;
        Label1.Text = string.Empty;
        lblusername.Text = string.Empty;


    }

    protected void txtuserid_TextChanged(object sender, EventArgs e)
    {
        try
        {
            string UserID = txtuserid.Text;
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Name from MLM_Registration where JoinType='Free' and UserID='" + UserID + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                   lblusername.Text = dt.Rows[0]["Name"].ToString();
                   btnsave.Enabled = true;
                   dropdown();

            }
            else
            {
               
                ShowPopupMessage("Incorrect User ID", PopupMessageType.Warning);

            }

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }


    public void dropdown()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand com = new SqlCommand("Select ID,PackageName from PackageInfo", con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable ds = new DataTable();
        da.Fill(ds);
        drplpackage.DataTextField = "PackageName";
        drplpackage.DataValueField = "ID";
        drplpackage.DataSource = ds;
        drplpackage.DataBind();
        drplpackage.Items.Insert(0, new ListItem("--Select Package--", "0"));
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void drplpackage_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblname.Text = drplpackage.SelectedItem.Value;

        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select Amount from PackageInfo where ID='" + lblname.Text + "'", ref message);
        if (dt.Rows.Count > 0)
        {
            Label1.Text = dt.Rows[0]["Amount"].ToString();
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        if(drplpackage.SelectedItem.Value!="0")
        { 
              con = new SqlConnection(connstring);
              con.Open();
              cmd = new SqlCommand("USSERUPDATE_ALL", con);
              cmd.CommandType = CommandType.StoredProcedure;
              cmd.Parameters.AddWithValue("@UserID", txtuserid.Text);
              cmd.Parameters.AddWithValue("@PackageName", drplpackage.SelectedItem.Text);
              cmd.Parameters.AddWithValue("@Mode", "UPD_STATUS");
              int flag = cmd.ExecuteNonQuery();
              if (flag > 0)
              {
                      LedgerCredit();
                      LedgerDebit();
                      clear();
                      ShowPopupMessage("User Activated Sucessfull", PopupMessageType.Success);
                      
                     


              }
        }
        else
        {
            //ShowPopupMessage("Please Select Package", PopupMessageType.Warning);
        }
    }

    private void LedgerCredit()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtuserid.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", Label1.Text);
        cmd.Parameters.AddWithValue("@DR", 0);
        cmd.Parameters.AddWithValue("@Descriptions", "Current Package Amount!");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
    }
    private void LedgerDebit()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtuserid.Text);
        cmd.Parameters.AddWithValue("@TransactionType", "DR");
        cmd.Parameters.AddWithValue("@CR", 0);
        cmd.Parameters.AddWithValue("@DR", Label1.Text);
        cmd.Parameters.AddWithValue("@Descriptions", "Current Package Amount!");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();
        
    }



    protected void btnOk_Command(object sender, CommandEventArgs e)
    {
            Response.Redirect("Activateuser.aspx", true);
    }
}