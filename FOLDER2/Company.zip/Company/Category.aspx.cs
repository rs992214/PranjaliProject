﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Category : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {

            }
            else
            {
                Response.Redirect("Logout.aspx");

            }
        }

    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        
        try
        {
            CategoryMatserProperty CMP = new CategoryMatserProperty { CategoryName = txtcategory.Text };
            CategoryMaster CM = new CategoryMaster();
            int rowaffected = CM.SaveCategory(CMP, ref message);
            if (rowaffected > 0)
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", "Category Save Successfully.");
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
              
            }
            else
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", message);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
            }
        }
        catch (Exception ex)
        {
            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        txtcategory.Text = null;
    }
}