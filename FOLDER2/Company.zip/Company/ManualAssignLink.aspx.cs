﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_ManualAssignLink : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    string ph_userid = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            if (Session["UserName"] != null)
            {
                showsmssender();
                ShowGHMemberDetail();
                ShowPHMemberDetail();
                DisplayTotalAmount();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void showsmssender()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from Smsmaster", ref message);
            if (dt.Rows.Count > 0)
            {
                userid = dt.Rows[0]["Userid"].ToString();
                password = dt.Rows[0]["Password"].ToString();
                senderid = dt.Rows[0]["Senderid"].ToString();
                route = dt.Rows[0]["Routeid"].ToString();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowGHMemberDetail()
    {
        try
        {
            DataTable dt = dal.Gettable("select gh.ID,gh.UserID,mr.Name,Amount,gh.Date from GetHelp gh inner join MLM_Registration mr on gh.UserID=mr.UserID where mr.IsBlock='No' order by id desc", ref message);
            if (dt.Rows.Count > 0)
            {
                gdvGet.DataSource = dt;
                gdvGet.DataBind();
            }
            else
            {
                gdvGet.DataSource = dt;
                gdvGet.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowPHMemberDetail()
    {
        try
        {
            DataTable dt = dal.Gettable("select ph.ID,ph.UserID,mr.Name,Amount,ph.Date from ProvideHelp ph inner join MLM_Registration mr on ph.UserID=mr.UserID where mr.IsBlock='No'  order by id asc", ref message);
            if (dt.Rows.Count > 0)
            {
                gdvProvide.DataSource = dt;
                gdvProvide.DataBind();
            }
            else
            {
                gdvProvide.DataSource = dt;
                gdvProvide.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void DisplayTotalAmount()
    {
        decimal total_gh = 0; decimal total_ph = 0;
        for (int i = 0; i < gdvGet.Rows.Count; i++)
        {
            total_gh += Convert.ToDecimal(gdvGet.Rows[i].Cells[4].Text);
        }
        for (int j = 0; j < gdvProvide.Rows.Count; j++)
        {
            total_ph += Convert.ToDecimal(gdvProvide.Rows[j].Cells[5].Text);
        }
        lblTotalAmount_GH.Text = total_gh.ToString();
        lblTotalAmount_PH.Text = total_ph.ToString();
    }
    decimal totselect_gh = 0; decimal totselect_ph = 0;
    protected void chkGet_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow rowgh in gdvGet.Rows)
            {
                if (rowgh.RowType == DataControlRowType.DataRow)
                {
                    RadioButton get = (RadioButton)rowgh.FindControl("chkGet");
                    if (get.Checked == true)
                    {
                        totselect_gh = totselect_gh + Convert.ToDecimal(rowgh.Cells[4].Text);
                        lblSelectedAmount_GH.Text = totselect_gh.ToString();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void chkProvide_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            //decimal bal = 0;
            //decimal TSA = Convert.ToDecimal(lblSelectedAmount_GH.Text);
            foreach (GridViewRow rowph in gdvProvide.Rows)
            {
                if (rowph.RowType == DataControlRowType.DataRow)
                {
                    CheckBox provide = (CheckBox)rowph.FindControl("chkProvide");
                    if (provide.Checked == true)
                    {
                        //TextBox txtAmount = (TextBox)rowph.FindControl("txtAmount");
                        decimal tsa_ph = Convert.ToDecimal(lblSelectedAmount_PH.Text);
                        decimal tsa_gh = Convert.ToDecimal(lblSelectedAmount_GH.Text);
                        if (tsa_ph == tsa_gh)
                        {
                            gdvProvide.Enabled = false;
                            break;
                        }
                        else
                        {
                            ShowPopupMessage("Please Enter Link Amount!", PopupMessageType.Message);
                        }
                        //totselect_ph = totselect_ph + Convert.ToDecimal(rowph.Cells[5].Text);
                        //lblSelectedAmount_PH.Text = totselect_ph.ToString();
                        //rowph.Cells[6].Text = rowph.Cells[5].Text;
                        //    if (TSA == Convert.ToDecimal(rowph.Cells[5].Text))
                        //    {
                        //        rowph.Cells[6].Text = rowph.Cells[5].Text;
                        //        bal = TSA - Convert.ToDecimal(rowph.Cells[6].Text);
                        //        provide.Enabled = false;
                        //    }
                        //    else if (TSA != Convert.ToDecimal(rowph.Cells[5].Text))
                        //    {
                        //        rowph.Cells[6].Text = rowph.Cells[5].Text;
                        //        bal = TSA - Convert.ToDecimal(rowph.Cells[6].Text);
                        //        provide.Enabled = true;
                        //    }
                        //    else if (bal == 0)
                        //    {
                        //        provide.Enabled = false;
                        //    }
                    }
                }
            }

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void txtAmount_TextChanged(object sender, EventArgs e)
    {
        decimal tsa_ph = 0;
        decimal tsa_gh = 0;
        decimal balance = 0;
        foreach (GridViewRow rowph in gdvProvide.Rows)
        {
            if (rowph.RowType == DataControlRowType.DataRow)
            {
                CheckBox provide = (CheckBox)rowph.FindControl("chkProvide");
                if (provide.Checked == true)
                {
                    TextBox txtAmount = (TextBox)rowph.FindControl("txtAmount");
                    tsa_gh = Convert.ToDecimal(lblSelectedAmount_GH.Text);
                    if (Convert.ToDecimal(txtAmount.Text) <= tsa_gh)
                    {
                        totselect_ph = totselect_ph + Convert.ToDecimal(txtAmount.Text);
                        tsa_ph = totselect_ph;
                        if (tsa_ph == tsa_gh)
                        {
                            lblSelectedAmount_PH.Text = totselect_ph.ToString();
                            balance = tsa_gh - totselect_ph;
                            lblBalance_PH.Text = balance.ToString();
                            provide.Enabled = false;
                            lnkAssign.Enabled = true;
                            break;
                        }
                        else
                        {
                            balance = tsa_gh - totselect_ph;
                            if (Convert.ToDecimal(txtAmount.Text) == balance)
                            {
                                lblSelectedAmount_PH.Text = totselect_ph.ToString();
                                lblBalance_PH.Text = balance.ToString();
                                provide.Enabled = false;
                                lnkAssign.Enabled = true;
                            }
                            else if (Convert.ToDecimal(txtAmount.Text) < tsa_gh) //balance
                            {
                                lblSelectedAmount_PH.Text = totselect_ph.ToString();
                                lblBalance_PH.Text = balance.ToString();
                                lnkAssign.Enabled = true;
                                break;
                            }
                            else
                            {
                                txtAmount.Text = string.Empty;
                                ShowPopupMessage("Amount should be less than or equal to Balance Amount!", PopupMessageType.Message);
                                lnkAssign.Enabled = false;
                                break;
                            }
                        }
                    }
                    else
                    {
                        txtAmount.Text = string.Empty;
                        lnkAssign.Enabled = false;
                        ShowPopupMessage("Amount should be less than or equal to Total Selected GH Amount!", PopupMessageType.Message);
                    }
                }
            }
        }
    }
    protected void lnkAssign_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(connstring);
        con.Open();
        lnkAssign.Enabled = false;
        try
        {
            if (Convert.ToDecimal(lblSelectedAmount_GH.Text) >= Convert.ToDecimal(lblSelectedAmount_PH.Text))
            {
                string ghid = string.Empty;
                foreach (GridViewRow rowgh in gdvGet.Rows)
                {
                    if (rowgh.RowType == DataControlRowType.DataRow)
                    {
                        RadioButton get = (RadioButton)rowgh.FindControl("chkGet");
                        if (get.Checked == true)
                        {
                            foreach (GridViewRow rowph in gdvProvide.Rows)
                            {
                                if (rowph.RowType == DataControlRowType.DataRow)
                                {
                                    CheckBox provide = (CheckBox)rowph.FindControl("chkProvide");
                                    TextBox txtAmount = (TextBox)rowph.FindControl("txtAmount");
                                    if (provide.Checked == true && !string.IsNullOrEmpty(txtAmount.Text))
                                    {
                                        cmd = new SqlCommand("Donation_ALL", con);
                                        cmd.CommandType = CommandType.StoredProcedure;
                                        cmd.Parameters.AddWithValue("@PayAmount", txtAmount.Text);
                                        cmd.Parameters.AddWithValue("@GetAmount", rowph.Cells[5].Text);
                                        cmd.Parameters.AddWithValue("@GH_ID", rowgh.Cells[1].Text);
                                        cmd.Parameters.AddWithValue("@PH_ID", rowph.Cells[2].Text);
                                        cmd.Parameters.AddWithValue("@Mode", "IN");
                                        int flag = cmd.ExecuteNonQuery();
                                        if (flag > 0)
                                        {
                                            SendMsgToPH(rowph.Cells[2].Text, rowgh.Cells[1].Text, Convert.ToDecimal(txtAmount.Text));
                                            SendMsgToGH(rowgh.Cells[1].Text, rowph.Cells[2].Text, Convert.ToDecimal(txtAmount.Text));
                                            ShowPopupMessage("Links are Assigned Successfully!", PopupMessageType.Success);
                                            Label lblghid = (Label)rowgh.FindControl("lblghid");
                                            ghid = lblghid.Text;
                                            Label lblphid = (Label)rowph.FindControl("lblphid");
                                            //to remains ph user present
                                            decimal totamount = Convert.ToDecimal(rowph.Cells[5].Text);
                                            decimal linkamount = Convert.ToDecimal(txtAmount.Text);
                                            if (totamount != linkamount)
                                            {
                                                if (totamount > linkamount)
                                                {
                                                    int updateph = dal.Executequery("update ProvideHelp set Amount='" + (totamount - linkamount).ToString() + "' where ID='" + lblphid.Text + "'", ref message);
                                                }
                                            }
                                            else
                                            {
                                                int deleteph = dal.Executequery("delete from ProvideHelp where ID='" + lblphid.Text + "'", ref message);
                                            }
                                        }
                                        else
                                        {
                                            ShowPopupMessage("Failed!", PopupMessageType.Error);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                //to remains gh user present
                decimal gh_tsa = Convert.ToDecimal(lblSelectedAmount_GH.Text);
                decimal ph_tsa = Convert.ToDecimal(lblSelectedAmount_PH.Text);
                if (gh_tsa != ph_tsa)
                {
                    if (gh_tsa > ph_tsa)
                    {
                        int updategh = dal.Executequery("update GetHelp set Amount='" + (gh_tsa - ph_tsa).ToString() + "' where ID='" + ghid + "'", ref message);
                    }
                }
                else
                {
                    int deletegh = dal.Executequery("delete from GetHelp where ID='" + ghid + "'", ref message);
                }
            }
            else
            {
                ShowPopupMessage("Get Help Amount and Provide Help Amount must be Equal!", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        finally
        {
            con.Close();
            ShowGHMemberDetail();
            ShowPHMemberDetail();
            DisplayTotalAmount();
            gdvProvide.Enabled = true;
            lblSelectedAmount_GH.Text = string.Empty;
            lblSelectedAmount_PH.Text = string.Empty;
            lnkAssign.Enabled = true;

          //  Response.Redirect("ManualAssignLink.aspx");

        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect("ManualAssignLink.aspx");
    }
    public void SendMsgToPH(string ph_userid, string gh_userid, decimal amount )
    {
        object phmobno = dal.Getscalar("select Mobile from MLM_Registration where UserID='" + ph_userid + "'", ref message);


        DataTable dt = dal.Gettable("select TOP 1 ph.ID,ph.PH_ID,ph.GH_ID,(select mobile from MLM_Registration  where  UserID = ph.GH_ID) As Mobile ,GetAmount from Donation ph inner join MLM_Registration mr on ph.PH_ID = mr.UserID where mr.UserID ='" + ph_userid + "'", ref message);

        DataTable dt1 = dal.Gettable("select TOP 1 ph.ID,ph.PH_ID,ph.GH_ID,(select UserID from MLM_Registration  where  UserID = ph.GH_ID) As ghid ,GetAmount from Donation ph inner join MLM_Registration mr on ph.PH_ID = mr.UserID where mr.UserID ='" + ph_userid + "'", ref message);
        DataTable dt2 = dal.Gettable("select TOP 1 ph.ID,ph.PH_ID,ph.GH_ID,(select Name from MLM_Registration  where  UserID = ph.PH_ID) As Name ,GetAmount from Donation ph inner join MLM_Registration mr on ph.PH_ID = mr.UserID where mr.UserID ='" + ph_userid + "'", ref message);

        DataTable dt5 = dal.Gettable("select website from CompanyInfo", ref message);
        string ghMobile = dt.Rows[0]["Mobile"].ToString();
        string ghid = dt1.Rows[0]["ghid"].ToString();
        string phname = dt2.Rows[0]["Name"].ToString();
        string website = dt5.Rows[0]["website"].ToString();
        ///end  of phcode 





        // Name '"+ name + "' Mobile '"+ Mobile + "'
        if (dt != null)
        {
            // string text = "Dear '" + phname + "' Please pay help of Rs'" + amount + "' to '" + ghid + "' Mobile '" + ghMobile + "'.For Details Plz visit '"+ website + "' ";
            string text = "Dear '" + phname + "' Please Pay Help To '" + ghid + "' Mobile '" + ghMobile + "'.For Details Plz visit '"+ website + "'";


            // string text = "Dear Donor Please pay help of Rs'" + amount + "' to   Mobile '" + ghMobile + "'.For Details Plz visit \n";


            try
            {
                string sURL;
                StreamReader objReader;
                sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userid + "&password=" + password + "&sender=" + senderid + "&to=" + phmobno + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + route + "";
                WebRequest wrGETURL;
                wrGETURL = WebRequest.Create(sURL);
                try
                {
                    Stream objStream;
                    objStream = wrGETURL.GetResponse().GetResponseStream();
                    objReader = new StreamReader(objStream);
                    objReader.Close();
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
    public void SendMsgToGH(string gh_userid, string ph_userid, decimal amount)
    {

        object phmobno2 = dal.Getscalar("select Mobile from MLM_Registration where UserID='" + ph_userid + "'", ref message);

        DataTable dt2 = dal.Gettable("select TOP 1 ph.ID,ph.PH_ID,ph.GH_ID,(select mobile from MLM_Registration  where  UserID = ph.GH_ID) As Mobile ,GetAmount from Donation ph inner join MLM_Registration mr on ph.PH_ID = mr.UserID where mr.UserID ='" + ph_userid + "'", ref message);


        DataTable dt3 = dal.Gettable("select TOP 1 ph.ID,ph.PH_ID,ph.GH_ID,(select Name from MLM_Registration  where  UserID = ph.GH_ID) As Ghname ,GetAmount from Donation ph inner join MLM_Registration mr on ph.PH_ID = mr.UserID where mr.UserID ='" + ph_userid + "'", ref message);

        DataTable dt4 = dal.Gettable("select TOP 1 ph.ID,ph.PH_ID,ph.GH_ID,(select UserID from MLM_Registration  where  UserID = ph.PH_ID) As phsid ,GetAmount from Donation ph inner join MLM_Registration mr on ph.PH_ID = mr.UserID where ph.PH_ID ='" + ph_userid + "'", ref message);

        DataTable dt5 = dal.Gettable("select website from CompanyInfo", ref message);


        string phMobile = dt2.Rows[0]["Mobile"].ToString();
        string phName = dt3.Rows[0]["Ghname"].ToString();
        string phsid = dt4.Rows[0]["phsid"].ToString();

        string website = dt5.Rows[0]["website"].ToString();




        if (phMobile != null)
        {
            // string text = "Dear Donor,Get Help from '"+ phName + "' Mobile '"+ phmobno2 + "' of ('" + amount + "') from  Donor.Thank You.\n";
            // string text = "Dear Donor,Get Help of ('" + amount + "') and Mobile '"+ phMobile + "' from  Donor.Thank You.\n";
            // string text = "Dear '" + phName + "' YOU ARE ELIGIBLE TO GET HELP OF '" + amount + "'INR,HIS MOBILE NUMBER IS'" + phmobno2 + "' AND CUSTOMER ID IS '" + phsid + "' visit '"+ website + "' ";
            string text = "Dear '" + phName + "' YOU ARE ELIGIBLE TO GET HELP,HIS MOBILE NUMBER IS'" + phmobno2 + "' AND CUSTOMER ID IS '" + phsid + "' visit '"+ website + "' ";


            try
            {
                string sURL;
                StreamReader objReader;
                sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userid + "&password=" + password + "&sender=" + senderid + "&to=" + phMobile + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + route + "";
                WebRequest wrGETURL;
                wrGETURL = WebRequest.Create(sURL);
                try
                {
                    Stream objStream;
                    objStream = wrGETURL.GetResponse().GetResponseStream();
                    objReader = new StreamReader(objStream);
                    objReader.Close();
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            catch (Exception)
            {
                throw;
            }
        
    }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here    

    protected void gdvGet_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvGet.PageIndex = e.NewPageIndex;
        ShowGHMemberDetail();
    }

    protected void gdvProvide_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvProvide.PageIndex = e.NewPageIndex;
        ShowPHMemberDetail();
    }
}