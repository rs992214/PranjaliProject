﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_UserDetail : System.Web.UI.Page
{
    string message = string.Empty;
    string loginip = GetLocalIPAddress();
    string UserName1 = "";
    string password1 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        AdminLoginInfo();
        GetLocalIPAddress();

        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                //  ShowStateName();
                //drpcity.Items.Insert(0, new ListItem("Select District", "0"));
                ShowCountry();

                if (!string.IsNullOrEmpty(Request.QueryString["AccountNo"]))
                {
                    ViewState["AccountNo"] = Request.QueryString["AccountNo"].ToString();
                    ShowUserDetail();
                    kycupdate();
                    statuskyc();
                }
                else
                {
                    Response.Redirect("BBOList.aspx");
                }
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void ShowCountry()
    {
      DAL  dal = new DAL();
        DataTable dt = dal.Gettable("select * from [dbo].[CountryMaster]", ref message);
        if (dt.Rows.Count > 0)
        {
            ddlCountry.DataSource = dt;
            ddlCountry.DataTextField = "Name";
            ddlCountry.DataValueField = "ID";
            ddlCountry.DataBind();
            ddlCountry.Items.Insert(0, new ListItem("--Select Country--", "0"));
        }
        else
        {

        }
    }

    public void ShowStateName()
    {
        drpstate.DataTextField = "StateName";
        drpstate.DataValueField = "StateID";
        // State St = new State();
        DAL dal = new DAL();
        DataTable dt = dal.Gettable("Select StateID,StateName from [State] where CountryID=" + ddlCountry.SelectedValue, ref message);
        //  DataTable dt = St.GetData(ref message);
        if (dt.Rows.Count > 0)
        {
            drpstate.DataSource = dt;
            drpstate.DataBind();
            drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));

        }
        else
        {
            drpstate.DataSource = null;
            drpstate.DataBind();
            drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));
        }
    }

    public void statuskyc()
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            DataTable dt1 = dal.Gettable("Select KYC from MLM_UserDetail where UserID='" + userID.ToString() + "'", ref message);
            if(dt1.Rows.Count>0)
            {
                string status = dt1.Rows[0]["KYC"].ToString();
                if(status=="Yes")
                {
                    span10.Visible = true;
                    span9.Visible = false;
                    btnKYC.Visible = false;
                }
                else
                {
                    span9.Visible = true;
                    btnKYC.Visible = true;

                }
            }


        }
        catch(Exception ex)
        {

        }
    }
    public void kycupdate()
    {
        MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = ViewState["AccountNo"].ToString() };
        MLMUserDetailLogic MDL = new MLMUserDetailLogic();
        DataTable dt = MDL.UserDetail(MDP, ref message);
        if (dt.Rows.Count > 0)
        {
            string validate = dt.Rows[0]["AddressProofvalue"].ToString();
            string validate1 = dt.Rows[0]["Address2value"].ToString();
            string validate2 = dt.Rows[0]["IdentityProofvalue"].ToString();
            string validate3 = dt.Rows[0]["BankProofvalue"].ToString();
            if ( validate2 == "1")//validate == "1" && validate1=="1" && validate3 == "1"
            {
                btnKYC.Enabled = true;
            }
            else
            {
                btnKYC.Enabled = false;
            }
            
        }
    }

    public void ShowCityName()
    {

        drpcity.DataTextField = "CityName";
        drpcity.DataValueField = "CityID";
        CityProperty Cp = new CityProperty();
        Cp.StateID = Convert.ToInt32(drpstate.SelectedValue);
        try
        {
            City cty = new City();
            DataTable dt = cty.GetData(Cp, ref message);
            if (dt.Rows.Count > 0)
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
            }
            else
            {
                drpcity.DataSource = dt;
                drpcity.DataBind();
                drpcity.Items.Insert(0, new ListItem("Select District", "0"));
            }
        }
        catch (Exception ex)
        {
            string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);

        }
    }
    private void Bind_Country_State_City()
    {
     DAL   dal = new DAL();
        DataTable dt = dal.Gettable("select State,City,CityName,Country,CountryName,Nationality,Address,Telegram,AddressLine2,CityName,StateName,Country,Zipcode from MLM_UserDetail where UserID='" + ViewState["AccountNo"] .ToString()+ "'", ref message);
        if (dt.Rows.Count > 0)
        {
            string CountryID = dt.Rows[0]["Country"].ToString();
            if (!string.IsNullOrEmpty(CountryID))
            {
                ddlCountry.ClearSelection();
                //  drpstate.Items.FindByValue(dt.Rows[0]["State"].ToString()).Selected = true;
                ddlCountry.Items.FindByValue(dt.Rows[0]["Country"].ToString()).Selected = true;
                //  drpstate.Enabled = false;
                //ddlCountry.Enabled = false;
                ShowStateName();
                // ShowCityName();
                //  drpcity.ClearSelection();
                string cityid = dt.Rows[0]["CityName"].ToString();
                if (!string.IsNullOrEmpty(cityid))
                {
                    txtCity.Text = dt.Rows[0]["CityName"].ToString();
                    //  txtCity.Enabled = false;
                    //  drpcity.Items.FindByValue(dt.Rows[0]["CityName"].ToString()).Selected = true;
                    //  drpcity.Enabled = false;
                }
            }

            string Stateid = dt.Rows[0]["State"].ToString();
            if (!string.IsNullOrEmpty(Stateid))
            {
                drpstate.ClearSelection();
                drpstate.Items.FindByValue(dt.Rows[0]["State"].ToString()).Selected = true;
                //  drpstate.Enabled = false;
                //  ShowCityName();
                //  drpcity.ClearSelection();
                string cityid = dt.Rows[0]["CityName"].ToString();
                if (!string.IsNullOrEmpty(cityid))
                {
                    txtCity.Text = dt.Rows[0]["CityName"].ToString();
                    //  txtCity.Enabled = false;
                    //    drpcity.Items.FindByValue(dt.Rows[0]["CityName"].ToString()).Selected = true;
                    //    drpcity.Enabled = false;
                }
            }

        }
    }

    public void ShowUserDetail()
    {
        MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = ViewState["AccountNo"].ToString() };
        MLMUserDetailLogic MDL = new MLMUserDetailLogic();
        DataTable dt= MDL.UserDetail(MDP, ref message);
        if (dt.Rows.Count>0)
        {
            lblsponsoraccount.Text = dt.Rows[0]["SponsorID"].ToString();
            lblplaceaccountno.Text = dt.Rows[0]["PlaceunderID"].ToString();
            lblaccountno.Text = dt.Rows[0]["UserID"].ToString();
            lbljoindate.Text = dt.Rows[0]["JoinDate"].ToString();
            lbldesignation.Text = dt.Rows[0]["PackInfo"].ToString(); ;
            lblstatus.Text = dt.Rows[0]["Status"].ToString();
            if (lblstatus.Text=="Active")
            {
                //btnstatusactive.Enabled = false;
            }
            txtname.Text = dt.Rows[0]["Name"].ToString();
            string Gender = dt.Rows[0]["Gender"].ToString();
            if (!string.IsNullOrEmpty(Gender))
            {
                drpgender.ClearSelection();
                drpgender.Items.FindByText(dt.Rows[0]["Gender"].ToString()).Selected = true;
            }
            txtdob.Text = dt.Rows[0]["DOB"].ToString();
            txtmobile.Text = dt.Rows[0]["Mobile"].ToString();
            //txtmobile.ReadOnly = true;
            txtalternate.Text = dt.Rows[0]["AlternateMobile"].ToString();
            txtofficeno.Text = dt.Rows[0]["Office"].ToString();
            txtemail.Text = dt.Rows[0]["Email"].ToString();
            Bind_Country_State_City();
            #region Unused Code
            //txtemail.ReadOnly = true;
            //string stateid= dt.Rows[0]["State"].ToString();
            //if (!string.IsNullOrEmpty(stateid))
            //{
            //    drpstate.ClearSelection();
            //    drpstate.Items.FindByValue(stateid).Selected = true;
            //    drpcity.ClearSelection();
            //    ShowCityName();
            //    string Cityid = dt.Rows[0]["District"].ToString();
            //    if (!string.IsNullOrEmpty(Cityid))
            //    {
            //        drpcity.Items.FindByValue(Cityid).Selected = true;
            //    }
            //}
            //txtcity.Text = dt.Rows[0]["City"].ToString();
            #endregion
            txtpostalcode.Text = dt.Rows[0]["PostalCode"].ToString();
            txtaddress.Text = dt.Rows[0]["Address"].ToString();
            txtpayeename.Text = dt.Rows[0]["PayeeName"].ToString();
            txtbankname.Text = dt.Rows[0]["BankName"].ToString();
            txtbranch.Text = dt.Rows[0]["Branch"].ToString();
            txtaccountno.Text = dt.Rows[0]["AccountNo"].ToString();
            string Accounttype = dt.Rows[0]["AccountType"].ToString();
            if (!string.IsNullOrEmpty(Accounttype))
            {
                drpaccounttype.ClearSelection();
                drpaccounttype.Items.FindByText(dt.Rows[0]["AccountType"].ToString()).Selected = true;
            }
            txtifsc.Text = dt.Rows[0]["IFSCCode"].ToString();
            txtpanno.Text = dt.Rows[0]["PANNO"].ToString();
            txtpaytm.Text = dt.Rows[0]["Paytm"].ToString();
            string Addressproof = dt.Rows[0]["AddressProof"].ToString();
            if (!string.IsNullOrEmpty(Addressproof))
            {
                lblname1.Text = Addressproof;
                string validate = dt.Rows[0]["AddressProofvalue"].ToString();
                if (validate == "1")
                {
                    spanadress2.Visible = true;
                    spanadress1.Visible = false;
                }
                else
                {
                    spanadress1.Visible = true;
                    spanadress2.Visible = false;
                }
                string addressimage = dt.Rows[0]["AddressProofUrl"].ToString();
                if (!string.IsNullOrEmpty(addressimage))
                {
                    string Logo = addressimage.ToString();
                    if (!string.IsNullOrEmpty(Logo))
                    {
                        byte[] bytes = (byte[])dt.Rows[0]["AddressProofUrl"];
                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                        Image1.ImageUrl = "data:image/png;base64," + base64String;
                        aimg1.HRef = "data:image/jpeg;base64," + base64String;
                    }
                    //Image1.ImageUrl = addressimage;
                    //aimg1.HRef= addressimage; 
                }
                else
                {
                    Image1.ImageUrl = "~/Company/images/dummy.jpg";
                    aimg1.HRef = "~/Company/images/dummy.jpg";
                }
            }
            else
            {
                btnaprove1.Enabled = false;
                btnreject1.Enabled = false;
                spanadress1.Visible = false;
                spanadress2.Visible = false;
                Image1.ImageUrl = "~/Company/images/dummy.jpg";
                aimg1.HRef = "~/Company/images/dummy.jpg";
                lblname1.Text = "";
            }
            string Addressproof2 = dt.Rows[0]["Address2"].ToString();
            if (!string.IsNullOrEmpty(Addressproof2))
            {
                lblname2.Text = Addressproof2;
                string validate = dt.Rows[0]["Address2value"].ToString();
                if (validate == "1")
                {
                    span2.Visible = true;
                    span1.Visible = false;
                }
                else
                {
                    span2.Visible = false;
                    span1.Visible = true;
                }
                string Addressproofimage2 = dt.Rows[0]["Address2ProofUrl"].ToString();
                if (!string.IsNullOrEmpty(Addressproofimage2))
                {
                    string Logo = Addressproofimage2.ToString();
                    if (!string.IsNullOrEmpty(Logo))
                    {
                        byte[] bytes = (byte[])dt.Rows[0]["Address2ProofUrl"];
                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                        Image2.ImageUrl = "data:image/png;base64," + base64String;
                        //aimg1.HRef = "data:image/png;base64," + base64String;
                        a2img.HRef = "data:image/jpeg;base64," + base64String;
                    }
                    
                    //Image2.ImageUrl= Addressproofimage2;
                }
                else
                {
                    Image2.ImageUrl = "~/Company/images/dummy.jpg";
                    a2img.HRef = "~/Company/images/dummy.jpg";
                }
            }
            else
            {
                btnaprove2.Enabled = false;
                btnreject2.Enabled = false;
                span2.Visible = false;
                span1.Visible = false;
                Image2.ImageUrl = "~/Company/images/dummy.jpg";
                a2img.HRef = "~/Company/images/dummy.jpg";
                lblname2.Text = "";
            }
            string pancard = dt.Rows[0]["IdentityProof"].ToString();
            if (!string.IsNullOrEmpty(pancard))
            {
                lblname3.Text = pancard;
                string validate = dt.Rows[0]["IdentityProofvalue"].ToString();
                if (validate == "1")
                {
                    span4.Visible = true;
                    span3.Visible = false;
                }
                else
                {
                    span3.Visible = true;
                    span4.Visible = false;
                }
                string Pancardimage = dt.Rows[0]["IdentityProofUrl"].ToString();
                if (!string.IsNullOrEmpty(Pancardimage))
                {
                    string Logo = Pancardimage.ToString();
                    if (!string.IsNullOrEmpty(Logo))
                    {
                        byte[] bytes = (byte[])dt.Rows[0]["IdentityProofUrl"];
                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                        Image3.ImageUrl = "data:image/png;base64," + base64String;
                        //aimg1.HRef = "data:image/png;base64," + base64String;
                        a3img.HRef = "data:image/jpeg;base64," + base64String;
                    }
                    //a3img.HRef = Pancardimage;
                    //Image3.ImageUrl = Pancardimage;
                }
                else
                {
                    Image3.ImageUrl = "~/Company/images/dummy.jpg";
                    a3img.HRef = "~/Company/images/dummy.jpg";
                }
            }
            else
            {
                btnaprove3.Enabled = false;
                btnreject3.Enabled = false;
                span4.Visible = false;
                span3.Visible = false;
                Image3.ImageUrl = "~/Company/images/dummy.jpg";
                a3img.HRef = "~/Company/images/dummy.jpg";
                lblname3.Text = "";
            }
            string bankproof = dt.Rows[0]["BankProof"].ToString();
            if (!string.IsNullOrEmpty(bankproof))
            {
                lblname4.Text = bankproof;
                string validate = dt.Rows[0]["BankProofvalue"].ToString();
                if (validate == "1")
                {
                    span6.Visible = true;
                    span5.Visible = false;
                }
                else
                {
                    span5.Visible = true;
                    span6.Visible = false;
                }
                string bankimage = dt.Rows[0]["BankProofUrl"].ToString();
                if (!string.IsNullOrEmpty(bankimage))
                {
                    string Logo = bankimage.ToString();
                    if (!string.IsNullOrEmpty(Logo))
                    {
                        byte[] bytes = (byte[])dt.Rows[0]["BankProofUrl"];
                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                        image4.ImageUrl = "data:image/png;base64," + base64String;
                        //aimg1.HRef = "data:image/png;base64," + base64String;
                        aimg4.HRef = "data:image/jpeg;base64," + base64String;
                    }
                   // aimg4.HRef = bankimage;
                   // image4.ImageUrl = bankimage;
                }
                else
                {
                    image4.ImageUrl = "~/Company/images/dummy.jpg";
                    aimg4.HRef = "~/Company/images/dummy.jpg";
                }
            }
            else
            {
                btnaprove4.Enabled = false;
                btnreject4.Enabled = false;
                span5.Visible = false;
                span6.Visible = false;
                image4.ImageUrl = "~/Company/images/dummy.jpg";
                aimg4.HRef = "~/Company/images/dummy.jpg";
                lblname4.Text = "";
            }
            string GSTProof = dt.Rows[0]["GST"].ToString();
            if (!string.IsNullOrEmpty(GSTProof))
            {
                lblname5.Text = GSTProof;
                string validate = dt.Rows[0]["GSTProofvalue"].ToString();
                if (validate == "1")
                {
                    span8.Visible = true;
                    span7.Visible = false;
                }
                else
                {
                    span7.Visible = true;
                    span8.Visible = false;
                }
                string Gstimage = dt.Rows[0]["GSTProofUrl"].ToString();
                if (!string.IsNullOrEmpty(Gstimage))
                {
                    string Logo = Gstimage.ToString();
                    if (!string.IsNullOrEmpty(Logo))
                    {
                        byte[] bytes = (byte[])dt.Rows[0]["GSTProofUrl"];
                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                        image5.ImageUrl = "data:image/png;base64," + base64String;
                        //aimg1.HRef = "data:image/png;base64," + base64String;
                        aimg5.HRef = "data:image/jpeg;base64," + base64String;
                    }
                    //aimg5.HRef= Gstimage;
                    //image5.ImageUrl = Gstimage;
                }
                else
                {
                    image5.ImageUrl = "~/Company/images/dummy.jpg";
                    aimg5.HRef = "~/Company/images/dummy.jpg";
                }
            }
            else
            {
                btnaprove5.Enabled = false;
                btnreject5.Enabled = false;
                span7.Visible = false;
                span8.Visible = false;
                image5.ImageUrl = "~/Company/images/dummy.jpg";
                aimg5.HRef = "~/Company/images/dummy.jpg";
                lblname5.Text = "";
            }
            ShowSponsorName();
        }
        else
        {
              Response.Redirect("Logout.aspx");
        }         
    }
    public void ShowSponsorName()
    {
    try
    {
        DAL dal = new DAL();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select Name from MLM_Registration where UserID='{0}'", lblsponsoraccount.Text);
        StringBuilder sba = new StringBuilder();
        sba.AppendFormat("select Name from MLM_Registration where UserID='{0}'", lblplaceaccountno.Text);
        object Sposorname = dal.Getscalar(sb.ToString(), ref message);
        object PlaceName = dal.Getscalar(sba.ToString(), ref message);
        if (Sposorname is DBNull)
        {
            lblsponsorname.Text = "Company";
        }
        else
        {
            if (Sposorname != null)
            {
                lblsponsorname.Text = Sposorname.ToString();
            }
            else
            {
                lblsponsorname.Text = "Company";
            }
        }
        if (PlaceName is DBNull)
        {
            lblplaceaccountname.Text = "Company";
        }
        else
        {
            if (PlaceName != null)
            {
                lblplaceaccountname.Text = PlaceName.ToString();
            }
            else
            {
                lblplaceaccountname.Text = "Company";
            }
        }
    }
    catch (Exception ex)
    {
        
    }
}
    protected void drpstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpcity.Items.Clear();
        ShowCityName();
    }

    protected void btnpersonalupdate_Click(object sender, EventArgs e)
    {
        // && drpcity.SelectedValue != "0"
        if (txtname.Text != string.Empty && txtemail.Text != string.Empty && txtmobile.Text != string.Empty && txtCity.Text!=string.Empty&& drpstate.SelectedValue != "0" && txtalternate.Text != string.Empty && txtofficeno.Text != string.Empty && drpgender.SelectedValue != "-1" && txtpostalcode.Text != string.Empty && txtaddress.Text != string.Empty)
        {

            string[] Date = txtdob.Text.Split('/');
            string FinalDate = Date[2] + "/" + Date[1] + "/" + Date[0];
            DAL dal = new DAL();
            string messgae = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("update MLM_Registration set Name='{0}',Mobile='{1}',Email='{2}' where UserID='{3}'", txtname.Text, txtmobile.Text, txtemail.Text, ViewState["AccountNo"].ToString());

            StringBuilder sba = new StringBuilder();
              sba.AppendFormat("update MLM_UserDetail set Gender='{0}',DOB='{1}',AlternateMobile='{2}',Office='{3}',State='{4}',City='{5}',PostalCode='{6}',Address='{7}',StateName='{8}',CityName='{9}',Country='{10}',CountryName='{11}' where UserID='{12}'", drpgender.SelectedItem.Text, FinalDate, txtalternate.Text, txtofficeno.Text, Convert.ToInt32(drpstate.SelectedValue), drpcity.SelectedValue, txtpostalcode.Text, txtaddress.Text, drpstate.SelectedItem.Text, txtCity.Text, ddlCountry.SelectedValue, ddlCountry.SelectedItem.Text, ViewState["AccountNo"].ToString());
            //  sba.AppendFormat("update MLM_UserDetail set Gender='{0}',Alternatemobile='{1}',Office='{2}',State='{3}',District='{4}',City='{5}',PostalCode='{6}',Address='{7}',DOB='{8}',StateName='{9}',CityName='{10}',Country='{11}',CountryName='{12}'  where UserID='{13}'", drpgender.SelectedItem.Text, txtalternate.Text, txtofficeno.Text, drpstate.SelectedValue, drpcity.SelectedValue, drpcity.SelectedValue, txtpostalcode.Text, txtaddress.Text, FinalDate,drpstate.SelectedItem.Text,txtCity.Text,ddlCountry.SelectedValue,ddlCountry.SelectedItem.Text,ViewState["AccountNo"].ToString());
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
                if (rowaffected > 0 && rowaffected1 > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Personal Information Updated Successfully')", true);
                }
                else
                {
                    string Errormessage = string.Format("Message: Please Check All Fields...\\n\\n", messgae);
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
                }
            }
            catch (Exception ex)
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
            }
            finally
            {
                ShowUserDetail();
            }
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Fill All Personal Information')", true);
        }
    }

    protected void btnbankupdate_Click(object sender, EventArgs e)
    {
        if (txtaccountno.Text != string.Empty && txtbankname.Text != string.Empty && txtbranch.Text != string.Empty && txtpayeename.Text != string.Empty && txtpanno.Text != string.Empty && txtifsc.Text != string.Empty)
        {

            DAL dal = new DAL();
            string messgae = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("update MLM_UserDetail set PayeeName='{0}',BankName='{1}',Branch='{2}',AccountNo='{3}',AccountType='{4}',IFSCCode='{5}',PANNO='{6}',Paytm='{7}' where UserID='{8}'", txtpayeename.Text, txtbankname.Text, txtbranch.Text, txtaccountno.Text, drpaccounttype.SelectedItem.Text, txtifsc.Text, txtpanno.Text, txtpaytm.Text, ViewState["AccountNo"].ToString());

            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Bank Information Updated Successfully')", true);
                }
                else
                {
                    string Errormessage = string.Format("Message: {0}\\n\\n", messgae);
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
                }
            }
            catch (Exception ex)
            {
                string Errormessage = string.Format("Message: {0}\\n\\n", ex.Message);
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert(\"" + Errormessage + "\");", true);
            }
            finally
            {
                ShowUserDetail();
            }
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Fill All Bank Information')", true);
        }
    }

    private void ImageDeleteFromFolder(string imagename)
    {
        string file_name = imagename;
        string path = Server.MapPath(imagename);
        if (File.Exists(path)) //check file exsit or not  
        {
            File.Delete(path);
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Photo Delete Successfully')", true);

        }
        else
        {
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('This File dose not exists in folder.')", true);
            return;
        }
    }
  
    //NEW SMS API
    public string sendSMS_new()
    {

        DAL dal = new DAL();
        string website1 = "";
        string txtApiurl = "";
        string txtApikeys = "";
        string txtSender = "";
        string companyname = "";
        string message = string.Empty;

        DataTable dt = dal.Gettable("select api_key,url,sender,Status from Smsmaster Where Status='Active'", ref message);
        DataTable dt1 = dal.Gettable("Select CompanyName,Website from Companyinfo", ref message);

        if (dt.Rows.Count > 0)
        {
            txtApiurl = dt.Rows[0]["url"].ToString();
            txtApikeys = dt.Rows[0]["api_key"].ToString();
            txtSender = dt.Rows[0]["sender"].ToString();
            string status = dt.Rows[0]["Status"].ToString();
            website1 = dt1.Rows[0]["Website"].ToString();
            companyname = dt1.Rows[0]["CompanyName"].ToString();

        }

        //end
        String result;

        string apiKey = txtApikeys.ToString(); 

        string numbers = txtmobile.Text; // in a comma seperated list


        string sms = "Congratulations, Dear '" + txtname.Text + "' Welcome To " + companyname + " Your Account is Verified Successfully.Your Customer ID: '" + lblaccountno.Text + "' and Password:'12345'.For More Info Visit '"+website1+"'";



        String url = "" + txtApiurl + "" + apiKey + "&numbers=" + numbers + "&message=" + sms + "&sender=" + txtSender;
        //refer to parameters to complete correct url string

        StreamWriter myWriter = null;
        HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

        objRequest.Method = "POST";
        objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
        objRequest.ContentType = "application/x-www-form-urlencoded";
        try
        {
            myWriter = new StreamWriter(objRequest.GetRequestStream());
            myWriter.Write(url);
        }
        catch (Exception e)
        {
            return e.Message;
        }
        finally
        {
            myWriter.Close();
        }

        HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
        using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
        {
            result = sr.ReadToEnd();

            sr.Close();
        }
        return result;
    }
    protected void btnstatusactive_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("update MLM_Registration set Status='{0}',JoinType='{1}' where UserID='{2}'", "Active","Paid", lblaccountno.Text);
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected>0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Account is Activated Successfully')", true);
                sendSMS_new();
                ShowUserDetail();
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }

        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }

    //APROVE AND REJECT BUTTON CODE START
    protected void btnaprove1_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set AddressProofvalue='1' where UserID ='"+userID.ToString()+"' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Approve Successfully')", true);
                kycupdate();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnreject1_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = ViewState["AccountNo"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            if (dt.Rows.Count > 0)
            {
                String path = dt.Rows[0]["AddressProofUrl"].ToString();
                System.IO.File.Delete(path);

            }
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set AddressProof='',AddressProofvalue='0',AddressProofUrl=null,AddressProofvalidate=0,KYC='NO' where UserID='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Rejected Successfully')", true);
              
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnaprove2_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set Address2value='1' where UserID ='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Approve Successfully')", true);
                kycupdate();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnreject2_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = ViewState["AccountNo"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            if (dt.Rows.Count > 0)
            {
                String path = Server.MapPath(dt.Rows[0]["Address2ProofUrl"].ToString());
                System.IO.File.Delete(path);

            }
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set Address2value='0',Address2='',Address2ProofUrl=null,Address2validate=0,KYC='NO' where UserID='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Rejected Successfully')", true);
                
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnaprove3_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set IdentityProofvalue='1' where UserID ='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Approve Successfully')", true);
                kycupdate();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnreject3_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = ViewState["AccountNo"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            if (dt.Rows.Count > 0)
            {
                String path = Server.MapPath(dt.Rows[0]["IdentityProofUrl"].ToString());
                System.IO.File.Delete(path);

            }
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set IdentityProofvalue='0',IdentityProof='',IdentityProofUrl=null,IdentityProofvalidate=0,KYC='NO' where UserID='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Rejected Successfully')", true);

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnaprove4_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set BankProofvalue='1' where UserID ='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Approve Successfully')", true);
                kycupdate();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnreject4_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = ViewState["AccountNo"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            if (dt.Rows.Count > 0)
            {
                String path = Server.MapPath(dt.Rows[0]["BankProofUrl"].ToString());
                System.IO.File.Delete(path);

            }
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set BankProofvalue='0',BankProof='',BankProofUrl=null,BankProofvalidate=0,KYC='NO' where UserID='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Rejected Successfully')", true);

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnaprove5_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set GSTProofvalue='1' where UserID ='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Approve Successfully')", true);
                kycupdate();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnreject5_Click(object sender, EventArgs e)
    {
        try
        {
            string userID = ViewState["AccountNo"].ToString();
            DAL dal = new DAL();
            string message = string.Empty;
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = ViewState["AccountNo"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            if (dt.Rows.Count > 0)
            {
                String path = Server.MapPath(dt.Rows[0]["GSTProofUrl"].ToString());
                System.IO.File.Delete(path);

            }
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Update MLM_UserDetail Set GSTProofvalue='0',GST='',GSTProofUrl=null,GSTProofvalidate=0,KYC='NO' where UserID='" + userID.ToString() + "' ");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Rejected Successfully')", true);

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            ShowUserDetail();
        }
    }
    protected void btnKYC_Click(object sender, EventArgs e)
    {
        try
        {
            MLMUserDetailProperty MDP = new MLMUserDetailProperty { UserID = ViewState["AccountNo"].ToString() };
            MLMUserDetailLogic MDL = new MLMUserDetailLogic();
            DataTable dt = MDL.UserDetail(MDP, ref message);
            if (dt.Rows.Count > 0)
            {
                string validate = dt.Rows[0]["AddressProofvalue"].ToString();
                string validate1 = dt.Rows[0]["Address2value"].ToString();
                string validate2 = dt.Rows[0]["IdentityProofvalue"].ToString();
                string validate3 = dt.Rows[0]["BankProofvalue"].ToString();
                if ( validate2 == "1")//validate == "1" && validate1 == "1"&& validate3 == "1"
                {
                 string userID = ViewState["AccountNo"].ToString();
                 DAL dal = new DAL();
                 string message = string.Empty;
                 StringBuilder sb = new StringBuilder();
                 sb.AppendFormat("Update MLM_UserDetail Set KYC='Yes' where UserID='" + userID.ToString() + "' ");
                 int rowaffected = dal.Executequery(sb.ToString(), ref message);
                 if (rowaffected > 0)
                 {
                        KycTrace();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Kyc Update Successfully')", true);
                    statuskyc();
                 }
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Update All KYC....')", true);
                btnKYC.Visible = true;
            }

        }
        catch (Exception ex)
        {
            string error = "";
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {


                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName1 + "','" + password1 + "','" + loginip + "',GETDATE(),'Error:"+error+" ')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

        }
        finally
        {
            ShowUserDetail();
            statuskyc();
        }
    }

    //APROVE AND REJECT BUTTON CODE END
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName1 = dt.Rows[0]["UserName"].ToString();
                password1 = dt.Rows[0]["password"].ToString();

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

    public void KycTrace()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName1 + "','" + password1 + "','" + loginip + "',GETDATE(),'Sucess:Kyc Done Successfully For ID="+ lblaccountno.Text + " ')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }


    }

    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowStateName();
    }
}