﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;
using System.Collections;
using System.Web.Script.Serialization;
using System.Threading;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Globalization;

public partial class Company_GeneratePayment : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    public double countA = 0;
    public double countB = 0;
    public double PreA = 0;
    public double PreB = 0;
    public double CarryA = 0;
    public double CarryB = 0;
    public double carry = 0;
    string userid;
    ArrayList UserIDRightList = new ArrayList();
    ArrayList UserIDRightList1 = new ArrayList();
    string message = string.Empty;
    DAL dal = new DAL();
    int Star = 0, Gold = 0, Diamond = 0, DoubleDiamond = 0, PlantinumDiamond = 0, Directorship = 0, CarTravelFund = 0, HouseFund = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                //Payoutdata();
                //BBOdata();
                FetchLastPaymentDate();
                // GeneratePaymentDouble();

            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void FetchLastPaymentDate()
    {
        DAL dal = new DAL();
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select LastDate from LastPayoutDate");
        object Date = dal.Getscalar(sb.ToString(), ref message);
        if (Date is DBNull)
        {
            lbllastpaymentdate.Text = "No Last Date Found";
        }
        else if (Date != null)
        {

            DateTime dte = Convert.ToDateTime(Date);
            lbllastpaymentdate.Text = dte.Day + "/" + dte.Month + "/" + dte.Year;
            DateTime newdate = dte.AddDays(1);
            txtfromdate.Text = newdate.Day + "/" + newdate.Month + "/" + newdate.Year;
            txtfromdate.Enabled = false;

            //DateTime newdate1 = dte.AddDays(1);
            //txttodate.Text = newdate1.Day + "/" + newdate1.Month + "/" + newdate1.Year;
            //txttodate.Enabled = false;

            ////ToDate Fill
            //int numDays = DateTime.DaysInMonth(dte.Year, dte.Month);
            //if (numDays == 31)
            //{
            //    DateTime todate = dte.AddDays(16);
            //    txttodate.Text = todate.Day + "/" + todate.Month + "/" + todate.Year;
            //    txttodate.Enabled = false;
            //}
            //else
            //{
            //    DateTime todate = dte.AddDays(10);
            //    txttodate.Text = todate.Day + "/" + todate.Month + "/" + todate.Year;
            //    txttodate.Enabled = false;
            //}
            //if (Convert.ToDateTime(txttodate.Text) <= DateTime.Now.Date)
            //{

            //    btngenratepayment.Enabled = true;
            //}




        }
        else
        {
            lbllastpaymentdate.Text = "No Last Date Found";
        }
    }

    DataTable dt = new DataTable();

    private void Payoutdata()
    {
        dt.Columns.Add("UserID", typeof(string));
        dt.Columns.Add("PayoutPair", typeof(int));
        dt.Columns.Add("PayoutAmount", typeof(decimal));
        dt.Columns.Add("LeftCarry", typeof(int));
        dt.Columns.Add("RightCarry", typeof(int));
        dt.Columns.Add("AdminCharge", typeof(decimal));
        dt.Columns.Add("TDS", typeof(decimal));
        dt.Columns.Add("NetAmount", typeof(decimal));
        dt.Columns.Add("PayoutBetween", typeof(string));
        ViewState["dtsession"] = dt;
    }

    DataTable dt1 = new DataTable();

    private void BBOdata()
    {
        dt1.Columns.Add("UserID", typeof(string));
        dt1.Columns.Add("LeftCarry", typeof(int));
        dt1.Columns.Add("RightCarry", typeof(int));
        ViewState["dtsession1"] = dt1;
    }
    protected void btngenratepayment_Click(object sender, EventArgs e)
    {
        //Thread.Sleep(50000);
        Label2.Visible = true;
        try
        {
            string[] dte = txtfromdate.Text.Split('/');
            string[] dte1 = txttodate.Text.Split('/');
            string joinstring = "/";

            DateTime date1 = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
            DateTime date2 = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);
            if (date2 < date1)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Incorrect Dates')", true);
                return;
            }

            int datediffernce = (date2 - date1).Days;
            if (datediffernce > 10)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('The Date You have Selected is greater then 10 days.')", true);
                return;
            }
            else
            {

                // CTO();
                // GeneratePaymentDouble();
                GeneratePayment();
               // LedgerDirectIncome();
                //Spouser Income//
                //   SpouserIncome();
                // DoubleCTO();
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            txttodate.Text = null;
            FetchLastPaymentDate();
            Label2.Visible = false;
            btngenratepayment.Enabled = true;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Payment Generated Successfully')", true);

        }
          ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Payment Generated Successfully')", true);

    }

    private void GeneratePayment()
    {
        string[] dte = txtfromdate.Text.Split('/');
        string[] dte1 = txttodate.Text.Split('/');
        string joinstring = "/";

        DateTime date1 = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
        DateTime date2 = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);

        DAL dal = new DAL();
        StringBuilder sb1 = new StringBuilder();
        sb1.AppendFormat("select LLeg,RLeg,UserID from MLM_Registration");
        DataTable dt = dal.Gettable(sb1.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string userid = dt.Rows[i]["UserID"].ToString();
                string Leftuserid = dt.Rows[i]["LLeg"].ToString();
                string Rightuserid = dt.Rows[i]["RLeg"].ToString();
                countA = 0;
                countB = 0;
                try
                {
                    string L = null;
                    string R = null;
                    int TeamASV = 0;
                    string UserID = Leftuserid;
                    do
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                        DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                        if (UserDetail.Rows.Count > 0)
                        {
                            L = UserDetail.Rows[0]["LLeg"].ToString();
                            R = UserDetail.Rows[0]["RLeg"].ToString();

                            StringBuilder sbgold = new StringBuilder();
                            sbgold.AppendFormat("select * from MLM_Registration where UserID='{0}' and JoinType='Paid' and cast(JoinDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);
                            //  sbgold.AppendFormat("select * from MLM_Registration where UserID='{0}' and JoinType='Paid'", UserID);
                            DataTable dtpaid = dal.Gettable(sbgold.ToString(), ref message);
                            // TeamASV = Convert.ToInt32(UserDetail.Rows[0]["SV"]);
                            if (dtpaid.Rows.Count > 0)
                            {
                                countA++;
                                //if (countA <= 2 && countA > 0)
                                //{
                                //    if (countA == 2)
                                //    {
                                //        countA = 2;
                                //        break;
                                //    }

                                //}

                            }
                        }
                        if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                            UserIDRightList.Add(R);
                        }
                        if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                        }
                        else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserIDRightList.Add(R);
                            int count = UserIDRightList.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList[count - 1].ToString();
                                UserIDRightList.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }

                        }
                        else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            int count = UserIDRightList.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList[count - 1].ToString();
                                UserIDRightList.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }

                        }
                    } while (UserID != null);
                    //Response.Write(countA);
                    //Response.End();
                }
                catch (Exception)
                {

                    throw;
                }

                //Right Count
                try
                {
                    string L = null;
                    string R = null;
                    int TeamASV = 0;
                    string UserID = Rightuserid;
                    do
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                        DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                        if (UserDetail.Rows.Count > 0)
                        {
                            L = UserDetail.Rows[0]["LLeg"].ToString();
                            R = UserDetail.Rows[0]["RLeg"].ToString();
                            StringBuilder sbgold = new StringBuilder();
                            sbgold.AppendFormat("select * from MLM_Registration where UserID='{0}' and JoinType='Paid' and cast(JoinDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "'", UserID);
                            // sbgold.AppendFormat("select * from MLM_Registration where UserID='{0}' and JoinType='Paid'", UserID);
                            DataTable dtpaid = dal.Gettable(sbgold.ToString(), ref message);
                            //TeamASV = Convert.ToInt32(UserDetail.Rows[0]["SV"]);
                            if (dtpaid.Rows.Count > 0)
                            {
                                countB++;
                                //if (countB <= 2 && countB > 0)
                                //{
                                //    if (countB == 2)
                                //    {
                                //        countB = 2;
                                //        break;
                                //    }
                                //}

                            }
                        }
                        if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                            UserIDRightList1.Add(R);
                        }
                        if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                        }
                        else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserIDRightList1.Add(R);
                            int count = UserIDRightList1.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList1[count - 1].ToString();
                                UserIDRightList1.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }

                        }
                        else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            int count = UserIDRightList1.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList1[count - 1].ToString();
                                UserIDRightList1.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }

                        }
                    } while (UserID != null);
                    //Response.Write(countB++);
                    //Response.End();
                }
                catch (Exception)
                {

                    throw;
                }
                //Response.Write(countA + "/" + countB);
                //Response.End();
                lbla.Text = Convert.ToInt32(countA).ToString();
                lblb.Text = Convert.ToInt32(countB).ToString();

                //Payment
                if (countA > 0 && countA >= 2 && countB > 0 && countB >= 1)
                {
                    //Insert Into MemberPaymrnt
                    SqlConnection con = new SqlConnection(connstring);
                    con.Open();

                    // string packAmt = "select pp.Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='" + userid + "'";
                    StringBuilder packAmt = new StringBuilder();
                    packAmt.AppendFormat("select pp.DonationAmount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='{0}'", userid);
                    DataTable UserDetail = dal.Gettable(packAmt.ToString(), ref message);
                    if (UserDetail.Rows.Count > 0)
                    {
                        double tds = 0;
                        double admincharge = 0;
                        double netamt = 0;
                        double calamt = Convert.ToDouble(UserDetail.Rows[0]["DonationAmount"]);
                        double amt = calamt * 10 / 100;
                        tds = amt * 0 / 100;
                        admincharge = amt * 0 / 100;
                        netamt = amt - (tds + admincharge);

                        SqlCommand mcmd = new SqlCommand("InsertMemberPayment", con);
                        mcmd.CommandType = CommandType.StoredProcedure;
                        mcmd.Parameters.AddWithValue("@UserID", userid);
                        mcmd.Parameters.AddWithValue("@PayoutAmount", amt);
                        mcmd.Parameters.AddWithValue("@TDS", tds);
                        mcmd.Parameters.AddWithValue("@AdminCharge", admincharge);
                        mcmd.Parameters.AddWithValue("@NetAmount", netamt);
                        mcmd.Parameters.AddWithValue("@Pair", "10");
                        mcmd.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                        // mcmd.Parameters.AddWithValue("@PayoutBetween", date1.ToString()+'-'+date2.ToString());
                        mcmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                        mcmd.Parameters.AddWithValue("@TransactionType", "CR");
                        mcmd.Parameters.AddWithValue("@CR", netamt);
                        mcmd.Parameters.AddWithValue("@DR", "0.00");
                        mcmd.Parameters.AddWithValue("@Descriptions", "Matching Income");

                        mcmd.Parameters.AddWithValue("@Mode", "savepayment");
                        int flag = mcmd.ExecuteNonQuery();
                        if (flag > 0)
                        {
                            int countA1 = Convert.ToInt32(countA - 2);
                            int countB1 = Convert.ToInt32(countB - 1);
                            //if (countA1 == 0 || countB1 == 0)
                            //{
                            //    //Not Payment 1:1
                            //}
                            //else
                            //{
                            //    if (countA1 > countB1)
                            //    {
                            //        SqlCommand mcmd1 = new SqlCommand("InsertMemberPayment", con);
                            //        mcmd1.CommandType = CommandType.StoredProcedure;
                            //        mcmd1.Parameters.AddWithValue("@UserID", userid);
                            //        mcmd1.Parameters.AddWithValue("@PayoutAmount", amt * countB1);
                            //        mcmd1.Parameters.AddWithValue("@TDS", tds * countB1);
                            //        mcmd1.Parameters.AddWithValue("@AdminCharge", admincharge * countB1);
                            //        mcmd1.Parameters.AddWithValue("@NetAmount", netamt * countB1);
                            //        mcmd1.Parameters.AddWithValue("@Pair", "10");
                            //        mcmd1.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                            //        // mcmd.Parameters.AddWithValue("@PayoutBetween", date1.ToString()+'-'+date2.ToString());
                            //        mcmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                            //        mcmd1.Parameters.AddWithValue("@TransactionType", "CR");
                            //        mcmd1.Parameters.AddWithValue("@CR", netamt * countB1);
                            //        mcmd1.Parameters.AddWithValue("@DR", "0.00");
                            //        mcmd1.Parameters.AddWithValue("@Descriptions", "Payment11");

                            //        mcmd1.Parameters.AddWithValue("@Mode", "savepayment");
                            //        int flag1 = mcmd1.ExecuteNonQuery();
                            //    }
                            //    else
                            //    {
                            //        SqlCommand mcmd1 = new SqlCommand("InsertMemberPayment", con);
                            //        mcmd1.CommandType = CommandType.StoredProcedure;
                            //        mcmd1.Parameters.AddWithValue("@UserID", userid);
                            //        mcmd1.Parameters.AddWithValue("@PayoutAmount", amt * countA1);
                            //        mcmd1.Parameters.AddWithValue("@TDS", tds * countA1);
                            //        mcmd1.Parameters.AddWithValue("@AdminCharge", admincharge * countA1);
                            //        mcmd1.Parameters.AddWithValue("@NetAmount", netamt * countA1);
                            //        mcmd1.Parameters.AddWithValue("@Pair", "10");
                            //        mcmd1.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                            //        // mcmd.Parameters.AddWithValue("@PayoutBetween", date1.ToString()+'-'+date2.ToString());
                            //        mcmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                            //        mcmd1.Parameters.AddWithValue("@TransactionType", "CR");
                            //        mcmd1.Parameters.AddWithValue("@CR", netamt * countA1);
                            //        mcmd1.Parameters.AddWithValue("@DR", "0.00");
                            //        mcmd1.Parameters.AddWithValue("@Descriptions", "Payment11");

                            //        mcmd1.Parameters.AddWithValue("@Mode", "savepayment");
                            //        int flag1 = mcmd1.ExecuteNonQuery();
                            //    }
                            //}


                        }



                    }

                }
                else if (countA > 0 && countA >= 1 && countB > 0 && countB >= 2)
                {
                    //Insert Into MemberPaymrnt
                    SqlConnection con = new SqlConnection(connstring);
                    con.Open();

                    // string packAmt = "select pp.Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='" + userid + "'";
                    StringBuilder packAmt = new StringBuilder();
                    packAmt.AppendFormat("select pp.DonationAmount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='{0}'", userid);
                    DataTable UserDetail = dal.Gettable(packAmt.ToString(), ref message);
                    if (UserDetail.Rows.Count > 0)
                    {
                        double tds = 0;
                        double admincharge = 0;
                        double netamt = 0;
                        double calamt = Convert.ToDouble(UserDetail.Rows[0]["DonationAmount"]);
                        double amt = calamt * 10 / 100;
                        tds = amt * 0 / 100;
                        admincharge = amt * 0 / 100;
                        netamt = amt - (tds + admincharge);

                        SqlCommand mcmd = new SqlCommand("InsertMemberPayment", con);
                        mcmd.CommandType = CommandType.StoredProcedure;
                        mcmd.Parameters.AddWithValue("@UserID", userid);
                        mcmd.Parameters.AddWithValue("@PayoutAmount", amt);
                        mcmd.Parameters.AddWithValue("@TDS", tds);
                        mcmd.Parameters.AddWithValue("@AdminCharge", admincharge);
                        mcmd.Parameters.AddWithValue("@NetAmount", netamt);
                        mcmd.Parameters.AddWithValue("@Pair", "10");
                        mcmd.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                        mcmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                        mcmd.Parameters.AddWithValue("@TransactionType", "CR");
                        mcmd.Parameters.AddWithValue("@CR", netamt);
                        mcmd.Parameters.AddWithValue("@DR", "0.00");
                        mcmd.Parameters.AddWithValue("@Descriptions", "Matching Income");

                        mcmd.Parameters.AddWithValue("@Mode", "savepayment");
                        int flag = mcmd.ExecuteNonQuery();

                        if (flag > 0)
                        {
                            int countA1 = Convert.ToInt32(countA - 1);
                            int countB1 = Convert.ToInt32(countB - 2);
                            //if (countA1 == 0 || countB1 == 0)
                            //{
                            //    //Not Payment 1:1
                            //}
                            //else
                            //{
                            //    if (countA1 > countB1)
                            //    {
                            //        SqlCommand mcmd1 = new SqlCommand("InsertMemberPayment", con);
                            //        mcmd1.CommandType = CommandType.StoredProcedure;
                            //        mcmd1.Parameters.AddWithValue("@UserID", userid);
                            //        mcmd1.Parameters.AddWithValue("@PayoutAmount", amt * countB1);
                            //        mcmd1.Parameters.AddWithValue("@TDS", tds * countB1);
                            //        mcmd1.Parameters.AddWithValue("@AdminCharge", admincharge * countB1);
                            //        mcmd1.Parameters.AddWithValue("@NetAmount", netamt * countB1);
                            //        mcmd1.Parameters.AddWithValue("@Pair", "10");
                            //        mcmd1.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                            //        // mcmd.Parameters.AddWithValue("@PayoutBetween", date1.ToString()+'-'+date2.ToString());
                            //        mcmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                            //        mcmd1.Parameters.AddWithValue("@TransactionType", "CR");
                            //        mcmd1.Parameters.AddWithValue("@CR", netamt * countB1);
                            //        mcmd1.Parameters.AddWithValue("@DR", "0.00");
                            //        mcmd1.Parameters.AddWithValue("@Descriptions", "Payment11");

                            //        mcmd1.Parameters.AddWithValue("@Mode", "savepayment");
                            //        int flag1 = mcmd1.ExecuteNonQuery();
                            //    }
                            //    else
                            //    {
                            //        SqlCommand mcmd1 = new SqlCommand("InsertMemberPayment", con);
                            //        mcmd1.CommandType = CommandType.StoredProcedure;
                            //        mcmd1.Parameters.AddWithValue("@UserID", userid);
                            //        mcmd1.Parameters.AddWithValue("@PayoutAmount", amt * countA1);
                            //        mcmd1.Parameters.AddWithValue("@TDS", tds * countA1);
                            //        mcmd1.Parameters.AddWithValue("@AdminCharge", admincharge * countA1);
                            //        mcmd1.Parameters.AddWithValue("@NetAmount", netamt * countA1);
                            //        mcmd1.Parameters.AddWithValue("@Pair", "10");
                            //        mcmd1.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                            //        // mcmd.Parameters.AddWithValue("@PayoutBetween", date1.ToString()+'-'+date2.ToString());
                            //        mcmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                            //        mcmd1.Parameters.AddWithValue("@TransactionType", "CR");
                            //        mcmd1.Parameters.AddWithValue("@CR", netamt * countA1);
                            //        mcmd1.Parameters.AddWithValue("@DR", "0.00");
                            //        mcmd1.Parameters.AddWithValue("@Descriptions", "Payment11");

                            //        mcmd1.Parameters.AddWithValue("@Mode", "savepayment");
                            //        int flag1 = mcmd1.ExecuteNonQuery();
                            //    }
                            //}


                        }

                    }

                }
                else if (countA >= 2 && countA == countB && countB >= 2)
                {
                    //Insert Into MemberPaymrnt
                    SqlConnection con = new SqlConnection(connstring);
                    con.Open();

                    // string packAmt = "select pp.Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='" + userid + "'";
                    StringBuilder packAmt = new StringBuilder();
                    packAmt.AppendFormat("select pp.Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='{0}'", userid);
                    DataTable UserDetail = dal.Gettable(packAmt.ToString(), ref message);
                    if (UserDetail.Rows.Count > 0)
                    {
                        double tds = 0;
                        double admincharge = 0;
                        double netamt = 0;
                        double calamt = Convert.ToDouble(UserDetail.Rows[0]["Amount"]);
                        double amt = calamt * 10 / 100;
                        tds = amt * 0 / 100;
                        admincharge = amt * 0 / 100;
                        netamt = amt - (tds + admincharge);

                        SqlCommand mcmd = new SqlCommand("InsertMemberPayment", con);
                        mcmd.CommandType = CommandType.StoredProcedure;
                        mcmd.Parameters.AddWithValue("@UserID", userid);
                        mcmd.Parameters.AddWithValue("@PayoutAmount", amt);
                        mcmd.Parameters.AddWithValue("@TDS", tds);
                        mcmd.Parameters.AddWithValue("@AdminCharge", admincharge);
                        mcmd.Parameters.AddWithValue("@Pair", "22");
                        mcmd.Parameters.AddWithValue("@NetAmount", netamt);
                        mcmd.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM--dd")).ToString());
                        mcmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                        mcmd.Parameters.AddWithValue("@TransactionType", "CR");
                        mcmd.Parameters.AddWithValue("@CR", netamt);
                        mcmd.Parameters.AddWithValue("@DR", "0.00");
                        mcmd.Parameters.AddWithValue("@Descriptions", "Matching Income");

                        mcmd.Parameters.AddWithValue("@Mode", "savepayment");
                        int flag = mcmd.ExecuteNonQuery();
                        if (flag > 0)
                        {
                            int countA1 = Convert.ToInt32(countA - 2);
                            int countB1 = Convert.ToInt32(countB - 1);
                            if (countA1 == 0 || countB1 == 0)
                            {
                                //Not Payment 1:1
                            }
                            else
                            {
                                //if (countA1 > countB1)
                                //{
                                //    SqlCommand mcmd1 = new SqlCommand("InsertMemberPayment", con);
                                //    mcmd1.CommandType = CommandType.StoredProcedure;
                                //    mcmd1.Parameters.AddWithValue("@UserID", userid);
                                //    mcmd1.Parameters.AddWithValue("@PayoutAmount", amt * countB1);
                                //    mcmd1.Parameters.AddWithValue("@TDS", tds * countB1);
                                //    mcmd1.Parameters.AddWithValue("@AdminCharge", admincharge * countB1);
                                //    mcmd1.Parameters.AddWithValue("@NetAmount", netamt * countB1);
                                //    mcmd1.Parameters.AddWithValue("@Pair", "10");
                                //    mcmd1.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                                //    // mcmd.Parameters.AddWithValue("@PayoutBetween", date1.ToString()+'-'+date2.ToString());
                                //    mcmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                                //    mcmd1.Parameters.AddWithValue("@TransactionType", "CR");
                                //   // mcmd1.Parameters.AddWithValue("@CR", netamt * countB1);
                                //    mcmd1.Parameters.AddWithValue("@CR", "0.00");
                                //    mcmd1.Parameters.AddWithValue("@DR", "0.00");
                                //    mcmd1.Parameters.AddWithValue("@Descriptions", "Payment11");

                                //    mcmd1.Parameters.AddWithValue("@Mode", "savepayment");
                                //    int flag1 = mcmd1.ExecuteNonQuery();
                                //}
                                //else
                                //{
                                //    SqlCommand mcmd1 = new SqlCommand("InsertMemberPayment", con);
                                //    mcmd1.CommandType = CommandType.StoredProcedure;
                                //    mcmd1.Parameters.AddWithValue("@UserID", userid);
                                //    mcmd1.Parameters.AddWithValue("@PayoutAmount", amt * countA1);
                                //    mcmd1.Parameters.AddWithValue("@TDS", tds * countA1);
                                //    mcmd1.Parameters.AddWithValue("@AdminCharge", admincharge * countA1);
                                //    mcmd1.Parameters.AddWithValue("@NetAmount", netamt * countA1);
                                //    mcmd1.Parameters.AddWithValue("@Pair", "10");
                                //    mcmd1.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                                //    // mcmd.Parameters.AddWithValue("@PayoutBetween", date1.ToString()+'-'+date2.ToString());
                                //    mcmd1.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                                //    mcmd1.Parameters.AddWithValue("@TransactionType", "CR");
                                //    mcmd1.Parameters.AddWithValue("@CR", netamt * countA1);
                                //    mcmd1.Parameters.AddWithValue("@DR", "0.00");
                                //    mcmd1.Parameters.AddWithValue("@Descriptions", "Payment11");

                                //    mcmd1.Parameters.AddWithValue("@Mode", "savepayment");
                                //    int flag1 = mcmd1.ExecuteNonQuery();
                                //}
                            }


                        }

                    }


                }


            }

        }

    }


    // 15-07-2019 Generate Double payment
    //private void GeneratePaymentDouble()
    //{
    //    string[] dte = txtfromdate.Text.Split('/');
    //    string[] dte1 = txttodate.Text.Split('/');
    //    string joinstring = "/";
    //    IFormatProvider cul = new System.Globalization.CultureInfo("en-us", true);

    //    DateTime date1 = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
    //    DateTime date2 = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);

    //    DAL dal = new DAL();
    //    StringBuilder sb1 = new StringBuilder();
    //    sb1.AppendFormat("select LLeg,RLeg,UserID from MLM_Registration where JoinType ='Paid' Order By DID Asc");
    //    DataTable dt = dal.Gettable(sb1.ToString(), ref message);
    //    if (dt.Rows.Count > 0)
    //    {
    //        for (int i = 0; i < dt.Rows.Count; i++)
    //        {
    //            string userid = dt.Rows[i]["UserID"].ToString();
    //            string Leftuserid = dt.Rows[i]["LLeg"].ToString();
    //            string Rightuserid = dt.Rows[i]["RLeg"].ToString();
    //            countA = 0;
    //            countB = 0;
    //            PreA = 0;
    //            PreB = 0;
    //            CarryA = 0;
    //            CarryB = 0;
    //            try
    //            {
    //                string L = null;
    //                string R = null;
    //                int TeamASV = 0;
    //                string UserID = Leftuserid;
    //                do
    //                {
    //                    StringBuilder sb = new StringBuilder();
    //                    sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
    //                    DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
    //                    if (UserDetail.Rows.Count > 0)
    //                    {
    //                        L = UserDetail.Rows[0]["LLeg"].ToString();
    //                        R = UserDetail.Rows[0]["RLeg"].ToString();

    //                        StringBuilder sbgold = new StringBuilder();
    //                        //query for  package and without package  calculation 
    //                       // sbgold.AppendFormat("select * from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where mm.UserID='{0}' and mm.JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);

    //                       ///query without package only  on join type
    //                        sbgold.AppendFormat("select * from MLM_Registration mm  where mm.UserID='{0}' and mm.JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);


    //                        DataTable dtpaid = dal.Gettable(sbgold.ToString(), ref message);
    //                        if (dtpaid.Rows.Count > 0)
    //                        {
    //                            // countA += Convert.ToDouble(dtpaid.Rows[0]["Amount"]);
    //                            countA++;
    //                        }


    //                    }
    //                    if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
    //                    {
    //                        UserID = L;
    //                        UserIDRightList.Add(R);
    //                    }
    //                    if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
    //                    {
    //                        UserID = L;
    //                    }
    //                    else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
    //                    {
    //                        UserIDRightList.Add(R);
    //                        int count = UserIDRightList.Count;
    //                        if (count > 0)
    //                        {
    //                            string Last = UserIDRightList[count - 1].ToString();
    //                            UserIDRightList.Remove(Last);
    //                            UserID = Last;
    //                        }
    //                        else
    //                        {
    //                            UserID = null;
    //                        }
    //                    }
    //                    else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
    //                    {
    //                        int count = UserIDRightList.Count;
    //                        if (count > 0)
    //                        {
    //                            string Last = UserIDRightList[count - 1].ToString();
    //                            UserIDRightList.Remove(Last);
    //                            UserID = Last;
    //                        }
    //                        else
    //                        {
    //                            UserID = null;
    //                        }

    //                    }
    //                } while (UserID != null);
    //                //Response.Write(countA);
    //                //Response.End();
    //            }
    //            catch (Exception ex)
    //            {
    //                throw;
    //            }

    //            //Right Count
    //            try
    //            {
    //                string L = null;
    //                string R = null;
    //                int TeamASV = 0;
    //                string UserID = Rightuserid;
    //                do
    //                {
    //                    StringBuilder sb = new StringBuilder();
    //                    sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
    //                    DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
    //                    if (UserDetail.Rows.Count > 0)
    //                    {
    //                        L = UserDetail.Rows[0]["LLeg"].ToString();
    //                        R = UserDetail.Rows[0]["RLeg"].ToString();
    //                        StringBuilder sbgold = new StringBuilder();
    //                        //query with package
    //                        //  sbgold.AppendFormat("select * from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where mm.UserID='{0}' and mm.JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);


    //                        ///query without package only  on join type
    //                        sbgold.AppendFormat("select * from MLM_Registration mm  where mm.UserID='{0}' and mm.JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);


    //                        DataTable dtpaid = dal.Gettable(sbgold.ToString(), ref message);
    //                        if (dtpaid.Rows.Count > 0)
    //                        {
    //                            //countB += Convert.ToDouble(dtpaid.Rows[0]["Amount"]);
    //                            countB++;
    //                        }
    //                        //Previous Bal
    //                        StringBuilder sbgold2 = new StringBuilder();
    //                        sbgold2.AppendFormat("select mm.Package,Isnull(SUM(pp.Amount),0)as Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='{0}' and JoinType='Paid' and  cast(PackageDate as date) <=(Select LastDate From LastPayoutDate) group by mm.Package,Amount ", UserID);
    //                        DataTable dtpaid2 = dal.Gettable(sbgold2.ToString(), ref message);
    //                        if (dtpaid2.Rows.Count > 0)
    //                        {
    //                           // PreB += Convert.ToDouble(dtpaid1.Rows[0]["Amount"]);
    //                        }
    //                    }
    //                    if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
    //                    {
    //                        UserID = L;
    //                        UserIDRightList1.Add(R);
    //                    }
    //                    if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
    //                    {
    //                        UserID = L;
    //                    }
    //                    else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
    //                    {
    //                        UserIDRightList1.Add(R);
    //                        int count = UserIDRightList1.Count;
    //                        if (count > 0)
    //                        {
    //                            string Last = UserIDRightList1[count - 1].ToString();
    //                            UserIDRightList1.Remove(Last);
    //                            UserID = Last;
    //                        }
    //                        else
    //                        {
    //                            UserID = null;
    //                        }
    //                    }
    //                    else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
    //                    {
    //                        int count = UserIDRightList1.Count;
    //                        if (count > 0)
    //                        {
    //                            string Last = UserIDRightList1[count - 1].ToString();
    //                            UserIDRightList1.Remove(Last);
    //                            UserID = Last;
    //                        }
    //                        else
    //                        {
    //                            UserID = null;
    //                        }
    //                    }
    //                } while (UserID != null);
    //                //Response.Write( countA+"/"+countB);
    //               //Response.End();
    //            }
    //            catch (Exception ex)
    //            {

    //                throw;
    //            }


    //            //Previous Bal
    //            StringBuilder sbgold1 = new StringBuilder();
    //            //  sbgold1.AppendFormat("select mm.Package,Isnull(SUM(pp.Amount),0)as Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='{0}' and JoinType='Paid' and  cast(PackageDate as date) <=(Select LastDate From LastPayoutDate) group by mm.Package,Amount ", UserID);
    //            sbgold1.AppendFormat("select top 1 ISNULL(LeftCarry,0) as LeftCarry,ISNULL(RightCarry,0) as RightCarry  from MemberPayment where UserID='" + userid + "' and  PayoutPair=20 order by PaymentID desc");
    //            DataTable dtpaid1 = dal.Gettable(sbgold1.ToString(), ref message);
    //            if (dtpaid1.Rows.Count > 0)
    //            {
    //                PreA += Convert.ToDouble(dtpaid1.Rows[0]["LeftCarry"]);
    //                PreB += Convert.ToDouble(dtpaid1.Rows[0]["RightCarry"]);
    //            }


    //            DirectIncome(userid);

    //            countA = countA + PreA;
    //            countB = countB + PreB;

    //            //Response.Write(countA + "/" + countB);
    //           // Response.End();

    //            //Payment
    //            //if (countA > 0 && countB > 0)
    //            //{
    //                if (countA > countB)
    //                {
    //                    CarryA = countA - countB;
    //                    CarryB = 0;

    //                    if (countB >= 20)
    //                    {
    //                        countB = 20;
    //                    }

    //                    double tds = 0;
    //                    double admincharge = 0;
    //                    double netamt = 0;
    //                    double calamt = countB;

    //                //binary income 1 : 1
    //                    double amt = 100;
    //                    tds = amt * 0 / 100;
    //                    admincharge = amt * 0 / 100;
    //                    netamt = amt - (tds + admincharge);
    //                    if (amt != 0)
    //                    {
    //                        SqlConnection con = new SqlConnection(connstring);
    //                        con.Open();
    //                        try
    //                        {
    //                            SqlCommand mcmd = new SqlCommand("InsertMemberPayment", con);
    //                            mcmd.CommandType = CommandType.StoredProcedure;
    //                            mcmd.Parameters.AddWithValue("@UserID", userid);
    //                            mcmd.Parameters.AddWithValue("@PayoutAmount", amt * calamt);
    //                            mcmd.Parameters.AddWithValue("@TDS", tds * calamt);
    //                            mcmd.Parameters.AddWithValue("@AdminCharge", admincharge * calamt);
    //                            mcmd.Parameters.AddWithValue("@NetAmount", netamt * calamt);
    //                            mcmd.Parameters.AddWithValue("@Pair", "20");
    //                            mcmd.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
    //                            mcmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));
    //                            mcmd.Parameters.AddWithValue("@LeftCarry", CarryA);
    //                            mcmd.Parameters.AddWithValue("@RightCarry", CarryB);
    //                            mcmd.Parameters.AddWithValue("@TransactionType", "CR");
    //                            mcmd.Parameters.AddWithValue("@CR", netamt * calamt);
    //                            mcmd.Parameters.AddWithValue("@DR", "0.00");
    //                            mcmd.Parameters.AddWithValue("@Descriptions", "Matching Income");
    //                        // mcmd.Parameters.AddWithValue("@", "Matching Income");
    //                            mcmd.Parameters.AddWithValue("@Mode", "savepayment");
    //                            int flag = mcmd.ExecuteNonQuery();
    //                        }
    //                        catch (Exception ex)
    //                        {

    //                        }
    //                    }
    //                    else
    //                    {

    //                    }
    //                }
    //                else
    //                {
    //                    CarryB = countB - countA;
    //                    CarryA = 0;

    //                //change saurabh  10 change to 0
    //                    //if (countA >= 0)
    //                    //{
    //                    //    countA = 100;
    //                    //}

    //                    double tds = 0;
    //                    double admincharge = 0;
    //                    double netamt = 0;
    //                    double calamt = countA;
    //                    double amt = 100;
    //                    tds = amt * 0 / 100;
    //                    admincharge = amt * 0 / 100;
    //                    netamt = amt - (tds + admincharge);
    //                    if (amt != 0)
    //                    {
    //                        SqlConnection con = new SqlConnection(connstring);
    //                        con.Open();
    //                        try
    //                        {
    //                            SqlCommand mcmd = new SqlCommand("InsertMemberPayment", con);
    //                            mcmd.CommandType = CommandType.StoredProcedure;
    //                            mcmd.Parameters.AddWithValue("@UserID", userid);
    //                            mcmd.Parameters.AddWithValue("@PayoutAmount", amt * calamt);
    //                            mcmd.Parameters.AddWithValue("@TDS", tds * calamt);
    //                            mcmd.Parameters.AddWithValue("@AdminCharge", admincharge * calamt);
    //                            mcmd.Parameters.AddWithValue("@NetAmount", netamt * calamt);
    //                            mcmd.Parameters.AddWithValue("@Pair", "20");
    //                            mcmd.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
    //                            mcmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));
    //                            mcmd.Parameters.AddWithValue("@LeftCarry", CarryA);
    //                            mcmd.Parameters.AddWithValue("@RightCarry", CarryB);
    //                            mcmd.Parameters.AddWithValue("@TransactionType", "CR");
    //                            mcmd.Parameters.AddWithValue("@CR", netamt * calamt);
    //                            mcmd.Parameters.AddWithValue("@DR", "0.00");
    //                            mcmd.Parameters.AddWithValue("@Descriptions", "Matching Income");
    //                            mcmd.Parameters.AddWithValue("@Mode", "savepayment");
    //                            int flag = mcmd.ExecuteNonQuery();

    //                       // LedgerDirectIncome();


    //                            //Insert Into ScheduleSummary
    //                            //string str = "insert into ScheduleSummary (UserID,TeamA,TeamB,Matching,Income,ScheduleDate) values('" + userid + "','" + countA + "','" + countB + "','" + countA + "','" + amt + "','" + (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString() + "')";
    //                            //SqlCommand SDM = new SqlCommand(str, con);
    //                            //SDM.ExecuteNonQuery();
    //                            //con.Close();

    //                        }
    //                        catch (Exception ex)
    //                        {

    //                        }
    //                    }
    //                    else
    //                    {
    //                        ////Insert Into ScheduleSummary
    //                        //SqlConnection con = new SqlConnection(connstring);
    //                        //con.Open();
    //                        //string str = "insert into ScheduleSummary (UserID,TeamA,TeamB,Matching,Income,ScheduleDate) values('" + userid + "','" + countA + "','" + countB + "','" + countA + "','" + amt + "','" + (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString() + "')";
    //                        //SqlCommand SDM = new SqlCommand(str, con);
    //                        //SDM.ExecuteNonQuery();
    //                        //con.Close();
    //                    }
    //                }
    //           // }
    //        }     
    //    }
    //}
    public void LedgerDirectIncome()
    {
        string[] dte = txtfromdate.Text.Split('/');
        string[] dte1 = txttodate.Text.Split('/');
        string joinstring = "/";
        IFormatProvider cul = new System.Globalization.CultureInfo("en-us", true);


        DateTime date1 = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
        DateTime date2 = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);

        DAL dal = new DAL();
        StringBuilder sb1 = new StringBuilder();
        sb1.AppendFormat("select LLeg,RLeg,UserID from MLM_Registration where JoinType ='Paid' Order By DID Asc");
        DataTable dt = dal.Gettable(sb1.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string userid = dt.Rows[i]["UserID"].ToString();
                string Leftuserid = dt.Rows[i]["LLeg"].ToString();
                string Rightuserid = dt.Rows[i]["RLeg"].ToString();
                countA = 0;
                countB = 0;
                PreA = 0;
                PreB = 0;
                CarryA = 0;
                CarryB = 0;
                try
                {
                    string L = null;
                    string R = null;
                    int TeamASV = 0;
                    string UserID = Leftuserid;
                    do
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                        DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                        if (UserDetail.Rows.Count > 0)
                        {
                            L = UserDetail.Rows[0]["LLeg"].ToString();
                            R = UserDetail.Rows[0]["RLeg"].ToString();

                            StringBuilder sbgold = new StringBuilder();
                            sbgold.AppendFormat("select Isnull(SUM(pp.Amount),0)as Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where mm.UserID='{0}' and mm.JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);
                            //    sbgold.AppendFormat("select * from MLM_Registration  where UserID='" + UserID + "' and JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "'");
                            DataTable dtpaid = dal.Gettable(sbgold.ToString(), ref message);
                            if (dtpaid.Rows.Count > 0)
                            {
                                // countA += Convert.ToDouble(dtpaid.Rows[0]["Amount"]);
                                countA++;
                            }

                            //Previous Bal
                            StringBuilder sbgold1 = new StringBuilder();
                            sbgold1.AppendFormat("select mm.Package,Isnull(SUM(pp.Amount),0)as Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='{0}' and JoinType='Paid' and  cast(PackageDate as date) <=(Select LastDate From LastPayoutDate) group by mm.Package,Amount ", UserID);
                            DataTable dtpaid1 = dal.Gettable(sbgold1.ToString(), ref message);
                            if (dtpaid1.Rows.Count > 0)
                            {
                                PreA += Convert.ToDouble(dtpaid1.Rows[0]["Amount"]);
                            }
                        }
                        if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                            UserIDRightList.Add(R);
                        }
                        if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                        }
                        else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserIDRightList.Add(R);
                            int count = UserIDRightList.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList[count - 1].ToString();
                                UserIDRightList.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }
                        }
                        else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            int count = UserIDRightList.Count;
                            if(count > 0)
                            {
                                string Last = UserIDRightList[count - 1].ToString();
                                UserIDRightList.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }
                        }
                    } while (UserID != null);
                    //Response.Write(countA);
                    //Response.End();
                }
                catch (Exception ex)
                {
                    throw;
                }

                //Right Count
                try
                {
                    string L = null;
                    string R = null;
                    int TeamASV = 0;
                    string UserID = Rightuserid;
                    do
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                        DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                        if (UserDetail.Rows.Count > 0)
                        {
                            L = UserDetail.Rows[0]["LLeg"].ToString();
                            R = UserDetail.Rows[0]["RLeg"].ToString();
                            StringBuilder sbgold = new StringBuilder();
                            //sbgold.AppendFormat("select Isnull(SUM(pp.Amount),0)as Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where mm.UserID='{0}' and mm.JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "'", UserID);
                            //sbgold.AppendFormat("select * from MLM_Registration   where UserID='{0}' and JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);
                            // sbgold.AppendFormat("select * from MLM_Registration  where UserID='"+ UserID + "' and JoinType='Paid' ");
                            // sbgold.AppendFormat("select * from MLM_Registration  where UserID='" + UserID + "' and JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ");
                            sbgold.AppendFormat("select Isnull(SUM(pp.Amount),0)as Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where mm.UserID='{0}' and mm.JoinType='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", UserID);
                            DataTable dtpaid = dal.Gettable(sbgold.ToString(), ref message);
                            if (dtpaid.Rows.Count > 0)
                            {
                                //countB += Convert.ToDouble(dtpaid.Rows[0]["Amount"]);
                                countB++;
                            }

                            //Previous Bal
                            StringBuilder sbgold1 = new StringBuilder();
                            sbgold1.AppendFormat("select mm.Package,Isnull(SUM(pp.Amount),0)as Amount from MLM_Registration mm inner join PackageInfo pp on mm.Package=pp.PackageName where UserID='{0}' and JoinType='Paid' and  cast(PackageDate as date) <=(Select LastDate From LastPayoutDate) group by mm.Package,Amount ", UserID);
                            DataTable dtpaid1 = dal.Gettable(sbgold1.ToString(), ref message);
                            if (dtpaid1.Rows.Count > 0)
                            {
                                PreB += Convert.ToDouble(dtpaid1.Rows[0]["Amount"]);
                            }
                        }
                        if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                            UserIDRightList1.Add(R);
                        }
                        if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            UserID = L;
                        }
                        else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                        {
                            UserIDRightList1.Add(R);
                            int count = UserIDRightList1.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList1[count - 1].ToString();
                                UserIDRightList1.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }
                        }
                        else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                        {
                            int count = UserIDRightList1.Count;
                            if (count > 0)
                            {
                                string Last = UserIDRightList1[count - 1].ToString();
                                UserIDRightList1.Remove(Last);
                                UserID = Last;
                            }
                            else
                            {
                                UserID = null;
                            }
                        }
                    } while (UserID != null);
                    //Response.Write(countB++);
                    //Response.End();
                }
                catch (Exception)
                {

                    throw;
                }

                //lbla.Text = countA.ToString();
                //lblb.Text = countB.ToString();

                //Response.Write(countA + "/" + countB);
                //Response.End();

                //Response.Write(countA + "/" + countB);
                //Response.End();

                if (PreA > PreB)
                {
                    CarryA = PreA - PreB;
                    CarryB = 0;
                }
                else if (PreA < PreB)
                {
                    CarryB = PreB - PreA;
                    CarryA = 0;
                }
                else if (PreA == PreB)
                {
                    CarryA = PreA - PreA;
                    CarryB = PreB - PreB;
                }

                countA = countA + CarryA;
                countB = countB + CarryB;

                //Response.Write(countA + "/" + countB);
                //Response.End();

                //Payment
                if (countA > 0 && countB > 0)
                {
                    if (countA > countB)
                    {
                        double tds = 0;
                        double admincharge = 0;
                        double netamt = 0;
                        double calamt = countB;
                        double amt = 100;
                        tds = amt * 0 / 100;
                        admincharge = amt * 0 / 100;
                        netamt = amt - (tds + admincharge);

                        if (amt != 0)
                        {
                            try
                            {
                                string UserID = userid;
                                //string UserID = "RAJA001";
                                string SpID = null;
                                string SpMobile = null;
                                DataTable dt1 = dal.Gettable("select sponsorid from MLM_Registration where userid='" + UserID + "'", ref message);

                                if (dt1.Rows.Count > 0)
                                {
                                    SpID = dt1.Rows[0]["sponsorid"].ToString();
                                    DataTable dtMob = dal.Gettable("select Mobile from MLM_Registration where userid='" + SpID + "'", ref message);
                                    if (dt.Rows.Count > 0)
                                    {
                                        SpMobile = dtMob.Rows[0]["Mobile"].ToString();
                                    }
                                }
                                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                                SqlConnection con = new SqlConnection(connstring);
                                con.Open();
                                SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@UserID", SpID);
                                cmd.Parameters.AddWithValue("@TransactionType", "CR");
                                cmd.Parameters.AddWithValue("@CR", netamt);
                                cmd.Parameters.AddWithValue("@DR", 0);
                                cmd.Parameters.AddWithValue("@Descriptions", "Direct Income");
                                //     cmd.Parameters.AddWithValue("@TransferBy",SpID);
                                cmd.Parameters.AddWithValue("@Mode", "IN1");
                                int flag = cmd.ExecuteNonQuery();
                                //   con = new SqlConnection(connstring);
                                //  string str = "Insert into Ledger_Wallet (UserID,TransactionType,CR,Descriptions,TransferBy,) values ('"+UserID+"','CR','"+600+"','Ashish',"+SpID+")";
                                //   string str = "Insert into Ledger_Wallet (UserID,SponsorID,CR,TransactionType,Descriptions) values ('" + UserID + "','" + SpID + "','" + 600 + "','CR','Direct Income')";
                                //   cmd = new SqlCommand(str, con);
                                //     con.Open();
                                //     cmd.ExecuteNonQuery();
                                //     Donation4000(SpID);
                                con.Close();
                            }
                            catch (Exception ex)
                            {

                            }
                            //SqlConnection con = new SqlConnection(connstring);
                            //con.Open();
                            //try
                            //{
                            //    SqlCommand mcmd = new SqlCommand("Ledger_Wallet_ALL", con);
                            //    mcmd.CommandType = CommandType.StoredProcedure;
                            //    mcmd.Parameters.AddWithValue("@UserID", userid);
                            //    mcmd.Parameters.AddWithValue("@TransactionType", "CR");
                            //    mcmd.Parameters.AddWithValue("@CR", amt);
                            //    mcmd.Parameters.AddWithValue("@DR", "0.00");
                            //    mcmd.Parameters.AddWithValue("@NetAmount", netamt);
                            //     mcmd.Parameters.AddWithValue("@Pair", "00");
                            //        mcmd.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                            //      mcmd.Parameters.AddWithValue("", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                            //    mcmd.Parameters.AddWithValue("@TransactionType", "CR");
                            //             mcmd.Parameters.AddWithValue("@CR", amt);
                            //       mcmd.Parameters.AddWithValue("@DR", "0.00");
                            //    mcmd.Parameters.AddWithValue("@Descriptions", "Direct Income");

                            //      mcmd.Parameters.AddWithValue("@Mode", "IN1");
                            //     int flag = mcmd.ExecuteNonQuery();

                            //Insert Into ScheduleSummary
                            //string str = "insert into ScheduleSummary (UserID,TeamA,TeamB,Matching,Income,ScheduleDate) values('" + userid + "','" + countA + "','" + countB + "','" + countB + "','" + amt + "','" + (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString() + "')";
                            //SqlCommand SDM = new SqlCommand(str, con);
                            //SDM.ExecuteNonQuery();
                            //con.Close();

                        
                        }
                        else
                        {
                            //Insert Into ScheduleSummary
                            //SqlConnection con = new SqlConnection(connstring);
                            //con.Open();
                            //string str = "insert into ScheduleSummary (UserID,TeamA,TeamB,Matching,Income,ScheduleDate) values('" + userid + "','" + countA + "','" + countB + "','" + countB + "','" + amt + "','" + (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString() + "')";
                            //SqlCommand SDM = new SqlCommand(str, con);
                            //SDM.ExecuteNonQuery();
                            //con.Close();

                        }
                    }
                    else
                    {
                        double tds = 0;
                        double admincharge = 0;
                        double netamt = 0;
                        double calamt = countA;
                        double amt = 0;
                        tds = amt * 0 / 100;
                        admincharge = amt * 0 / 100;
                        netamt = amt - (tds + admincharge);
                        if (amt != 0)
                        {
                            //SqlConnection con = new SqlConnection(connstring);
                            //con.Open();
                            //try
                            //{
                                try
                                {
                                    string UserID = userid;
                                    //string UserID = "RAJA001";
                                    string SpID = null;
                                    string SpMobile = null;
                                    DataTable dt1 = dal.Gettable("select sponsorid from MLM_Registration where userid='" + UserID + "'", ref message);

                                    if (dt1.Rows.Count > 0)
                                    {
                                        SpID = dt1.Rows[0]["sponsorid"].ToString();
                                        DataTable dtMob = dal.Gettable("select Mobile from MLM_Registration where userid='" + SpID + "'", ref message);
                                        if (dt.Rows.Count > 0)
                                        {
                                            SpMobile = dtMob.Rows[0]["Mobile"].ToString();
                                        }
                                    }
                                    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                                    SqlConnection con = new SqlConnection(connstring);
                                    con.Open();
                                    SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.Parameters.AddWithValue("@UserID", SpID);
                                    cmd.Parameters.AddWithValue("@TransactionType", "CR");
                                    cmd.Parameters.AddWithValue("@CR", netamt);
                                    cmd.Parameters.AddWithValue("@DR", 0);
                                    cmd.Parameters.AddWithValue("@Descriptions", "Direct Income");
                                    //     cmd.Parameters.AddWithValue("@TransferBy",SpID);
                                    cmd.Parameters.AddWithValue("@Mode", "IN1");
                                    int flag1 = cmd.ExecuteNonQuery();
                                    //   con = new SqlConnection(connstring);
                                    //  string str = "Insert into Ledger_Wallet (UserID,TransactionType,CR,Descriptions,TransferBy,) values ('"+UserID+"','CR','"+600+"','Ashish',"+SpID+")";
                                    //   string str = "Insert into Ledger_Wallet (UserID,SponsorID,CR,TransactionType,Descriptions) values ('" + UserID + "','" + SpID + "','" + 600 + "','CR','Direct Income')";
                                    //   cmd = new SqlCommand(str, con);
                                    //     con.Open();
                                    //     cmd.ExecuteNonQuery();
                                    //     Donation4000(SpID);
                                    con.Close();
                                }
                                catch (Exception ex)
                                {

                                }
                                //SqlCommand mcmd = new SqlCommand("Ledger_Wallet_ALL", con);
                                //mcmd.CommandType = CommandType.StoredProcedure;
                                //mcmd.Parameters.AddWithValue("@UserID", userid);
                                //mcmd.Parameters.AddWithValue("@TransactionType", "CR");
                                //mcmd.Parameters.AddWithValue("@CR", amt);
                                //mcmd.Parameters.AddWithValue("@DR", "0.00");
                                //    mcmd.Parameters.AddWithValue("@NetAmount", netamt);
                                //     mcmd.Parameters.AddWithValue("@Pair", "00");
                                //        mcmd.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
                                //      mcmd.Parameters.AddWithValue("", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));

                                //    mcmd.Parameters.AddWithValue("@TransactionType", "CR");
                                //             mcmd.Parameters.AddWithValue("@CR", amt);
                                //       mcmd.Parameters.AddWithValue("@DR", "0.00");
                          //      mcmd.Parameters.AddWithValue("@Descriptions", "Direct Income");

                          //      mcmd.Parameters.AddWithValue("@Mode", "IN1");
                   //             int flag = mcmd.ExecuteNonQuery();

                                //Insert Into ScheduleSummary
                                //string str = "insert into ScheduleSummary (UserID,TeamA,TeamB,Matching,Income,ScheduleDate) values('" + userid + "','" + countA + "','" + countB + "','" + countA + "','" + amt + "','" + (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString() + "')";
                                //SqlCommand SDM = new SqlCommand(str, con);
                                //SDM.ExecuteNonQuery();
                                //con.Close();

                   //         }
                  //          catch (Exception ex)
                   //         {
                   
                  //          }
                        }
                        else
                        {
                            ////Insert Into ScheduleSummary
                            //SqlConnection con = new SqlConnection(connstring);
                            //con.Open();
                            //string str = "insert into ScheduleSummary (UserID,TeamA,TeamB,Matching,Income,ScheduleDate) values('" + userid + "','" + countA + "','" + countB + "','" + countA + "','" + amt + "','" + (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString() + "')";
                            //SqlCommand SDM = new SqlCommand(str, con);
                            //SDM.ExecuteNonQuery();
                            //con.Close();
                        }

                    }

                }

            }

        }
    }

    // 21/11/ 2019 Direct Income 
    public void DirectIncome( string userid)
    {
        double sp = 0;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        DataTable dt1 = dal.Gettable("select count(*) as count1 from MLM_Registration where SponsorID='" + userid + "' and JoinType ='Paid' and cast(PackageDate as date) between '" + Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd") + "' ", ref message);
      
        if(dt1.Rows.Count>0)
        {
            sp = Convert.ToDouble(dt1.Rows[0]["count1"]);
        }
        double tds = 0;
        double admincharge = 0;
        double netamt = 0;
        double calamt = sp;
        double amt = 0;
        tds = amt * 0 / 100;
        admincharge = amt * 0 / 100;
        netamt = amt - (tds + admincharge);
        string UserID = userid;

        SqlCommand mcmd = new SqlCommand("InsertMemberPayment", con);
        mcmd.CommandType = CommandType.StoredProcedure;
        mcmd.Parameters.AddWithValue("@UserID", userid);
        mcmd.Parameters.AddWithValue("@PayoutAmount", amt * calamt);
        mcmd.Parameters.AddWithValue("@TDS", tds * calamt);
        mcmd.Parameters.AddWithValue("@AdminCharge", admincharge * calamt);
        mcmd.Parameters.AddWithValue("@NetAmount", netamt * calamt);
        mcmd.Parameters.AddWithValue("@Pair", "00");
        mcmd.Parameters.AddWithValue("@PayoutBetween", (Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd") + '-' + Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd")).ToString());
        mcmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));
        mcmd.Parameters.AddWithValue("@TransactionType", "CR");
        mcmd.Parameters.AddWithValue("@CR", netamt * calamt);
        mcmd.Parameters.AddWithValue("@DR", "0.00");
        mcmd.Parameters.AddWithValue("@Descriptions", "Direct Income");
        mcmd.Parameters.AddWithValue("@Mode", "savepayment");
        int flag = mcmd.ExecuteNonQuery();
        con.Close();
    }
    public void CTO()
    {
        try
        {
            SqlConnection con = new SqlConnection(connstring);
            SqlCommand cmd;
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Company_Turnover", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(txtfromdate.Text).ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(txttodate.Text).ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@Mode", "CTO");
            int flag = cmd.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {

        }
    }

    public void DoubleCTO()
    {

        //for 30 or 31 days
        DAL dal = new DAL();
        string dd = "";
        string from = "";
        DateTime fromdte;
        StringBuilder sbtot1 = new StringBuilder();
        StringBuilder sb1 = new StringBuilder();
        sb1.AppendFormat("select LastDate from LastPayoutDate");
        object Date = dal.Getscalar(sb1.ToString(), ref message);
        if (Date is DBNull)
        {
            dd = "No Last Date Found";
        }
        else if (Date != null)
        {
            DateTime dte = Convert.ToDateTime(Date);
            dd = dte.Day + "/" + dte.Month + "/" + dte.Year;

            //ToDate Fill
            int numDays = DateTime.DaysInMonth(dte.Year, dte.Month);
            if (numDays == 31)
            {
                fromdte = dte.AddDays(-16);
                from = Convert.ToDateTime(fromdte).ToString("yyyy-MM-dd");
            }
            else
            {
                fromdte = dte.AddDays(-15);
                from = Convert.ToDateTime(fromdte).ToString("yyyy-MM-dd");
            }
        }
        try
        {
            SqlConnection con = new SqlConnection(connstring);
            SqlCommand cmd;
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Company_Turnover", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FromDate", from);
            cmd.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(Date).ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@Mode", "CTO");
            int flag = cmd.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {

        }
    }
}