﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.IO;
using System.Net;
//using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;
using System.Configuration;
public partial class customer_Dashboard : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    ArrayList UserIDRightList = new ArrayList();
    ArrayList UserIDRightList1 = new ArrayList();
    ArrayList UserIDRightList2 = new ArrayList();
    string message = string.Empty;
    public int countA = 0;
    public int countB = 0;
    string websitename = "";
    int TotalLeftcount = 0;
    int TotalRightcount = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // if (Request.QueryString["UserID"] != null && Request.QueryString["UserID"] != string.Empty)

            if (Session["UserID"] != null)
            {
                string msg = "";
                DAL dal = new DAL();
                DataTable dt = dal.Gettable("select Website from CompanyInfo", ref msg);
                if (dt.Rows.Count > 0)
                {
                    websitename = dt.Rows[0]["Website"].ToString();
                }

                string text = "" + websitename + "/MemberRegistration.aspx?Refferalid=" + Session["UserID"].ToString();

                //   lnkReferalLink.Text = text;
                //   lnkReferalLink.NavigateUrl = text;
                //   lnksend.Text = text;
                
                showname();
                ShowBreakingNews();
                ShowPaidFreeMember();
                activationtimer();
                Showuserlogo();
                //GrowthWallet();
                Wallet();
                LeadershipWallet();
                LevelWallet();
                RoyaltyWallet();
                //directincome();
                //matchingincome();
                latesttransactions();
                Showdesignation();
                //Percent20income();
                showstatus();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }
    public void Showuserlogo()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select PhotoPath from MLM_UserDetail where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                string Logo = dt.Rows[0]["PhotoPath"].ToString();
                if (!string.IsNullOrEmpty(Logo))
                {
                    //byte[] bytes = (byte[])dt.Rows[0]["PhotoPath"];
                    //string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                    //// imglogo.ImageUrl = "data:image/png;base64," + base64String;
                    //Image1.ImageUrl = "data:image/png;base64," + base64String;
                    Image1.ImageUrl = Logo.ToString();
                }
            }
            else
            {
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void activationtimer()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select Convert(nvarchar,PackageDate,105) as PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {

                string dateInString = dt.Rows[0]["PackageDate"].ToString();

                //DateTime startDate = DateTime.Parse(dateInString);
                //DateTime expiryDate = startDate.AddDays(0);
                //DateTime expiryDate1 = startDate.AddDays(15);
                //DateTime upgradetime = startDate.AddDays(5);

                //lblTimer.Text = expiryDate.ToString();
                lblTimer.Text = dateInString.ToString();


                //  lblUpgradetime.Text = upgradetime.ToString();


                //if (DateTime.Now > expiryDate1)
                //{
                //    //... trial expired
                // //   lblTimer.Text = "Activation Time Expired";
                ////    Response.Redirect("auth-recomit.aspx");

                //}
                //if (DateTime.Now > upgradetime)
                //{
                // //   lblUpgradetime.Text = "Booster Time Expired";

                //}
            }
            else
            {
             //   lblname.Text = "Demo";
            }
        }
        catch (Exception ex)
        {
          //  ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }

    }
    public void showname()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            //sb.AppendFormat("select Name,status,CAST(JoinDate as date) as JoinDate,CAST(PackageDate as date) as PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            sb.AppendFormat("select Name,status,JoinDate,PackageDate from MLM_Registration where UserID='{0}'", Session["UserID"].ToString());
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblcustomername.Text = dt.Rows[0]["Name"].ToString();
                //lblUserName.Text = dt.Rows[0]["Name"].ToString();
                // lbljoindate.Text = Convert.ToDateTime(dt.Rows[0]["JoinDate"]).ToString("dd-MM-yyyy");
            //    lblactivationdate.Text = Convert.ToDateTime(dt.Rows[0]["PackageDate"]).ToString("dd-MM-yyyy");
                string status = dt.Rows[0]["status"].ToString();
                if (status == "InActive")
                {
                    Response.RedirectPermanent("~/pages/Status.html");
                }
            }
            else
            {
                lblcustomername.Text = "Company Associate";
            }
        }
        catch (Exception ex)
        {
           /// ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowPaidFreeMember()
    {
        try
        {
            DAL dal = new DAL();
            string LeftUser = null;
            string RightUser = null;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();

                if (LeftUser != null)
                {
                    ShowPaidFreeofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowPaidFreeofteamB(RightUser);
                }

                //lbldownlines.Text = (Convert.ToInt32(lblFree_A.Text) + Convert.ToInt32(lblPaid_A.Text) + Convert.ToInt32(lblPaid_B.Text) + Convert.ToInt32(lblFree_B.Text)).ToString();
            }
        }
        catch (Exception ex)
        {
            //ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowPaidFreeofteamA(string Leftuserid)
    {
        try
        {
            string L = null;
            string R = null;
            string UserID = Leftuserid;
            int membercountpaid = 0;
            int membercountfree = 0;
            double TotalBusinessTeamA = 0;
            double CurrentTotalBusinessTeamA = 0;

            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    object dtcountpaid = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "' and JoinType='Paid'", ref message);
                    if (dtcountpaid != null)
                    {
                        membercountpaid += Convert.ToInt32(dtcountpaid);
                    }
                    object dtcountfree = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "' and JoinType='Free'", ref message);
                    if (dtcountfree != null)
                    {
                        membercountfree += Convert.ToInt32(dtcountfree);
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
            //   lblFree_A.Text = membercountfree.ToString();

            TotalLeftcount = membercountpaid + membercountfree;
            //lblMyteamcount.Text = membercountpaid.ToString();

        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowPaidFreeofteamB(string Rightuserid)
    {
        try
        {
            string L = null;
            string R = null;
            string UserID = Rightuserid;
            int membercountpaid = 0;
            int membercountfree = 0;
            double TotalBusinessTeamB = 0;
            double CurrentTotalBusinessTeamB = 0;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    object dtcountpaid = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "' and JoinType='Paid'", ref message);
                    if (dtcountpaid != null)
                    {
                        membercountpaid += Convert.ToInt32(dtcountpaid);
                    }
                    object dtcountfree = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "' and JoinType='Free'", ref message);
                    if (dtcountfree != null)
                    {
                        membercountfree += Convert.ToInt32(dtcountfree);
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }

            } while (UserID != null);
            //lblFree_B.Text = membercountfree.ToString();
            //lblMyteamcount.Text = membercountpaid.ToString();
            TotalRightcount = membercountpaid + membercountfree;
            lblMyteamcount.Text = (TotalLeftcount + TotalRightcount).ToString();
        }
        catch (Exception)
        {
            throw;
        }
    }
    private void showmydownlines()
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            string LeftUser = null;
            string RightUser = null;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", Session["UserID"]);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                LeftUser = dt.Rows[0]["LLeg"].ToString();
                RightUser = dt.Rows[0]["RLeg"].ToString();

                if (LeftUser != null)
                {
                    ShowMembersofteamA(LeftUser);
                }
                if (RightUser != null)
                {
                    ShowMembersofteamB(RightUser);
                }
                //int totalcount = Convert.ToInt32(hdfleft.Value) + Convert.ToInt32(hdfright.Value);
                //   lbldownlines.Text = totalcount.ToString();
            }
        }
        catch (Exception ex)
        {
            //ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void ShowMembersofteamA(string Leftuserid)
    {
        try
        {
            string L = null;
            string R = null;
            string UserID = Leftuserid;
            int membercount = 0;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    object dtcount = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtcount != null)
                    {
                        membercount += Convert.ToInt32(dtcount);

                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
            } while (UserID != null);
            //hdfleft.Value = membercount.ToString();

        }
        catch (Exception)
        {
            throw;
        }
    }
    public void ShowMembersofteamB(string Rightuserid)
    {
        try
        {
            string L = null;
            string R = null;
            string UserID = Rightuserid;
            int membercount = 0;
            DAL dal = new DAL();
            do
            {
                string message = string.Empty;
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("Select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
                DataTable UserDetail = dal.Gettable(sb.ToString(), ref message);
                if (UserDetail.Rows.Count > 0)
                {
                    L = UserDetail.Rows[0]["LLeg"].ToString();
                    R = UserDetail.Rows[0]["RLeg"].ToString();
                    object dtcount = dal.Getscalar("select COUNT(*) from MLM_Registration where UserID='" + UserID + "'", ref message);
                    if (dtcount != null)
                    {
                        membercount += Convert.ToInt32(dtcount);
                    }
                }
                if (!string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserID = L;
                    UserIDRightList.Add(R);
                }
                if (!string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    UserID = L;
                }
                else if (string.IsNullOrEmpty(L) && !string.IsNullOrEmpty(R))
                {
                    UserIDRightList.Add(R);
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }

                }
                else if (string.IsNullOrEmpty(L) && string.IsNullOrEmpty(R))
                {
                    int count = UserIDRightList.Count;
                    if (count > 0)
                    {
                        string Last = UserIDRightList[count - 1].ToString();
                        UserIDRightList.Remove(Last);
                        UserID = Last;
                    }
                    else
                    {
                        UserID = null;
                    }
                }

            } while (UserID != null);
            //hdfright.Value = membercount.ToString();
        }
        catch (Exception)
        {
            throw;
        }
    }
 
    public void ShowBreakingNews()
    {
        DAL dal = new DAL();
        try
        {
            DataTable dt = dal.Gettable("select * from News where NewsType='Breaking News' order by ID desc", ref message);
            if (dt.Rows.Count > 0)
            {
                string text = string.Empty;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    text += i + 1 + ". " + dt.Rows[i]["News"].ToString();
                    text += "..&nbsp;";
                }
                breakingnews.Text = text;
            }
            else
            {
                breakingnews.Text = "No News Today!";
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "'" + ex.Message + "'", true);
        }
    }
    private void latesttransactions()
    {
        try
        {
            DataTable dt = new DataTable();
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
          
                dt = objDAL.Gettable("Select top 10 ID,UserID,TransactionType,CR,DR,Descriptions,CONVERT(nvarchar,CreationDate,105)As CreationDate,TransferBy From Ledger_Wallet Where UserID='" + UserID + "' order by CreationDate desc", ref message);
           
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
           
        }
    }
    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        latesttransactions();
    }
    public void Wallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                lblMywallet.Text = dt.Rows[0]["WalletAmount"].ToString();
                //lblMywallet1.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblMywallet.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void GrowthWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions='Growth Income' ", ref message);
            if (dt.Rows.Count > 0)
            {
                //lblGrowthwallet.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                //lblGrowthwallet.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void LevelWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions='LEVEL INCOME' ", ref message);
            if (dt.Rows.Count > 0)
            {
                lbllevelincome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lbllevelincome.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void RoyaltyWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions='ROYALTY INCOME' ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblroyalty.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblroyalty.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void LeadershipWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions='LEADERSHIP INCOME' ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblleadershipIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblleadershipIncome.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void RankWallet()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions='RANK INCOME' ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblrank.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                lblrank.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void directincome()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions in ('Main Wallet','Pin Purchased.') ", ref message);
            if (dt.Rows.Count > 0)
            {
                //lblMainIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                //lblMainIncome.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void matchingincome()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions in ('Crowd Wallet','Deduction','From Silver','Director Deduction','From Director','Sapphire Deduction','From Sapphire')", ref message);
            if (dt.Rows.Count > 0)
            {
               // lblCrowdIncome.Text = dt.Rows[0]["WalletAmount"].ToString();
            }
            else
            {
                //lblCrowdIncome.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void Showdesignation()
    {
        try
        {
            string UserID = Session["UserID"].ToString();
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select Designation from MLM_Registration Where UserID='" + Session["UserID"].ToString() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                lbldesignation.Text = dt.Rows[0]["Designation"].ToString();
                if(lbldesignation.Text=="0")
                {
                    lbldesignation.Text = "All THE BEST";
                }
                else
                {
                    lbldesignation.Text = dt.Rows[0]["Designation"].ToString().ToUpper();
                }
            }
            else
            {
                lbldesignation.Text = "0";
            }
        }
        catch (Exception ex)
        {

        }
    }

    public void Percent20income()
    {
        try
        {
            string UserID = Session["UserID"].ToString();

            if (UserID.ToUpper().ToString() == "TOP")
            {
                DAL objDAL = new DAL();
                DataTable dt = objDAL.Gettable("Select (COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount From Ledger_Wallet Where UserID='" + Session["UserID"].ToString() + "' and Descriptions='20% Income' ", ref message);
                if (dt.Rows.Count > 0)
                {
                    //lblincome.Text = dt.Rows[0]["WalletAmount"].ToString();
                }
                else
                {
                    //lblincome.Text = "0";
                }
            }
            else
            {
                divIncome.Visible = false;
            }

           
        }
        catch (Exception ex)
        {

        }
    }

    public void showstatus()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Select JoinType from MLM_Registration where UserID ='" + Session["UserID"].ToString() + "'");
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            string Status = dt.Rows[0]["JoinType"].ToString();
            if (Status == "Paid")
            {
                lblactive.Text = "Activate";
                imgstatus.ImageUrl = "assets/images/G.png";

            }
            else
            {
                lblactive.Text = "Inactivate";
                imgstatus.ImageUrl = "assets/images/R.png";
            }

        }
        else
        {
            lblactive.Text = "INACTIVE";
            imgstatus.ImageUrl = "assets/images/R.png";
        }
    }



}