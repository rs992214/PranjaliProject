﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using System.IO;
using System.Net;
using DataAccessLayer;
using System.Web.Script.Serialization;

public partial class Company_Composesms : System.Web.UI.Page
{
    
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
       
            if (!IsPostBack)
            {
                if (Session["UserName"] != null)
                {
                    showsmssender();
                    showtemplate();
                    ShowData();
                    
            }
                else
                {
                    Response.Redirect("Logout.aspx");
                }
            }
                 
    }

    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    static string Status = string.Empty;
    public void showsmssender()
      {
          DAL dal = new DAL();

          try
          {
              DataTable dt = dal.Gettable("select * from Smsmaster", ref message);
              if (dt.Rows.Count > 0)
              {
                  userid = dt.Rows[0]["Userid"].ToString();
                  password = dt.Rows[0]["Password"].ToString();
                  senderid = dt.Rows[0]["Senderid"].ToString();
                  route = dt.Rows[0]["Routeid"].ToString();
                  Status = dt.Rows[0]["Status"].ToString();
                    if (Status=="Inactive")
                 {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('SMS is In inactive Mode.Change the Status From SMS Matser')", true);
                        Button1.Enabled = false;
                 }
                else
                {
                    Button1.Enabled = true;
                }
              }
              else
             {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Configure SMS Setting First.')", true);
                Button1.Enabled = false;
             }
          }
          catch (Exception ex)
          {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
          }
      }

    private void ShowData()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
           
                if (drpmemebertype.SelectedValue=="0")
                {
                    sb.AppendFormat("select Name,Mobile from MLM_Registration order by Name");
                }
                else if (drpmemebertype.SelectedValue == "1")
                {
                    sb.AppendFormat("select Name,Mobile from MLM_Registration where Status='Active' order by Name");
                }
                else if (drpmemebertype.SelectedValue == "2")
                {
                    sb.AppendFormat("select Name,Mobile from MLM_Registration where Status='InActive' order by Name ");
                }  
           
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                GridView1.PageSize = dt.Rows.Count;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        ShowData();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        ShowData();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        DAL dal = new DAL();
        string message = string.Empty;
       
        foreach (GridViewRow row in GridView1.Rows)
        {
            CheckBox chk = (CheckBox)row.Cells[0].FindControl("chkbox");
             if (chk.Checked == true && txtmessage.Text != string.Empty)
             {
                        string name = row.Cells[1].Text;
                        string mobile = row.Cells[2].Text;
                        StringBuilder sb = new StringBuilder();
                        sb.AppendLine("insert into SMSHistory(Name,MobileNo,Message)");
                        sb.AppendFormat("values('{0}','{1}','{2}')", name, mobile, txtmessage.Text);

                        try
                        {
                            int rowaffected = dal.Executequery(sb.ToString(), ref message);
                           
                            if (rowaffected > 0)
                            {
                               
                                string sURL;
                                StreamReader objReader;
                                sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username="+userid+"&password="+password+"&sender=" + senderid + "" + "&to=" + mobile + "&message=" + txtmessage.Text + " &reqid=1&format={json|text}&route_id="+route+"";
                                WebRequest wrGETURL;
                                wrGETURL = WebRequest.Create(sURL);

                                try
                                {
                                    Stream objStream;
                                    objStream = wrGETURL.GetResponse().GetResponseStream();
                                    objReader = new StreamReader(objStream);
                                    objReader.Close();
                                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Message Send Successfully')", true);

                                }
                                catch (Exception ex)
                                {
                                    ex.ToString();
                                }
                            }
                            else
                            {
                                  ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('"+message+"')", true);
                            }
                        }
                        catch (Exception ex)
                        {
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('"+ex.Message+"')", true);
                        }
             }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Proper Information')", true);
            }
        }
    }
              
    protected void Button2_Click(object sender, EventArgs e)
    {
       /* if(RadioButton1.Checked==true)
        {
            try
            {
                DataTable dt = bal.showempdetailsearch(txtsearch.Text,ref message);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                  
                }
                else
                {
                    GridView1.DataSource = null;
                    GridView1.DataBind();
                    GridView1.EmptyDataText = "No Record Found";
                }
            }
            catch (Exception ex)
            {
            }
        }
        else
        {
            bal.session = drpsession.SelectedItem.Text;
            bal.standard = drpstandard.SelectedItem.Text;
            bal.section = drpsection.SelectedItem.Text;
            bal.firstname = txtsearch.Text;
            try
            {
                DataTable dt = bal.showstudentsmssearch(ref message);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();

                }
                else
                {
                    GridView1.DataSource = null;
                    GridView1.DataBind();
                    GridView1.EmptyDataText = "No Record Found";
                }
            }
            catch (Exception ex)
            {
            }
        }*/
    }
    public void showtemplate()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select Template from Template order by TemplateID desc");
        try
        {
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                grdtemplates.DataSource = dt;
                grdtemplates.DataBind();
            }
            else
            {
                grdtemplates.DataSource = null;
                grdtemplates.DataBind();
            }
        }
        catch (Exception ex)
        {
 
        }
    }
    protected void grdtemplates_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtmessage.Text = grdtemplates.SelectedRow.Cells[0].Text;
    }
    protected void btntemplate_Click(object sender, EventArgs e)
    {
        popup.Show();
    }

    
}