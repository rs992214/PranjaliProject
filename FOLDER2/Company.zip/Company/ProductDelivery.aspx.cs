﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_ProductDelivery : System.Web.UI.Page
{
    string userid = string.Empty;
    string status = string.Empty;
    string mobile = string.Empty;
    string message = string.Empty;
    string UserName = "";
    string password1 = "";
    string loginip = GetLocalIPAddress();

    DAL dal = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        AdminLoginInfo();
            if (!IsPostBack)
            {
                GetData();
                showinfo();
            }
    }
    private void GetData()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,PackageDate from MLM_Registration where JoinType='Paid'", ref message);
            if (dt.Rows.Count > 0)
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }
            else
            {
                GV1.DataSource = null;
                GV1.DataBind();
            }
        }
        catch (Exception ex)
        {
           
        }
    }
    void GetStatus()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
        string SQL = "Select ProductDeliveryStatus,Mobile from MLM_Registration where UserID='" + userid + "'";
        SqlCommand cmd = new SqlCommand(SQL, con);
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            status = reader["ProductDeliveryStatus"].ToString();
            mobile = reader["Mobile"].ToString();
        }
        reader.Close();
        con.Close();
    }

    protected void GV1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
           if (e.CommandName == "Pending")
           {
            userid = e.CommandArgument.ToString();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
            string SQL = "Update MLM_Registration set ProductDeliveryStatus='Pending' where UserID='"+ userid + "'";
            SqlCommand cmd = new SqlCommand(SQL, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            InsertPending();
            GetStatus();
            SMS();
            }
            else if(e.CommandName == "Dispatched")
            {
                userid = e.CommandArgument.ToString();
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
                string SQL = "Update MLM_Registration set ProductDeliveryStatus='Dispatched' where UserID='" + userid + "'";
                SqlCommand cmd = new SqlCommand(SQL, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                InsertDispatch();
                GetStatus();
                SMS();
            }
           else if (e.CommandName == "Delivered")
            {
            userid = e.CommandArgument.ToString();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
            string SQL = "Update MLM_Registration set ProductDeliveryStatus='Delivered' where UserID='" + userid + "'";
            SqlCommand cmd = new SqlCommand(SQL, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            InsertDelivered();
            GetStatus();
            SMS();
            }
        }
        catch (Exception ex)
        {
            string error = ex.ToString();
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);
            try
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Error:"+error+"')", con);
                cmd.CommandType = CommandType.Text;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {

                }
            }
            catch (Exception ex1)
            {

            }
            finally
            {
                con.Close();
            }

        }
        finally
        {
            Response.Redirect("ProductDelivery.aspx");
        }
    }

    protected void GV1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            userid = (e.Row.Cells[1].Text);
            GetStatus();
            LinkButton btnPending = e.Row.FindControl("btnPending") as LinkButton;
            LinkButton btnDelivered = e.Row.FindControl("btnDelivered") as LinkButton;
            LinkButton btnDispatched = e.Row.FindControl("btnDispatched") as LinkButton;
            if (status == "Pending")
            {
                btnDispatched.Visible = true;
            }
            else if (status == "Dispatched")
            {
                btnDelivered.Visible = true;
            }
            else if (status == "Delivered")
            {
            }
            else
            {
                btnPending.Visible = true;
            }
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex > 0)
        {
            GetStatus();
            if (DropDownList1.SelectedIndex == 1)
            {
                DAL objDAL = new DAL();
                DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,PackageDate from MLM_Registration where ProductDeliveryStatus='Pending'", ref message);
                GV1.DataSource = dt;
                GV1.DataBind();
            }
            else if(DropDownList1.SelectedIndex == 2)
            {
                DAL objDAL = new DAL();
                DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,PackageDate from MLM_Registration where ProductDeliveryStatus='Dispatched'", ref message);
                GV1.DataSource = dt;
                GV1.DataBind();
            }
            else
            {
                DAL objDAL = new DAL();
                DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,PackageDate from MLM_Registration where ProductDeliveryStatus='Delivered'", ref message);
                GV1.DataSource = dt;
                GV1.DataBind();
            }

        }
        else
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,PackageDate from MLM_Registration where JoinType='Paid'", ref message);
            if (dt.Rows.Count > 0)
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }
            else
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        if (txtfromdate.Text != string.Empty && txttodate.Text != string.Empty)
        {

        if (DropDownList1.SelectedIndex == 0)
        {
        //string[] dte = txtfromdate.Text.Split('/');
        //string[] dte1 = txttodate.Text.Split('/');
        //string joinstring = "/";
        //string date1 = dte[2] + joinstring + dte[1] + joinstring + dte[0];
        //string date2 = dte1[2] + joinstring + dte1[1] + joinstring + dte1[0];
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,convert(nvarchar(50),PackageDate,103) as PackageDate from MLM_Registration where PackageDate between '" + txtfromdate.Text + "'" + " and '" + txtfromdate.Text + "'" , ref message);
        if (dt.Rows.Count > 0)
        {
            GV1.DataSource = dt;
            GV1.DataBind();
        }
        else
        {
            GV1.DataSource = dt;
            GV1.DataBind();
        }
        }
        else if(DropDownList1.SelectedIndex == 1)
        {
            //string[] dte = txtfromdate.Text.Split('/');
            //string[] dte1 = txttodate.Text.Split('/');
            //string joinstring = "/";
            //string date1 = dte[2] + joinstring + dte[1] + joinstring + dte[0];
            //string date2 = dte1[2] + joinstring + dte1[1] + joinstring + dte1[0];
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,convert(nvarchar(50),PackageDate,103) as PackageDate from MLM_Registration where ProductDeliveryStatus='Pending' and PackageDate between '" + txtfromdate.Text + "'" + " and '" + txttodate.Text + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }
            else
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }
        }
        else if(DropDownList1.SelectedIndex == 2)
        {
            //string[] dte = txtfromdate.Text.Split('/');
            //string[] dte1 = txttodate.Text.Split('/');
            //string joinstring = "/";
            //string date1 = dte[2] + joinstring + dte[1] + joinstring + dte[0];
            //string date2 = dte1[2] + joinstring + dte1[1] + joinstring + dte1[0];
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,convert(nvarchar(50),PackageDate,103) as PackageDate from MLM_Registration where ProductDeliveryStatus='Dispatched' and PackageDate between '" + txtfromdate.Text + "'" + " and '" + txttodate.Text + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }
            else
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }
        }
        else if(DropDownList1.SelectedIndex == 3)
        {
            //string[] dte = txtfromdate.Text.Split('/');
            //string[] dte1 = txttodate.Text.Split('/');
            //string joinstring = "/";
            //string date1 = dte[2] + joinstring + dte[1] + joinstring + dte[0];
            //string date2 = dte1[2] + joinstring + dte1[1] + joinstring + dte1[0];
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select UserID,Package,ProductDeliveryStatus,convert(nvarchar(50),PackageDate,103) as PackageDate from MLM_Registration where ProductDeliveryStatus='Delivered' and PackageDate between '" + txtfromdate.Text + "'" + " and '" + txtfromdate.Text + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }
            else
            {
                GV1.DataSource = dt;
                GV1.DataBind();
            }

            }
        }
    }

    static string userId = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    static string Status = string.Empty;
    public void showinfo()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from Smsmaster", ref message);
            if (dt.Rows.Count > 0)
            {
                userId = dt.Rows[0]["Userid"].ToString();
                password = dt.Rows[0]["Password"].ToString();
                senderid = dt.Rows[0]["Senderid"].ToString();
                route = dt.Rows[0]["Routeid"].ToString();
                Status = dt.Rows[0]["Status"].ToString();
                if (Status == "Inactive")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('SMS is In inactive Mode.Change the Status From SMS Matser')", true);
                }
                else
                {
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Configure SMS Setting First.')", true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    void SMS()
    {
        if (status == "Pending")
        {
            string Message = "Dear Member, Your order has been ready for dispatch by Admin.";
            string strUrl = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userId + "&password=" + password + "&sender=" + senderid + "" + "&to=" + mobile + "&message=" + Message + " &reqid=1&format={json|text}&route_id=" + route + "";
        // Create a request object  
        WebRequest request = HttpWebRequest.Create(strUrl);
        // Get the response back  
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        Stream s = (Stream)response.GetResponseStream();
        StreamReader readStream = new StreamReader(s);
        string dataString = readStream.ReadToEnd();
        response.Close();
        s.Close();
        readStream.Close();
        }
        else if(status=="Dispatched")
        {
            string Message1 = "Dear Member, Your Order has been dispatched successfully by Admin.";
            string strUrl = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userId + "&password=" + password + "&sender=" + senderid + "" + "&to=" + mobile + "&message=" + Message1 + " &reqid=1&format={json|text}&route_id=" + route + "";
            // Create a request object  
            WebRequest request = HttpWebRequest.Create(strUrl);
            // Get the response back  
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream s = (Stream)response.GetResponseStream();
            StreamReader readStream = new StreamReader(s);
            string dataString = readStream.ReadToEnd();
            response.Close();
            s.Close();
            readStream.Close();
        }
        else if(status == "Delivered")
        {
            string Message2 = "Dear Member, Your Order has been delivered successfully.";
            string strUrl = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userId + "&password=" + password + "&sender=" + senderid + "" + "&to=" + mobile + "&message=" + Message2 + " &reqid=1&format={json|text}&route_id=" + route + "";
            // Create a request object  
            WebRequest request = HttpWebRequest.Create(strUrl);
            // Get the response back  
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream s = (Stream)response.GetResponseStream();
            StreamReader readStream = new StreamReader(s);
            string dataString = readStream.ReadToEnd();
            response.Close();
            s.Close();
            readStream.Close();
        }
    }
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName = dt.Rows[0]["UserName"].ToString();
                password1 = dt.Rows[0]["password"].ToString();

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }
    public void InsertPending()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Status:ProductDeliveryStatus=Pending for " + userid+"')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }
    public void InsertDispatch()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Status:ProductDeliveryStatus=Dispatched for " + userid + "')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }
    public void InsertDelivered()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Status:ProductDeliveryStatus=Delivered for " + userid + "')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }


}