﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Web.Script.Serialization;

public partial class Company_Setting : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            showPlanSetting();
        }

    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("insert into PlanSetting(AdminCharge,TDS,servicecharge,cess)");
            sb.AppendFormat("values('{0}','{1}','{2}','{3}')",txtadmincharge.Text,txttds.Text,txtservice.Text,txtcess.Text);
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected>0)
            {
                Response.Redirect("SuccessView.aspx?Link=Setting.aspx");
                // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Plan Setting Save Successfully')", true);
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
        Clear();
        showPlanSetting();
    }
    private void showPlanSetting()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select AdminCharge,TDS,servicecharge as ServiceCharge,cess as Cess from PlanSetting");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                btnsave.Enabled = false;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnsave.Enabled = true;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    private void Clear()
    {
        txtadmincharge.Text = null;
        txttds.Text = null;
        txtcess.Text = null;
        txtservice.Text = null;
    }

   

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            //string ID = GridView1.DataKeys[e.RowIndex].Values["ID"].ToString();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Delete from PlanSetting");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected>0)
            {
                Response.Redirect("SuccessView.aspx?Link=Setting.aspx");
                // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Plan Setting Information Deleted Successfully')", true);
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
        showPlanSetting();
    }
}