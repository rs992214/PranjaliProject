﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_News : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["ID"]))
            {
                ViewState["ID"] = Request.QueryString["ID"].ToString();
                ShowNewsDetail();
                btnsave.Text = "Update";
            }
            else
            {
                btnsave.Text = "Save";
            }
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtNews.Text != string.Empty && ddlType.SelectedValue != "0")
            {
                if (btnsave.Text == "Save")
                {
                    int rowaffected = dal.Executequery("Insert into News (News,NewsType) values ('" + txtNews.Text + "','" + ddlType.SelectedItem.Text + "')", ref message);
                    if (rowaffected > 0)
                    {
                        Response.Redirect("SuccessView.aspx?Link=News.aspx");
                       // ShowPopupMessage("News Added Successfully.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Error);
                    }
                }
                else
                {
                    int rowaffected = dal.Executequery("Update News set News='" + txtNews.Text + "',NewsType='" + ddlType.SelectedItem.Text + "' where ID='" + ViewState["ID"].ToString() + "'", ref message);
                    if (rowaffected > 0)
                    {
                        ShowPopupMessage("News Updated Successfully.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message, PopupMessageType.Error);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        finally
        {
            Clear();
        }
    }
    public void ShowNewsDetail()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from News where ID='" + ViewState["ID"].ToString() + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                txtNews.Text = dt.Rows[0]["News"].ToString();
                ddlType.ClearSelection();
                ddlType.Items.FindByText(dt.Rows[0]["NewsType"].ToString()).Selected = true;
            }
            else
            {
                Clear();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "'" + ex.Message + "'", true);
        }
    }
    public void Clear()
    {
        txtNews.Text = string.Empty;
        ddlType.ClearSelection();
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

}