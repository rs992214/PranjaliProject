﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_VideoGallery : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                //txtID.Text = GetUniqueKey(6).ToString();
                //GetPinNo();
                //txtID.ReadOnly = true;

                ShowData();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }

        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
            SqlConnection con = new SqlConnection(connstring);

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into VideoGallery(Name,Videos,Status,Date) values('" + txtName.Text + "','" + txtlink.Text + "','" + drpstatus.SelectedItem.Text + "',GETDATE())", con);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //sda.Fill(dt);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                Response.Write("<script>alert('Data Inserted Sucessfully...!!')</script>");

            }
            else
            {
                Response.Write("<script>alert('Data Not Inserted ...!!')</script>");
            }


        }
        catch (Exception ex)
        {

        }
        finally
        {
            Reset();
            ShowData();
        }

    }
    void ShowData()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select ID,Name,Videos,Status,Date from VideoGallery", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {

        }

    }
    void Reset()
    {
        txtName.Text = string.Empty;
        txtlink.Text = string.Empty;
        drpstatus.SelectedIndex = -1;
        //GetPinNo();
    }


    protected void btnEdit_Command(object sender, CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        ViewState["ID"] = id;


        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from VideoGallery where ID='" + id + "'", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                btnAdd.Visible = false;
                btncancel.Visible = false;
                btnupdate.Visible = true;
                txtName.Text = dt.Rows[0]["Name"].ToString();
                txtlink.Text = dt.Rows[0]["Videos"].ToString();
                drpstatus.SelectedItem.Text = dt.Rows[0]["Status"].ToString();
                //imgUpdate.ImageUrl = dt.Rows[0]["Images"].ToString();

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            
            con.Open();
            SqlCommand cmd = new SqlCommand("update VideoGallery set Name='" + txtName.Text + "',Videos='" + txtlink.Text + "',Status='" + drpstatus.SelectedItem.Text + "' where ID='" + ViewState["ID"].ToString() + "' ", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();

            if (a > 0)
            {
                Response.Write("<script>alert('Record Updated Sucessfully...!!')</script>");
                ShowData();
            }
            else
            {
                Response.Write("<script>alert('Record Not Updated Sucessfully...!!')</script>");
            }


        }
        catch (Exception ex)
        {

        }

        finally
        {

            con.Close();

            clear();


        }
    }
    public void clear()
    {
        txtlink.Text = "";
        txtName.Text = "";
        drpstatus.SelectedItem.Text = "Select Status";

    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Reset();
    }
}