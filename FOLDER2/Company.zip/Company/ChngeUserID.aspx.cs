﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Text;
using System.Data;
using System.Web.Script.Serialization;

public partial class Company_ChngeUserID : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
               
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    protected void btnchange_Click(object sender, EventArgs e)
    {
        try
        {
            ChangeUserIDproperty CUP = new ChangeUserIDproperty { OldUserID = txtoldaccountno.Text, NewUserID = txtnewaccountno.Text };
            ChangeUserIDLogic CUL = new ChangeUserIDLogic();
           int rowaffected= CUL.ChangeUserID(CUP, ref message);
            if (rowaffected>0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Account Number Change Successfully')", true);
                txtnewaccountno.Text = null;
                txtoldaccountno.Text = null;
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);

        }
    }

    protected void txtoldaccountno_TextChanged(object sender, EventArgs e)
    {
        showAccountdetail();
    }
    private void showAccountdetail()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select Name from MLM_Registration where UserID='{0}'", txtoldaccountno.Text);
            object obj = dal.Getscalar(sb.ToString(), ref message);
            if (obj is DBNull)
            {
                lblname.Text = "Invalid Account Number.";
                btnchange.Enabled = false;
                lblname.ForeColor = System.Drawing.Color.Red;
            }
            else if (obj != null)
            {
                lblname.Text = obj.ToString();
                btnchange.Enabled = true;
                lblname.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblname.Text = "Invalid Account Number.";
                btnchange.Enabled = false;
                lblname.ForeColor = System.Drawing.Color.Red;
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
}