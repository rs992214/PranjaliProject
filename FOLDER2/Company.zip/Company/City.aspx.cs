﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;

public partial class Company_City : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ShowStateName();
            ShowCityName();
            btnupdate.Visible = false;
        }
    }
    public void ShowStateName()
    {
        drpstate.DataTextField = "StateName";
        drpstate.DataValueField = "StateID";
        drpstate1.DataTextField = "StateName";
        drpstate1.DataValueField = "StateID";
        State St = new State();
        DataTable dt= St.GetData(ref message);
        if (dt.Rows.Count>0)
        {
            drpstate.DataSource = dt;
            drpstate.DataBind();
            drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));
            drpstate1.DataSource = dt;
            drpstate1.DataBind();
            drpstate1.Items.Insert(0, new ListItem("Select State Name", "0"));
        }
        else
        {
            drpstate.DataSource =null;
            drpstate.DataBind();
            drpstate.Items.Insert(0, new ListItem("Select State Name", "0"));
            drpstate1.DataSource = null;
            drpstate1.DataBind();
            drpstate1.Items.Insert(0, new ListItem("Select State Name", "0"));
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        CityProperty Cp = new CityProperty();
        Cp.StateID =Convert.ToInt32(drpstate.SelectedValue);
        Cp.CityName = txtcity.Text;
        City Cty = new City();
        try
        {
          int rowaffetced=  Cty.SaveCity(Cp, ref message);
            if (rowaffetced>0)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "City Save Successfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowCityName();
        }

    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        CityProperty Cp = new CityProperty();
        Cp.StateID = Convert.ToInt32(drpstate.SelectedValue);
        Cp.CityID = Convert.ToInt32(ViewState["CityID"]);
        Cp.CityName = txtcity.Text;
        try
        {
            City cty = new City();
            int rowaffected = cty.UpdateCity(Cp, ref message);
            if (rowaffected > 0)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "City Updated Successfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowCityName();
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        drpstate.SelectedIndex = 0;
        txtcity.Text = string.Empty;
        btnsave.Visible = true;
        btnupdate.Visible = false;
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        CityProperty Cp = new CityProperty();
        Cp.CityName = txtsearch.Text;
        try
        {
            City cty = new City();
            DataTable dt= cty.SearchData(Cp, ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                drpstate1.SelectedValue = dt.Rows[0]["StateID"].ToString();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

        }
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowCityName();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        CityProperty Cp = new CityProperty();
        Cp.CityID = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values["CityID"].ToString());
        try
        {
            City cty = new City();
            int rowaffected = cty.DeleteCity(Cp, ref message);
            if (rowaffected > 0)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "City Deleted Successfully";
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            }
        }
        catch (Exception ex)
        {
            lblmsg.Visible = true;
            lblmsg.BackColor = System.Drawing.Color.White;
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = ex.Message;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
        }
        finally
        {
            ShowCityName();
        }

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpstate.SelectedValue = drpstate1.SelectedValue;
        ViewState["CityID"] = GridView1.SelectedRow.Cells[0].Text;
        txtcity.Text= GridView1.SelectedRow.Cells[1].Text;
        btnsave.Visible = false;
        btnupdate.Visible = true;
    }

    public void ShowCityName()
    {
        if (drpstate1.SelectedIndex > 0)
        {
            CityProperty Cp = new CityProperty();
            Cp.StateID = Convert.ToInt32(drpstate1.SelectedValue);
            try
            {
                City cty = new City();
                DataTable dt= cty.GetData(Cp, ref message);
                if (dt.Rows.Count>0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {
                    GridView1.DataSource = null;
                    GridView1.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblmsg.Visible = true;
                lblmsg.BackColor = System.Drawing.Color.White;
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = ex.Message;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);

            }
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> getcityname(string prefixText)
    {
        List<string> name = new List<string>();
        DAL dal = new DAL();
        string message = string.Empty;
        try
        {
            StringBuilder sbb = new StringBuilder();
            sbb.AppendFormat("select CityName from City where CityName like'{0}%'", prefixText);

            DataTable dt = dal.Gettable(sbb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    name.Add(dt.Rows[i][0].ToString());
                }

            }
        }

        catch (Exception)
        {
            throw;
        }
        return name;
    }


    protected void drpstate1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowCityName();
    }
}