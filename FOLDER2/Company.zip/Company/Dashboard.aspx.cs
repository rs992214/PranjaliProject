﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.IO;
using System.Configuration;
using System.Net;
using System.Text;
using DataAccessLayer;
using System.Web.Script.Serialization;

public partial class Dashboard : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                GetDate();
                date = date1.ToString();
                showsmssender();
                paidmemberuserlist();
                freememberuserlist();
                Inactiveuserlist();
                todayjoin();
                TotalCollectionWithGst();
                TotalCollectionWithoutGst();
                GetTotalPin();
                todayjoinPaid();
                todayjoinPaidAmount();
                TotalOngoingWithdrawal();
                TotalGst();
                PrintChart();
                
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void PrintChart()
    {
        System.Text.StringBuilder sb = new StringBuilder();
        sb.AppendFormat("MemberChart(" + lblfreemeber.Text + ", " + lblpaidmemeber.Text + ");");
        sb.AppendFormat("MemberCollectionChart(" + lblsuperinactive.Text + ", " + lbltotwith.Text + ", " + lbloutgingwith.Text + ");");
        //sb.AppendFormat("MyDownlineLevelWise(" + Label0.Text + ", " + Label1.Text + ", " + Label2.Text + ", " + Label3.Text + ", " + Label4.Text + ", " + Label5.Text + ", " + Label6.Text + ", " + Label7.Text + ", " + lbltotalteam.Text + ");");
        ScriptManager.RegisterStartupScript(this, this.GetType(), "", sb.ToString(), true);
        //ScriptManager.RegisterStartupScript(this, this.GetType(), "", "myFunction(20, 25, 25, 10 ,20);MyDownlineLevelWise(" + Label0.Text + ", " + Label1.Text + ", " + Label2.Text + ", " + Label3.Text + ", " + Label4.Text + ", " + Label5.Text + ", " + Label6.Text + ", " + Label7.Text + ", " + lbltotalteam.Text + ");", true);        
    }

    // Stockist Listing Code

    public void paidmemberuserlist()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select count(*) from MLM_Registration where JoinType='Paid' and PackageDate between '" + date+"' and Cast(GetDate() as Date)");
        try
        {
            object ActiveList = dal.Getscalar(sb.ToString(), ref message);
            if (ActiveList != null)
            {
                int Count = Convert.ToInt32(ActiveList);
                if (DBNull.Value.Equals(Count))
                {
                    lblpaidmemeber.Text = "0";
                }
                else
                {
                    lblpaidmemeber.Text = Count.ToString();
                }
            }
            else
            {
                lblpaidmemeber.Text = "0";
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void freememberuserlist()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select count(*) from MLM_Registration where JoinType='Free' and Cast(JoinDate as Date) between '" + date + "' and Cast(GetDate() as Date)");
        try
        {
            object inActiveList = dal.Getscalar(sb.ToString(), ref message);
            if (inActiveList != null)
            {
                int Count = Convert.ToInt32(inActiveList);
                if (DBNull.Value.Equals(Count))
                {
                    lblfreemeber.Text = "0";
                }
                else
                {
                    lblfreemeber.Text = Count.ToString();
                }
            }
            else
            {
                lblfreemeber.Text = "0";
            }
        }
        catch (Exception)
        {

        }
    }
    public void Inactiveuserlist()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select count(*) from MLM_Registration where Status='InActive' and Cast(JoinDate as Date) between '" + date + "' and Cast(GetDate() as Date) ");
        try
        {
            object inActiveList = dal.Getscalar(sb.ToString(), ref message);
            if (inActiveList != null)
            {
                int Count = Convert.ToInt32(inActiveList);
                if (DBNull.Value.Equals(Count))
                {
                    lblinacrivemember.Text = "0";
                }
                else
                {
                    lblinacrivemember.Text = Count.ToString();
                }
            }
            else
            {
                lblinacrivemember.Text = "0";
            }
        }
        catch (Exception)
        {

        }
    }
    public void todayjoin()
    {
        StringBuilder sb = new StringBuilder();
        // sb.AppendFormat("select CAST(Count(*)*(pack.Amount) as decimal(18,2)) as total from MLM_Registration as MR inner join PackageInfo as Pack on mr.package = Pack.PackageName group by pack.Amount where MR.packageDate between '{0}' and '{0}' group by pack.Amount", System.DateTime.Now.ToString("yyyy-MM-dd"));
          sb.AppendFormat("select count(*)as todays from MLM_Registration where cast(JoinDate as date)='" + DateTime.Now.ToString("yyyy-MM-dd") + "'");
        //sb.Append("select count(*)as todays from MLM_Registration where cast(JoinDate as date) Between (Select LastDate From LastPayoutDate) and (Select DATEADD(DAY,15,LastDate)from LastPayoutDate )");
        try
        {
            object ActiveList = dal.Getscalar(sb.ToString(), ref message);
            if (!DBNull.Value.Equals(ActiveList))
            {
                if (ActiveList != null)
                {
                    int Count = Convert.ToInt32(ActiveList);

                    lblTodayjoin.Text = Count.ToString();
                }
                else
                {
                    lblTodayjoin.Text = "0";
                }
            }
            else
            {
                lblTodayjoin.Text = "0";
            }
        }
        catch (Exception)
        {

        }
    }
    public void TotalCollectionWithGst()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select CAST(Count(*)*(pack.Amount) as decimal(18,2)) as total from MLM_Registration as MR inner join PackageInfo as Pack on mr.package = Pack.PackageName and Cast(PackageDate as Date) between '"+date+"' and Cast(GetDate() as Date) And JoinType='Paid'  group by pack.Amount");
        try
        {
            object inActiveList = dal.Getscalar(sb.ToString(), ref message); 
            if (inActiveList != null)
            {
                int Count = Convert.ToInt32(inActiveList);
                if (DBNull.Value.Equals(Count))
                {
                    lblsuperinactive.Text = "0";
                }
                else
                {
                    lblsuperinactive.Text = Count.ToString();
                }
            }
            else
            {
                lblsuperinactive.Text = "0";
            }
        }
        catch (Exception)
        {

        }
    }

    string date = string.Empty;
    public void TotalCollectionWithoutGst()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Select (COALESCE(SUM(Amount),0))As WalletAmount From WithdrawalRequest where CreationDate between '" + date+"' and Cast(GETDATE() as Date) And Status='Approved'");
        try
        {
            object inActiveList = dal.Getscalar(sb.ToString(), ref message);
            if (inActiveList != null)
            {
                int Count = Convert.ToInt32(inActiveList);
                if (DBNull.Value.Equals(Count))
                {
                    lbltotwith.Text = "0";
                }
                else
                {
                    lbltotwith.Text = Count.ToString();
                }
            }
            else
            {
                lbltotwith.Text = "0";
            }
        }
        catch (Exception)
        {

        }
    }

    public void TotalOngoingWithdrawal()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("Select (COALESCE(SUM(Amount),0))As WalletAmount From WithdrawalRequest where CreationDate between '" + date + "' and Cast(GETDATE() as Date) and Status='REQUEST'");
        try
        {
            object inActiveList = dal.Getscalar(sb.ToString(), ref message);
            if (inActiveList != null)
            {
                int Count = Convert.ToInt32(inActiveList);
                if (DBNull.Value.Equals(Count))
                {
                    lbloutgingwith.Text = "0";
                }
                else
                {
                    lbloutgingwith.Text = Count.ToString();
                }
            }
            else
            {
                lbloutgingwith.Text = "0";
            }
        }
        catch (Exception)
        {

        }
    }
    private void GetTotalPin()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select COUNT(PinNo)As Total From PinGenerateNew ", ref message);
            if (dt.Rows.Count > 0)
            {
                lblTotalPin.Text = dt.Rows[0]["Total"].ToString();
            }
            else
            {
                lblTotalPin.Text = "0";
            }
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        Random rnd = new Random();
        Session["randomnumber"] = (rnd.Next(100000, 999999)).ToString();
        string no = Session["randomnumber"].ToString();
        SendMsg();
        ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "openModal();", true);
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        try
        {
            if (Session["randomnumber"].ToString() == txtOtp.Text)
            {
                SqlCommand cmd = new SqlCommand("RESET_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                int flag = cmd.ExecuteNonQuery();
                if (flag > 0)
                {
                    //ClientScript.RegisterStartupScript(this.GetType(), "Success", "<script type='text/javascript'>alert('You have successfully reset your data!');window.location='Dashboard.aspx';</script>'",true);
                    //Response.Write("<script>alert('You have successfully reset your data.')</script>");
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('You have successfully reset your data!')", true);
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "openModal();", true);
                    txtOtp.Text = string.Empty;
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "closeModal();", true);
            }
        }
        catch (Exception ex)
        {
            var errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            con.Close();
        }
    }
    public void SendMsg()
    {
        string text = Session["randomnumber"].ToString() + " is your OTP to verify your account. Thank You,\n SQUADCAN TEAM.";
        try
        {
            string sURL;
            StreamReader objReader;
            sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + userid + "&password=" + password + "&sender=" + senderid + "&to=" + hdfMobileNo.Value + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + route + "";
            WebRequest wrGETURL;
            wrGETURL = WebRequest.Create(sURL);

            try
            {
                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                objReader.Close();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    static string userid = string.Empty;
    static string password = string.Empty;
    static string senderid = string.Empty;
    static string route = string.Empty;
    public void showsmssender()
    {
        try
        {
            DataTable dt = dal.Gettable("select * from Smsmaster", ref message);
            if (dt.Rows.Count > 0)
            {
                userid = dt.Rows[0]["Userid"].ToString();
                password = dt.Rows[0]["Password"].ToString();
                senderid = dt.Rows[0]["Senderid"].ToString();
                route = dt.Rows[0]["Routeid"].ToString();

            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }

    public void todayjoinPaid()
    {
        StringBuilder sb = new StringBuilder();
        // sb.AppendFormat("select CAST(Count(*)*(pack.Amount) as decimal(18,2)) as total from MLM_Registration as MR inner join PackageInfo as Pack on mr.package = Pack.PackageName group by pack.Amount where MR.packageDate between '{0}' and '{0}' group by pack.Amount", System.DateTime.Now.ToString("yyyy-MM-dd"));
        sb.AppendFormat("select count(*)as todays from MLM_Registration where cast(PackageDate as date)='" + DateTime.Now.ToString("yyyy-MM-dd") + "' and JoinType='Paid'");
        //sb.Append("select count(*)as todays from MLM_Registration where cast(JoinDate as date) Between (Select LastDate From LastPayoutDate) and (Select DATEADD(DAY,15,LastDate)from LastPayoutDate )");
        try
        {
            object ActiveList = dal.Getscalar(sb.ToString(), ref message);
            if (!DBNull.Value.Equals(ActiveList))
            {
                if (ActiveList != null)
                {
                    int Count = Convert.ToInt32(ActiveList);

                    lblpaidtoday.Text = Count.ToString();
                }
                else
                {
                    lblpaidtoday.Text = "0";
                }
            }
            else
            {
                lblpaidtoday.Text = "0";
            }
        }
        catch (Exception)
        {

        }
    }

    public void todayjoinPaidAmount()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select  sum(Pack.Amount) from MLM_Registration as MR inner join PackageInfo as Pack on mr.package = Pack.PackageName where MR.PackageDate='{0}' and MR.JoinType='Paid'", System.DateTime.Now.ToString("yyyy-MM-dd"));
        try
        {
            object ActiveList = dal.Getscalar(sb.ToString(), ref message);
            if (!DBNull.Value.Equals(ActiveList))
            {
                if (ActiveList != null)
                {
                    int Count = Convert.ToInt32(ActiveList);

                    lblamount.Text = Count.ToString();
                }
                else
                {
                    lblamount.Text = "0";
                }
            }
            else
            {
                lblamount.Text = "0";
            }
        }
        catch (Exception)
        {

        }
    }
    string date1 = string.Empty;
    void GetDate()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select JoinDate from MLM_Registration where UserID='TOP'");
        try
        {
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if(dt.Rows.Count > 0)
            {
                date1 = Convert.ToDateTime(dt.Rows[0]["JoinDate"]).ToString("yyyy-MM-dd");
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void ddldate_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddldate.SelectedItem.Text == "ALL")
        {
            GetDate();
            date = date1.ToString();
            paidmemberuserlist();
            freememberuserlist();
            Inactiveuserlist();
            todayjoin();
            TotalCollectionWithGst();
            TotalCollectionWithoutGst();
            GetTotalPin();
            todayjoinPaid();
            todayjoinPaidAmount();
            TotalOngoingWithdrawal();
            TotalGst();
            PrintChart();
        }
        else if(ddldate.SelectedItem.Text == "Today")
        {
            date = DateTime.Now.ToString("yyyy-MM-dd");
            paidmemberuserlist();
            freememberuserlist();
            Inactiveuserlist();
            todayjoin();
            TotalCollectionWithGst();
            TotalCollectionWithoutGst();
            GetTotalPin();
            todayjoinPaid();
            todayjoinPaidAmount();
            TotalOngoingWithdrawal();
            TotalGst();
            PrintChart();

        }
        else if (ddldate.SelectedItem.Text == "Week")
        {
            string dt = DateTime.Now.ToString("yyyy-MM-dd");
            DateTime dateTime = Convert.ToDateTime(dt);
            DateTime lastWeek = dateTime.AddDays(-7.0);
            date = lastWeek.ToString("yyyy-MM-dd");
            paidmemberuserlist();
            freememberuserlist();
            Inactiveuserlist();
            todayjoin();
            TotalCollectionWithGst();
            TotalCollectionWithoutGst();
            GetTotalPin();
            todayjoinPaid();
            todayjoinPaidAmount();
            TotalOngoingWithdrawal();
            TotalGst();
            PrintChart();
        }
        else if (ddldate.SelectedItem.Text == "Month")
        {
            string dt = DateTime.Now.ToString("yyyy-MM-dd");
            DateTime dateTime = Convert.ToDateTime(dt);
            DateTime lastMonth = dateTime.AddDays(-30.0);
            date = lastMonth.ToString("yyyy-MM-dd");
            paidmemberuserlist();
            freememberuserlist();
            Inactiveuserlist();
            todayjoin();
            TotalCollectionWithGst();
            TotalCollectionWithoutGst();
            GetTotalPin();
            todayjoinPaid();
            todayjoinPaidAmount();
            TotalOngoingWithdrawal();
            TotalGst();
            PrintChart();
        }
        else if(ddldate.SelectedItem.Text == "Quarter")
        {
            string dt = DateTime.Now.ToString("yyyy-MM-dd");
            DateTime dateTime = Convert.ToDateTime(dt);
            DateTime lastquarter = dateTime.AddDays(-90.0);
            date = lastquarter.ToString("yyyy-MM-dd");
            paidmemberuserlist();
            freememberuserlist();
            Inactiveuserlist();
            todayjoin();
            TotalCollectionWithGst();
            TotalCollectionWithoutGst();
            GetTotalPin();
            todayjoinPaid();
            todayjoinPaidAmount();
            TotalOngoingWithdrawal();
            TotalGst();
            PrintChart();
        }
        else
        {
            string dt = DateTime.Now.ToString("yyyy-MM-dd");
            DateTime dateTime = Convert.ToDateTime(dt);
            DateTime lastyear = dateTime.AddDays(-364.0);
            date = lastyear.ToString("yyyy-MM-dd");
            paidmemberuserlist();
            freememberuserlist();
            Inactiveuserlist();
            todayjoin();
            TotalCollectionWithGst();
            TotalCollectionWithoutGst();
            GetTotalPin();
            todayjoinPaid();
            todayjoinPaidAmount();
            TotalOngoingWithdrawal();
            TotalGst();
            PrintChart();
        }
    }

   
    void TotalGst()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select (Count(UserID)*pg.Amount) as Wallet from MLM_Registration m inner join PackageInfo pg on m.Package=pg.PackageName where Cast(m.PackageDate as Date) between '" + date + "' and Cast(GETDATE() as Date) group by pg.Amount");
        try
        {
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                double main = Convert.ToDouble(dt.Rows[0]["Wallet"]);
                StringBuilder sb1 = new StringBuilder();
                sb1.AppendFormat("select (Count(UserID)*t.Taxable_Amount) as GST from MLM_Registration m inner join Tax_Master t on m.Package=t.PackageName where Cast(m.PackageDate as Date) between '" + date + "' and Cast(GETDATE() as Date) group by Taxable_Amount ");
                DataTable dt1 = dal.Gettable(sb1.ToString(), ref message);
                if (dt1.Rows.Count > 0)
                {
                    double GST = Convert.ToDouble(dt1.Rows[0]["GST"]);

                    lblgst.Text = (main - GST).ToString();
                }
            }
            else
            {
                lblgst.Text = "0.00";
            }
        }
        catch (Exception ex)
        {

        }
    }
}

