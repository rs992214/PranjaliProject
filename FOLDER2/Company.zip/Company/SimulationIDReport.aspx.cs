﻿using DataAccessLayer;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_SimulationIDReport : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string package = string.Empty;
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                GetList();
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void GetList()
    {
        try
        {
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("Select UserID,Sum(CR) As Credit,Sum(DR) As Debit,(COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount from Ledger_Wallet Group By UserID ", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rdr);
            con.Close();
            if (dt.Rows.Count > 0)
            {
                GV_Donation_List.DataSource = dt;
                GV_Donation_List.DataBind();
            }
            else
            {
                GV_Donation_List.DataSource = null;
                GV_Donation_List.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void CreateExcelFile(DataTable Excel)
    {

        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=SimulationIDReport.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {
            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {
                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";
            }

            Response.Write("\n");
        }
        Response.End();
    }

    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = new DataTable();
            if (txtsearch.Text == string.Empty)
            {
                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("Select UserID,Sum(CR) As Credit,Sum(DR) As Debit,(COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount from Ledger_Wallet Group By UserID ", con);
                cmd.CommandType = CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                con.Close();
            }
            else
            {
                con = new SqlConnection(connstring);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("Ledger_Wallet_ALL", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.AddWithValue("@UserID", txtsearch.Text);
                da.SelectCommand.Parameters.AddWithValue("@Mode", "SelectUserID");
               
                da.Fill(dt);
            }
            if (dt.Rows.Count > 0)
            {
                CreateExcelFile(dt);
            }

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void GV_Donation_List_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_Donation_List.PageIndex = e.NewPageIndex;
        GetList();
    }

    void CreatePdfFile(DataTable PDF)
    {
        string filename = "SimulationIDReport.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);


        Document doc = new Document(PageSize.A4, 10, 10, 10, 10);

        Paragraph p = new Paragraph();
        p.Alignment = Element.ALIGN_CENTER;

        try
        {
            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(11);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("Simulation ID List", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("../Company/images/plutologo.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------

            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "application/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch
        {

        }
    }
    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }


    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }

   

    protected void btnpdf_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = new DataTable();
            if (txtsearch.Text == string.Empty)
            {
                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("Select UserID,Sum(CR) As Credit,Sum(DR) As Debit,(COALESCE(SUM(CR),0)-COALESCE(SUM(DR),0))As WalletAmount from Ledger_Wallet Group By UserID ", con);
                cmd.CommandType = CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                con.Close();
            }
            else
            {
                con = new SqlConnection(connstring);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("Ledger_Wallet_ALL", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.AddWithValue("@UserID", txtsearch.Text);
                da.SelectCommand.Parameters.AddWithValue("@Mode", "SelectUserID");
                da.Fill(dt);

                string[] columnNames = (from dc in dt.Columns.Cast<DataColumn>()
                                        select dc.ColumnName).ToArray();
            }
            if (dt.Rows.Count > 0)
            {
                CreatePdfFile(dt);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
            DataTable dt = new DataTable();
            con = new SqlConnection(connstring);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Ledger_Wallet_ALL", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@UserID", txtsearch.Text);
            da.SelectCommand.Parameters.AddWithValue("@Mode", "SelectUserID");
            da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            GV_Donation_List.DataSource = dt;
            GV_Donation_List.DataBind();
        }
        else
        {
            GV_Donation_List.DataSource = null;
            GV_Donation_List.DataBind();
        }
    }
}