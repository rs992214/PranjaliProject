﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.IO;
using System.Drawing;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.Web.Script.Serialization;

public partial class company_DonationAcceptTrust : System.Web.UI.Page
{
    string cn = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlConnection con1;
    SqlCommand cmd;
    SqlCommand cmd1;
   
    DAL dal = new DAL();

    string message = string.Empty;
    DAL objDAL = new DAL();
    int index = 0;
    string placeunderid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            GetData();

        }
    }
    private void GetData()
    {
        try
        {
           // string UserID = Session["UserID"].ToString();
            DataTable dt = new DataTable();
            if (!(string.IsNullOrEmpty(txtfromdate.Text) && string.IsNullOrEmpty(txttodate.Text)))
            {
                string[] dte = txtfromdate.Text.Split('/');
                string[] dte1 = txttodate.Text.Split('/');
                string joinstring = "/";
                DateTime fromdate = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
                DateTime todate = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);
                dt = objDAL.Gettable("select * from DonationNew where Amount='500' and sponsorid='top' and Status!='Confirm' order by Id desc", ref message);
            }
            else
            {
                dt = objDAL.Gettable("select * from DonationNew where Amount='500' and sponsorid='top' and Status!='Confirm' order by Id desc", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        GetData();
    }
 
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            GetData();
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=DonationLink.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GV_LedgerList.AllowPaging = false;
                GetData();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GV_LedgerList.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GV_LedgerList.HeaderRow.Cells)
                {
                    cell.BackColor = GV_LedgerList.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GV_LedgerList.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GV_LedgerList.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GV_LedgerList.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GV_LedgerList.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

   
    public void btnUpdate_Command(object sender, CommandEventArgs e)
    {

       
            int id = Convert.ToInt32(e.CommandArgument);

            DAL dal = new DAL();

           

            string message = string.Empty;
            string username = "";
            string password = "";
            string senderId = "";
            string routeId = "";
            

            DataTable dt = dal.Gettable("select Userid,MobileNo from DonationNew Where  Id=" + id, ref message);
            DataTable smsdt = dal.Gettable("select Userid,Password,Senderid,Routeid from Smsmaster Where Status='Active'", ref message);

            string customerid = dt.Rows[0]["Userid"].ToString();
            string MobileNo = dt.Rows[0]["MobileNo"].ToString();


            if (dt.Rows.Count > 0)
            {
                username = smsdt.Rows[0]["Userid"].ToString();
                password = smsdt.Rows[0]["Password"].ToString();
                senderId = smsdt.Rows[0]["Senderid"].ToString();
                routeId = smsdt.Rows[0]["Routeid"].ToString();


                con = new SqlConnection(cn);
                con1 = new SqlConnection(cn);
                cmd = new SqlCommand("Update DonationNew set status = 'Confirm', ConfirmDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' where ID=" + id, con);
                cmd1 = new SqlCommand("Update MLM_Registration set JoinType = 'Paid', PackageDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' where UserID='" + customerid.ToString() + "'", con1);


                con.Open();
                con1.Open();
                int i = cmd.ExecuteNonQuery();
                int i1 = cmd1.ExecuteNonQuery();
                con.Close();
                con1.Close();
                if (i > 0)
                {
                    LedgerCredit();
                    LedgerDebit(id);
                    Response.Write("<script>alert('Donation Verified and Customer Activated Successfully.');window.location='DonationTrustAccept.aspx';</script>");
                }
                if (dt.Rows.Count > 0)
                {

                    //string text = "Congratulations, Dear Donor Welcome To World Big Opportunity. Your User ID: '" + txtaadharno.Text + "' and password:'" + txtpassword.Text + "'.Thank You.";

                    string text = "Dear Donor Your Account Approved Succesfully. Kindly login Your Account on http://www.vsharecrowdfund.in  Thank you.";




                string sURL;
                StreamReader objReader;
                sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=" + username + "&password=" + password + "&sender=" + senderId + "&to=" + MobileNo + "&message=" + text + " &reqid=1&format={json|text}&route_id=" + routeId + "";
                WebRequest wrGETURL;
                wrGETURL = WebRequest.Create(sURL);


                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                objReader.Close();

            }
                else
                {

                }

            }



    string sponsorid = "TOP";
     
    string trimatrixsignupid = customerid.ToUpper();

    DataTable dt1 = dal.Gettable("select Name,Mobile,Email,PlaceunderID from MLM_Registration where UserID='"+trimatrixsignupid.ToString()+"'", ref message);
        DataTable dt2 = dal.Gettable("select Gender from MLM_UserDetail where UserID='" + trimatrixsignupid.ToString()+"'" , ref message);

       // string gender = dt2.Rows[0]["Gender"].ToString();
        string gender = "Male";

        if (dt1.Rows.Count > 0)
        {



            string name = dt1.Rows[0]["Name"].ToString();
            string mobileno = dt1.Rows[0]["Mobile"].ToString();
            string emailid = dt1.Rows[0]["Email"].ToString();
            string placeunderid = dt1.Rows[0]["PlaceunderID"].ToString();

            StringBuilder sba = new StringBuilder();
            sba.AppendLine("insert into MLM_Registration_matrix(SponsorID,PlaceunderID,UserID,Password,Name,Mobile,Email)");
            sba.AppendFormat("values('{0}','{1}','{2}','{3}','{4}','{5}','{6}')", sponsorid.ToUpper(), placeunderid, trimatrixsignupid, "12345", name, mobileno, emailid);
            int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
            if (rowaffected1 > 0)
            {
                StringBuilder sbb = new StringBuilder();
                sbb.AppendLine("insert into MLM_UserDetail_matrix(UserID, Gender)");
                sbb.AppendFormat("values('{0}','{1}')", customerid.ToUpper(), gender);
                int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);
                if (rowaffected1 > 0 && rowaffected2 > 0)
                {
                    Updatejoining(trimatrixsignupid.ToUpper(), sponsorid.ToUpper());
                    //SavePinNo();
                    // SendMsg();
                    //CreditSponsorIncome(txtsponsorid.Text);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your account Has been Registered For Trimatrix.');'", true);
                }
                else
                {
                    var errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                    var script = string.Format("alert({0});", errormessage);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
                }
            }
        }


        }
    public void Updatejoining(string userid, string placeunder)
    {
    string Username = userid;
    string placeunderid = placeunder;
    int joiningcount = 0;
    do
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select PlaceunderID,ISNULL(Joining,0)as Joining from MLM_Registration_matrix where UserID='{0}'", placeunderid);
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            joiningcount = Convert.ToInt32(dt.Rows[0]["Joining"]);
            joiningcount++;
            ViewState["PlaceunderID"] = dt.Rows[0]["PlaceunderID"];
            StringBuilder sba = new StringBuilder();
            sba.AppendFormat("update MLM_Registration set Joining='{0}' where Userid='{1}'", joiningcount, placeunderid);
            int rowaffected = dal.Executequery(sba.ToString(), ref message);

            if (ViewState["PlaceunderID"] != null)
            {
                placeunderid = ViewState["PlaceunderID"].ToString();
            }
            else
            {
                placeunderid = null;
            }
        }
        else
        {
            placeunderid = null;
        }

    }
        while (!string.IsNullOrEmpty(placeunderid));
}


protected void GV_LedgerList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        index = Convert.ToInt32(e.CommandArgument);
    }
    protected void btnReject_Command(object sender, CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        try
        {
            con = new SqlConnection(cn);
            cmd = new SqlCommand("Update DonationNew set status = 'Pending', ConfirmDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', Image = 'images/warning.jpg' where ID=" + id, con);

         
            con.Open();
            int i = cmd.ExecuteNonQuery();
       
            con.Close();
       
            if (i > 0)
            {
                Response.Write("<script>alert('Donation Rejected Successfully.');window.location='DonationTrustAccept.aspx';</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
            //Note: Exception.Message returns a detailed message that describes the current exception. 
            //For security reasons, we do not recommend that you return Exception.Message to end users in 
            //production environments. It would be better to put a generic error message. 
        }
    }

 

    private void LedgerCredit()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", "Main");
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", "500");
        cmd.Parameters.AddWithValue("@DR", "0.00");
        cmd.Parameters.AddWithValue("@Descriptions", "Activation");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();

    }
    private void LedgerDebit(int uid)
    {
            DAL dal = new DAL();
            string userid = "";
            DataTable dtsp = dal.Gettable("select UserID from DonationTrustNew where id='" + uid + "'", ref message);
            if (dtsp.Rows.Count > 0)
            {
                userid = dtsp.Rows[0]["UserID"].ToString();
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserID", userid);
                cmd.Parameters.AddWithValue("@TransactionType", "DR");
                cmd.Parameters.AddWithValue("@CR", "0.00");
                cmd.Parameters.AddWithValue("@DR", "500");
                cmd.Parameters.AddWithValue("@Descriptions", "Activation");
                cmd.Parameters.AddWithValue("@Mode", "IN");
                int flag = cmd.ExecuteNonQuery();
        }
        
    }
    
}