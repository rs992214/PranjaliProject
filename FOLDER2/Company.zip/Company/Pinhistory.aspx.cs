﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Security.Cryptography;

public partial class Company_Pinhistory : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DAL dal = new DAL();

    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData("Unused");
        }
    }
   
    private void GetData(string Status)
    {
        try
        {
            if (txtSearchUserID.Text == "")
            {
                lblStatus.Text = Status;
            }
                
            DAL objDAL = new DAL();
            DataTable dt;
            if (txtSearchUserID.Text == "")
            {
                dt = objDAL.Gettable("select ph.UserID,ph.Transferby,ph.transferto,ph.PackageID,ph.PinNo,ph.CreationDate,ph.ID,ph.Status,p.PackageName,p.Amount from PinGenerateNew ph inner join PackageInfo P on ph.PackageID = p.ID Where ph.Status = '"+lblStatus.Text+"' order by ID desc", ref message);
            }
            else
            {
                dt = objDAL.Gettable("select ph.UserID,ph.Transferby,ph.transferto,ph.PackageID,ph.PinNo,ph.CreationDate,ph.ID,ph.Status,p.PackageName,p.Amount from PinGenerateNew ph inner join PackageInfo P on ph.PackageID = p.ID Where ph.transferto = '" + txtSearchUserID.Text + "' order by ID desc", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_PackageList.DataSource = dt;
                GV_PackageList.DataBind();
            }
            else
            {
                GV_PackageList.DataSource = null;
                GV_PackageList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
   
    protected void btnCancel_Click(object sender, EventArgs e)
    {
      
        Response.Redirect("PinSale.aspx");
    }
    protected void GV_PackageList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_PackageList.PageIndex = e.NewPageIndex;
        string Status = string.Empty;
        if (rdActive.Checked == true)
        {
            Status = "Used";
        }
        else
        {
            Status = "Unused";
        }
        GetData(Status);
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            con = new SqlConnection(connstring);
            con.Open();
            cmd = new SqlCommand("PinGenerateNew_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Parameters.AddWithValue("@Mode", "DEL");
            int flag = cmd.ExecuteNonQuery();
            con.Close();
            if (flag > 0)
            {
               
                ShowPopupMessage("Pin has been Deleted successfully.", PopupMessageType.Success);
            }
            else
            {
                ShowPopupMessage("This Pin in used.", PopupMessageType.Message);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void rdActive_CheckedChanged(object sender, EventArgs e)
    {
        GetData("Used");

        lblStatus.Text = "used";
    }

    protected void rdInactive_CheckedChanged(object sender, EventArgs e)
    {
        GetData("Unused");
        lblStatus.Text = "unused";
    }

    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }
    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        try
        {
            txtSearchUserID.Text = "";
            GetData("Unused");
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtSearchUserID.Text == "")
            {
                ShowPopupMessage("Please Enter User ID", PopupMessageType.Message);
            }
            else
            {
                DataTable dt = dal.Gettable("select ph.UserID,ph.Transferby,ph.transferto,ph.PackageID,ph.PinNo,ph.CreationDate,ph.ID,ph.Status,p.PackageName,p.Amount from PinGenerateNew ph inner join PackageInfo P on ph.PackageID = p.ID Where Status ='"+lblStatus.Text+"' And ph.transferto = '" + txtSearchUserID.Text + "'", ref message);

                if (dt.Rows.Count > 0)
                {
                    GV_PackageList.DataSource = dt;
                    GV_PackageList.DataBind();
                }
                else
                {
                    GV_PackageList.DataSource = null;
                    GV_PackageList.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
}