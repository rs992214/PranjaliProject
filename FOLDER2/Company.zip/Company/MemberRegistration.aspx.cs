﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Net;

public partial class Company_MemberRegistration : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetUserID();
        }
    }
    private void GetUserID()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        int flag = 1;
        while (flag == 1)
        {
            string UserID = "DGT" + GetUniqueKey(6);
            SqlCommand cmd = new SqlCommand("MLM_Registration_ALL", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", UserID);
            cmd.Parameters.AddWithValue("@Mode", "CHECK_USERID");
            flag = (int)cmd.ExecuteScalar();
            txtaadharno.Text = UserID;
        }
        con.Close();

    }
    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }

    protected void txtsponsorid_TextChanged(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select Name From MLM_Registration where UserID='{0}'", txtsponsorid.Text);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                lblsponsorname.ForeColor = System.Drawing.Color.Green;
                lblsponsorname.Text = dt.Rows[0]["Name"].ToString();
            }
            else
            {
                lblsponsorname.ForeColor = System.Drawing.Color.Red;
                lblsponsorname.Text = "Invalid Sponsor ID";
            }
            checkvalidity();
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    public void checkvalidity()
    {
        if (lblsponsorname.Text == "Invalid Sponsor ID" || string.IsNullOrEmpty(lblsponsorname.Text))
        {
            btnSave.Enabled = false;
        }
        else
        {
            btnSave.Enabled = true;
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        //int age = 0;
        //string joinstring = "/";
        //string[] date = txtdob.Text.Split('/');
        //DateTime finaldate = Convert.ToDateTime(date[2] + joinstring + date[1] + joinstring + date[0]);
        ////DateTime finaldate = Convert.ToDateTime(txtdob.Text);
        ////age = DateTime.Now.Year - finaldate.Year;
        ////if (DateTime.Now.DayOfYear < finaldate.DayOfYear)
        ////    age = age - 1;
        ////if (age > 18)
        //{
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select {0} From MLM_Registration where UserID='{1}'", drppoistion.SelectedValue, txtsponsorid.Text);
        try
        {
            object Position = dal.Getscalar(sb.ToString(), ref message);
            if (Position is DBNull)
            {
                SaveRecord(txtsponsorid.Text);
            }
            else
            {
                if (Position != null)
                {
                    ExploringNetwork(drppoistion.SelectedValue, Position.ToString());
                }
                else
                {
                    SaveRecord(txtsponsorid.Text);
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        //}
        //else
        //{
        //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('BBO Age Must Be More Than 18 year.')", true);
        //    return;
        //}
    }
    private void Save_Counting()
    {
        DAL objDAL = new DAL();
        string type = drppoistion.SelectedValue;
        int Current = 0;
        int Previous = 0;
        int Total = 0;
        if (type == "LLeg")
        {
            type = "LEFT";
            DataTable dtCount = objDAL.Gettable("Select UserID,CurrentCount,PreviousCount,Total From LeftCounting Where UserID='" + txtsponsorid.Text + "'", ref message);
            if (dtCount.Rows.Count > 0)
            {
                Current = Convert.ToInt32(dtCount.Rows[0]["CurrentCount"]);
                Previous = Convert.ToInt32(dtCount.Rows[0]["PreviousCount"]);
                Current = Current + 1;
                Total = Previous + Current;
            }
            else
            {
                Current = 1;
                Total = Previous + Current;
            }
        }
        else if (type == "RLeg")
        {
            type = "RIGHT";
            DataTable dtCount = objDAL.Gettable("Select UserID,CurrentCount,PreviousCount,Total From RightCounting Where UserID='" + txtsponsorid.Text + "'", ref message);
            if (dtCount.Rows.Count > 0)
            {
                Current = Convert.ToInt32(dtCount.Rows[0]["CurrentCount"]);
                Previous = Convert.ToInt32(dtCount.Rows[0]["PreviousCount"]);
                Current = Current + 1;
                Total = Previous + Current;
            }
            else
            {
                Current = 1;
                Total = Previous + Current;
            }
        }

        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("LEFT_RIGHT_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", txtsponsorid.Text);
        cmd.Parameters.AddWithValue("@CurrentCount", Current);
        cmd.Parameters.AddWithValue("@PreviousCount", Previous);
        cmd.Parameters.AddWithValue("@Total", Total);
        cmd.Parameters.AddWithValue("@Type", type);
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();

    }
    public void SaveRecord(string PlaceunderID)
    {
        try
        {
            //string joinstring = "/";
            //string[] date = txtdob.Text.Split('/');
            //string finaldate = date[2] + joinstring + date[1] + joinstring + date[0];

            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sba = new StringBuilder();
            sba.AppendLine("insert into MLM_Registration(SponsorID,PlaceunderID,UserID,Password,Name,Mobile,Email)");
            sba.AppendFormat("values('{0}','{1}','{2}','{3}','{4}','{5}','{6}')", txtsponsorid.Text, PlaceunderID, txtaadharno.Text, txtpassword.Text, txtname.Text, txtmobileno.Text, txtemailid.Text);
            int rowaffected1 = dal.Executequery(sba.ToString(), ref message);
            if (rowaffected1 > 0)
            {
                StringBuilder sbb = new StringBuilder();
                sbb.AppendLine("insert into MLM_UserDetail(UserID)");
                sbb.AppendFormat("values('{0}')", txtaadharno.Text);
                int rowaffected2 = dal.Executequery(sbb.ToString(), ref message);


                if (rowaffected1 > 0 && rowaffected2 > 0)
                {
                    SendMsg();
                    StringBuilder sb = new StringBuilder();
                    sb.AppendFormat("Update MLM_Registration set {0}='{1}' where UserID='{2}'", drppoistion.SelectedValue, txtaadharno.Text, PlaceunderID);
                    int rowaffected = dal.Executequery(sb.ToString(), ref message);
                    if (rowaffected > 0)
                    {
                        Updatejoining(txtaadharno.Text, PlaceunderID);
                        //Save_Counting();
                        ShowPopupMessage("Registration has been completed.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage(message.ToString(), PopupMessageType.Error);
                    }
                }
            }
            else
            {
                ShowPopupMessage(message.ToString(), PopupMessageType.Error);
            }

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
        finally
        {
            Clear();
            GetUserID();
        }
    }
    public void Updatejoining(string userid, string placeunder)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        string Username = userid;
        string placeunderid = placeunder;
        int CurrentCount = 0;
        int Previous = 0;
        int Total = 0;

        do
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select PlaceunderID,LLeg,RLeg,ISNULL(LJoining,0)as LJoining,ISNULL(PreviousLJoin,0)as PreviousLJoin,ISNULL(TotalLJoin,0)as TotalLJoin,ISNULL(Rjoining,0) as Rjoining,ISNULL(PreviousRJoin,0) as PreviousRJoin,ISNULL(TotalRJoin,0) as TotalRJoin from MLM_Registration where UserID='{0}'", placeunderid);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["LLeg"].ToString() == Username)
                {
                    CurrentCount = Convert.ToInt32(dt.Rows[0]["LJoining"]);
                    Previous = Convert.ToInt32(dt.Rows[0]["PreviousLJoin"]);
                    CurrentCount = CurrentCount + 1;
                    Total = Previous + CurrentCount;
                    //joiningcount++;
                    StringBuilder sba = new StringBuilder();
                    sba.AppendFormat("update MLM_Registration set LJoining='{0}',TotalLJoin='{1}' where Userid='{2}'", CurrentCount, Total, placeunderid);
                    int rowaffected = dal.Executequery(sba.ToString(), ref message);
                    Username = placeunderid;
                    ViewState["PlaceunderID"] = dt.Rows[0]["PlaceunderID"];
                    if (ViewState["PlaceunderID"] != null)
                    {
                        placeunderid = ViewState["PlaceunderID"].ToString();
                    }
                    else
                    {
                        placeunderid = null;
                    }

                }
                else if (dt.Rows[0]["RLeg"].ToString() == Username)
                {
                    CurrentCount = Convert.ToInt32(dt.Rows[0]["RJoining"]);
                    Previous = Convert.ToInt32(dt.Rows[0]["PreviousRJoin"]);
                    CurrentCount = CurrentCount + 1;
                    Total = Previous + CurrentCount;
                    //joiningcount++;
                    StringBuilder sba = new StringBuilder();
                    sba.AppendFormat("update MLM_Registration set Rjoining='{0}',TotalRJoin='{1}' where Userid='{2}'", CurrentCount, Total, placeunderid);
                    int rowaffected = dal.Executequery(sba.ToString(), ref message);
                    Username = placeunderid;
                    ViewState["PlaceunderID"] = dt.Rows[0]["PlaceunderID"];
                    if (ViewState["PlaceunderID"] != null)
                    {
                        placeunderid = ViewState["PlaceunderID"].ToString();
                    }
                    else
                    {
                        placeunderid = null;
                    }
                }
                else
                {
                    placeunderid = null;
                }

            }
            else
            {
                placeunderid = null;
            }

        } while (!string.IsNullOrEmpty(placeunderid));
    }
    public void ExploringNetwork(string Leg, string UserName)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        bool Condition = true;
        string UserID = UserName;
        string Poisition = Leg;
        do
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select {0} from MLM_Registration where UserID='{1}'", Poisition, UserID);
            object Result = dal.Getscalar(sb.ToString(), ref message);
            if (Result is DBNull)
            {
                SaveRecord(UserID);
                Condition = false;
            }
            else
            {
                if (Result != null)
                {
                    UserID = Result.ToString();
                }
                else
                {
                    SaveRecord(UserID);
                    Condition = false;
                }
            }
        } while (Condition);
    }
    public void SendMsg()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        string text = "Congratulations, Dear User Your Account Has Been Created Successfully. Your User ID: '" + txtaadharno.Text + "' and password:'" + txtpassword.Text + "'.For Sales And Support :9873766366. http://digitallyworks.in Thank You. Regards digitallyworks.in";
        try
        {
            string sURL;
            StreamReader objReader;
            sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=idm&password=idm123&sender=IDTECH&to=" + txtmobileno.Text + "&message=" + text + " &reqid=1&format={json|text}&route_id=7";
            WebRequest wrGETURL;
            wrGETURL = WebRequest.Create(sURL);

            try
            {
                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                objReader.Close();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    public void Clear()
    {
        txtsponsorid.Text = null;
        lblsponsorname.Text = null;
        txtname.Text = null;
        txtaadharno.Text = null;
        txtmobileno.Text = null;
        drppoistion.SelectedIndex = 0;
        txtemailid.Text = null;
        txtpassword.Text = null;
        txtconfirmpassword.Text = null;
        
        if (ViewState["PlaceunderID"] != null)
        {
            ViewState["PlaceunderID"] = null;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
        Response.Redirect("MemberRegistration.aspx");
    }



    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here



    
}