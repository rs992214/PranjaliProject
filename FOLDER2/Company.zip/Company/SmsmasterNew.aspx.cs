﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;
using DataAccessLayer;

public partial class Company_SmsmasterNew : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                Getdata();
               // GridView1.DataBind();
                //SMSMATER();

            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        StringBuilder sba = new StringBuilder();
        sba.AppendFormat("select * from Smsmaster Where Status='pending'");
        DataTable dt = dal.Gettable(sba.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('SMS Config Allready Prresent')", true);
            return;
        }
        else if (Button1.Text == "Save")
        {
            string status = string.Empty;
            if (RadioButton2.Checked == true)
            {
                status = RadioButton2.Text;
            }
            else
            {
                status = RadioButton1.Text;
            }


            StringBuilder sb = new StringBuilder();
            sb.AppendLine("insert into SmsMasterNew(APIurl,Username,APIkey,APIrequest,Sender,Route,Status)");
            sb.AppendFormat("values('{0}','{1}','{2}','{3}','{4}','{5}','{6}')", txturl.Text,txtusername.Text, txtkey.Text, txtrquest.Text, txtsender.Text,txtroute.Text, status);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {
                    Getdata();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Save Successfully')", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Oops!Some Error Occur.Try After Some Time.')", true);
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                //txtuserid.Text = string.Empty;
                //txtpassword.Text = string.Empty;
                //txtsenderid.Text = string.Empty;
                //txtroute.Text = string.Empty;
                //GridView1.DataBind();
               // SMSMATER();
                Getdata();

            }

        }

        else if (Button1.Text == "Update")
        {
            string status = string.Empty;
            if (RadioButton2.Checked == true)
            {
                status = RadioButton2.Text;
            }
            else
            {
                status = RadioButton1.Text;
            }

            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Update SmsmasterNew set APIurl='{0}',Username='{1}',APIkey='{2}',APIrequest='{3}',Sender='{4}',Route='{5}',Status='{6}'", txturl.Text, txtusername.Text, txtkey.Text, txtrquest.Text, txtsender.Text, txtroute.Text, status);
            try
            {
                int rowaffected = dal.Executequery(sb.ToString(), ref message);
                if (rowaffected > 0)
                {
                    Getdata();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Update Successfully')", true);
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Oops!Some Error Occur.Try After Some Time.')", true);
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                //GridView1.DataBind();
               // SMSMATER();
                Getdata();

            }
        }

    }
    protected void SMSMATER()
    {
        DataTable dt = dal.Gettable("select Userid,Password,Senderid,Routeid,Status from Smsmaster", ref message);
        if (dt.Rows.Count > 0)
        {
            txtuserid.Text = dt.Rows[0]["Userid"].ToString();
            txtpassword.Text = dt.Rows[0]["Password"].ToString();
            txtsenderid.Text = dt.Rows[0]["Senderid"].ToString();
            txtroute.Text = dt.Rows[0]["Routeid"].ToString();
            string status = dt.Rows[0]["Status"].ToString();
            if (status == "Active")
            {
                RadioButton1.Checked = true;
                RadioButton2.Checked = false;
                Button1.Text = "Update";
            }
            else if (status == "InActive")
            {
                RadioButton2.Checked = true;
                RadioButton1.Checked = false;
                Button1.Text = "Update";
            }

        }
    }
    protected void Getdata()
    {
        DataTable dt = dal.Gettable("select SrNo,APIurl,Username,APIkey,APIrequest,Sender,Route,isnull(CreditSMS,0) as CreditSMS,Status from SmsmasterNew", ref message);
        if (dt.Rows.Count > 0)
        {
            Button1.Text = "Update";
            Button1.Visible = false;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Button1.Visible = true;

        txturl.Text         = GridView1.SelectedRow.Cells[1].Text;
        txturl.ReadOnly = true;
        txtusername.Text    = GridView1.SelectedRow.Cells[2].Text;
        txtusername.ReadOnly = true;
        txtkey.Text         = GridView1.SelectedRow.Cells[3].Text;
        txtkey.ReadOnly = true;
        txtrquest.Text      = GridView1.SelectedRow.Cells[4].Text;
        txtrquest.ReadOnly = true;
        txtsender.Text      = GridView1.SelectedRow.Cells[5].Text;
        txtsender.ReadOnly = true;
        txtroute.Text       = GridView1.SelectedRow.Cells[6].Text;
        txtroute.ReadOnly = true;
        txtSMS.Text         = GridView1.SelectedRow.Cells[7].Text;
        txtSMS.ReadOnly = true;
        string status       = GridView1.SelectedRow.Cells[8].Text;

        if (status == "InActive")
        {
            RadioButton1.Checked = false;
            RadioButton2.Checked = true;
        }
        else
        {
            RadioButton2.Checked = false;
            RadioButton1.Checked = true;
        }

      

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string SrNo = GridView1.DataKeys[e.RowIndex].Values["SrNo"].ToString();
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("delete from SsmMasterNew where SrNo='{0}'", SrNo);
        try
        {
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('SMS Setting Deleted Successfully')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + message + "')", true);
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            
        }

    }
}