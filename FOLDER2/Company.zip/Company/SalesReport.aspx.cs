﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Text;

public partial class Company_SalesReport : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            showdata();    
        }
    }

    private void showdata()
    {
        try
        {
            if (!string.IsNullOrEmpty(Request.QueryString["Type"]) && !string.IsNullOrEmpty(Request.QueryString["Date1"]) && !string.IsNullOrEmpty(Request.QueryString["Date2"]))
            {
                string type = Request.QueryString["Type"].ToString();
                string Date1 = Request.QueryString["Date1"].ToString();
                string Date2 = Request.QueryString["Date2"].ToString();
                string joinstring = "/";
                string[] tempdate1 = Date1.Split('/');
                string[] tempdate2 = Date2.Split('/');

                string FinalDate1 = tempdate1[2] + joinstring + tempdate1[1] + joinstring + tempdate1[0];
                string FinalDate2 = tempdate2[2] + joinstring + tempdate2[1] + joinstring + tempdate2[0];


                DAL dal = new DAL();
                StringBuilder sb = new StringBuilder();

                if (type == "BBO")
                {
                    Label1.Text = "BBO Sales Report";
                }
                else if (type == "1")
                {
                    Label1.Text = "Mega Stockist Sales Report";
                }
                else if (type == "2")
                {
                    Label1.Text = "Super Stockist Sales Report";
                }
                else if (type == "3")
                {
                    Label1.Text = "BLS Sales Report";
                }


                if (type == "BBO")
                {
                    sb.AppendFormat("select MR.UserID,MR.Name,BOT.InvoiceNo,isnull(BOT.TotalAmount,0) as TotalAmount,convert(nvarchar(10),BOT.Date,103) as Date from BBOOredertbl as BOT inner Join MLM_Registration as MR On BOT.OrderBy = MR.UserID where BOT.Date between'{0}'and'{1}' and BOT.PaymentStatus='Success' and BOT.TransferBy='Company'", FinalDate1, FinalDate2);
                }
                else
                {
                    sb.AppendFormat("select SD.UserID,SD.Name,SOT.InvoiceNo,isnull(SOT.TotalAmount,0) as TotalAmount,convert(nvarchar(10),SOT.Date,103) as Date from StockistOrdertbl as SOT inner join StockistDetail as SD on SOT.OrderBy = SD.UserID where SOT.StockistType='{0}' and SOT.Date between '{1}' and '{2}' and BOT.PaymentStatus='Success' and BOT.TransferBy='Company'", type, FinalDate1, FinalDate2);

                }
                DataTable dt = dal.Gettable(sb.ToString(), ref message);
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {
                    GridView1.DataSource = null;
                    GridView1.DataBind();
                }

            }
            else
            {
                Response.Redirect("Reports.aspx");
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        showdata();
    }
    decimal netamount = 0;
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //decimal amount = 0;
            netamount += Convert.ToDecimal(e.Row.Cells[4].Text);
           

        }
        lblnetamount.Text = "Net Amount: " + netamount.ToString();
    }
}