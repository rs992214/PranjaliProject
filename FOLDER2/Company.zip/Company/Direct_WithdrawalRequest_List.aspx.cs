﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Direct_WithdrawalRequest_List : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
        }
    }
    private void GetData()
    {
        try
        {
            MLMUserDetailProperty MDP = new MLMUserDetailProperty();
            if (txtFrom.Text != string.Empty)
            {
                MDP.FromDate = txtFrom.Text;
            }
            if (txtTo.Text != string.Empty)
            {
                MDP.ToDate = txtTo.Text;
            }

            if (txtSearch.Text != string.Empty)
            {
                MDP.UserID = txtSearch.Text;
            }

            con = new SqlConnection(connstring);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@UserID", MDP.UserID);
            da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
            da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
            da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA1");
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GV_WithdrawalRequest_List.DataSource = dt;
                GV_WithdrawalRequest_List.DataBind();
                btnExport.Visible = true;
            }
            else
            {
                GV_WithdrawalRequest_List.DataSource = dt;
                GV_WithdrawalRequest_List.DataBind();
                btnExport.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void GV_WithdrawalRequest_List_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_WithdrawalRequest_List.PageIndex = e.NewPageIndex;
        GetData();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        GetData();
    }
    protected void GV_WithdrawalRequest_List_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblStatus = e.Row.FindControl("lblStatus") as Label;
            LinkButton btnreject = e.Row.FindControl("btnreject") as LinkButton;
            LinkButton btnApproved = e.Row.FindControl("btnApproved") as LinkButton;
            if (lblStatus.Text == "REQUEST")
            {
                btnApproved.Enabled = true;
                btnreject.Enabled = true;
                btnreject.CssClass = "btn btn-sm btn-danger";
                btnApproved.CssClass = "btn btn-sm btn-blue";
            }
            else
            {
                btnApproved.Enabled = false;
                btnApproved.CssClass = "btn btn-sm btn-blue disabled";
                btnreject.Enabled = false;
                btnreject.CssClass = "btn btn-sm btn-danger disabled";
            }
        }
    }
    protected void btnApproved_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;

            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,UserID,Amount,Description From WithdrawalRequest Where ID='" + ID + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                ID = dt.Rows[0]["ID"].ToString();
                string UserID = dt.Rows[0]["UserID"].ToString();
                decimal DR = Convert.ToDecimal(dt.Rows[0]["Amount"]);
                //string Description = dt.Rows[0]["Description"].ToString();
                decimal CR = 0;

                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", ID);
                cmd.Parameters.AddWithValue("@UserID", UserID);
                cmd.Parameters.AddWithValue("@TransactionType", "DR");
                cmd.Parameters.AddWithValue("@CR", CR);
                cmd.Parameters.AddWithValue("@DR", DR);
                cmd.Parameters.AddWithValue("@Descriptions", "Withdrwal Request");
                cmd.Parameters.AddWithValue("@Mode", "UPD_WITHDRAWAL_STATUS");
                int flag = cmd.ExecuteNonQuery();
                // int flag = 1;
                con.Close();
                if (flag > 0)
                {
                    GetData();
                    ShowPopupMessage("Withdrawal request has been approved.", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage("Some error occurred.", PopupMessageType.Error);
                }
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Direct_WithdrawalRequest_List.aspx");
    }
    public void CreateExcelFile(DataTable Excel)
    {

        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=WithdrawalList.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {
            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {
                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";
            }

            Response.Write("\n");
        }
        Response.End();
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            MLMUserDetailProperty MDP = new MLMUserDetailProperty();
            if (txtFrom.Text != string.Empty)
            {
                MDP.FromDate = txtFrom.Text;
            }
            if (txtTo.Text != string.Empty)
            {
                MDP.ToDate = txtTo.Text;
            }

            if (txtSearch.Text != string.Empty)
            {
                MDP.UserID = txtSearch.Text;
            }

            con = new SqlConnection(connstring);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@UserID", MDP.UserID);
            da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
            da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
            da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA1");
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                CreateExcelFile(dt);
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void btnPDF_Click(object sender, EventArgs e)
    {
        MLMUserDetailProperty MDP = new MLMUserDetailProperty();
        if (txtFrom.Text != string.Empty)
        {
            MDP.FromDate = txtFrom.Text;
        }
        if (txtTo.Text != string.Empty)
        {
            MDP.ToDate = txtTo.Text;
        }

        if (txtSearch.Text != string.Empty)
        {
            MDP.UserID = txtSearch.Text;
        }

        con = new SqlConnection(connstring);
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("WithdrawalRequest_ALL", con);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        da.SelectCommand.Parameters.AddWithValue("@UserID", MDP.UserID);
        da.SelectCommand.Parameters.AddWithValue("@FromDate", MDP.FromDate);
        da.SelectCommand.Parameters.AddWithValue("@ToDate", MDP.ToDate);
        da.SelectCommand.Parameters.AddWithValue("@Mode", "GETDATA1");
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            //CreatePdfFile(dt);
        }

        string[] columnNames = (from dc in dt.Columns.Cast<DataColumn>()
                                select dc.ColumnName).ToArray();

    }

  


    
}