﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Text;
using DataAccessLayer;

public partial class Company_DepositQR : System.Web.UI.Page
{
   
    DAL dal;
    SqlConnection con;
    string message = string.Empty;
    SqlCommand cmd;
    string constrc = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getdata();
        }
    }

    private void getdata()
    {
        dal = new DAL();
        DataTable dt = dal.Gettable("Select ID,Depositqr,image,Address,Date from QR_Master", ref message);
        if (dt.Rows.Count > 0)
        {

            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = null;
            GridView1.DataBind();
        }
    }
   void reset()
    {
        txtAddress.Text = string.Empty;
        ddldeposit.ClearSelection();


    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        string filename = Path.GetFileName(FileUpload1.FileName);
        FileUpload1.SaveAs(Server.MapPath("~/Company/QRImage/" + filename));
        SqlConnection conn = new SqlConnection(constrc);
        SqlCommand cmd = new SqlCommand("insert into QR_Master(Depositqr,image,Address)values(@Depositqr,@image,@Address) ", conn);
        cmd.Parameters.AddWithValue("@Depositqr", ddldeposit.SelectedItem.Text.Trim());
        cmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
        //cmd.Parameters.AddWithValue("@EventDescription", txtproduct.Text.Trim());
        cmd.Parameters.AddWithValue("@image", "~/Company/QRImage/" + FileUpload1.FileName);
        conn.Open();
        int flag = cmd.ExecuteNonQuery();
        if (flag > 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "", "alert('Data insert Successfully.')", true);
            getdata();
            reset();
            // ClientScript.RegisterClientScriptBlock(this.GetType(), "save", "swal('Good','Event Update successfully!...','success')", true);
            // Response.Write("<script>alert('Update successfully !!')</script>");
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "", "alert('Data not insert Successfully.')", true);
        }
    }

  

    protected void btndelete_Command(object sender, CommandEventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            int id = Convert.ToInt32(e.CommandArgument);
            int flag = dal.Executequery("Delete from QR_Master where ID="+id+"", ref message);
            if (flag > 0)
            {

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert(' deleted Successfully')", true);
                getdata();
            }
        }catch(Exception ex)
        {

        }

    }
}