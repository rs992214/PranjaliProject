﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;

public partial class Company_Discount : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                ShowStockisttype();
                ShowDiscountDetail();
                btnupdate.Visible = false;
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void ShowStockisttype()
    {
        try
        {
            drpstockisttype.DataTextField = "StockistType";
            drpstockisttype.DataValueField = "StockistTypeID";
           StockistType ST = new StockistType();
           DataTable dt=  ST.GetStockistType(ref message);
            if (dt.Rows.Count>0)
            {
                drpstockisttype.DataSource = dt;
                drpstockisttype.DataBind();
                drpstockisttype.Items.Insert(0, new ListItem("Select Franchise Type", "0"));
            }
            else
            {
                drpstockisttype.DataSource = null;
                drpstockisttype.DataBind();
                drpstockisttype.Items.Insert(0, new ListItem("Select Franchise Type", "0"));
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    public void ShowDiscountDetail()
    {
        try
        {
            DiscountLogic DL = new DiscountLogic();
            DataTable dt=  DL.DiscountDetails(ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ViewState["ID"] = GridView1.SelectedRow.Cells[2].Text;
        drpstockisttype.ClearSelection();
        drpstockisttype.Items.FindByText(GridView1.SelectedRow.Cells[3].Text).Selected = true;
        drpstockisttype.Enabled = false;
        txtdiscount.Text = GridView1.SelectedRow.Cells[4].Text;
        btnsave.Visible = false;
        btnupdate.Visible = true;
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowDiscountDetail();
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DiscountProperty DP = new DiscountProperty { ID = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values["ID"].ToString()) };
            DiscountLogic DL = new DiscountLogic();
           int rowaffected=  DL.DiscountDelete(DP, ref message);
            if (rowaffected>0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Discount Deleted Successfully')", true);
                ShowDiscountDetail();
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }

        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            DiscountProperty DP = new DiscountProperty
            {
                StockistTypeID = Convert.ToInt32(drpstockisttype.SelectedValue),
                Discount = (!string.IsNullOrEmpty(txtdiscount.Text)) ? Convert.ToDecimal(txtdiscount.Text) : 0
            };
            DiscountLogic DL = new DiscountLogic();
            int rowaffected = DL.Discountsave(DP, ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Discount Save Successfully')", true);
            }
            else
            {

                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowDiscountDetail();
        }
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        try
        {
            DiscountProperty DP = new DiscountProperty
            {
                ID=Convert.ToInt32(ViewState["ID"]),
                StockistTypeID = Convert.ToInt32(drpstockisttype.SelectedValue),
                Discount = (!string.IsNullOrEmpty(txtdiscount.Text)) ? Convert.ToDecimal(txtdiscount.Text) : 0
            };
            DiscountLogic DL = new DiscountLogic();
            int rowaffected = DL.DiscountUpdate(DP, ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Discount Updated Successfully')", true);
            }
            else
            {

                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert({0});", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert({0});", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            btncancel_Click(sender, new EventArgs());
            ShowDiscountDetail();
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        drpstockisttype.SelectedIndex = 0;
        drpstockisttype.Enabled = true;
        txtdiscount.Text = null;
        btnsave.Visible = true;
        btnupdate.Visible = false;
        if (ViewState["ID"]!=null)
        {
            ViewState["ID"] = null;
        }
    }
}