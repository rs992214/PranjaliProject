﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_PACKAGEMASTERNEW : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
            btnsave.Text = "Save";
            txtDirect.Text = "0";
            txtDonationAmount.Text = "0";
        }
    }

    private void GetData()
    {
        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,PackageName,Amount,DonationAmount,DailyROI,DirectIncome,BinaryIncome,BoosterROI,SpillIncome,MonthlyCapping,Validity,CONVERT(nvarchar,CreationDate,105)As CreationDate From PackageInfo Order By ID ASC", ref message);
            if (dt.Rows.Count > 0)
            {
                GV_PackageList.DataSource = dt;
                GV_PackageList.DataBind();
            }
            else
            {
                GV_PackageList.DataSource = null;
                GV_PackageList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }
    private void Clear()
    {
        txtpackagename.Text = string.Empty;
        txtpackagename.Text = string.Empty;
        txtPackageAmount.Text = string.Empty;
        txtDailyROI.Text = string.Empty;
        txtDirect.Text = string.Empty;
        txtBinary.Text = string.Empty;
        txtDonationAmount.Text = string.Empty;
        //txtMonthlyCapping.Text = string.Empty;
        txtValidity.Text = string.Empty;
        ViewState["PackageID"] = null;
        txtpackagename.ReadOnly = false;
        GetData();
    }

    protected void txtPackageAmount_TextChanged(object sender, EventArgs e)
    {
        //Calculation();
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (btnsave.Text == "Save")
            {
                if (txtPackageAmount.Text != "" && txtpackagename.Text != "")
                {
                    con = new SqlConnection(connstring);
                    con.Open();
                    cmd = new SqlCommand("PackageInfo_ALL", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PackageName", txtpackagename.Text);
                    cmd.Parameters.AddWithValue("@Amount", txtPackageAmount.Text);
                    cmd.Parameters.AddWithValue("@DailyROI", txtDailyROI.Text);
                    cmd.Parameters.AddWithValue("@DirectIncome", txtDirect.Text);
                    cmd.Parameters.AddWithValue("@BinaryIncome", txtBinary.Text);
                    cmd.Parameters.AddWithValue("@DonationAmount", txtDonationAmount.Text);
                    //cmd.Parameters.AddWithValue("@SpillIncome", txtSpillIncome.Text);
                    //cmd.Parameters.AddWithValue("@MonthlyCapping", txtMonthlyCapping.Text);
                    cmd.Parameters.AddWithValue("@Validity", txtValidity.Text);
                    cmd.Parameters.AddWithValue("@Mode", "IN");
                    int flag = cmd.ExecuteNonQuery();
                    con.Close();
                    if (flag > 0)
                    {
                        Clear();
                        Response.Redirect("SuccessView.aspx?Link=PACKAGEMASTERNEW.aspx");
                        //ShowPopupMessage("Package has been Added Successfully.", PopupMessageType.Success);
                    }
                    else
                    {
                        ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                    }
                }
                else
                {
                    ShowPopupMessage("Please Enter Data", PopupMessageType.Warning);
                }
            }
            else if (ViewState["PackageID"] != null && txtpackagename.Text != null)
            {
                string ID = ViewState["PackageID"].ToString();
                con = new SqlConnection(connstring);
                con.Open();
                cmd = new SqlCommand("PackageInfo_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", ID);
                cmd.Parameters.AddWithValue("@PackageName", txtpackagename.Text);
                cmd.Parameters.AddWithValue("@Amount", txtPackageAmount.Text);
                cmd.Parameters.AddWithValue("@DailyROI", txtDailyROI.Text);
                cmd.Parameters.AddWithValue("@DirectIncome", txtDirect.Text);
                cmd.Parameters.AddWithValue("@BinaryIncome", txtBinary.Text);
                cmd.Parameters.AddWithValue("@DonationAmount", txtDonationAmount.Text);
                //cmd.Parameters.AddWithValue("@SpillIncome", txtSpillIncome.Text);
                //cmd.Parameters.AddWithValue("@MonthlyCapping", txtMonthlyCapping.Text);
                cmd.Parameters.AddWithValue("@Validity", txtValidity.Text);
                cmd.Parameters.AddWithValue("@Mode", "UPD");
                int flag = cmd.ExecuteNonQuery();
                con.Close();
                if (flag > 0)
                {
                    Clear();
                    Response.Redirect("SuccessView.aspx?Link=PACKAGEMASTERNEW.aspx");
                   // ShowPopupMessage("Package has been Updated Successfully.", PopupMessageType.Success);
                }
                else
                {
                    ShowPopupMessage("Some Error occurred.", PopupMessageType.Error);
                }
            }

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Clear();
        Response.Redirect("MemberPackageMaster.aspx");
    }

    private void Calculation()
    {
        double PackageAmount = 0;
        double DailyROI = 1.5;
        double BoosterROI = 2;
        double _DailyROI_Amount = 0;
        double _BoosterROI_Amount = 0;
        if (txtPackageAmount.Text != string.Empty)
        {
            PackageAmount = Convert.ToDouble(txtPackageAmount.Text);
        }
        else
        {
            txtPackageAmount.Text = "0";
        }

        _DailyROI_Amount = PackageAmount * DailyROI / 100;
        txtDailyROI.Text = _DailyROI_Amount.ToString();

        _BoosterROI_Amount = PackageAmount * BoosterROI / 100;
        //txtBoosterROI.Text = _BoosterROI_Amount.ToString();
        //txtMonthlyCapping.Text = PackageAmount.ToString();
        txtValidity.Text = "365";

    }

    protected void GV_PackageList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_PackageList.PageIndex = e.NewPageIndex;
        GetData();
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            string ID = btn.CommandArgument;
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("Select ID,PackageName,Amount,DonationAmount,DailyROI,DirectIncome,BinaryIncome,BoosterROI,SpillIncome,MonthlyCapping,Validity,CONVERT(nvarchar,CreationDate,105)As CreationDate From PackageInfo Where ID='" + ID + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                ViewState["PackageID"] = dt.Rows[0]["ID"].ToString();
                txtpackagename.Text = dt.Rows[0]["PackageName"].ToString();
                txtpackagename.ReadOnly = true;
                txtPackageAmount.Text = dt.Rows[0]["Amount"].ToString();
                txtDailyROI.Text = dt.Rows[0]["DailyROI"].ToString();
                txtDirect.Text = dt.Rows[0]["DirectIncome"].ToString();
                txtBinary.Text = dt.Rows[0]["BinaryIncome"].ToString();
                txtDonationAmount.Text = dt.Rows[0]["DonationAmount"].ToString();
                //txtSpillIncome.Text = dt.Rows[0]["SpillIncome"].ToString();
                //txtMonthlyCapping.Text = dt.Rows[0]["MonthlyCapping"].ToString();
                txtValidity.Text = dt.Rows[0]["Validity"].ToString();
                Calculation();
                btnsave.Text = "Update";
            }
            else
            {

            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here

    protected void btnDelete_Click(object sender, EventArgs e)
    {

    }
}