﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_booster : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
               
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void packagedatesponsor()
    {
        string UserID = TextBox1.Text;
        DAL objDAL = new DAL();
        DataTable dt = objDAL.Gettable("Select PackageDate as JoinDate From MLM_Registration Where UserID='" + UserID + "'", ref message);
        if (dt.Rows.Count > 0)
        {

            lblPkg.Text = dt.Rows[0]["JoinDate"].ToString();
        }
        else
        {
            lblPkg.Text = "0";


        }

    }


    public void booster()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("SELECT DD.PH_ID, MR.Name, dd.GetAmount, DD.PayAmount, DD.Status, mr.PackageDate, DD.CreationDate FROM MLM_Registration MR INNER JOIN  Donation DD ON MR.UserID = DD.PH_ID WHERE MR.SponsorID = '" + TextBox1.Text + "'");
        try
        {
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GV_Receive_List.DataSource = dt;
                GV_Receive_List.DataBind();
            }
            else
            {
                GV_Receive_List.DataSource = null;
                GV_Receive_List.DataBind();
            }
        }
        catch (Exception)
        {

            throw;
        }
    }

 
 

    protected override void InitializeCulture()
    {
        CultureInfo ci = new CultureInfo("en-IN");
        ci.NumberFormat.CurrencySymbol = "₹";
        Thread.CurrentThread.CurrentCulture = ci;
        base.InitializeCulture();
    }
    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }


    protected void btnbooster_Click(object sender, EventArgs e)
    {
        packagedatesponsor();
        booster();

    }
}