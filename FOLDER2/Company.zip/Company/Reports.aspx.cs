﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using DataAccessLayer;

public partial class Company_Reports : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            string[] dte = txtfromdate.Text.Split('/');
            string[] dte1 = txttodate.Text.Split('/');
            string joinstring = "/";
            DateTime date1 = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
            DateTime date2 = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select MR.UserID,MR.Name,PAck.PackageName,PAck.Amount,convert(nvarchar(10),MR.PackageDate,103)as [Package Date] from MLM_Registration as MR inner join PackageInfo as PAck on MR.Package = PAck.PackageName where MR.packageDate between '{0}' and '{1}'",date1,date2);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count>0)
            {
                GridView1.AllowPaging = false;
                GridView1.PageSize = dt.Rows.Count;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
               
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
}