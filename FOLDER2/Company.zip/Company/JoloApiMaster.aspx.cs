﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Web.Script.Serialization;

public partial class Company_JoloApiMaster : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            showPlanSetting();
        }

    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("insert into JoloGetway(APIKey, Mode, Status)");
            sb.AppendFormat("values('{0}','{1}','{2}')", txtadmincharge.Text, rdMode.SelectedValue.ToString(), rdStatus.SelectedValue.ToString());
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                Response.Redirect("SuccessView.aspx?Link=JoloApiMaster.aspx");
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Save Successfully')", true);
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
        Clear();
        showPlanSetting();
    }
    private void showPlanSetting()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select APIKey, Mode, Status from JoloGetway");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                btnsave.Enabled = false;
                btnUpdate.Enabled = false;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnsave.Enabled = true;
                btnUpdate.Enabled = false;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    private void Clear()
    {
        txtadmincharge.Text = null;
        //txtmonthlycapping.Text = null;
    }



    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            //string ID = GridView1.DataKeys[e.RowIndex].Values["ID"].ToString();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Delete from JoloGetway");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                Response.Redirect("SuccessView.aspx?Link=JoloApiMaster.aspx");
                // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('JOLO Gateway Information Deleted Successfully')", true);
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
        showPlanSetting();
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            int index = dal.Executequery("UPDATE JoloGetway SET APIKey = '"+ txtadmincharge.Text +"', Mode = '"+ rdMode.SelectedValue.ToString() +"', Status = '"+ rdStatus.SelectedValue.ToString() +"',DATE=GETDATE()", ref message);
            if (index > 0)
            {

                showPlanSetting(); 
                string errormessage = new JavaScriptSerializer().Serialize("Record Updated Successfully.");
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
    }


    protected void btnEdit_Command(object sender, CommandEventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            DataTable dt = dal.Gettable("SELECT APIKey, Mode, Status FROM JoloGetway", ref message);
            if (dt.Rows.Count > 0)
            {
                txtadmincharge.Text = dt.Rows[0]["APIKey"].ToString();
                rdMode.Items.FindByValue(dt.Rows[0]["Mode"].ToString()).Selected = true;
                rdStatus.Items.FindByValue(dt.Rows[0]["Status"].ToString()).Selected = true;
                btnUpdate.Enabled = true;
            }
            else
            {
                txtadmincharge.Text = string.Empty;
                btnUpdate.Enabled = true;
            }
        }
        catch(Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
    }
}