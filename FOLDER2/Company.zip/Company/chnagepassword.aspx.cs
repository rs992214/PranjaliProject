﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Text;
using System.Net;

public partial class Company_FormChangeAdminPassword : System.Web.UI.Page
{
    string loginip = GetLocalIPAddress();
    string UserName = "";
    string password1 = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        GetLocalIPAddress();
        AdminLoginInfo();
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                showEmail();
            }
            else
            {
                Response.Redirect("Logout.aspx");

            }
            
        }
    }
    public void reset()
    {
        txtConfnewpass.Text = string.Empty;
        txtNewpassword.Text = string.Empty;
        txtOldpassword.Text = string.Empty;
        txtOldusename.Text = string.Empty;
        txtNewusername.Text = string.Empty;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
        con.Open();
        string str1 = "select * from Adminlogin where username='" + txtOldusename.Text + "' AND password ='" + txtOldpassword.Text + "'";
        SqlCommand cmd = new SqlCommand(str1, con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
            con1.Open();


            string str = "update Adminlogin set username='" + txtNewusername.Text + "', password='" + txtNewpassword.Text + "' where username='" + txtOldusename.Text + "' AND password='" + txtOldpassword.Text + "'";
            // string str = "update adminlogin set username='" +txtNewusername.Text +"' where password= '"+txtOldpassword.Text+"'";
            SqlCommand cmd1 = new SqlCommand(str, con1);
            cmd1.ExecuteNonQuery();
            lblstatus.ForeColor = System.Drawing.Color.Green;
            ChangePasswordTrace();
            lblstatus.Text = "Your Password has been changed successfully ";
            con1.Close();
            con.Close();
            reset();
            // Response.Redirect("logout.aspx");
        }
        else
        {
            WrongPassword();

            lblstatus.Text = " Your old Password is incorrect try again... ";
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        reset();
    }


    public void showEmail()
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select Emailid from Adminlogin");
        try
        {
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count> 0)
            {
                txtemail.Text = dt.Rows[0]["Emailid"].ToString();
            }
            else
            {
                txtemail.Text = null;
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    protected void btnemailupdate_Click(object sender, EventArgs e)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("update Adminlogin set Emailid='{0}'", txtemail.Text);
        try
        {
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Email Updated Successfully')", true);
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + message + "')", true);
            }
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            txtemail.Text = null;
            showEmail();
        }
    }
    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }

        }


        throw new Exception("No network adapters with an IPv4 address in the system!");
    }
    public void AdminLoginInfo()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select UserName,password from Adminlogin", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                UserName = dt.Rows[0]["UserName"].ToString();
                password1 = dt.Rows[0]["password"].ToString();

            }

        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }
    }

    public void ChangePasswordTrace()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {


            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Success: Detail Changed from Old_UserName="+txtOldusename.Text+" and Old_Password="+ txtOldpassword.Text + " to New_UserName="+ txtNewusername .Text+ " and NewPassword="+txtNewpassword.Text+" ')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }

    }
    public void WrongPassword()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        try
        {


            con.Open();
            SqlCommand cmd = new SqlCommand("insert into AdminLoginLogoutDetail(UserID,Password,loginIP,Date,Status) values('" + UserName + "','" + password1 + "','" + loginip + "',GETDATE(),'Warning:You Have Entered "+txtOldusename.Text+" And Your Old Password is Incorrect  ')", con);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {

            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            con.Close();
        }


    }

}