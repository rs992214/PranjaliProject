﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Script.Serialization;
using DataAccessLayer;

public partial class Admin_CurrencyMaster : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Getdata();
            BindCurrency();
            showCurrency();
        }

    }
    void Getdata()
    {
        try
        {
            DataTable dt = new DataTable();
            dt = dal.Gettable("select Currency,Cast(CreationDate as Date) from CurrencyList", ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            // ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    void BindCurrency()
    {
        DataTable dt = new DataTable();

        dt = dal.Gettable("select * from Currency", ref message);

        if (dt.Rows.Count > 0)
        {
            ddlcurrency.DataSource = dt;
            ddlcurrency.DataTextField = "code";
            ddlcurrency.DataValueField = "symbol";
            ddlcurrency.DataBind();
        }
        else
        {
            ddlcurrency.DataSource = dt;
            ddlcurrency.DataTextField = "code";
            ddlcurrency.DataValueField = "symbol";
            ddlcurrency.DataBind();
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            string currency = string.Empty;
            if(ddlcurrency.SelectedItem.Text == "AFN")
            {
                currency = "₹";
            }
            else
            {
                currency = ddlcurrency.SelectedValue;
            }

            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("insert into CurrencyList(Currency,CreationDate)");
            sb.AppendFormat("values('"+ currency + "',GetDate())");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                showCurrency();
                Response.Redirect("SuccessView.aspx?Link=CurrencyMaster.aspx");
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Saved Successfully')", true);
                btnsave.Enabled = false;
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
        finally
        {
            Clear();
            showCurrency();
        }
    }
    private void showCurrency()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select sr_no as SrNO,currency,CreationDate as Date from CurrencyList");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                btnsave.Enabled = false;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnsave.Enabled = true;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    private void Clear()
    {
        Response.Redirect("SuccessView.aspx?Link=CurrencyMaster.aspx");
       // Response.Redirect("CurrencyMaster.aspx");
        //txtAmount.Text = null;
        //txtAmountIn.Text = null;
        //txtother.Text = null;
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DAL dal = new DAL();
            //string ID = GridView1.DataKeys[e.RowIndex].Values["ID"].ToString();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Delete from CurrencyList");
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Deleted Successfully')", true);
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
            }
        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", script, true);
        }
        finally
        {
            showCurrency();
        }
    }


    protected void ddlcurrency_SelectedIndexChanged(object sender, EventArgs e)
    {
        if(ddlcurrency.SelectedItem.Text == "AFN")
        {
            string currency = "₹";
        }
    }
}