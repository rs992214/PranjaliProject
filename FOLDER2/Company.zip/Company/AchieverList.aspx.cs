﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;
using System.Text;

public partial class Company_AchieverList : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        SHowData();
    }
    private void SHowData()
    {
        try
        {
            StringBuilder sb = new StringBuilder();
            if (drprank.SelectedValue == "0")
            {
                sb.AppendFormat("select UserID as BBOID,Name,Mobile,Email,'Star' as Achievement,Status from MLM_Registration where Star='1' order by DID");
            }
            else if (drprank.SelectedValue == "1")
            {
                sb.AppendFormat("select UserID as BBOID,Name,Mobile,Email,'Gold' as Achievement,Status from MLM_Registration where Gold='1' order by DID");
            }
            else if (drprank.SelectedValue == "2")
            {
                sb.AppendFormat("select UserID as BBOID,Name,Mobile,Email,'Diamond' as Achievement,Status from MLM_Registration where Diamond='1' order by DID");
            }
            else if (drprank.SelectedValue == "3")
            {
                sb.AppendFormat("select UserID as BBOID,Name,Mobile,Email,'Double Diamond' as Achievement,Status from MLM_Registration where DoubleDiamond='1' order by DID");
            }
            else if (drprank.SelectedValue == "4")
            {
                sb.AppendFormat("select UserID as BBOID,Name,Mobile,Email,'Plantinum Diamond' as Achievement,Status from MLM_Registration where PlantinumDiamond='1' order by DID");
            }
            else
            {
                sb.AppendFormat("select UserID as BBOID,Name,Mobile,Email,Status from MLM_Registration where Directorship='1' order by DID");
            }
            DAL dal = new DAL();
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
}