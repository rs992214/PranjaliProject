﻿using DataAccessLayer;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_KycReport : System.Web.UI.Page
{
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetData();
        }
    }
    public void GetData()
    {
        DataTable dt = new DataTable();
        if(!(string.IsNullOrEmpty(txtfrom.Text)) && !(string.IsNullOrEmpty(txtto.Text)))
        {
          //  dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (BankProof Is Not Null And BankProofvalue=0) OR (GST Is Not Null And GSTProofvalue=0) OR (Address2 Is Not Null And Address2value=0) OR (Application is not null) And Cast(M.JoinDate as Date ) between '"+txtfrom.Text+"' And '"+txtto.Text+"'", ref message);
            dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (IdentityProof is not null and IdentityProofvalue=0)  And Cast(M.JoinDate as Date )  between '" + txtfrom.Text+"' And '"+txtto.Text+"'", ref message);
        }
        else
        {
            dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (IdentityProof is not null and IdentityProofvalue=0)", ref message);
        }
        if(dt.Rows.Count > 0)
        {
            GV_Receive_List.DataSource = dt;
            GV_Receive_List.DataBind();
        }
        else
        {
            GV_Receive_List.DataSource = null;
            GV_Receive_List.DataBind();
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        GetData();
    }

    protected void btnexportexcel_Click(object sender, EventArgs e)
    {

        DataTable dt = new DataTable();
        if (!(string.IsNullOrEmpty(txtfrom.Text)) && !(string.IsNullOrEmpty(txtto.Text)))
        {
            dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (IdentityProof is not null and IdentityProofvalue=0)  And Cast(M.JoinDate as Date )  between '" + txtfrom.Text+"' And '"+txtto.Text+"'", ref message);

            //  dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (BankProof Is Not Null And BankProofvalue=0) OR (GST Is Not Null And GSTProofvalue=0) OR (Address2 Is Not Null And Address2value=0) OR (Application is not null) And Cast(M.JoinDate as Date ) between '" + txtfrom.Text + "' And '" + txtto.Text + "'", ref message);
        }
        else
        {
            dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (IdentityProof is not null and IdentityProofvalue=0)", ref message);

            // dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (BankProof Is Not Null And BankProofvalue=0) OR (GST Is Not Null And GSTProofvalue=0) OR (Address2 Is Not Null And Address2value=0) OR (Application is not null)", ref message);
        }
        if (dt.Rows.Count > 0)
        {
            CreateExcelFile(dt);
        }

        //try
        //{
        //    Response.Clear();
        //    Response.Buffer = true;
        //    Response.AddHeader("content-disposition", "attachment;filename=ReceiveReport.xls");
        //    Response.Charset = "";
        //    Response.ContentType = "application/vnd.ms-excel";
        //    using (StringWriter sw = new StringWriter())
        //    {
        //        HtmlTextWriter hw = new HtmlTextWriter(sw);

        //        //To Export all pages
        //        GV_Receive_List.AllowPaging = false;
        //        GetData();
        //        //GridView1.HeaderRow.Cells[0].Visible = false;
        //        //GridView1.HeaderRow.Cells[1].Visible = false;
        //        GV_Receive_List.HeaderRow.BackColor = Color.White;
        //        foreach (TableCell cell in GV_Receive_List.HeaderRow.Cells)
        //        {
        //            cell.BackColor = GV_Receive_List.HeaderStyle.BackColor;
        //        }
        //        foreach (GridViewRow row in GV_Receive_List.Rows)
        //        {
        //            //row.Cells[0].Visible = false;
        //            //row.Cells[1].Visible = false;
        //            row.BackColor = Color.White;
        //            foreach (TableCell cell in row.Cells)
        //            {
        //                if (row.RowIndex % 2 == 0)
        //                {
        //                    cell.BackColor = GV_Receive_List.AlternatingRowStyle.BackColor;
        //                }
        //                else
        //                {
        //                    cell.BackColor = GV_Receive_List.RowStyle.BackColor;
        //                }
        //                cell.CssClass = "textmode";
        //            }
        //        }

        //        GV_Receive_List.RenderControl(hw);

        //        //style to format numbers to string
        //        string style = @"<style> .textmode { } </style>";
        //        Response.Write(style);
        //        Response.Output.Write(sw.ToString());
        //        Response.Flush();
        //        Response.End();
        //    }

        //}
        //catch (Exception)
        //{

        //    throw;
        //}
    }

    public void CreateExcelFile(DataTable Excel)
    {
        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=Kyc_Report.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {
            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {

                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";

            }

            Response.Write("\n");

        }
        Response.End();
    }

    protected void btnexportPdf_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        if (!(string.IsNullOrEmpty(txtfrom.Text)) && !(string.IsNullOrEmpty(txtto.Text)))
        {
            dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (IdentityProof is not null and IdentityProofvalue=0)  And Cast(M.JoinDate as Date )  between '" + txtfrom.Text + "' And '" + txtto.Text + "'", ref message);

            //  dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (BankProof Is Not Null And BankProofvalue=0) OR (GST Is Not Null And GSTProofvalue=0) OR (Address2 Is Not Null And Address2value=0) OR (Application is not null) And Cast(M.JoinDate as Date ) between '" + txtfrom.Text + "' And '" + txtto.Text + "'", ref message);
        }
        else
        {
            dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (IdentityProof is not null and IdentityProofvalue=0)", ref message);

            //dt = dal.Gettable("select M.UserID,M.Name,M.JoinType,M.Mobile,KYC='NO',M.JoinDate from MLM_Registration M inner join MLM_UserDetail U On M.UserID=U.UserID where (BankProof Is Not Null And BankProofvalue=0) OR (GST Is Not Null And GSTProofvalue=0) OR (Address2 Is Not Null And Address2value=0) OR (Application is not null)", ref message);
        }
        if (dt.Rows.Count > 0)
        {
            CreatePdfFile(dt);
        }
    }


    void CreatePdfFile(DataTable PDF)
    {
        string filename = "KYCReport.pdf";
        string filepath = Path.Combine(Server.MapPath("~/PdfFiles"), filename);


        Document doc = new Document(PageSize.A4, 10, 10, 40, 10);

        Paragraph p = new Paragraph("KYC Report");
        p.Alignment = Element.ALIGN_CENTER;

        try
        {
            PdfWriter.GetInstance(doc, new FileStream(filepath, FileMode.Create));
            PdfPTable pdfPtable = new PdfPTable(11);

            pdfPtable.HorizontalAlignment = 1;
            pdfPtable.SpacingBefore = 20f;
            pdfPtable.SpacingAfter = 20f;
            doc.Open();
            Chunk c = new Chunk("", FontFactory.GetFont("TimesNewRoman", 11));
            p.Alignment = Element.ALIGN_CENTER;
            p.Add(c);
            doc.Add(p);
            //--- Add Logo of PDF ----
            string imageFilePath = System.Web.HttpContext.Current.Server.MapPath("../Company/images/plutologo.png");
            iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
            //Resize image depend upon your need
            jpg.ScaleToFit(80f, 60f);
            //Give space before image
            jpg.SpacingBefore = 0f;
            //Give some space after the image
            jpg.SpacingAfter = 1f;
            jpg.Alignment = Element.HEADER;
            doc.Add(jpg);
            iTextSharp.text.Font font8 = FontFactory.GetFont("ARIAL", 7);
            //--- Add new Line ------------
            Phrase phrase1 = new Phrase(Environment.NewLine);
            doc.Add(phrase1);
            //-------------------------------

            DataTable dt = PDF;
            if (dt != null)
            {
                //---- Add Result of DataTable to PDF file With Header -----
                PdfPTable pdfTable = new PdfPTable(dt.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100; // percentage
                pdfTable.DefaultCell.BorderWidth = 2;
                pdfTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;

                foreach (DataColumn column in dt.Columns)
                {
                    pdfTable.AddCell(FormatHeaderPhrase(column.ColumnName));
                }
                pdfTable.HeaderRows = 1; // this is the end of the table header
                pdfTable.DefaultCell.BorderWidth = 1;

                foreach (DataRow row in dt.Rows)
                {
                    foreach (object cell in row.ItemArray)
                    {
                        //assume toString produces valid output
                        pdfTable.AddCell(FormatPhrase(cell.ToString()));
                    }
                }
                doc.Add(pdfTable);
            }

            doc.Close();
            byte[] content = File.ReadAllBytes(filepath);

            HttpContext context = HttpContext.Current;

            context.Response.BinaryWrite(content);
            context.Response.ContentType = "application/pdf";
            context.Response.AppendHeader("content-disposition", "attachment; filename=" + filename);
            context.Response.End();
        }
        catch
        {

        }
    }
    private static Phrase FormatHeaderPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8, iTextSharp.text.Font.UNDERLINE, new iTextSharp.text.BaseColor(0, 0, 255)));
    }
    private Phrase FormatPhrase(string value)
    {
        return new Phrase(value, FontFactory.GetFont(FontFactory.TIMES, 8));
    }
}