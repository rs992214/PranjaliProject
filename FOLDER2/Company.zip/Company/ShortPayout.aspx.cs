﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_ShortPayout : System.Web.UI.Page
{
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] != null)
            {
                ShowPayout();
                btnexcel.Visible = false;
            }
            else
            {
                Response.Redirect("Logout.aspx");
            }
        }
    }

    public void ShowPayout()
    {
        try
        {
            drppayout.DataTextField = "PayoutBetween";
            drppayout.DataValueField = "PayoutBetween";
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select DISTINCT PayoutBetween,max(Date) from BBOPayment group by PayoutBetween order by max(Date)");
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                drppayout.DataSource = dt;
                drppayout.DataBind();
                drppayout.Items.Insert(0, new ListItem("Select Payout Date", "0"));
            }
            else
            {
                drppayout.DataSource = null;
                drppayout.DataBind();
                drppayout.Items.Insert(0, new ListItem("Select Payout Date", "0"));
            }
        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }
    public void ShowPayoutSheet()
    {
        try
        {
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            if (drpkyc.SelectedValue == "0")
            {
               sb.AppendFormat("select MR.UserID, MR.Name,BP.PaymentID,BP.NetAmount, BP.PaymentStatus, BP.PaymentMode, BP.ReferenceNo,convert(nvarchar(10), BP.PaymentDate, 103) as PaymentDate, MLU.PayeeName, MLU.BankName, MLU.AccountNo, MLU.IFSCCode,MLU.PANNO,MLU.Paytm from BBOPayment as BP inner join MLM_Registration as MR on BP.UserID = MR.UserID Left join MLM_UserDetail as MLU on MR.UserID = MLU.UserID where MR.UserID In(select userID from MLM_UserDetail where isnull(AddressProofvalidate, 0) = 1 and isnull(IdentityProofvalidate, 0) = 1 and isnull(BankProofvalidate, 0) = 1 and isnull(Applicationvalidate, 0) = 1 and isnull(Address2validate, 0) = 1) and Bp.PayoutBetween = '{0}' and BP.NetAmount>0", drppayout.SelectedValue);
            }
            else
            {
                sb.AppendFormat("select MR.UserID, MR.Name,BP.PaymentID,BP.NetAmount, BP.PaymentStatus, BP.PaymentMode, BP.ReferenceNo, convert(nvarchar(10), BP.PaymentDate, 103) as PaymentDate, MLU.PayeeName, MLU.BankName, MLU.AccountNo, MLU.IFSCCode,MLU.PANNO,MLU.Paytm  from BBOPayment as BP inner join MLM_Registration as MR on BP.UserID = MR.UserID Left join MLM_UserDetail as MLU on MR.UserID = MLU.UserID where MR.UserID In(select userID from MLM_UserDetail where isnull(AddressProofvalidate, 0) = 0 OR isnull(IdentityProofvalidate, 0) = 0 OR isnull(BankProofvalidate, 0) = 0 OR isnull(Applicationvalidate, 0) = 0 OR isnull(Address2validate, 0) = 0) and Bp.PayoutBetween = '{0}' and BP.NetAmount>0", drppayout.SelectedValue);
            }
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
                btnexcel.Visible = true;
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
                btnexcel.Visible = false;

            }

        }
        catch (Exception ex)
        {
            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        ShowPayoutSheet();
    }

    protected void btnexcel_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string filename = drppayout.SelectedItem.Text;
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename='" + filename + "'.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridView1.AllowPaging = false;
                this.ShowPayoutSheet();
                GridView1.HeaderRow.Cells[1].Visible = false;
                GridView1.HeaderRow.Cells[2].Visible = false;
                GridView1.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridView1.HeaderRow.Cells)
                {
                    cell.BackColor = GridView1.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridView1.Rows)
                {
                    row.Cells[1].Visible = false;
                    row.Cells[2].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridView1.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridView1.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridView1.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        ShowPayoutSheet();
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            
            DAL dal = new DAL();
            string userID = e.Row.Cells[7].Text;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", userID);
            DataTable jointype = dal.Gettable(sb.ToString(), ref message);


            StringBuilder sba = new StringBuilder();
            sba.AppendFormat("select isnull(AddressProofvalidate,0) as AddressProofvalidate,isnull(IdentityProofvalidate,0) as IdentityProofvalidate,isnull(BankProofvalidate,0) as BankProofvalidate,isnull(Applicationvalidate,0) as Applicationvalidate,isnull(Address2validate,0) as Address2validate from MLM_UserDetail where UserID='{0}'", userID);
            DataTable dt = dal.Gettable(sba.ToString(), ref message);
            int AddressProofvalidate = 0;
            int IdentityProofvalidate = 0;
            int BankProofvalidate = 0;
            int Applicationvalidate = 0;
            int address2validate = 0;

            if (dt.Rows.Count > 0)
            {
                AddressProofvalidate = Convert.ToInt32(dt.Rows[0]["AddressProofvalidate"]);
                IdentityProofvalidate = Convert.ToInt32(dt.Rows[0]["IdentityProofvalidate"]);
                BankProofvalidate = Convert.ToInt32(dt.Rows[0]["BankProofvalidate"]);
                Applicationvalidate = Convert.ToInt32(dt.Rows[0]["Applicationvalidate"]);
                address2validate = Convert.ToInt32(dt.Rows[0]["Address2validate"]);
            }

            //string date= drppayout.SelectedItem.Text;
            string[] temp = drppayout.SelectedItem.Text.Split('-');
            string[] date = temp[1].Split('/');
            string joinstring = "/";
            string date1 = date[2] + joinstring + date[1] + joinstring + date[0];

            StringBuilder sbb = new StringBuilder();
            sbb.AppendFormat("select isnull(sum(TotalSV),0) from BBOOredertbl where OrderBy='{0}' and Date >'{1}'", userID, date1);
            object totalsv = dal.Getscalar(sbb.ToString(), ref message);
            int _userSv = Convert.ToInt32(totalsv);


            if (jointype.Rows[0]["JoinType"].ToString() == "Free")
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/orange.svg";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Not Procced";
                e.Row.Cells[2].Enabled = false;
            }
            else if (jointype.Rows[0]["Status"].ToString() == "Inactive")
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/red.png";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Not Procced";
                e.Row.Cells[2].Enabled = false;
            }
            else if (AddressProofvalidate == 0 || IdentityProofvalidate == 0 || BankProofvalidate == 0 || Applicationvalidate == 0 || address2validate == 0)
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/free.png";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Not Procced";
                e.Row.Cells[2].Enabled = false;
            }
            else if (_userSv == 0)
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/sv.png";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment Not Procced";

                if (drpkyc.SelectedItem.Text == "KYC MEMBER")
                {
                    e.Row.Cells[2].Enabled = true;
                }
                else
                {
                    e.Row.Cells[2].Enabled = false;
                }
            }
            else
            {
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).ImageUrl = "images/green.png";
                ((System.Web.UI.WebControls.Image)e.Row.Cells[0].FindControl("Image1")).AlternateText = "Payment";
               
            }

        }
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            string paymentID = GridView1.DataKeys[e.RowIndex].Values["PaymentID"].ToString();
            string paymentstatus = ((DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList1")).SelectedItem.Text;
            string paymentmode = ((DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList2")).SelectedItem.Text;
            string refernceno = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtrefernceno")).Text;
            string paymentDate = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox3")).Text;
            string[] dte = paymentDate.Split('/');
            string finaldate = dte[2] + "/" + dte[1] + "/" + dte[0];
            DAL dal = new DAL();
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("update BBOPayment set PaymentStatus='{0}',PaymentMode='{1}',ReferenceNo='{2}',PaymentDate='{3}' where PaymentID='{4}'", paymentstatus, paymentmode, refernceno, finaldate, paymentID);
            int rowaffected = dal.Executequery(sb.ToString(), ref message);
            if (rowaffected > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Payment Info Updated')", true);
                if (paymentstatus == "Success")
                {
                    SendMsg(paymentID);
                }
            }
            else
            {
                string errormessage = new JavaScriptSerializer().Serialize(message.ToString());
                var script = string.Format("alert('{0}');", errormessage);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            }

        }
        catch (Exception ex)
        {

            string errormessage = new JavaScriptSerializer().Serialize(ex.Message.ToString());
            var script = string.Format("alert('{0}');", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        }
        finally
        {
            GridView1.EditIndex = -1;
            ShowPayoutSheet();
        }

    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        ShowPayoutSheet();
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        ShowPayoutSheet();
    }


    public void SendMsg(string PaymentID)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select BOP.NetAmount,BOP.PaymentMode,BOp.PaymentDate,BOP.PayoutBetween,MR.Name,MR.Mobile from BBOPayment as BOP inner join MLM_Registration as MR on BOP.UserID = MR.UserID where BOP.PaymentID = '{0}'", PaymentID);
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        string Amount = null;
        string Paymentmode = null;
        string Payout = null;
        string Name = null;
        string Mobile = null;
        if (dt.Rows.Count>0)
        {
            Amount = dt.Rows[0]["NetAmount"].ToString();
            Paymentmode= dt.Rows[0]["PaymentMode"].ToString();
            Payout = dt.Rows[0]["PayoutBetween"].ToString();
            Name= dt.Rows[0]["Name"].ToString();
            Mobile= dt.Rows[0]["Mobile"].ToString();
        }
            
        string text = "Dear Enterpreneur '" + Name+"','"+ Amount+"' rupees of '"+Payout+"' payout has been transfered successfully.For Sales And Support :9873766366. http://boomlife.co.in/ Thank You. Regards BoomLife International.";

        try
        {

            string sURL;
            StreamReader objReader;

            sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=boomlife&password=boomlife123&sender=BOOMLF&to=" + Mobile + "&message=" + text + " &reqid=1&format={json|text}&route_id=7";

            //sURL = "http://203.129.225.69/API/WebSMS/Http/v1.0a/index.php?username=probuz&password=probuz#123&sender=" + senderusername + "" + "&to=" + mobile + "&message=" + txtmessage.Text + " &reqid=1&format={json|text}&route_id=7";
            WebRequest wrGETURL;
            wrGETURL = WebRequest.Create(sURL);

            try
            {
                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                objReader.Close();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Message Send Successfully')", true);

            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

}