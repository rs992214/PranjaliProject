﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Company_Requestepinshow : System.Web.UI.Page
{
    string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    DAL objDAL = new DAL();
    DAL dal = new DAL();
    string message = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        GetData();
        if (Session["UserID"] != null)
        {

        }
        else
        {
            //  Response.Redirect("Logout.aspx");
        }
    }

    string user;
    decimal amnt = 0;
    decimal CR = 0;
    decimal DR = 0;
    decimal amntindollar = 0;
    string Description = "UPGRADE WALLET";
    private void InsertUpgradeWalletLedger(int id)
    {
        string query = "select UserID,PakageName,Qty,Amount from [dbo].[RequestEPinGenertae] where Id=" + id + " ";
        SqlConnection con1 = new SqlConnection(connstring);
        SqlCommand cmd1 = new SqlCommand();
         cmd1.Connection = con1;
        cmd1.CommandText =query;
     //   cmd.CommandType = CommandType.Text;
        SqlDataAdapter da = new SqlDataAdapter(cmd1);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if(dt.Rows.Count>0)
        {
            user = dt.Rows[0]["UserID"].ToString();
            amnt = Convert.ToDecimal(dt.Rows[0]["Amount"]);
            amntindollar = Convert.ToDecimal(dt.Rows[0]["Qty"]);
        }
      
        con = new SqlConnection(connstring);
        con.Open();
        cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", user);
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", amntindollar);
        cmd.Parameters.AddWithValue("@DR", DR);
        cmd.Parameters.AddWithValue("@PayoutAmount", amntindollar);
        cmd.Parameters.AddWithValue("@NetAmount", amntindollar);
        cmd.Parameters.AddWithValue("@PaymentStatus", "Pending");
        cmd.Parameters.AddWithValue("@Descriptions", Description);
        cmd.Parameters.AddWithValue("@Mode", "Upgrade_Wallet");
        if(cmd.ExecuteNonQuery()>0)
        {

        }
        else
        {

        }
        con.Close();
    }
    private void GetData()
    {

        try
        {
            DAL objDAL = new DAL();
            DataTable dt = objDAL.Gettable("select Id,TransactionID,User_TransactionID,UserID,PakageName,Qty,Amount,Status,Date,Recipt from RequestEPinGenertae order by Date desc", ref message);
            if (dt.Rows.Count > 0)
            {
                GV_WithdrawalRequest_List.DataSource = dt;
                GV_WithdrawalRequest_List.DataBind();
            }
            else
            {
                GV_WithdrawalRequest_List.DataSource = null;
                GV_WithdrawalRequest_List.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }



    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void btnApproved_Click(object sender, EventArgs e)
    {
        //string user = "0";
        //string package = "0";
        //int qty = 0;
        //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
        //try
        //{
        //    con.Open();
        //    SqlCommand cmd;
        //    SqlCommand cmd1;
        //    DataTable dt = new DataTable();
        //    string query = "select UserID,PakageName,Qty from [dbo].[RequestEPinGenertae] where Id='" + e.CommandArgument + "'";
        //    cmd1 = new SqlCommand(query, con);
        //    SqlDataAdapter da = new SqlDataAdapter(cmd1);
        //    da.Fill(dt);
        //    if (dt.Rows.Count > 0)
        //    {

        //        user = dt.Rows[0]["UserID"].ToString();
        //        package = dt.Rows[0]["PakageName"].ToString();
        //        qty = Convert.ToInt32(dt.Rows[0]["Qty"]);
        //    }

        //    if (qty > 0)
        //    {
        //        int Count = 0;
        //        for (int i = 0; i < qty; i++)
        //        {
        //            //GetPinNo();

        //            cmd = new SqlCommand("PinGenerateNew_ALL", con);
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.AddWithValue("@UserID", user);
        //            cmd.Parameters.AddWithValue("@PackageID", package);
        //            cmd.Parameters.AddWithValue("@Status", "Unused");
        //            //cmd.Parameters.AddWithValue("@PinNo", lblPinNo.Text);
        //            cmd.Parameters.AddWithValue("@Mode", "IN2");
        //            int flag = cmd.ExecuteNonQuery();

        //            if (flag > 0)
        //            {
        //                Count = Count + flag;
        //                string msg = string.Empty;
        //                msg = "The Pin has been Approve Successfully.";
        //                var errormessage = new JavaScriptSerializer().Serialize(msg.ToString());
        //                var script = string.Format("alert({0});window.location='PinRequestAccept.aspx';", errormessage);
        //                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
        //                //ShowPopupMessage("The Pin has been Sale Successfully.", PopupMessageType.Success);
        //            }
        //            else
        //            {
        //                Count = Count + flag;
        //                ShowPopupMessage("You Have Insufficient Pin Qty for '" + package + "'", PopupMessageType.Error);
        //                //btnApproved.Enabled = false;
        //            }




        //            DAL dal = new DAL();
        //           // int id = Convert.ToInt32(e.CommandArgument.ToString());

        //            int index = dal.Executequery("UPDATE RequestEPinGenertae SET Status = 'APPROVED' WHERE ID = " + id, ref message);
        //            if (index > 0)
        //            {
        //                ShowPopupMessage("Request Approved Successfully.", PopupMessageType.Success);
        //                GetData();
        //            }
        //            else
        //            {
        //                ShowPopupMessage("Could Not Approved Request.", PopupMessageType.Warning);
        //                GetData();
        //            }
        //        }
        //    }
        //}

        //catch (Exception ex)
        //{
        //    ShowPopupMessage(ex.ToString(), PopupMessageType.Error);
        //}
    }

    protected void GV_WithdrawalRequest_List_PageIndexChanging1(object sender, GridViewPageEventArgs e)
    {
        GV_WithdrawalRequest_List.PageIndex = e.NewPageIndex;
        GetData();
    }

    protected void GV_WithdrawalRequest_List_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblStatus = e.Row.FindControl("lblStatus") as Label;
            LinkButton btnApproved = e.Row.FindControl("btnApproved") as LinkButton;
             LinkButton btnView = e.Row.FindControl("btnView") as LinkButton;
            if (lblStatus.Text == "Pending")
            {

                btnApproved.Enabled = true;
                  btnView.Enabled = true;
                btnApproved.BackColor = System.Drawing.Color.Red;
                //   btnApproved.CssClass = "btn btn-sm btn-blue";
            }
            else
            {
                       btnView.Enabled = false;
                     btnApproved.Enabled = false;
                btnApproved.BackColor = System.Drawing.Color.Green;
                //    btnApproved.CssClass = "btn btn-sm btn-blue disabled";
            }
        }
    }

    protected void GV_WithdrawalRequest_List_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_WithdrawalRequest_List.PageIndex = e.NewPageIndex;
        GetData();
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)(sender);
            int id = Convert.ToInt32(btn.CommandArgument);

            DataTable dt = dal.Gettable("Select ID,UserID,Status From RequestEPinGenertae Where ID='" + id + "'", ref message);
            if (dt.Rows.Count > 0)
            {
                txtId.Text = dt.Rows[0]["ID"].ToString();
                txtUserID.Text = dt.Rows[0]["UserID"].ToString();
                txtstatus.Text = dt.Rows[0]["Status"].ToString();
                //txtBankName.Text = dt.Rows[0]["BankName"].ToString();
                //txtBranch.Text = dt.Rows[0]["Branch"].ToString();
                //txtAccountType.Text = dt.Rows[0]["AccountType"].ToString();
                //txtIFSCCode.Text = dt.Rows[0]["IFSCCode"].ToString();
                //txtPANNO.Text = dt.Rows[0]["PANNO"].ToString();
            }

            ClientScript.RegisterStartupScript(this.GetType(), "Pop", "openModal();", true);

        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }  
    }
    public void clear()
    {
        txtdecrpitons.Text = "";
        txtstatus.Text = "";
        txtname.Text = "";
        txtUserID.Text = "";
        txtId.Text = "";
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(connstring);

        cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@Mode", "ChangeStatusReject1");
        cmd.Parameters.AddWithValue("@UserID", txtId.Text);
        cmd.Parameters.AddWithValue("@RejectDecriptions", txtdecrpitons.Text);
        cmd.Parameters.AddWithValue("@Status", "Reject");
        con.Open();
        int flag = cmd.ExecuteNonQuery();
        {
            con.Close();
           // ShowPopupMessage("Pin Rejected Successfully.", PopupMessageType.Success);
            GetData();
            //ShowPopupMessage("Pin Rejected Successfully.", PopupMessageType.Success);
            string msg = string.Empty;
            msg = "The Pin has been Rejected...";
            var errormessage = new JavaScriptSerializer().Serialize(msg.ToString());
            var script = string.Format("alert({0});window.location='Requestepinshow.aspx';", errormessage);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            clear();
        }
    }

    //protected void DownloadFile(object sender, EventArgs e)
    //{
    //    string filePath = (sender as LinkButton).CommandArgument;
    //    Response.ContentType = ContentType;
    //    Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
    //    Response.WriteFile(filePath);
    //    Response.End();
    //}


    protected void btnbtnimage_Click(object sender, EventArgs e)
    {
        string filePath = (sender as ImageButton).CommandArgument;
        Response.ContentType = ContentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
        Response.Redirect(filePath);
        //Response.WriteFile(filePath);
        //Response.End();
    }

    protected void btnApproved_Command(object sender, CommandEventArgs e)
    {
        //string user = "0";
        //string package = "0";
        //int qty = 0;
        //decimal amnt = 0;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CN"].ConnectionString);
        try
        {
            #region Unused Code
            //con.Open();
            //SqlCommand cmd;
            //SqlCommand cmd1;
            //SqlCommand cmd2;
            //DataTable dt = new DataTable();
            //string query = "select UserID,PakageName,Qty,Amount from [dbo].[RequestEPinGenertae] where Id='" + e.CommandArgument + "'";
            //cmd1 = new SqlCommand(query, con);
            //SqlDataAdapter da = new SqlDataAdapter(cmd1);
            //da.Fill(dt);
            //if (dt.Rows.Count > 0)
            //{
            //    user = dt.Rows[0]["UserID"].ToString();
            //    package = dt.Rows[0]["PakageName"].ToString();
            //    qty = Convert.ToInt32(dt.Rows[0]["Qty"]);
            //    amnt = Convert.ToDecimal(dt.Rows[0]["Amount"]);
            //}

            //DataTable dt1 = new DataTable();
            //string query1 = "select count(*) as qty from PinGenerateNew where Status='Unused' And PackageID='"+package+ "' And TransferTo Is null";
            //cmd2 = new SqlCommand(query1, con);
            //SqlDataAdapter da1 = new SqlDataAdapter(cmd2);
            //da1.Fill(dt1);
            //if (dt1.Rows.Count > 0)
            //{
            //  int pinqty = Convert.ToInt32(dt1.Rows[0]["qty"]);

            //    if (qty > 0 && qty <= pinqty)
            //    {
            //        int Count = 0;
            //        for (int i = 0; i < qty; i++)
            //        {
            //            //GetPinNo();

            //            cmd = new SqlCommand("PinGenerateNew_ALL", con);
            //            cmd.CommandType = CommandType.StoredProcedure;
            //            cmd.Parameters.AddWithValue("@UserID", user);
            //            cmd.Parameters.AddWithValue("@PackageID", package);
            //            cmd.Parameters.AddWithValue("@Status", "Unused");
            //            //cmd.Parameters.AddWithValue("@PinNo", lblPinNo.Text);
            //            cmd.Parameters.AddWithValue("@Mode", "IN2");
            //            int flag = cmd.ExecuteNonQuery();

            //            if (flag > 0)
            //            {
            //                Count = Count + flag;
            //                string msg = string.Empty;
            //                msg = "The Top-Up Amount has been Approve Successfully.";
            //                var errormessage = new JavaScriptSerializer().Serialize(msg.ToString());
            //                var script = string.Format("alert({0});window.location='Requestepinshow.aspx';", errormessage);
            //                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "", script, true);
            //                //ShowPopupMessage("The Pin has been Sale Successfully.", PopupMessageType.Success);
            //            }
            //            else
            //            {
            //                Count = Count + flag;
            //                ShowPopupMessage("You Have Insufficient Top-Up Amount for '" + package + "'", PopupMessageType.Error);
            //                //btnApproved.Enabled = false;
            //            }

            #endregion

            //  DAL dal1 = new DAL();
            int ID1 = Convert.ToInt32(e.CommandArgument.ToString());
            InsertUpgradeWalletLedger(ID1);

            DAL dal = new DAL();
            int id = Convert.ToInt32(e.CommandArgument.ToString());

            int index = dal.Executequery("UPDATE RequestEPinGenertae SET Status = 'APPROVED' WHERE ID = " + id, ref message);
            if (index > 0)
            {
                Response.Redirect("SuccessView.aspx?Link=Requestepinshow.aspx");
                // ShowPopupMessage("Request Approved Successfully.", PopupMessageType.Success);
                GetData();
            }
            else
            {
                ShowPopupMessage("Could Not Approved Request.", PopupMessageType.Warning);
                GetData();
            }
            //        }
            //    }
            //    else
            //    {
            //        ShowPopupMessage("You Have Insufficient Pin Qty...", PopupMessageType.Warning);
            //    }
            //}


        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.ToString(), PopupMessageType.Error);
        }
    }
}