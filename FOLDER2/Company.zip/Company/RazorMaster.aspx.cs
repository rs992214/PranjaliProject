﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.Web.Script.Serialization;

public partial class Company_RazorMaster : System.Web.UI.Page
{
    string message = string.Empty;
    DAL dal = new DAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetCreadential();
        }

    }


    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dtCheck = dal.Gettable("SELECT * FROM Razor_Credential_Master", ref message);
            if (dtCheck.Rows.Count > 0)
            {
                if (string.IsNullOrEmpty(txtTestKey.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Test Key')", true);
                }
                else if (string.IsNullOrEmpty(txtTestSecrete.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Test Secrete')", true);
                }
                else if (string.IsNullOrEmpty(txtTestAccount.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Test Account')", true);
                }
                else
                {
                    StringBuilder str = new StringBuilder();
                    str.AppendFormat("UPDATE [dbo].[Razor_Credential_Master] ");
                    str.AppendFormat("SET [Razor_Test_Key] = '" + txtTestKey.Text + "',[Razor_Test_Secrete] = '" + txtTestSecrete.Text + "',[Razor_Test_Account] = '" + txtTestAccount.Text + "',[Razor_Status] = '" + rdTest.SelectedValue.ToString() + "',[Updated_Date] = GETDATE()");
                    int index = dal.Executequery(str.ToString(), ref message);
                    if (index > 0)
                    {
                        GetCreadential();
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Test Credential Updated Successfully')", true);
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Could Not Update Test Credential')", true);
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(txtTestKey.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Test Key')", true);
                }
                else if (string.IsNullOrEmpty(txtTestSecrete.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Test Secrete')", true);
                }
                else if (string.IsNullOrEmpty(txtTestAccount.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Test Account')", true);
                }
                else
                {
                    StringBuilder str = new StringBuilder();
                    str.AppendFormat("INSERT INTO [dbo].[Razor_Credential_Master] ([Razor_Test_Key],[Razor_Test_Secrete],[Razor_Test_Account],[Razor_Status],[Created_Date]) ");
                    str.AppendFormat("VALUES ('" + txtTestKey.Text + "','" + txtTestSecrete.Text + "','" + txtTestAccount.Text + "','" + rdTest.SelectedValue.ToString() + "',GETDATE())");
                    int index = dal.Executequery(str.ToString(), ref message);
                    if (index > 0)
                    {
                        GetCreadential();
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Test Credential Added Successfully')", true);
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Could Not Add Test Credential')", true);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.ToString() + "')", true);
        }
    }

    protected void btnLive_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dtCheck = dal.Gettable("SELECT * FROM Razor_Credential_Master", ref message);
            if (dtCheck.Rows.Count > 0)
            {
                if (string.IsNullOrEmpty(txtLiveKey.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Live Key')", true);
                }
                else if (string.IsNullOrEmpty(txtLiveSecrete.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Live Secrete')", true);
                }
                else if (string.IsNullOrEmpty(txtLiveAccount.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Live Account')", true);
                }
                else
                {
                    StringBuilder str = new StringBuilder();
                    str.AppendFormat("UPDATE [dbo].[Razor_Credential_Master] ");
                    str.AppendFormat("SET [Razor_Live_Key] = '" + txtLiveKey.Text + "',[Razor_Live_Secrete] = '" + txtLiveSecrete.Text + "',[Razor_Live_Account] = '" + txtLiveAccount.Text + "',[Razor_Status] = '" + rdLiveStatus.SelectedValue.ToString() + "',[Updated_Date] = GETDATE()");
                    int index = dal.Executequery(str.ToString(), ref message);
                    if (index > 0)
                    {
                        GetCreadential();
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Live Credential Updated Successfully')", true);
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Could Not Update Live Credential')", true);
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(txtLiveKey.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Live Key')", true);
                }
                else if (string.IsNullOrEmpty(txtLiveSecrete.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Live Secrete')", true);
                }
                else if (string.IsNullOrEmpty(txtLiveAccount.Text))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Please Enter Live Account')", true);
                }
                else
                {
                    StringBuilder str = new StringBuilder();
                    str.AppendFormat("INSERT INTO [dbo].[Razor_Credential_Master] ([Razor_Live_Key],[Razor_Live_Secrete],[Razor_Live_Account],[Razor_Status],[Created_Date]) ");
                    str.AppendFormat("VALUES ('" + txtLiveKey.Text + "','" + txtLiveSecrete.Text + "','" + txtLiveAccount.Text + "','" + rdLiveStatus.SelectedValue.ToString() + "',GETDATE())");
                    int index = dal.Executequery(str.ToString(), ref message);
                    if (index > 0)
                    {
                        GetCreadential();
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Live Credential Added Successfully')", true);
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Could Not Add Live Credential')", true);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.ToString() + "')", true);
        }
    }

    public void GetCreadential()
    {
        try
        {
            DataTable dtCredential = dal.Gettable("SELECT * FROM Razor_Credential_Master", ref message);
            if (dtCredential.Rows.Count > 0)
            {
                txtTestKey.Text = dtCredential.Rows[0]["Razor_Test_Key"].ToString();
                txtTestSecrete.Text = dtCredential.Rows[0]["Razor_Test_Secrete"].ToString();
                txtTestAccount.Text = dtCredential.Rows[0]["Razor_Test_Account"].ToString();
                txtLiveKey.Text = dtCredential.Rows[0]["Razor_Live_Key"].ToString();
                txtLiveSecrete.Text = dtCredential.Rows[0]["Razor_Live_Secrete"].ToString();
                txtLiveAccount.Text = dtCredential.Rows[0]["Razor_Live_Account"].ToString();
                rdTest.Items.FindByValue(dtCredential.Rows[0]["Razor_Status"].ToString()).Selected = true;
                rdLiveStatus.Items.FindByValue(dtCredential.Rows[0]["Razor_Status"].ToString()).Selected = true;

                btnsave.Text = "UPDATE";
                btnLive.Text = "UPDATE";
            }
            else
            {
                btnsave.Text = "SAVE";
                btnLive.Text = "SAVE";
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.ToString() + "')", true);
        }
    }
}