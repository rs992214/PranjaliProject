﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using DataAccessLayer;
using System.Text;
using System.IO;
using System.Drawing;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;

public partial class company_verifieddonations : System.Web.UI.Page
{
    string cn = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;

    string message = string.Empty;
    DAL objDAL = new DAL();
    int index = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            GetData();

        }
    }
    private void GetData()
    {
        try
        {
           // string UserID = Session["UserID"].ToString();
            DataTable dt = new DataTable();
            if (!(string.IsNullOrEmpty(txtfromdate.Text) && string.IsNullOrEmpty(txttodate.Text)))
            {
                string[] dte = txtfromdate.Text.Split('/');
                string[] dte1 = txttodate.Text.Split('/');
                string joinstring = "/";
                DateTime fromdate = Convert.ToDateTime(dte[2] + joinstring + dte[1] + joinstring + dte[0]);
                DateTime todate = Convert.ToDateTime(dte1[2] + joinstring + dte1[1] + joinstring + dte1[0]);
                dt = objDAL.Gettable("select * from DonationNew where Status='Confirm'", ref message);
            }
            else
            {
                dt = objDAL.Gettable("select * from DonationNew where Amount='500' and sponsorid='top' and Status='Confirm'", ref message);
            }
            if (dt.Rows.Count > 0)
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
            else
            {
                GV_LedgerList.DataSource = dt;
                GV_LedgerList.DataBind();
            }
        }
        catch (Exception ex)
        {
            ShowPopupMessage(ex.Message, PopupMessageType.Error);
        }
    }

    protected void GV_LedgerList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GV_LedgerList.PageIndex = e.NewPageIndex;
        GetData();
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            GetData();
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnexportexcel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=DonationLink.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GV_LedgerList.AllowPaging = false;
                GetData();
                //GridView1.HeaderRow.Cells[0].Visible = false;
                //GridView1.HeaderRow.Cells[1].Visible = false;
                GV_LedgerList.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GV_LedgerList.HeaderRow.Cells)
                {
                    cell.BackColor = GV_LedgerList.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GV_LedgerList.Rows)
                {
                    //row.Cells[0].Visible = false;
                    //row.Cells[1].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GV_LedgerList.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GV_LedgerList.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GV_LedgerList.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }

    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Member/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here


    protected void btnUpdate_Command(object sender, CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        try
        {
            con = new SqlConnection(cn);
            cmd = new SqlCommand("Update DonationNew set status = 'Confirm', ConfirmDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "' where ID=" + id, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            //int i = 1;
            con.Close();
            if (i > 0)
            {
               // LedgerCredit();
               // LedgerDebit(id);
                Response.Write("<script>alert('Donation Verified Successfully.');window.location='DonationTrustAccept.aspx';</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
            //Note: Exception.Message returns a detailed message that describes the current exception. 
            //For security reasons, we do not recommend that you return Exception.Message to end users in 
            //production environments. It would be better to put a generic error message. 
        }
    }
    protected void GV_LedgerList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        index = Convert.ToInt32(e.CommandArgument);
    }
    protected void btnReject_Command(object sender, CommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        try
        {
            con = new SqlConnection(cn);
            cmd = new SqlCommand("Update DonationTrustNew set status = 'Pending', ConfirmDate='" + DateTime.Now.ToString("yyyy-MM-dd") + "', Image = 'images/warning.jpg' where ID=" + id, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                Response.Write("<script>alert('Receipt Rejected Successfully.');window.location='DonationTrustAccept.aspx';</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
            //Note: Exception.Message returns a detailed message that describes the current exception. 
            //For security reasons, we do not recommend that you return Exception.Message to end users in 
            //production environments. It would be better to put a generic error message. 
        }
    }

    private void LedgerCredit()
    {
        string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(connstring);
        con.Open();
        SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@UserID", "Main");
        cmd.Parameters.AddWithValue("@TransactionType", "CR");
        cmd.Parameters.AddWithValue("@CR", "200");
        cmd.Parameters.AddWithValue("@DR", "0.00");
        cmd.Parameters.AddWithValue("@Descriptions", "Trust Donation");
        cmd.Parameters.AddWithValue("@Mode", "IN");
        int flag = cmd.ExecuteNonQuery();

    }
    private void LedgerDebit(int uid)
    {
            DAL dal = new DAL();
            string userid = "";
            DataTable dtsp = dal.Gettable("select UserID from DonationTrustNew where id='" + uid + "'", ref message);
            if (dtsp.Rows.Count > 0)
            {
                userid = dtsp.Rows[0]["UserID"].ToString();
                string connstring = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
                SqlConnection con = new SqlConnection(connstring);
                con.Open();
                SqlCommand cmd = new SqlCommand("Ledger_Wallet_ALL", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserID", userid);
                cmd.Parameters.AddWithValue("@TransactionType", "DR");
                cmd.Parameters.AddWithValue("@CR", "0.00");
                cmd.Parameters.AddWithValue("@DR", "200");
                cmd.Parameters.AddWithValue("@Descriptions", "Trust Donation");
                cmd.Parameters.AddWithValue("@Mode", "IN");
                int flag = cmd.ExecuteNonQuery();
        }
        
    }
    
}