﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Text;
using System.Data;
using DataAccessLayer;

public partial class Company_MyTeam : System.Web.UI.Page
{
    string L = null, R = null;
    ArrayList UserIDList = new ArrayList();
    ArrayList UserIDRightList = new ArrayList();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //detail(Session["UserID"].ToString());
            detail("ZENFORCE");
            btnback.Visible = false;
        }
    }
    public void find(string UserID, out string Left, out string Right)
    {
        Left = null;
        Right = null;
        DAL dal = new DAL();
        string message = string.Empty;
        StringBuilder sb = new StringBuilder();
        sb.AppendFormat("select LLeg,RLeg from MLM_Registration where UserID='{0}'", UserID);
        DataTable dt = dal.Gettable(sb.ToString(), ref message);
        if (dt.Rows.Count > 0)
        {
            Left = dt.Rows[0]["LLeg"].ToString();
            Right = dt.Rows[0]["RLeg"].ToString();
        }
    }

    public DataTable fillUserDetail(string UserID)
    {
        try
        {
            DAL dal = new DAL();
            string message = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("select Name,JoinType,LLeg,RLeg,isnull(LJoining,0)as LJoining,isnull(TotalLJoin,0)as TotalLJoin,isnull(Rjoining,0)as Rjoining,isnull(TotalRJoin,0)as TotalRJoin,Status from MLM_Registration where  UserID='{0}'", UserID);
            DataTable dt = dal.Gettable(sb.ToString(), ref message);
            return dt;
        }
        catch (Exception)
        {

            throw;
        }

    }

    public void ClearLeftRight()
    {
        L = null;
        R = null;
    }
    public void detail(string UserID)
    {
        DAL dal = new DAL();
        string message = string.Empty;
        DataTable UserDetail = new DataTable();
        UserDetail = fillUserDetail(UserID);
        if (UserDetail.Rows.Count > 0)
        {
            Lb1.Text = UserID;
            lblname.Text = UserDetail.Rows[0]["Name"].ToString();
            lblljoin.Text = UserDetail.Rows[0]["LJoining"].ToString();
            lblTotalLJoin.Text = UserDetail.Rows[0]["TotalLJoin"].ToString();
            lblrjoin.Text = UserDetail.Rows[0]["Rjoining"].ToString();
            lblTotalRJoin.Text = UserDetail.Rows[0]["TotalRJoin"].ToString();
            string jointype = UserDetail.Rows[0]["JoinType"].ToString();
            string Status = UserDetail.Rows[0]["Status"].ToString();
            if (Status == "InActive")
            {
                i1.Src = "images/R.png";
            }
            if (jointype == "Paid")
            {
                i1.Src = "images/G.png";
            }
            else
            {
                i1.Src = "images/F.png";
            }
        }
        check();
        ClearLeftRight();
        find(Lb1.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb2L.Visible = true;
            Lb2L.Text = L;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", L);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);
            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i2.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i2.Src = "images/G.png";
                }
                else
                {
                    i2.Src = "images/F.png";
                }
            }
        }

        if (!string.IsNullOrEmpty(R))
        {
            Lb3R.Visible = true;
            Lb3R.Text = R;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", R);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);

            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i3.Src = "images/R.png";
                }
                if (UserJointype == "Paid")
                {
                    i3.Src = "images/G.png";
                }
                else
                {
                    i3.Src = "images/F.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb2L.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb4L.Visible = true;
            Lb4L.Text = L;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", L);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);

            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i4.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i4.Src = "images/G.png";
                }
                else
                {
                    i4.Src = "images/F.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb5R.Visible = true;
            Lb5R.Text = R;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", R);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);

            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i5.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i5.Src = "images/G.png";
                }
                else
                {
                    i5.Src = "images/F.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb4L.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb8L.Visible = true;
            Lb8L.Text = L;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", L);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);

            if (joindt.Rows.Count > 0)
            {

                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i8.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i8.Src = "images/G.png";
                }
                else
                {
                    i8.Src = "images/F.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb9R.Visible = true;
            Lb9R.Text = R;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", R);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);

            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i9.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i9.Src = "images/G.png";
                }
                else
                {
                    i9.Src = "images/F.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb5R.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb10L.Visible = true;
            Lb10L.Text = L;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", L);
            DataTable Joindt = dal.Gettable(JT.ToString(), ref message);
            if (Joindt.Rows.Count > 0)
            {
                string UserJointype = Joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = Joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i10.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i10.Src = "images/G.png";
                }
                else
                {
                    i10.Src = "images/F.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb11R.Visible = true;
            Lb11R.Text = R;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", R);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);
            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i11.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i11.Src = "images/G.png";
                }
                else
                {
                    i11.Src = "images/F.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb3R.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb6L.Visible = true;
            Lb6L.Text = L;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", L);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);
            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i6.Src = "images/R.png";
                }
                if (UserJointype == "Paid")
                {
                    i6.Src = "images/G.png";
                }
                else
                {
                    i6.Src = "images/F.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb7R.Visible = true;
            Lb7R.Text = R;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", R);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);
            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i7.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i7.Src = "images/G.png";
                }
                else
                {
                    i7.Src = "images/F.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb6L.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb12L.Visible = true;
            Lb12L.Text = L;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", L);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);
            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i12.Src = "images/R.Png";
                }
                else if (UserJointype == "Paid")
                {
                    i12.Src = "images/G.Png";
                }
                else
                {
                    i12.Src = "images/F.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb13R.Visible = true;
            Lb13R.Text = R;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", R);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);
            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i13.Src = "images/R.png";
                }
                else if (UserJointype == "Paid")
                {
                    i13.Src = "images/G.png";
                }
                else
                {
                    i13.Src = "images/F.png";
                }
            }
        }
        ClearLeftRight();
        find(Lb7R.Text, out L, out R);
        if (!string.IsNullOrEmpty(L))
        {
            Lb14L.Visible = true;
            Lb14L.Text = L;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", L);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);
            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i14.Src = "images/R.png";
                }
                if (UserJointype == "Paid")
                {
                    i14.Src = "images/G.png";
                }
                else
                {
                    i14.Src = "images/F.png";
                }
            }
        }
        if (!string.IsNullOrEmpty(R))
        {
            Lb15R.Visible = true;
            Lb15R.Text = R;
            StringBuilder JT = new StringBuilder();
            JT.AppendFormat("select JoinType,Status from MLM_Registration where UserID='{0}'", R);
            DataTable joindt = dal.Gettable(JT.ToString(), ref message);
            if (joindt.Rows.Count > 0)
            {
                string UserJointype = joindt.Rows[0]["JoinType"].ToString();
                string UserStatus = joindt.Rows[0]["Status"].ToString();
                if (UserStatus == "InActive")
                {
                    i15.Src = "images/R.png";
                }
                if (UserJointype == "Paid")
                {
                    i15.Src = "images/G.png";
                }
                else
                {
                    i15.Src = "images/F.png";
                }
            }
        }
    }

    public void check()
    {
        Lb2L.Text = "JoinNow";
        Lb3R.Text = "JoinNow";
        Lb4L.Text = "JoinNow";
        Lb5R.Text = "JoinNow";
        Lb6L.Text = "JoinNow";
        Lb7R.Text = "JoinNow";
        Lb8L.Text = "JoinNow";
        Lb9R.Text = "JoinNow";
        Lb10L.Text = "JoinNow";
        Lb11R.Text = "JoinNow";
        Lb12L.Text = "JoinNow";
        Lb13R.Text = "JoinNow";
        Lb14L.Text = "JoinNow";
        Lb15R.Text = "JoinNow";
        i2.Src = "images/B.png";
        i3.Src = "images/B.png";
        i4.Src = "images/B.png";
        i5.Src = "images/B.png";
        i6.Src = "images/B.png";
        i7.Src = "images/B.png";
        i8.Src = "images/B.png";
        i9.Src = "images/B.png";
        i10.Src = "images/B.png";
        i11.Src = "images/B.png";
        i12.Src = "images/B.png";
        i13.Src = "images/B.png";
        i14.Src = "images/B.png";
        i15.Src = "images/B.png";
    }


    protected void Lb2L_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb2L.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb2L.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb2L.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb2L.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb3R_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb3R.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb3R.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb3R.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb3R.Text);
            btnback.Visible = true;
        }
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        UserIDList = ((ArrayList)Session["tempBack"]);
        int count = UserIDList.Count - 1;
        if (count > 0)
        {
            string last = UserIDList[count - 1].ToString();
            UserIDList.Remove(last);
            Session["tempBack"] = UserIDList;
            detail(last);
        }
        else if (count == 0)
        {
            detail("ZENFORCE");
            Session["tempBack"] = null;
            btnback.Visible = false;
        }
    }

    protected void Lb4L_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb4L.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb4L.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb4L.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb4L.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb5R_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb5R.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb5R.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb5R.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb5R.Text);
            btnback.Visible = true;
        }

    }

    protected void Lb6L_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb6L.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb6L.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb6L.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb6L.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb7R_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb7R.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb7R.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb7R.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb7R.Text);
            btnback.Visible = true;
        }

    }

    protected void Lb8L_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb8L.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb8L.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb8L.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb8L.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb9R_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb9R.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb9R.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb9R.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb9R.Text);
            btnback.Visible = true;
        }

    }

    protected void Lb10L_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb10L.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb10L.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb10L.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb10L.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb11R_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb11R.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb11R.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb11R.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb11R.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb12L_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb12L.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb12L.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb12L.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb12L.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb13R_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb13R.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb13R.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb13R.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb13R.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb14L_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb14L.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb14L.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb14L.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb14L.Text);
            btnback.Visible = true;
        }
    }

    protected void Lb15R_Click(object sender, EventArgs e)
    {
        txtSearch.Text = string.Empty;
        if (Lb15R.Text == "Vacant")
        {
            return;
        }
        else
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(Lb15R.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(Lb15R.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(Lb15R.Text);
            btnback.Visible = true;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        DAL dal = new DAL();
        string message = string.Empty;

        DataTable dtLoginUser = dal.Gettable("Select DID From MLM_Registration Where UserID='TOP'", ref message);
        DataTable dtSearchUser = dal.Gettable("Select DID From MLM_Registration Where UserID='" + txtSearch.Text + "'", ref message);
        int LoginDID = Convert.ToInt32(dtLoginUser.Rows[0]["DID"]);
        int SearchDID = 0;
        if (dtSearchUser.Rows.Count > 0)
        {
            SearchDID = Convert.ToInt32(dtSearchUser.Rows[0]["DID"]);
        }
        else
        {
            SearchDID = 0;
        }

        if (SearchDID > LoginDID)
        {
            if (Session["tempBack"] != null)
            {
                UserIDList = ((ArrayList)Session["tempBack"]);
                UserIDList.Add(txtSearch.Text);
                Session["tempBack"] = UserIDList;
            }
            else
            {
                UserIDList.Add(txtSearch.Text);
                Session["tempBack"] = UserIDList;
            }
            detail(txtSearch.Text);
            btnback.Visible = true;
        }
        else
        {
            txtSearch.Text = string.Empty;
            ShowPopupMessage("You can not search upline UserID.", PopupMessageType.Message);
        }

    }







    // Modal PopUp Code Goes here
    private void ShowPopupMessage(string message, PopupMessageType messageType)
    {
        switch (messageType)
        {
            case PopupMessageType.Error:
                lblMessagePopupHeading.Text = "Error";
                //Render image in literal control
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/error_icon.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Message:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/information-symbol.png") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Warning:
                lblMessagePopupHeading.Text = "Warning";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/warning.jpg") + "' alt='' height=20px width=22px />";
                break;
            case PopupMessageType.Success:
                lblMessagePopupHeading.Text = "Success";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("~/Company/images/success.png") + "' alt='' height=20px width=22px />";
                break;
            default:
                lblMessagePopupHeading.Text = "Information";
                ltrMessagePopupImage.Text = "<img src='" +
                  Page.ResolveUrl("/images/imgInformation.png") + "' alt='' height=20px width=22px />";
                break;
        }

        lblMessagePopupText.Text = message;
        mpeMessagePopup.Show();
    }

    /// <summary>
    /// Message type enum
    /// </summary>
    public enum PopupMessageType
    {
        Error,
        Message,
        Warning,
        Success
    }
    // Modal PopUp Code end here




}