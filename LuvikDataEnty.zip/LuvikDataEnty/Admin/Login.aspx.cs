﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Login : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
        //Session["Custom_Id"] = txtcustomerid.Text;
    }

    void clear()
    {
        txtuserid.Text = string.Empty; txtpassword.Text = string.Empty; txtuserid.Focus();
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        try
        {
            cmd.CommandText = ("Select Username,Password from Admin_Login where Username =@Custm_id and Password=@Password");
            con.Open();
            cmd.Parameters.AddWithValue("@Custm_id", txtuserid.Text);
            cmd.Parameters.AddWithValue("@Password", txtpassword.Text);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                Response.Write("<script>alert('Login Successfull......')</script>");
                Session["Username"] = txtuserid.Text;
                Response.Redirect("Dashboard.aspx");
            }
            else
            {
                Response.Write("<script>alert('Failed......')</script>");
            }
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            clear();
        }
    }
}