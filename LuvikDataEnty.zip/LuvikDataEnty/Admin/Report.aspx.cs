﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Report : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter adapt;
    DataTable dt;
    string status;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
        adapt = new SqlDataAdapter(cmd);
        if (Session["Username"] == null)
        {
            Response.Redirect("Logout.aspx", true);
        }              
    }
    void clear()
    {
        txtCustomerid.Text = string.Empty; txtfrom.Text = string.Empty; txtto.Text = string.Empty;
        txtCustomerid.Focus();
    }
    protected void ShowData()
    {
        try
        {            
            //adapt = new SqlDataAdapter("[dbo].[Compare_2_Table]", con);
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(txtfrom.Text).ToString("yyyy-MM-dd"));
            //cmd.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(txtto.Text).ToString("yyyy-MM-dd"));
            //cmd.Parameters.AddWithValue("@Customer_Id", txtCustomerid.Text.Trim());
            //adapt = new SqlDataAdapter(cmd);
            //dt = new DataTable();
            //adapt.Fill(dt);

            SqlConnection con = new SqlConnection(cnfg);
            SqlCommand cmd = new SqlCommand("Compare_2_Table", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(txtfrom.Text).ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(txtto.Text).ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@Customer_Id", txtCustomerid.Text.Trim());
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            con.Close();
            int total = dt.AsEnumerable().Sum(row => row.Field<int>("FormError"));
            GridView1.FooterRow.Cells[8].Text = "Total Error Form";
            GridView1.FooterRow.Cells[8].Font.Bold = true;
            GridView1.FooterRow.Cells[16].HorizontalAlign = HorizontalAlign.Center;
            GridView1.FooterRow.Cells[16].Text = total.ToString("N2");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            clear();
        }      
    } 
    protected void btnreport_Click(object sender, EventArgs e)
    {
        ShowData();
    }

    protected void btnexport_Click(object sender, EventArgs e)
    {
        Response.ClearContent();
        Response.Buffer = true;
        Response.ClearHeaders();
        Response.Charset = "";
        Response.AppendHeader("content-disposition", "attachment; filename=Report.xls");
        Response.ContentType = "application/excel";
        System.IO.StringWriter stringWriter = new System.IO.StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(stringWriter);
        GridView1.GridLines = GridLines.Both;
        GridView1.HeaderStyle.Font.Bold = true;
        GridView1.HeaderRow.Style.Add("background-color", "#FFFFFF");
        foreach (TableCell tableCell in GridView1.HeaderRow.Cells)
        {
            tableCell.Style["background-color"] = "#A55129";
        }
        foreach (GridViewRow gridViewRow in GridView1.Rows)
        {
            gridViewRow.BackColor = System.Drawing.Color.White;
            foreach (TableCell gridViewRowTableCell in gridViewRow.Cells)
            {
                gridViewRowTableCell.Style["background-color"] = "#FFF7E7";
            }
        }

        GridView1.RenderControl(htw);
        Response.Write(stringWriter.ToString());
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.End();
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //required to avoid the run time error "  
        //Control 'GridView1' of type 'Grid View' must be placed inside a form tag with runat=server."  
    }
}