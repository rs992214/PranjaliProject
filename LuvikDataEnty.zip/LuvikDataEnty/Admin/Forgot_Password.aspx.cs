﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Forgot_Password : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
    }

    void clear()
    {
         txtemail.Text = string.Empty; txtpass.Text = string.Empty;
        txtemail.Focus();
    }
    protected void btnresetpass_Click(object sender, EventArgs e)
    {
        try
        {
            cmd.CommandText = ("Update Customer_Registration set Password=@Password where Email='"+txtemail.Text+"' ");
            con.Open();
            //cmd.Parameters.AddWithValue("@email", txtemail.Text);
            cmd.Parameters.AddWithValue("@Password", txtpass.Text);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Password Updated Successfully......')</script>");              
            }
            else
            {
                Response.Write("<script>alert(' Failed..!!')</script>");
            }            
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
             clear();
        }
    }
}