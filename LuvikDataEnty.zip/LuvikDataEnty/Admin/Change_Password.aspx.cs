﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Change_Password : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter adapt;
    DataTable dt;
    SqlDataReader dr;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
        if (Session["Username"] == null)
        {
            Response.Redirect("Logout.aspx", true);
        }

    }

    void clear()
    {
        txtuserid.Text = string.Empty; txtnewpass.Text = string.Empty;
        txtuserid.Focus();
    }
    protected void btnChangePass_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "Admin")
        {
            cmd.CommandText = ("Update Admin_Login Set Password=@Password where Username=@userid ");
            con.Open();
            cmd.Parameters.AddWithValue("@userid", txtuserid.Text.Trim());
            cmd.Parameters.AddWithValue("@Password", txtnewpass.Text.Trim());
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Password Updated Successfully......')</script>");
                //DropDownList1.Items.FindByText("--Select--").selected = true;
               
                clear();
                DropDownList1.SelectedIndex = DropDownList1.Items.IndexOf(DropDownList1.Items.FindByText("--Select--"));
            }
            else
            {
                Response.Write("<script>alert(' Failed..!!')</script>");
            }
            con.Close();
        }
        if (DropDownList1.SelectedItem.Text == "User")
        {
            cmd.CommandText = ("Update Customer_Registration Set Password=@Password,Conform_Password=@Password where Customer_Id=@userid ");
            con.Open();
            cmd.Parameters.AddWithValue("@userid", txtuserid.Text.Trim());
            cmd.Parameters.AddWithValue("@Password", txtnewpass.Text.Trim());
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Password Updated Successfully......')</script>");
                clear();
                DropDownList1.SelectedIndex = DropDownList1.Items.IndexOf(DropDownList1.Items.FindByText("--Select--"));
            }
            else
            {
                Response.Write("<script>alert(' Failed..!!')</script>");
            }
            con.Close();
        }
    }
}