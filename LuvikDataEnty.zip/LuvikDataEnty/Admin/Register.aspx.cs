﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Register : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
        if (!IsPostBack)
        {
            txtcustomerid.Text = "LK" + GetUniqueKey(6);
        }
    }

    public string GetUniqueKey(int maxSize)
    {
        char[] chars = new char[62];
        chars = "123456789".ToCharArray();

        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[maxSize];
        crypto.GetNonZeroBytes(data);
        System.Text.StringBuilder result = new System.Text.StringBuilder(maxSize);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }
        return result.ToString();
    }

    void clear()
    {
        txtcustomerid.Text = string.Empty; txtemail.Text = string.Empty; txtpass.Text = string.Empty;
        txtpassagain.Text = string.Empty; txtpass.Text = string.Empty; txtcustomerid.Focus();
    }

    public void SendEmail()
    {
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.mycontrolbox.in";
        smtp.Port = 587;
        smtp.UseDefaultCredentials = true;
        smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
        smtp.Credentials = new System.Net.NetworkCredential("no_reply@mycontrolbox.in", "tk%zazU4");
        smtp.EnableSsl = false;
        MailMessage msg = new MailMessage();
        msg.Subject = "Hello " + txtcustomerid.Text + "  Thanks for Register ";
        msg.Body = "Hi, Thanks For Your Registration at our site , Your Password is " + txtpass.Text + ". Thanks";
        string toaddress = txtemail.Text;
        msg.To.Add(toaddress);
        string fromaddress = "<no_reply@mycontrolbox.in>";
        msg.From = new MailAddress(fromaddress);
        try
        {
            // msg.To.Add(new MailAddress("txtEmail.Text"));
            smtp.Send(msg);
            lblemail.Text = "Email Send Successfully";           
           // txtemail.Text = "";
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "')</script>");
            //throw;
        }
    }

    //public void SendSMS()
    //{
    //    string Username = "SAURABH";
    //    string APIKey = "B3AF5-7737D";
    //    string SenderName = "PROREG";
    //    string Number = txtmobno.Text;
    //    string Route = "TRANS";
    //    string Format = "JSON";
    //    string TemplateID = "1707161744326123203";
    //    string Message = "Congratulations, Dear User Your Account Has Been Created Successfully.Your CustomerID is "+txtcustomerid.Text+" ";

    //    string URL = "http://sms.probuztech.com/sms-panel/api/http/index.php?username=" + Username + "&apikey=" + APIKey + "&apirequest=Text&sender=" + SenderName + "&mobile=" + Number + "&message=" + Message + "&route=" + Route + "&TemplateID=" + TemplateID + "&format=" + Format + "";

    //    HttpWebRequest req = (HttpWebRequest)WebRequest.Create(URL);
    //    HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
    //    StreamReader sr = new StreamReader(resp.GetResponseStream());
    //    try
    //    {
    //        string results = sr.ReadToEnd();
    //        //lblmobno.Text = "SMS Sent to " + Number + " Successfully";
    //        lblmobno.Text = "SMS Sent Successfully";
    //        sr.Close();

    //    }
    //    catch (Exception ex)
    //    {
    //        Response.Write("<script>alert('" + ex.Message + "')</script>");
    //    }
    //}

    protected void btnregister_Click(object sender, EventArgs e)
    {
        try
        {
            cmd.CommandText = "Insert into Customer_Registration(Customer_Id,Email,Password,Conform_Password) values (@Customer_Id,@Email,@Password,@Conform_Pass)";
            con.Open();
            cmd.Parameters.AddWithValue("@Customer_Id", txtcustomerid.Text);
            cmd.Parameters.AddWithValue("@Email", txtemail.Text);
            cmd.Parameters.AddWithValue("@Password", txtpass.Text);
            cmd.Parameters.AddWithValue("@Conform_Pass", txtpassagain.Text);
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert(' Account Created Successfuly..!!')</script>");
                SendEmail();
                //SendSMS();
                Session["email"] = txtemail.ToString();            
                Session["custumerID"] = txtcustomerid.ToString();
                //Response.Redirect("Login.aspx");
            }
            else
            {
                Response.Write("<script>alert(' Failed..!!')</script>");
            }
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            clear();
        }

    }
}