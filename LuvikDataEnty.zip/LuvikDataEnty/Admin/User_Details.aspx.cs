﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_User_Details : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter adapt;
    DataTable dt;
    string status;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
        if (Session["Username"] == null)
        {
            Response.Redirect("Logout.aspx", true);
        }
        else
        {
            if (!IsPostBack)
            {
                ShowData();
            }
        }
        //if (!IsPostBack)
        //{
        //    ShowData();
        //}
    }
    protected void ShowData()
    {        
        string status = rbstatus.SelectedItem.Value;    
         // string id = Session["Username"].ToString();             
        adapt = new SqlDataAdapter("Select * from Customer_Registration where Status='"+status+"' ", con);
        // cmd.Parameters.AddWithValue("@status", status);
        dt = new DataTable();
        adapt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
           
        }
        else
        {
           
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        con.Close();
    }

    protected void btnactive_Command(object sender, CommandEventArgs e)
    {
        string id = Convert.ToString(e.CommandArgument);      
        cmd.CommandText = " Update Customer_Registration  set Status='Active',TransactionDate=GETDATE() where Customer_Id='"+id+"' ";
        con.Open();              
        if (cmd.ExecuteNonQuery() > 0)
        {
            Response.Write("<script>alert('Your Account Activated........')</script>");
            ShowData();
        }
        else
        {
            Response.Write("<script>alert('Failed...........')</script>");
        }
        con.Close();
    }

    protected void rbstatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string status = rbstatus.SelectedItem.Value;
        //if (status == "Active")
        //{
        //    this.ShowData();
        //    Button btnstatus = (Button)e.NewSelectedIndex.FindControl("btnactive");
        //    btnactive.Visible = false;
        //}
        //else
        //{
        //    this.ShowData();
        //}
        this.ShowData();
    }
}