﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_My_Entries : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter adapt;
    DataTable dt;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
        if (Session["Custom_Id"] == null)
        {
            Response.Redirect("Logout.aspx", true);
        }
        else
        {
            if (!IsPostBack)
            {
                ShowData();
            }
        }

    }
    protected void ShowData()
    {
        string id = Session["Custom_Id"].ToString();
        dt = new DataTable();
        con.Open();
        adapt = new SqlDataAdapter("Select * from Form_Entry where Customer_Id='" + id + "' ORDER BY Customer_SrNo DESC ", con);
        adapt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        else
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        con.Close();
    }


    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        { 
            string id = Session["Custom_Id"].ToString();
            cmd.CommandText = "Select * from Form_Entry where Date between '" + txtfrom.Text + "' And '" + txtto.Text + "' And Customer_Id='" + id + "'";
            //ShowData();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void btnexport_Click(object sender, EventArgs e)
    {       
            Response.ClearContent();
            Response.AppendHeader("content-disposition", "attachment; filename=GridViewToExcel.xls");
            Response.ContentType = "application/excel";
            System.IO.StringWriter stringWriter = new System.IO.StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(stringWriter);
            GridView1.HeaderRow.Style.Add("background-color", "#FFFFFF");
            foreach (TableCell tableCell in GridView1.HeaderRow.Cells)
            {
                tableCell.Style["background-color"] = "#A55129";
            }
            foreach (GridViewRow gridViewRow in GridView1.Rows)
            {
                gridViewRow.BackColor = System.Drawing.Color.White;
                foreach (TableCell gridViewRowTableCell in gridViewRow.Cells)
                {
                    gridViewRowTableCell.Style["background-color"] = "#FFF7E7";
                }
            }

            GridView1.RenderControl(htw);
            Response.Write(stringWriter.ToString());
            Response.End();        
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //required to avoid the run time error "  
        //Control 'GridView1' of type 'Grid View' must be placed inside a form tag with runat=server."  
    }
}