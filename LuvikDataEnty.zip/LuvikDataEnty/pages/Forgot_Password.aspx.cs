﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Forgot_Password : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string password;
    string Email;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
    }

    void clear()
    {
         txtuserid.Text = string.Empty; 
        txtuserid.Focus();
    }
    //public void SendEmail()
    //{
    //    SmtpClient smtp = new SmtpClient();
    //    smtp.Host = "smtp.mycontrolbox.in";
    //    smtp.Port = 587;
    //    smtp.UseDefaultCredentials = true;
    //    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
    //    smtp.Credentials = new System.Net.NetworkCredential("no_reply@mycontrolbox.in", "tk%zazU4");
    //    smtp.EnableSsl = false;
    //    MailMessage msg = new MailMessage();
    //    msg.Subject = "Hello " + txtuserid.Text + "  ";
    //    msg.Body = " Your Password is " + password + ". Thanks";
    //    string toaddress = "  Email  ";
    //    msg.To.Add(toaddress);
    //    string fromaddress = "<no_reply@mycontrolbox.in>";
    //    msg.From = new MailAddress(fromaddress);
    //    try
    //    {
    //        msg.To.Add(new MailAddress("Email"));
    //        smtp.Send(msg);
    //        lblemail.Text = "Email Send Successfully";
    //        // txtemail.Text = "";
    //    }
    //    catch (Exception ex)
    //    {
    //        Response.Write("<script>alert('" + ex.Message + "')</script>");
    //        //throw;
    //    }
    //}
    protected void btnresetpass_Click(object sender, EventArgs e)
    {
        try
        {
            cmd.CommandText = "Select * from Customer_Registration where Customer_Id='" + txtuserid.Text + "'";
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                string Email = dt.Rows[0]["Email"].ToString();
                string password = dt.Rows[0]["Password"].ToString();

                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.mycontrolbox.in";
                smtp.Port = 587;
                smtp.UseDefaultCredentials = true;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Credentials = new System.Net.NetworkCredential("no_reply@mycontrolbox.in", "tk%zazU4");
                smtp.EnableSsl = false;
                MailMessage msg = new MailMessage();
                msg.Subject = "Hello " + txtuserid.Text + "  ";
                msg.Body = " Your Password is " + password + ". Thanks";
                string toaddress = Email;
                msg.To.Add(toaddress);
                string fromaddress = "<no_reply@mycontrolbox.in>";
                msg.From = new MailAddress(fromaddress);
                try
                {
                    // msg.To.Add(new MailAddress("Email"));
                    smtp.Send(msg);
                    lblemail.Text = "Email Send Successfully";
                    // txtemail.Text = "";
                }
                catch (Exception ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "')</script>");
                    //throw;
                }
            }
            else
            {
                Response.Write("Invalid User ID");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            clear();
        }

    }
       
}