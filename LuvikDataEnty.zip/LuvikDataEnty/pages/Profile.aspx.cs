﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Profile : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
        if (Session["Custom_Id"] == null)
        {
            Response.Redirect("Logout.aspx", true);
        }
        else
        {
            if (!IsPostBack)
            {
                ShowData();
            }
        }               
    }

    protected void ShowData()
    {
        try
        {
            cmd.CommandText = "Select * from Customer_Registration where Customer_Id='" + Session["Custom_Id"] + "'";
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtfullname.Text = dr["FullName"].ToString();
                txtmobile1.Text = dr["MobileNo_1"].ToString();
                txtmobile2.Text = dr["MobileNo_2"].ToString();
                txtemail.Text = dr["Email"].ToString();
                //ddlgender.SelectedItem.Text= dr["Gender"].ToString();
                txtgender.Text = dr["Gender"].ToString();
                txtaddress.Text = dr["Address"].ToString();
                txtpincode.Text = dr["Pincode"].ToString();
                //txtRegistration_Date.Text = Convert.ToDateTime(Reader["Registration_Date"]).ToString("dd/MM/yyyy");
                txtdob.Text = Convert.ToDateTime(dr["DateOfBirth"]).ToString("yyyy/MM/dd") ;
                //txtdob.Text = Convert.ToDateTime(dr["DateOfBirth"]).ToShortDateString();
            }
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
        }
        
    }

    void clear()
    {
        txtfullname.Text = string.Empty; txtmobile1.Text = string.Empty; txtmobile2.Text = string.Empty; txtemail.Text = string.Empty;
        txtaddress.Text = string.Empty; txtpincode.Text = string.Empty; txtdob.Text = string.Empty;//ddlgender.SelectedItem.Text = string.Empty;
        txtgender.Text = string.Empty; txtfullname.Focus();
    }
    
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        try
        {
            string userid = Session["Custom_Id"].ToString();
            cmd.CommandText = ("Update Customer_Registration Set FullName=@name,MobileNo_1=@mob1,MobileNo_2=@mob2,Gender=@gender,Email=@email,Address=@address,Pincode=@pincode,DateOfBirth=@dob where Customer_Id='" + userid + "' ");
            con.Open();
            cmd.Parameters.AddWithValue("@name", txtfullname.Text);
            cmd.Parameters.AddWithValue("@mob1", txtmobile1.Text);
            cmd.Parameters.AddWithValue("@mob2", txtmobile2.Text);            
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            //cmd.Parameters.AddWithValue("@gender", ddlgender.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@gender", txtgender.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpincode.Text);
            cmd.Parameters.AddWithValue("@dob", txtdob.Text);
            
            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Profile Updated Successfully......')</script>");
            }
            else
            {
                Response.Write("<script>alert(' Failed..!!')</script>");
            }
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            clear();
        }
    }
}