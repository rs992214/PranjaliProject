﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Login : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
        //Session["Custom_Id"] = txtcustomerid.Text;
    }

    void clear()
    {
        txtcustomerid.Text = string.Empty; txtpassword.Text = string.Empty; txtcustomerid.Focus();
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        try
        {           
            cmd.CommandText=("Select * from Customer_Registration where Customer_Id =@Custm_id and Password=@Password and Status='Active'");
            con.Open();
            cmd.Parameters.AddWithValue("@Custm_id", txtcustomerid.Text);
            cmd.Parameters.AddWithValue("@Password", txtpassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["Custom_Id"] = txtcustomerid.Text;
                Session["name"] = dt.Rows[0]["FullName"].ToString();                             
                Response.Write("<script>alert('Login successfully..')</script>");
                Response.Redirect("Dashboard.aspx");
            }            
            else
            {
                Response.Write("<script>alert('Your Account is Inactive . Contact Admin')</script>");
            }
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            clear();
        }      
    }
}