﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Change_Password : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string password;
    string Email;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;
       
        if (Session["Custom_Id"] == null)
        {
            Response.Redirect("Logout.aspx", true);
        }
        else
        {
            txtuserid.Text = Session["Custom_Id"].ToString();
            txtuserid.ReadOnly = true;
        }
    }

    void clear()
    {
        txtuserid.Text = string.Empty; txtnewpass.Text = string.Empty;
        txtuserid.Focus();
    }
    protected void btnChangePass_Click(object sender, EventArgs e)
    {
        try
        { 
            string id = Session["Custom_Id"].ToString();
            txtuserid.ReadOnly = true;
            //string textbox = txtuserid.Text.ReadOnly ;                     
                cmd.CommandText = ("Update Customer_Registration Set Password=@Password,Conform_Password=@Password where Customer_Id='" + id + "' ");
                con.Open();
                cmd.Parameters.AddWithValue("@Password", txtnewpass.Text);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    Response.Write("<script>alert('Password Updated Successfully......')</script>");
                }
                else
                {
                    Response.Write("<script>alert(' Failed..!!')</script>");
                }
                con.Close();            
        }
        catch(Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
        }
    }    
}
