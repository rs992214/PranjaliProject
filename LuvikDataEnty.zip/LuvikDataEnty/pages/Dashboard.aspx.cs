﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_Dashboard : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;   
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;

        if (Session["Custom_Id"] == null)
        {
            Response.Redirect("Logout.aspx", true);
        }
        if(Session["name"] == null)
        {
            lblusername.Text = "Welcome ";
        }
        else
        {
            lblusername.Text = "Welcome " + Session["name"].ToString();
            if (!IsPostBack)
            {
                MyEntry();
            }
        }
    }
    protected void MyEntry()
    {
        string id = Session["Custom_Id"].ToString();
        string Newconn = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
        SqlConnection con = new SqlConnection(Newconn);
        SqlCommand cmd = new SqlCommand("Select * from Form_Entry where Customer_Id='" + id + "'  ", con);
        //cmd.CommandText = ("Select * from Form_Entry where Customer_Id='" + id + "'");
        con.Open();
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lblmyentry.Text = dt.Rows.Count.ToString();
        }
        else
        {
            lblmyentry.Text = dt.Rows.Count.ToString();
            //Response.Write("No Entry Fill");
        }                
        con.Close();       
    }
}