﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pages_New_Entry : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    string cnfg = ConfigurationManager.ConnectionStrings["CN"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection(cnfg);
        cmd = new SqlCommand();
        cmd.Connection = con;       
        if (Session["Custom_Id"] == null)
        {
            Response.Redirect("Logout.aspx",true);
        }     
    }

    void clear()
    {
        txtuserid.Text = string.Empty; txtserialno.Text = string.Empty; txtfullname.Text = string.Empty; txtmobile1.Text = string.Empty; txtmobile2.Text = string.Empty;
        txtmobile3.Text = string.Empty; txtgender.Text = string.Empty; txtemail.Text = string.Empty; txtdob.Text = string.Empty; txtaddress.Text = string.Empty;
        txtcompanyname.Text = string.Empty; txtdesignation.Text = string.Empty; txtpincode.Text = string.Empty; txtuserid.Focus();
    }
   

    protected void btnsubmit_Click1(object sender, EventArgs e)
    {
        try
        {
            string id = Session["Custom_Id"].ToString();
            //SqlCommand cmd = new SqlCommand( "Insert Into Form_Entry(Username,[Sr.No],Name,Mob_No_1,Mob_No_2,Mob_No_3,Gender,Email,DateOfBirth,Address,Company_Name,Designation,Pincode,Date,Customer_Id) " +
            //    "values (@username,@srno,@name,@mob1,@mob2,@mob3,@gender,@email,@dob,@address,@company,@designation,@pincode,getdate(),@customId)",con);

            cmd.CommandText = "Insert Into Form_Entry(Username,[Sr.No],Name,Mob_No_1,Mob_No_2,Mob_No_3,Gender,Email,DateOfBirth,Address,Company_Name,Designation,Pincode,Date,Customer_Id) " +
                "values(@username, @srno, @name, @mob1, @mob2, @mob3, @gender, @email, @dob, @address, @company, @designation, @pincode, getdate(), @customId) ";

            //Response.Write(txtuserid.Text);

            cmd.Parameters.AddWithValue("@username", txtuserid.Text);
            cmd.Parameters.AddWithValue("@srno", txtserialno.Text);
            cmd.Parameters.AddWithValue("@name", txtfullname.Text);
            cmd.Parameters.AddWithValue("@mob1", txtmobile1.Text);
            cmd.Parameters.AddWithValue("@mob2", txtmobile2.Text);
            cmd.Parameters.AddWithValue("@mob3", txtmobile3.Text);
            cmd.Parameters.AddWithValue("@gender", txtgender.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            cmd.Parameters.AddWithValue("@dob", txtdob.Text);
            cmd.Parameters.AddWithValue("@address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@company", txtcompanyname.Text);
            cmd.Parameters.AddWithValue("@designation", txtdesignation.Text);
            cmd.Parameters.AddWithValue("@pincode", txtpincode.Text);
            cmd.Parameters.AddWithValue("@customId", id);

            con.Open();

            if (cmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('Record Insert Successfully...!')</script>");
            }
            else
            {
                Response.Write("<script>alert('Failed...!')</script>");
            }
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
             con.Close();
             clear();
        }
    }
}